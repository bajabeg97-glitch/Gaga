# Baja Music — Korg Pa800 FULL bundle

Kompletni, spremni paket sa **obje** Pa800 aplikacije + svi dokazi +
reference + demo izlaz. Jedina stvar koja se instalira prije pokretanja je
`install.bat` (kreira lokalni `.venv` s `numpy` i `pytest`).

---

## Struktura paketa

```
pa800_full_app/
├── install.bat             ← pokreni prvi put (admin nije potreban)
├── run.bat                 ← meni svih aplikacija
├── run_engine.bat          ← PA800 Engine: CLI sinteza MAX DEMO pjesme
├── run_engine_gui.bat      ← PA800 Engine: GUI studio (Tkinter)
├── run_tests.bat           ← kompletan test suite (oba paketa)
├── run_midi_app.bat        ← Baja MIDI Studio (CLI)
├── run_midi_gui.bat        ← Baja MIDI Studio (GUI, Tkinter)
│
├── pa800_engine/           ← glavni PA800 Engine (sinteza):
│   ├── engine.py, demo.py, gui.py, sources.py,
│   ├── clock.py, events.py, constants.py,
│   ├── songprepare/        (Song Prepare Modul: analyzer + scheduler + report)
│   ├── articulation/       (RX/DNC Articulation & Noise Engine: profiles,
│   │                        catalog, pravila, audit engine)
│   ├── voice/              (Voice pool: channel state, izvori, glas, allocator)
│   ├── dsp/                (ovojnice: AHDSR + gate; mixer: soft clip)
│   ├── data/               (4 dokazna JSON-a iz evidence baze — vidi ispod)
│   ├── tests/              (51 test, pytest)
│   └── README.md           (kompletna dokumentacija paketa)
│
├── pa800_midi_app/         ← baja_pa_manager aplikacija + alati:
│   ├── baja_pa_manager/    (core, midi, gui, sound, style, adapters,
│   │                        performance, set_manager, native, bkp)
│   ├── main.py             (CLI entry — dodano: `pipeline` komanda = KONAČNA LOGIKA
│   │                       19-step factory corpus pipeline: corpus → krive/range →
│   │                       controller + velocity reset → apply → sound change (engine
│   │                       trigger) → validate → output. Ciljevi: BASS→Picked Bass RX,
│   │                       GUITAR→Clean Guitar RX1. NRPN se nikad ne generira.)
│   ├── tools/              (demo PCG/MIDI generatori)
│   ├── tests/              (51 test, pytest)
│   └── requirements.txt
│
├── docs/                   ← reference i izvori:
│   ├── MASTER_SOURCE_ALL_MODULES.md        (glavni arhitektonski izvor, 1276 linija)
│   ├── PA800_REVERSE_CHECKPOINT_README_STATUS.md
│   ├── RESOURCE_INDEX_BANK01_DECOMP.txt    (resursni indeks BANK01)
│   ├── knowledge/          ← MASTER dosje 2026-09-22 (PDF 335 str + extract +
│   │                         INDEX + izdvojene sekcije: drum kit, velocity zone,
│   │                         NTT/NTR, FX, PRF)
│   ├── factory_corpus/     ← 54 onboard PA800 demo SMF-a (authority:
│   │                         ORIGINAL_PA800_PKG_OC20_DECODE, EXACT_DECODED
│   │                         SMI iz Pa800_os_res_v202.pkg, sa manifest sha256)
│   └── SCRIPTS/            (checkpoint skripte za reprodukciju evidencije)
│
├── evidence/               ← svi dokazi:
│   ├── PA800_EVIDENCE/     (registry JSON-ovi, desifrovani izvodi, zipovi:
│   │                        style identity, OC31 class map, literal run,
│   │                        master evidence report, KORG parseri)
│   └── SOURCES/            (BANK01.STY, BANK01 dekomprimerani izvori, OS fajlovi)
│
├── max_demo.wav            ← 48.9 s stvarnog engine izlaza
├── max_demo.report.json    ← kompletan audit izvještaj tog rendera
├── max_demo_simple.wav     ← kraća verzija (~34.9 s)
└── max_demo_simple.report.json
```

> Dokazi u **pa800_engine/data/** su unutar paketa da bi paket bio
> samostalan; ista kopija stoji i u **evidence/PA800_EVIDENCE** uz sve
> ostale izvode.

---

## Brzi start

```bat
install.bat        REM jednom po računaru
run.bat            REM meni svih aplikacija
```

Ili direktno iz CLI-a (nakon instalacije):

```bat
python -m pa800_engine               REM MAX DEMO (~49 s audio)
python -m pa800_engine --simple      REM kraća varijanta
python -m pa800_engine --midi moj.mid REM sinteza SMF fajla
python -m pa800_engine --records 20  REM prvih 20 rekorda u konzoli
python -m pytest pa800_engine\tests pa800_midi_app\tests -q
```

---

## Sadržaj dokaza u `pa800_engine/data/`

| Fajl | Sadržaj | Obim |
|---|---|---|
| `PA800_HARDWARE_VERIFIED_OSC_PROFILES.json` | 10 RX zvuka sa hardware-verified oscillator layerima (velocity/key zone, vel_switch_l_to_h, multisample imena + tagovi, confidence=HARDWARE_SCREEN) | 10 profila |
| `PA800_FACTORY_SPECIAL_REGISTRY_v2.json` | 23 DNC zvuka + RX drum kitovi (registry zapis) | 44 identiteta |
| `RX_OSCILLATOR_REGISTRY_v3.json` | drum per-key layer evidence + manual articulation guard | — |
| `RX_SOUND_CAPABILITIES_v1.json` | sounds + velocity windows status (UNRESOLVED_PRESERVE vs HARDWARE_OBSERVED_PARTIAL) | 44 |
| `PA800_FACTORY_SOUND_LIST_v1.json` | kompletan factory katalog imena sa adresama — fallback profili dobijaju pravo ime | 1003 bindinga |
| `PA800_DRUM_KIT_POP_STD_VEL_LAYERS_v1.json` | per-key verificirani velocity pod-slojevi Pop Std. Kit RX-a (HARDWARE_OBSERVED): 13 ključeva, Snare 6 slojeva pp..ff | 13 ključeva |
| `PA800_FACTORY_PERFORMANCE_PROFILES_v1.json` | izmjereni per-binding/range/velocity profili iz 54 onboard demo SMF-a (KONAČNA LOGIKA koraci 5-8) | 321 binding, 826 drum ključeva |

Ovi dokumenti su preslikani doslovno iz
`evidence/PA800_EVIDENCE/Pa800_os_res_v202_EXTRACTED_MASTER_EVIDENCE_REPORT.zip` —
engine ih ne parsira iznova, nego ih čita baš kako stoje (dokazno:
no quantization, no pitch tampering, address-first).

## Dokaz ispravnosti: primjer izvještaja `max_demo.report.json`

Za `max_demo.wav` (48.9 s audio, 434 odluke) engine je zapisao:

```json
"by_rule": {
  "DRUM_KEY_LAYER": 225,
  "HW_VELOCITY_ZONE": 205,
  "RX_NOISE_REGISTER": 4
},
"noise_triggers": {
  "NoiseKind.RX_REGISTER": 229,
  "NoiseKind.STOP_SCRAPE": 16,
  "NoiseKind.KEY_CLICK_ATTACK": 16,
  "NoiseKind.BREATH": 11,
  "NoiseKind.SLIDE": 9,
  "NoiseKind.FRET": 8
},
"decisions": 434
```

Render je determinističan — ponovni render istog ulaza daje bit-identičan
PCM (seed je izveden iz `make_seed(note, velocity, seq, kind_index)`).

---

## Napomena o GUI-u

Oba GUI-a su Tkinter (standardna biblioteka, dolazi sa zvaničnom Windows
Python instalacijom). Ako na Linuxu trebaš dodatni paket:

```bash
sudo apt install python3-tk   # Debian/Ubuntu
```

Sandbox u kojem je paket izrađen nema `DISPLAY` varijablu (vizuelni
self-test nije mogao biti pokrenut), ali `import pa800_engine.gui` bez
mainloop-a radi — to je dio pytest kompleta koji je uključen u paket.
