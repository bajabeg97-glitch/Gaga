@echo off
REM ============================================================
REM  Baja Music - Korg Pa800 MIDI Studio (CLI utility)
REM ============================================================
setlocal
cd /d "%~dp0"
if exist ..\.venv\Scripts\activate.bat call ..\.venv\Scripts\activate.bat
title Baja Music - MIDI Studio CLI
python pa800_midi_app\main.py %*
echo.
pause
