@echo off
REM ============================================================
REM  Baja Music - kompletan test suite (oba paketa)
REM ============================================================
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
title Baja Music - tests

echo.
echo [1/2] pa800_engine test suite...
python -m pytest pa800_engine\tests\ -q
if errorlevel 1 goto fail

echo.
echo [2/2] baja_pa_manager (MIDI app) test suite...
python -m pytest pa800_midi_app\tests\ -q --rootdir=pa800_midi_app
if errorlevel 1 goto fail

echo.
echo ============================================================
echo  SVI TESTOVI PROSLI
echo ============================================================
pause
exit /b 0

:fail
echo.
echo ============================================================
echo  Pojedini testovi su PALI — pogledaj izlaz gore.
echo ============================================================
pause
exit /b 1
