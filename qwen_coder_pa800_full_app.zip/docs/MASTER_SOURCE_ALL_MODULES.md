# MASTER SOURCE — ALL MODULES


## `baja_pa_manager/__init__.py`

```python
__version__ = "1.0.0"

```


## `baja_pa_manager/adapters/__init__.py`

```python
from .model import *

```


## `baja_pa_manager/adapters/model.py`

```python
from __future__ import annotations
from dataclasses import dataclass

from ..core.models import TargetModel


@dataclass(frozen=True, slots=True)
class ModelCapabilities:
    model: TargetModel
    user_dk_banks: int
    notes: str = ""


DEFAULT_CAPABILITIES = {
    TargetModel.PA800: ModelCapabilities(TargetModel.PA800, user_dk_banks=64, notes="safe default"),
    TargetModel.PA80: ModelCapabilities(TargetModel.PA80, user_dk_banks=64),
    TargetModel.PA1X: ModelCapabilities(TargetModel.PA1X, user_dk_banks=64),
    TargetModel.PA2X: ModelCapabilities(TargetModel.PA2X, user_dk_banks=64),
    TargetModel.PA3X: ModelCapabilities(TargetModel.PA3X, user_dk_banks=64),
    TargetModel.PA4X: ModelCapabilities(TargetModel.PA4X, user_dk_banks=64),
}


class ModelAdapter:
    def __init__(self, source: TargetModel, target: TargetModel):
        self.source = source
        self.target = target

    def address_crosswalk(self, msb: int, lsb: int, program: int) -> tuple[int, int, int]:
        # Address-first policy. Special-case mappings should be loaded from
        # an evidence DB rather than guessed here.
        return msb, lsb, program

```


## `baja_pa_manager/bkp/__init__.py`

```python
from .graph import *
from .container import *

```


## `baja_pa_manager/bkp/container.py`

```python
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class BKPArchive:
    root: Path
    raw: bytes


class BKPReader:
    def load(self, path: Path) -> BKPArchive:
        return BKPArchive(path, path.read_bytes())


class BKPWriter:
    def save(self, archive: BKPArchive, path: Path) -> None:
        # Safe default: exact preservation only.
        path.write_bytes(archive.raw)

```


## `baja_pa_manager/bkp/graph.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class DependencyNode:
    key: str
    kind: str
    metadata: dict = field(default_factory=dict)


class DependencyGraph:
    def __init__(self):
        self.nodes: dict[str, DependencyNode] = {}
        self.edges: dict[str, set[str]] = {}

    def add_node(self, node: DependencyNode) -> None:
        self.nodes[node.key] = node
        self.edges.setdefault(node.key, set())

    def link(self, parent: str, child: str) -> None:
        if parent not in self.nodes or child not in self.nodes:
            raise KeyError("Both nodes must exist before linking")
        self.edges[parent].add(child)

    def walk(self, start: str) -> list[str]:
        seen: set[str] = set()
        stack = [start]
        out: list[str] = []
        while stack:
            key = stack.pop()
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
            stack.extend(sorted(self.edges.get(key, ()), reverse=True))
        return out

    def orphans(self) -> list[str]:
        referenced = {c for children in self.edges.values() for c in children}
        return [k for k in self.nodes if k not in referenced]

```


## `baja_pa_manager/core/__init__.py`

```python
from .models import *
from .binary import *
from .evidence import *
from .validator import *

```


## `baja_pa_manager/core/binary.py`

```python
from __future__ import annotations

import struct
from dataclasses import dataclass


class BinaryError(ValueError):
    pass


@dataclass
class BinaryReader:
    data: bytes
    pos: int = 0

    def remaining(self) -> int:
        return len(self.data) - self.pos

    def take(self, n: int) -> bytes:
        if n < 0 or self.pos + n > len(self.data):
            raise BinaryError(f"Out of bounds read: pos={self.pos} n={n} size={len(self.data)}")
        out = self.data[self.pos:self.pos+n]
        self.pos += n
        return out

    def u8(self) -> int:
        return self.take(1)[0]

    def i8(self) -> int:
        return struct.unpack("<b", self.take(1))[0]

    def u16le(self) -> int:
        return struct.unpack("<H", self.take(2))[0]

    def u32le(self) -> int:
        return struct.unpack("<I", self.take(4))[0]

    def i16le(self) -> int:
        return struct.unpack("<h", self.take(2))[0]

    def i32le(self) -> int:
        return struct.unpack("<i", self.take(4))[0]

    def bytes_at(self, offset: int, n: int) -> bytes:
        if offset < 0 or offset + n > len(self.data):
            raise BinaryError("bytes_at out of range")
        return self.data[offset:offset+n]


class BinaryWriter:
    def __init__(self, initial: bytes = b""):
        self.buf = bytearray(initial)

    def write_at(self, offset: int, data: bytes) -> None:
        if offset < 0:
            raise BinaryError("negative offset")
        end = offset + len(data)
        if end > len(self.buf):
            self.buf.extend(b"\x00" * (end - len(self.buf)))
        self.buf[offset:end] = data

    def u8_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<B", value & 0xFF))

    def u16le_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<H", value & 0xFFFF))

    def u32le_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<I", value & 0xFFFFFFFF))

    def build(self) -> bytes:
        return bytes(self.buf)

```


## `baja_pa_manager/core/container.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class Resource:
    type_id: int
    name: str
    payload: bytes
    raw: bytes = b""
    metadata: dict = field(default_factory=dict)


@dataclass(slots=True)
class NativeContainer:
    magic: bytes
    resources: list[Resource] = field(default_factory=list)
    raw_prefix: bytes = b""
    raw_suffix: bytes = b""

    def add(self, resource: Resource) -> None:
        self.resources.append(resource)


class ContainerReader:
    """Generic preserve-first container shell.

    Exact PA800 container serializers belong to the concrete resource modules.
    This class intentionally does not invent a KBEG/KEND variant.
    """

    def load_file(self, path: Path) -> NativeContainer:
        data = path.read_bytes()
        return NativeContainer(magic=data[:4], raw_prefix=data)

    def load_bytes(self, data: bytes) -> NativeContainer:
        return NativeContainer(magic=data[:4], raw_prefix=data)


class ContainerWriter:
    def save_file(self, container: NativeContainer, path: Path) -> None:
        path.write_bytes(self.build(container))

    def build(self, container: NativeContainer) -> bytes:
        if container.raw_prefix and not container.resources:
            return container.raw_prefix
        return container.raw_prefix

```


## `baja_pa_manager/core/evidence.py`

```python
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

from .models import WritePolicy


@dataclass(frozen=True, slots=True)
class EvidenceRule:
    area: str
    feature: str
    app_module: str
    policy: WritePolicy
    confidence: str
    caveat: str


class EvidenceRegistry:
    def __init__(self, rules: Iterable[EvidenceRule]):
        self._rules = list(rules)

    @classmethod
    def default(cls) -> "EvidenceRegistry":
        return cls([
            EvidenceRule("SET", "Load/New/Save As", "SetManager", WritePolicy.IMPLEMENT, "HIGH", "Resource writers remain resource-specific."),
            EvidenceRule("STYLE", "Original/Working/Reset", "StyleWorkspace", WritePolicy.IMPLEMENT, "HIGH", "Working copy is explicit."),
            EvidenceRule("STYLE", "TrackInfo/Sound selector", "StyleTrackEditor", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Write only proven fields."),
            EvidenceRule("STYLE", "STS version compatibility", "STSAdapter", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Unknown leafs remain raw."),
            EvidenceRule("STYLE", "CV/Pattern/Type06", "StyleSerializer", WritePolicy.IMPLEMENT_GUARDED, "HIGH_SOFTWARE", "Use native writer authority."),
            EvidenceRule("SOUND", "Address-first resolver", "SoundResolver", WritePolicy.IMPLEMENT, "VERY_HIGH", "Name is secondary when numeric address exists."),
            EvidenceRule("SOUND", "Oscillator unknown leaves", "OscillatorEditor", WritePolicy.PRESERVE_ONLY, "HIGH", "Do not synthesize unknown bytes."),
            EvidenceRule("PERFORMANCE", "Release2/Release3 preservation", "PerformanceSerializer", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Preserve unknown extension regions."),
            EvidenceRule("BKP", "ALL/dependency graph", "DependencyResolver", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Unknown edge types stay opaque."),
            EvidenceRule("PCM", "Compression writer", "PCMManager", WritePolicy.LATER, "HIGH", "Read/preserve first; no unproven codec writer."),
            EvidenceRule("MIDI", "Existing note timing/pitch", "MidiSafety", WritePolicy.IMPLEMENT, "PROJECT_HARD_RULE", "No quantize, snap, humanize or pitch mutation."),
        ])

    def by_module(self, module: str) -> list[EvidenceRule]:
        return [r for r in self._rules if r.app_module == module]

    def modules(self) -> list[str]:
        return sorted({r.app_module for r in self._rules})

```


## `baja_pa_manager/core/models.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TargetModel(str, Enum):
    PA800 = "PA800"
    PA80 = "PA80"
    PA1X = "PA1X"
    PA2X = "PA2X"
    PA3X = "PA3X"
    PA4X = "PA4X"


class WritePolicy(str, Enum):
    IMPLEMENT = "IMPLEMENT"
    IMPLEMENT_GUARDED = "IMPLEMENT_GUARDED"
    PRESERVE_ONLY = "PRESERVE_ONLY"
    READ_ONLY = "READ_ONLY"
    HARDWARE_GATE = "HARDWARE_GATE"
    LATER = "LATER"


@dataclass(slots=True)
class RawRegion:
    offset: int
    data: bytes
    label: str = "unknown"

    @property
    def end(self) -> int:
        return self.offset + len(self.data)


@dataclass(slots=True)
class ResourceRef:
    resource_type: str
    name: str
    index: int | None = None
    address: tuple[int, int, int] | None = None
    size: int | None = None
    exists: bool | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ValidationIssue:
    level: str
    code: str
    message: str
    path: str | None = None


@dataclass(slots=True)
class ValidationReport:
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not any(i.level == "ERROR" for i in self.issues)

    def add(self, level: str, code: str, message: str, path: str | None = None) -> None:
        self.issues.append(ValidationIssue(level, code, message, path))

    def format(self) -> str:
        if not self.issues:
            return "VALIDATION: PASS"
        lines = ["VALIDATION: " + ("PASS" if self.ok else "FAIL")]
        for item in self.issues:
            where = f" [{item.path}]" if item.path else ""
            lines.append(f"{item.level} {item.code}{where}: {item.message}")
        return "\n".join(lines)

```


## `baja_pa_manager/core/validator.py`

```python
from __future__ import annotations

from .evidence import EvidenceRegistry
from .models import ValidationReport


class Validator:
    def __init__(self, evidence: EvidenceRegistry):
        self.evidence = evidence

    def validate_nonempty(self, name: str, value: object) -> ValidationReport:
        r = ValidationReport()
        if value is None or value == "" or value == b"":
            r.add("ERROR", "EMPTY", f"{name} is empty")
        return r

    def smoke_report(self) -> ValidationReport:
        r = ValidationReport()
        required = {
            "SetManager", "StyleWorkspace", "StyleTrackEditor",
            "SoundResolver", "PerformanceSerializer", "DependencyResolver"
        }
        available = set(self.evidence.modules())
        missing = sorted(required - available)
        if missing:
            r.add("ERROR", "MODULE_EVIDENCE", f"Missing evidence entries: {missing}")
        r.add("INFO", "POLICY", "Unknown fields are preserve-only by design")
        r.add("INFO", "MIDI", "Existing note positions and pitches are immutable")
        return r

```


## `baja_pa_manager/gui/__init__.py`

```python
from .app import run

```


## `baja_pa_manager/gui/app.py`

```python
from __future__ import annotations
import tkinter as tk
from tkinter import filedialog, messagebox

from ..core.models import TargetModel
from ..set_manager import SetManager


def run() -> None:
    root = tk.Tk()
    root.title("Baja Music — PA800 Manager")
    root.geometry("720x420")

    status = tk.StringVar(value="Ready")

    def open_set():
        folder = filedialog.askdirectory(title="Open SET")
        if not folder:
            return
        try:
            ws = SetManager(TargetModel.PA800).open_set(__import__("pathlib").Path(folder))
            status.set(f"Loaded: {ws.source}")
        except Exception as exc:
            messagebox.showerror("SET error", str(exc))

    tk.Label(root, text="Baja Music — Korg PA800 Manager", font=("Segoe UI", 18, "bold")).pack(pady=20)
    tk.Button(root, text="Open SET", command=open_set, width=18).pack(pady=10)
    tk.Label(root, textvariable=status, wraplength=650).pack(pady=20)

    tk.Label(
        root,
        text="Evidence-gated build • unknown bytes are preserved • existing MIDI notes stay fixed",
        fg="#555555",
    ).pack(side="bottom", pady=15)

    root.mainloop()

```


## `baja_pa_manager/performance/__init__.py`

```python
from .models import *
from .serializer import *

```


## `baja_pa_manager/performance/models.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class PerformanceSlot:
    slot_id: int
    payload: bytes
    release: int = 2
    extension: bytes = b""


@dataclass(slots=True)
class PerformanceBank:
    name: str
    slots: list[PerformanceSlot] = field(default_factory=list)
    raw: bytes = b""

```


## `baja_pa_manager/performance/serializer.py`

```python
from __future__ import annotations

from .models import PerformanceBank, PerformanceSlot


class PerformanceSerializer:
    RELEASE2_SLOT_SIZE = 261
    RELEASE3_SLOT_SIZE = 357

    def parse(self, data: bytes, name: str = "") -> PerformanceBank:
        # Native geometry known; exact leaf semantics remain partly open.
        return PerformanceBank(name=name, raw=bytes(data))

    def build(self, bank: PerformanceBank) -> bytes:
        if bank.raw and not bank.slots:
            return bank.raw
        raise ValueError("Safe PRF writer requires fixture-backed slot serializer")

```


## `baja_pa_manager/set_manager.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

from .core.models import TargetModel
from .core.container import ContainerReader, NativeContainer


@dataclass
class SetWorkspace:
    source: Path
    target_model: TargetModel
    root: Path
    resources: dict[str, list[Path]] = field(default_factory=dict)
    original_snapshots: dict[str, bytes] = field(default_factory=dict)

    def reset_resource(self, key: str) -> None:
        # Concrete resource engines perform the actual rollback.
        self.original_snapshots.pop(key, None)

    def manifest(self) -> dict:
        return {k: [str(p) for p in v] for k, v in self.resources.items()}


class SetManager:
    RESOURCE_DIRS = ("STYLE", "PAD", "PERFORM", "SOUND", "PCM", "GLOBAL")

    def __init__(self, model: TargetModel = TargetModel.PA800):
        self.model = model
        self.reader = ContainerReader()

    def open_set(self, path: Path) -> SetWorkspace:
        path = path.resolve()
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(path)
        ws = SetWorkspace(path, self.model, path)
        for name in self.RESOURCE_DIRS:
            folder = path / name
            if folder.exists():
                ws.resources[name] = sorted(folder.iterdir())
        return ws

    def new_set(self, path: Path) -> SetWorkspace:
        path.mkdir(parents=True, exist_ok=True)
        for name in self.RESOURCE_DIRS:
            (path / name).mkdir(exist_ok=True)
        return self.open_set(path)

```


## `baja_pa_manager/sound/__init__.py`

```python
from .catalog import *
from .resolver import *
from .pcg import *
from .oscillator import *
from .drumkit import *
from .multisample import *

```


## `baja_pa_manager/sound/catalog.py`

```python
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SoundAddress:
    msb: int
    lsb: int
    program: int

    def tuple(self) -> tuple[int, int, int]:
        return self.msb, self.lsb, self.program


@dataclass(slots=True)
class SoundEntry:
    address: SoundAddress
    name: str
    family: str | None = None
    factory: bool = True


class SoundCatalog:
    def __init__(self, entries: list[SoundEntry] | None = None):
        self.entries = entries or []
        self.by_address = {e.address.tuple(): e for e in self.entries}

    def add(self, entry: SoundEntry) -> None:
        self.entries.append(entry)
        self.by_address[entry.address.tuple()] = entry

    def get(self, address: SoundAddress):
        return self.by_address.get(address.tuple())

```


## `baja_pa_manager/sound/drumkit.py`

```python
from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class DrumKey:
    note: int
    payload: bytes


@dataclass(slots=True)
class DrumKit:
    name: str
    keys: list[DrumKey]
    raw: bytes


class DrumKitParser:
    def parse(self, payload: bytes, name: str = "") -> DrumKit:
        return DrumKit(name=name, keys=[], raw=bytes(payload))

    def build(self, kit: DrumKit) -> bytes:
        if kit.raw and not kit.keys:
            return kit.raw
        raise ValueError("DrumKit key writer needs proven descriptor layout")

```


## `baja_pa_manager/sound/multisample.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class SampleRef:
    sample_id: int
    name: str
    size: int


@dataclass(slots=True)
class Multisample:
    name: str
    samples: list[SampleRef] = field(default_factory=list)
    raw: bytes = b""


class MultisampleManager:
    def referenced_bytes(self, ms: Multisample) -> int:
        return sum(s.size for s in ms.samples)

    def can_fit(self, ms: Multisample, budget_bytes: int) -> bool:
        return self.referenced_bytes(ms) <= budget_bytes

```


## `baja_pa_manager/sound/oscillator.py`

```python
from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class Oscillator:
    index: int
    payload: bytes
    version: int = 0


class OscillatorSerializer:
    SUPPORTED_VERSIONS = set(range(4, 10))

    def parse(self, payload: bytes, version: int) -> Oscillator:
        if version not in self.SUPPORTED_VERSIONS:
            raise ValueError(f"Unsupported oscillator version: {version}")
        return Oscillator(index=0, payload=bytes(payload), version=version)

    def build(self, osc: Oscillator) -> bytes:
        # Unknown leaf semantics preserved exactly.
        return osc.payload

```


## `baja_pa_manager/sound/pcg.py`

```python
from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class Program:
    name: str
    payload: bytes
    version: int = 0
    oscillator_count: int = 0


class PCGParser:
    def parse(self, payload: bytes, name: str = "") -> Program:
        # Preserve-first parser: version/OSC fields should be populated only
        # when a fixture-backed map is attached.
        return Program(name=name, payload=bytes(payload))

    def build(self, program: Program) -> bytes:
        return bytes(program.payload)

```


## `baja_pa_manager/sound/resolver.py`

```python
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

from .catalog import SoundAddress, SoundCatalog, SoundEntry


class MatchState(str, Enum):
    FACTORY = "FACTORY"
    SAME = "SAME"
    MISSING = "MISSING"
    USER_UNMAPPED = "USER_UNMAPPED"


@dataclass(slots=True)
class ResolveResult:
    state: MatchState
    source: SoundEntry | None
    target: SoundEntry | None
    reason: str


class SoundResolver:
    def resolve(self, source: SoundEntry, target_catalog: SoundCatalog) -> ResolveResult:
        exact = target_catalog.get(source.address)
        if exact:
            state = MatchState.FACTORY if exact.factory else MatchState.SAME
            return ResolveResult(state, source, exact, "numeric address match")

        same_name = next((e for e in target_catalog.entries if e.name == source.name), None)
        if same_name:
            return ResolveResult(MatchState.SAME, source, same_name, "name fallback")

        if not source.factory:
            return ResolveResult(MatchState.USER_UNMAPPED, source, None, "user sound has no target mapping")
        return ResolveResult(MatchState.MISSING, source, None, "no target mapping")

    def remap(self, source: SoundEntry, replacement: SoundEntry) -> None:
        # Explicit operation; caller owns the audit trail.
        if replacement is None:
            raise ValueError("replacement required")

```


## `baja_pa_manager/style/__init__.py`

```python
from .models import *
from .workspace import *
from .track_editor import *
from .serializer import *
from .midi_bridge import *
from .sts import *

```


## `baja_pa_manager/style/midi_bridge.py`

```python
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path


class MidiSafetyError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class NoteFingerprint:
    channel: int
    note: int
    tick: int
    ordinal: int


def _iter_note_events(midi):
    # Optional mido dependency. We keep the import local.
    try:
        import mido
    except ImportError as exc:
        raise RuntimeError("Install optional dependency: pip install '.[midi]'") from exc
    absolute = 0
    ordinal = 0
    for track in midi.tracks:
        absolute = 0
        for msg in track:
            absolute += msg.time
            if msg.type in ("note_on", "note_off"):
                yield msg.channel, msg.note, absolute, ordinal, msg
                ordinal += 1


def snapshot_note_structure(midi) -> list[NoteFingerprint]:
    return [
        NoteFingerprint(ch, note, tick, ordinal)
        for ch, note, tick, ordinal, _ in _iter_note_events(midi)
    ]


def assert_note_structure_unchanged(before, after) -> None:
    a = snapshot_note_structure(before)
    b = snapshot_note_structure(after)
    if a != b:
        raise MidiSafetyError("Existing MIDI note timing/order/pitch changed")


class MidiBridge:
    def load(self, path: Path):
        try:
            import mido
        except ImportError as exc:
            raise RuntimeError("Install optional dependency: pip install '.[midi]'") from exc
        return mido.MidiFile(path)

    def save_checked(self, midi, path: Path, before_snapshot) -> None:
        # before_snapshot is a pre-edit MidiFile object.
        assert_note_structure_unchanged(before_snapshot, midi)
        midi.save(path)

```


## `baja_pa_manager/style/models.py`

```python
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass(slots=True)
class TrackInfo:
    sound_msb: int = 0
    sound_lsb: int = 0
    program: int = 0
    volume: int = 100
    expression: int = 127
    pan: int = 64
    chorus: int = 0
    reverb: int = 0
    min_key: int = 0
    max_key: int = 127
    ntt_type: int = 0
    ntr: int = 0
    raw: bytes = b""


@dataclass(slots=True)
class PatternEvent:
    tick: int
    status: int
    data: bytes


@dataclass(slots=True)
class StyleCV:
    index: int
    events: list[PatternEvent] = field(default_factory=list)
    raw: bytes = b""


@dataclass(slots=True)
class StyleElement:
    name: str
    cvs: list[StyleCV] = field(default_factory=list)
    tracks: dict[int, TrackInfo] = field(default_factory=dict)
    raw: bytes = b""


@dataclass(slots=True)
class Style:
    name: str
    version: int
    elements: dict[str, StyleElement] = field(default_factory=dict)
    raw: bytes = b""
    unknown_regions: list[tuple[int, bytes]] = field(default_factory=list)

```


## `baja_pa_manager/style/serializer.py`

```python
from __future__ import annotations
from dataclasses import dataclass

from ..core.binary import BinaryReader, BinaryWriter
from .models import Style, StyleElement, StyleCV, PatternEvent, TrackInfo


@dataclass(slots=True)
class ParsedType06:
    events: list[PatternEvent]
    raw: bytes


class Type06Codec:
    """Evidence-gated Type-06 codec.

    The event stream is treated as an opaque native region unless a concrete
    field map is supplied by a regression fixture.
    """

    def parse(self, payload: bytes) -> ParsedType06:
        return ParsedType06(events=[], raw=bytes(payload))

    def build(self, parsed: ParsedType06) -> bytes:
        if parsed.events:
            raise ValueError("No proven Type-06 event writer registered")
        return parsed.raw


class TrackInfoCodec:
    """Semantic TrackInfo facade; binary offset map must be injected by a
    native regression fixture before writing fields.
    """

    def parse(self, payload: bytes) -> TrackInfo:
        return TrackInfo(raw=bytes(payload))

    def build(self, info: TrackInfo) -> bytes:
        if info.raw:
            return info.raw
        raise ValueError("TrackInfo requires preserved native payload")


class StyleSerializer:
    def parse(self, data: bytes, name: str = "") -> Style:
        # Preserve-first shell. Exact native parser belongs here when the
        # concrete fixture set is wired into production.
        return Style(name=name, version=0, raw=bytes(data))

    def build(self, style: Style) -> bytes:
        if style.raw and not style.elements:
            return style.raw
        raise ValueError("Safe writer needs proven native Style fixture map")

```


## `baja_pa_manager/style/sts.py`

```python
from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class STSRecord:
    version_family: str
    payload: bytes
    raw: bytes


class STSAdapter:
    KNOWN_COMPANION_SIZES = {881, 921}

    def parse(self, payload: bytes) -> STSRecord:
        version = "unknown"
        if len(payload) in self.KNOWN_COMPANION_SIZES:
            version = f"known-size-{len(payload)}"
        return STSRecord(version, bytes(payload), bytes(payload))

    def compatible(self, a: STSRecord, b: STSRecord) -> bool:
        return a.version_family == b.version_family

    def build(self, record: STSRecord) -> bytes:
        return record.raw if record.raw else record.payload

```


## `baja_pa_manager/style/track_editor.py`

```python
from __future__ import annotations
from copy import deepcopy

from .models import Style, TrackInfo


class StyleTrackEditor:
    def original_sounds(self, style: Style) -> dict[str, dict[int, TrackInfo]]:
        out: dict[str, dict[int, TrackInfo]] = {}
        for element_name, element in style.elements.items():
            out[element_name] = deepcopy(element.tracks)
        return out

    def apply_sounds_to_all_elements(
        self, style: Style, source_element: str, original: dict[str, dict[int, TrackInfo]]
    ) -> None:
        if source_element not in style.elements:
            raise KeyError(source_element)
        src = style.elements[source_element].tracks
        for name, element in style.elements.items():
            if name == source_element:
                continue
            element.tracks = deepcopy(src)

    def restore_original_sounds(
        self, style: Style, original: dict[str, dict[int, TrackInfo]]
    ) -> None:
        for name, tracks in original.items():
            if name in style.elements:
                style.elements[name].tracks = deepcopy(tracks)

```


## `baja_pa_manager/style/workspace.py`

```python
from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass

from .models import Style


@dataclass
class StyleWorkspace:
    original: Style
    working: Style

    @classmethod
    def from_style(cls, style: Style) -> "StyleWorkspace":
        return cls(original=deepcopy(style), working=deepcopy(style))

    def update(self) -> Style:
        self.original = deepcopy(self.working)
        return self.working

    def reset(self) -> Style:
        self.working = deepcopy(self.original)
        return self.working

```


## `main.py`

```python
from __future__ import annotations

import argparse
from pathlib import Path

from baja_pa_manager.core.models import TargetModel
from baja_pa_manager.core.validator import Validator
from baja_pa_manager.core.evidence import EvidenceRegistry
from baja_pa_manager.set_manager import SetManager


def main() -> int:
    p = argparse.ArgumentParser(description="Baja Music PA800 Manager")
    p.add_argument("--self-test", action="store_true")
    p.add_argument("--set", dest="set_path")
    args = p.parse_args()

    if args.self_test:
        registry = EvidenceRegistry.default()
        validator = Validator(registry)
        report = validator.smoke_report()
        print(report.format())
        return 0 if report.ok else 1

    manager = SetManager(TargetModel.PA800)
    if args.set_path:
        workspace = manager.open_set(Path(args.set_path))
        print(f"Loaded SET workspace: {workspace.source}")
    else:
        print("Baja Music PA800 Manager — source build ready.")
        print("Use --self-test or --set <folder>")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

```


## `tests/test_core.py`

```python
from baja_pa_manager.core.evidence import EvidenceRegistry
from baja_pa_manager.core.validator import Validator


def test_registry():
    r = EvidenceRegistry.default()
    assert "SetManager" in r.modules()
    assert "SoundResolver" in r.modules()


def test_smoke():
    report = Validator(EvidenceRegistry.default()).smoke_report()
    assert report.ok

```


## `tests/test_dependency.py`

```python
from baja_pa_manager.bkp.graph import DependencyGraph, DependencyNode


def test_graph_walk():
    g = DependencyGraph()
    for key, kind in [("style:a","STYLE"),("sound:a","SOUND"),("ms:a","MULTISAMPLE"),("sample:a","SAMPLE")]:
        g.add_node(DependencyNode(key, kind))
    g.link("style:a", "sound:a")
    g.link("sound:a", "ms:a")
    g.link("ms:a", "sample:a")
    assert g.walk("style:a") == ["style:a", "sound:a", "ms:a", "sample:a"]

```


## `tests/test_midi_safety.py`

```python
import pytest

mido = pytest.importorskip("mido")

from baja_pa_manager.style.midi_bridge import snapshot_note_structure, MidiSafetyError, assert_note_structure_unchanged


def test_note_safety_velocity_allowed():
    before = mido.MidiFile(type=1, ticks_per_beat=480)
    tr = mido.MidiTrack()
    before.tracks.append(tr)
    tr.append(mido.Message("note_on", note=60, velocity=90, time=0))
    tr.append(mido.Message("note_off", note=60, velocity=0, time=480))

    after = mido.MidiFile(type=1, ticks_per_beat=480)
    tr2 = mido.MidiTrack()
    after.tracks.append(tr2)
    tr2.append(mido.Message("note_on", note=60, velocity=110, time=0))
    tr2.append(mido.Message("note_off", note=60, velocity=0, time=480))

    assert snapshot_note_structure(before) == snapshot_note_structure(after)
    assert_note_structure_unchanged(before, after)


def test_note_pitch_change_rejected():
    before = mido.MidiFile()
    tr = mido.MidiTrack()
    before.tracks.append(tr)
    tr.append(mido.Message("note_on", note=60, velocity=90, time=0))

    after = mido.MidiFile()
    tr2 = mido.MidiTrack()
    after.tracks.append(tr2)
    tr2.append(mido.Message("note_on", note=61, velocity=90, time=0))

    with pytest.raises(MidiSafetyError):
        assert_note_structure_unchanged(before, after)

```


## `tools/show_tree.py`

```python
from pathlib import Path


def main():
    root = Path(__file__).resolve().parents[1]
    for p in sorted(root.rglob("*")):
        if ".git" in p.parts or p.is_dir():
            continue
        print(p.relative_to(root))


if __name__ == "__main__":
    main()

```

