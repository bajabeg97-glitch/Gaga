# PA800 / PA1X STYLE REVERSE ENGINEERING CHECKPOINT
Date: 2026-09-16

## Current breakthrough

1. `DecompRes.exe` from Style Works XT Universal is a real Korg resource compressor/decompressor helper.
2. `DecompRes -d BANK01.STY BANK01_DECOMP.STY` successfully expanded the user's PA1X BANK01 from 172,587 bytes to 441,801 bytes.
3. Compressed resource flags change from `0x30` to `0x10`; the `0x20` bit is therefore the compression flag in the tested resources.
4. Resource header proven on tested BANK01:

```text
U8    type
U8    sub1
U8    sub2
U8    flags
BE32  payload_size
```

5. In decomp BANK01 the KBEG -> KEND area is a clean array of 4-byte BE32 physical offsets. KEND+4 stores the BE32 count.
6. BANK01 has 41 refs = 1 root + 20 Style resources + 20 companion resources.
7. Resource sequence alternates:

```text
05 root
06 style
09 companion/style-performance
06 style
09 companion/style-performance
...
```

8. First style resource at 0x03E4 is a native uncompressed object. It is recursively structured by 8-byte record headers.
9. First style name observed: `Zivljak Rumba`.
10. The style contains StyleElement/CV structures and a 48-byte block matching the PaStyleToMidi parser's `8 x TrackInfo[6]` layout.
11. StyleElementInfo byte0 is confirmed as a 6-bit CV presence mask: popcount(mask) equals the actual number of following CV records.
12. Across 20 styles / 210 style elements / 1,680 TrackInfo records, bytes 4 and 5 consistently behave as low/high key range (`low <= high`). This strongly matches Style Works `TrkMinKey/TrkMaxKey` and `LoLimit/HiLimit` fields.
13. TrackInfo byte1 is overwhelmingly `{120,121}` (with very rare 0). Track position behavior strongly suggests a Korg bank/sound-family field, but exact semantics remain OPEN until correlated against style-performance sound data.
14. `StwTypes2.dll` contains a real Microsoft TYPELIB with semantic field names including:

```text
TrkNTT, TrkNTR, TrkChord, TrkKey,
TrkMinKey, TrkMaxKey,
TrkMsb, TrkLsb,
ChordType, ChordFlags,
GTR_NTR, GTR_NTT, GTR_OnBass,
SEC3_NTR, SEC3_NTT
```

15. Pa80_StyleToMidi.exe contains original C++ source-path/debug traces:

```text
NlzdStyle/NstPaIfc.cpp
NlzdStyle/NstEditIfc.cpp
MemCoder/MaEncoder.cpp
CNstStyle
CNstStyleElem
CNstChordVar
CNstPattern
```

and validates magic/header fragments including `KORF`.

## PROVEN

- KBEG entries in decomp Style Works/Korg resources are BE32 offsets.
- KEND contains BE32 entry count in tested files.
- 8-byte resource header + BE32 payload size.
- Compression flag bit `0x20` for tested style/companion resources (`0x30 -> 0x10` after decompression).
- `DecompRes.exe -d` successfully produces native uncompressed BANK01.
- StyleElement CV presence mask behavior.
- 48-byte block = 8 x 6-byte TrackInfo records, independently consistent with PaStyleToMidi reverse engineering.

## STRONG

- resource type 06 = Style.
- resource type 09 = Style Performance / companion object.
- TrackInfo[4] = Min/Low Key.
- TrackInfo[5] = Max/High Key.
- TrackInfo[1] relates to Korg bank/sound family (120/121).

## OPEN / NEXT

Highest-priority next step:

1. Parse resource type 09 for the same Style and extract per-track sound/bank/program/volume/pan.
2. Correlate those values with TrackInfo bytes 0..3.
3. Lock byte1 as Bank MSB or reject that hypothesis.
4. Map TrackInfo bytes 2/3 to NTR/NTT/Chord/Key using `StwTypes2` TYPELIB names and multiple differential styles.
5. Continue `CNstPaIfc` disassembly for exact struct member order and save/write inverse functions.
6. Port `DecompRes` decompression/compression algorithm to Python so the project no longer depends on the Windows helper.

## Important files

- `SOURCES/BANK01.STY` - original compressed PA1X bank
- `SOURCES/BANK01_DECOMP.STY` - exact output of DecompRes -d
- `TOOLS/DecompRes.exe` - Style Works Korg resource compressor/decompressor helper
- `TOOLS/StwTypes2.dll` / `.tlb` - semantic type definitions
- `PA80_RE/PaStyleToMidi.exe` - Korg Style-to-MIDI tool
- `PA80_RE/*.asm`, `disasm.txt` - current reverse-engineering output
- `PA800_EVIDENCE/` - earlier PA800 parser/evidence checkpoint
- `SCRIPTS/inspect_korg_sty.py` - quick KBEG/resource inspector

