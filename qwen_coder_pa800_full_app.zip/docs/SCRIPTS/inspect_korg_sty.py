#!/usr/bin/env python3
from pathlib import Path
import struct, sys


def be32(b):
    return struct.unpack('>I', b)[0]


def hdr(data, off):
    if off + 8 > len(data):
        return None
    t, s1, s2, flags = data[off:off+4]
    size = be32(data[off+4:off+8])
    return t, s1, s2, flags, size


def main(path):
    data = Path(path).read_bytes()
    kb = data.find(b'KBEG')
    ke = data.find(b'KEND')
    print('file:', path)
    print('size:', len(data))
    print('KBEG:', hex(kb) if kb >= 0 else 'not found')
    print('KEND:', hex(ke) if ke >= 0 else 'not found')
    if kb < 0 or ke < 0 or ke < kb + 4:
        return
    raw = data[kb+4:ke]
    if len(raw) % 4:
        print('warning: KBEG payload not divisible by 4:', len(raw))
    refs = [be32(raw[i:i+4]) for i in range(0, len(raw)-3, 4)]
    count = be32(data[ke+4:ke+8]) if ke + 8 <= len(data) else None
    print('refs:', len(refs), 'KEND count:', count)
    for i, off in enumerate(refs):
        h = hdr(data, off)
        if h is None:
            print(f'{i:3d} 0x{off:08X} OUT_OF_RANGE')
            continue
        t,s1,s2,flags,size = h
        ok = off + 8 + size <= len(data)
        print(f'{i:3d} 0x{off:08X} type={t:02X} sub={s1:02X}/{s2:02X} flags={flags:02X} size={size:7d} end=0x{off+8+size:08X} ok={ok}')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('usage: inspect_korg_sty.py <file.STY>')
        raise SystemExit(2)
    main(sys.argv[1])
