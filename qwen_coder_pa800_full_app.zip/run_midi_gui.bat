@echo off
REM ============================================================
REM  Baja Music - Korg Pa800 MIDI Studio (Tkinter GUI)
REM ============================================================
setlocal
cd /d "%~dp0"
if exist ..\.venv\Scripts\activate.bat call ..\.venv\Scripts\activate.bat
title Baja Music - MIDI Studio GUI
python -c "import sys; sys.path.insert(0, r'%~dp0pa800_midi_app'); from baja_pa_manager.gui import run; run()"
if errorlevel 1 (
    echo GRESKA pri pokretanju GUI-a.
    pause
)
