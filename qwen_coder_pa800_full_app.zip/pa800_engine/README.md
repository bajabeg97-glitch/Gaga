# pa800_engine — Korg Pa800 Engine u Pythonu

Kompletan, determinističan sistem sinteze za Korg Pa800 sa dva fokusna
sistema koja oponašaju ponašanje factory firmware-a:

1. **Song Prepare Modul** — analiza cijele pjesme unaprijed (stream
   analysis) + pre-scheduling svih događaja u apsolutne sample indekse, po
   logici Korg **RX / DNC Factory MAX DEMO SONG** sistema.
2. **RX/DNC Articulation & Noise Engine** — dinamičko okidanje factory
   artikulacija i mehaničkih šumova iz dokazanog hardware profiliranja:
   fret noise, key-click attack/release, legato glide, damper šum,
   breath attack, growl na pritisak dirki, drum per-key slojevi.

Dvije faze sistema su čvrsto ulančane:
**Song Prepare analiza → Articulation Engine → Voice Pool → Mixer**.

> Render je u potpunosti determinističan: isti ulaz → bit-identičan izlaz
> (svi PRNG-ovi su seedovani po događaju; u odlukama nema zidnog sata).

---

## 1. Instalacija i pokretanje

Zahtjevi: Python 3.10+, `numpy` (testirano na 2.3.5). Za SMF ulaz dodatno
se koristi `baja_pa_manager.midi.optimizer` parser iz pripadajuće
aplikacije `pa800_midi_app` — ako je prisutan u istom korijenskom folderu,
testovi ga pokrivaju pune; inače engine radi u potpunosti na
`RawEvent` listama.

```bash
cd /home/user
python3 -m pa800_engine                       # MAX DEMO (≈49 s audio)
python3 -m pa800_engine --simple              # skraćena varijanta
python3 -m pa800_engine --midi pjesma.mid     # sinteza SMF fajla
python3 -m pa800_engine --records 20          # ispis prvih 20 rekorda odluka
```

Izlaz je stereo 16-bit WAV (default `max_demo.wav`) + JSON izvještaj
(`max_demo.report.json`) sa kompletnim audit tragom odluka.

## 2. Arhitektura

```
ingestion (SMF ili live RawEvent list)
        │
SongPrepareAnalyzer ──► PreparedSong  (uparene note, fraza, bindinge, laneovi)
        │
PreScheduler ──► apsolutni sample indeksi (compute-ahead lookahead)
        │
┌─────── render petlja po bloku (64 frejma @ 48 kHz) ────────────────┐
│ ChannelState (CC/PC/bend/pressure/damper)                          │
│ ArticulationEngine.decide_note — RX/DNC pravila, fiksni redoslijed │
│ VoiceAllocator (LRU steal, legato retarget, drum choke)            │
│ Voice = aditivni tonalni slojevi + oblikovani noise burstovi       │
│ Mixer (sumacija + soft clip x/(1+|x|))                             │
└────────────────────────────────────────────────────────────────────┘
        │
RenderResult (int16 stereo PCM + kompletan audit izvještaj)
```

### Moduli

| Modul | Uloga |
|---|---|
| `pa800_engine/constants.py` | CC mapa, key opsezi (C-1..G9), `midi_to_hz`, velocity krivulja |
| `pa800_engine/events.py` | `RawEvent` (frozen), `ScheduledEvent` (aps. sample + note_ctx), `Transport` |
| `pa800_engine/clock.py` | `TempoMap` (tick↔µs, BPM po ticku, (bar, beat, faza)), `MasterClock` (apsolutni sample brojač) |
| `pa800_engine/songprepare/report.py` | `NoteContext`, `ChannelPrepare`, `PreparedSong` — sve što prva faza izdvoji |
| `pa800_engine/songprepare/analyzer.py` | Dvojni prolaz sa dokazanom binding-commit semantikom |
| `pa800_engine/songprepare/scheduler.py` | PreScheduler — tick→sample mapiranje, lookahead prozor, release rep |
| `pa800_engine/articulation/profiles.py` | `SoundProfile`, `OscLayer`, `NoiseKind`/`NoiseSpec`, `NOISE_TABLE` |
| `pa800_engine/articulation/catalog.py` | `SoundCatalog`: 10 RX + 23 DNC + 17 RX kitova iz evidence baze |
| `pa800_engine/articulation/rules.py` | `decide()` — fiksni lanac pravila, release/damper/pressure trigaderi |
| `pa800_engine/articulation/engine.py` | `ArticulationEngine` + audit trail (`ArticulationRecord`) |
| `pa800_engine/voice/channel.py` | `ChannelState` — kontroleri, damper, binding commit |
| `pa800_engine/voice/source.py` | `TonalSource` (aditivna), `NoiseBurstSource` (PRNG, seedovano) |
| `pa800_engine/voice/voice.py` | `Voice` — glas sa slojevima, glide trajektorijom, noise dijelovima |
| `pa800_engine/voice/allocator.py` | `VoiceAllocator` — pool, LRU steal, legato retarget, drum choke |
| `pa800_engine/dsp/envelope.py` | `SegmentEnvelope` (AHDSR), `GateEnvelope` (noise decay) |
| `pa800_engine/dsp/mixer.py` | blok-sumator + soft clip master |
| `pa800_engine/engine.py` | `Pa800Engine`, `RenderResult` — vrh pipeline-a |
| `pa800_engine/demo.py` | MAX DEMO builder (višetaktačna pjesma sa svim sistemima) |
| `pa800_engine/sources.py` | SMF → `RawEvent` (baja SMF parser) |
| `pa800_engine/data/` | Dokazna JSON baza (§4.1) |

## 3. Song Prepare Modul (analiza + pre-scheduling)

### `SongPrepareAnalyzer.analyze(events, tpq, name) → PreparedSong`

Dvoprolazna analiza (ne mutira ulaz):

1. **Pass 1 — uparivanje + binding commit**: note-on/note-off parovi se
   spajaju u `NoteContext`; CC0/CC32 se drže kao *pending* dok `Program
   Change` ne komitira novu adresu — to je dokazana Pa800 semantika
   ("kasnija banka bez novog PC-a NE mijenja zvuk"). Svi relevantni CC
   redovi (`cc7/cc10/cc11/cc91/cc64/mod/bend/pressure`) se čuvaju u
   control lane-ovima za realtime kontekst.
2. **Pass 2 — frazni kontekst**: svakoj `NoteContext` instanci se dodaje
   `prev_note`, `interval`, `interval_dir`, `gap_ticks` (≤0 = overlap =
   **legato kandidat**), `simultaneous_on` (akord ili solo),
   `is_noise_register` (C7+, MIDI 96-127), `is_drum` (kanal 9).
   Nezatvorene note se produžuju do kraja pjesme.

### `PreScheduler`

Kao u Korg firmware-u, kontrolna nit radi unaprijed, audio nit samo
konzumira:

- **svi tickovi** se mapiraju u apsolutne int-sample indekse (preko
  `TempoMap` + `MasterClock`), monotono (bez skokova pri tempo promjeni);
- emituje stabilni redoslijed `(sample, seq)` zajedno sa sintetičkim
  *note-off* događajima (iz uparenih parova);
- `window(cursor, horizon)` daje spremne događaje za naredni blok plus
  compute-ahead margina (default 5 ms);
- `lookahead_voice_hint` unaprijed procjenjuje vrh polifonije za
  rezervaciju glasova;
- iza zadnjeg događaja uvodi se 250 ms release rep.

## 4. RX/DNC Articulation & Noise Engine

### 4.1 Izvor istine: dokazna JSON baza (`data/`)

Engine se ne oslanja na nagađanja — svi profili dolaze iz evidencije
reverse-engineeringiranog firmware-a:

| Fajl | Sadržaj | Obim |
|---|---|---|
| `PA800_HARDWARE_VERIFIED_OSC_PROFILES.json` | 10 RX zvuka sa oscillator layerima (velocity/key zone, `vel_switch_l_to_h`, multisample imena, tagovi, confidence=HARDWARE_SCREEN) | 10 |
| `PA800_FACTORY_SPECIAL_REGISTRY_v2.json` | 23 DNC zvuka + RX drum kitovi (`dnc_sounds`, `rx_drum_kits`, `rx_sounds`) | 44 |
| `RX_OSCILLATOR_REGISTRY_v3.json` | `drum_key_layer_evidence` (per-key decay info), `manual_articulation_guard` | — |
| `RX_SOUND_CAPABILITIES_v1.json` | `sounds` kandidati + velocity windows status (UNRESOLVED_PRESERVE vs HARDWARE_OBSERVED_PARTIAL) | 44 |
| `PA800_FACTORY_SOUND_LIST_v1.json` | kompletan factory katalog imena sa adresama (iz master dosjea 2026-09-22) — fallback profili dobijaju pravo ime + GM-family procjenu | 1003 bindinga |
| `PA800_DRUM_KIT_POP_STD_VEL_LAYERS_v1.json` | per-key verificirani velocity pod-slojevi za Pop Std. Kit RX (HARDWARE_OBSERVED): 13 ključeva, Snare 6 slojeva pp..ff, HiHat 4/2 layera | 13 ključeva |

**Pop Std. Kit RX** je jedini kit za koji postoji verificirana per-key
velocity mapa → sustav je kit-aware: kada je aktivan `120.0.4`, drum
odluka dobija i pod-sloj (`pp`, `p`, `mp`, `mf`, `f`, `ff`) u semantici,
a noise svjetlina raste monotono prema većiem pod-sloju.

**Evidence-gated pravilo**: velocity prozori se NIKAKO ne promoviraju na
zvuke sa statusom `UNRESOLVED_PRESERVE` — vrijede samo za 10 zvuka čiji
profili dolaze iz hardware-a. `SoundCatalog.stats()` izlaže to kao
`window_proven_sounds=10` (od 44 RX identiteta).

### 4.2 Fiksni redoslijed pravila (`articulation/rules.py`)

1. **`rule_noise_register`** — MIDI note ≥ C7 (96): čisti RX noise trigger
   (bez tonalnog sloja). Samo za RX/DNC profile (fallback ne odgovara).
2. **`rule_drum_key`** — drum kanal → per-key drum layer (GM-konformni
   opsezi: Kick 35-36, Cross Stick 37, Snare 38-40, HiHat Closed 42…).
3. **`rule_hardware_window`** — dokazane velocity/key zone biraju
   `OscLayer` (npr. `Picked Bass RX`: 114-127 = HARMONIC, 53-113 =
   WORKING_PICK_BASS, 23-52 = STOP_LH_RH, 1-22 = GLISS).
   `vel_switch_l_to_h` bira LOW/HIGH multisample unutar layer-a
   (`side` + `ms_ref`).
4. **`rule_legato`** — za RX/DNC profile na overlap notama: glide iz
   prethodne note (`34 + 6×interval` ms, capped na 120 ms) i uklanjanje
   novih attack noise trigadera; VoiceAllocator povezuje postojeći glas
   (donor retarget) — čvrsti legat bez novog attacka.
5. **`rule_dnc_augment`** — DNC attack augmentacija: `KEY_CLICK_ATTACK`
   (Jimmy Organ DNC), `BREATH` (Harmonica i WIND DNC porodica).

Dodatni kontekst-ovisni augmenti u `rule_hardware_window`
(modelirano po MAX DEMO ponašanju): kratka + meka nota u DEAD_TO_MUTE
zoni → DEAD strana; jaka dinamika + skok ≥5 polustepena u SLAP_TO_SLIDE
zoni → SLIDE noise uz slide hi stranu; brza solaža (gap ≤ pola tike) →
fret squeal; bas stop kratke note → tail scrape; gliss zona + interval≥5
pri visokoj gustoći → gliss scrape.

### 4.3 Release i pedala

- **`release_triggers`** — na note-off: KEY_CLICK_RELEASE (DNC zvuci sa
  `release_noise`), FRET squeal (DNC `fret_release` i staccato na RX
  guitar/bass porodici).
- **`damper_triggers`** — prijelaz CC64 down/up → `DAMPER_DOWN` /
  `DAMPER_UP` šum za DNC `damper_noise` porodicu (EP+Damper1/2 DNC).
  Dok je pedala dolje, prave note se drže u `sustain_hold`; cidni
  note-off dolazi tek na "pedala gore".
- **`pressure_response`** — kanalni pritisak dirki → `growl` koeficijent
  (Harmonica DNC 121.5.22) ili linearno povećanje svjetline (ostali);
  engine na prijelazu ≥0.5 dodaje trajni growl noise sloj na aktivnim
  tonalnim glasovima, a po prestanku pritiska ga gasi.

### 4.4 Audit (`articulation/engine.py`)

`ArticulationEngine.decide_note(ctx, channel, sample)` →
`(Decision, profile)` + puni `ArticulationRecord` zapis
(`seq, sample, tick, channel, note, velocity, binding, profile, rule,
semantic, side, multisample, noise[], legato, glide_ms, context`). Sve je
serializabilno u JSON (vidi `max_demo.report.json`).

## 5. Voice & DSP subsistem

- **`ChannelState`** — pending CC0/CC32 + commit PC-a; kontroleri (volume,
  expression, pan, damper, mod, pitch bend, pressure); `profile_for(ctx)`
  daje profil koji važi za dati note-on (binding po PC commit semantici).
- **`VoiceAllocator`** — pre-alokovani pool (default 78, Pa800 klasa).
  LRU steal (po slot age, prioritet otpuštenih); legato retarget (ne pali
  novi glas nego preusmjerava postojeći donor koji svira novu notu, glide
  prati pitch); drum mono-choke po istom layer imenu; `noise_only`
  glasovi (RX registar, damper šum, release šum); `note_off` je
  idempotentan po damper sustainu.
- **`Voice`** — aditivni izvor (1 do 8 parcijala po brightness parametru;
  dokazane oznake: SLAP→0.92, DEAD/MUTE→0.28, PICK→0.85, HARMONIC→0.96)
  + AHDSR ovojnica + noise burstovi (`GateEnvelope` po
  `NOISE_TABLE.decay_ms`). Render po bloku sa `freq_traj` (glide, vibrato
  po mod CC, pitch bend), odziv pritiska (svjetlina/growl), equal-power
  panning. Izvori su deterministični
  (`make_seed(note, velocity, seq, kind_index)`).
- **`Mixer`** — blok-sabiranje + soft clip `x/(1+|x|)` sa master gainom
  (oznaka: peak nikad ne prelazi 1.0, čak ni uz jako prebrizganje).

## 6. Determinizam i izvođenje

- **Isti ulaz → isti izlaz**: nema `time.time()` ni `random` u odlukama;
  dva nezavisna rendera iste pjesme daju bit-identičan niz.
- Performanse: MAX DEMO (≈49 s audio, 434 odluke, 10 aktivnih kanala)
  rendira se za ~8.7 s @ 48 kHz/64-frejm bloka (≈5.6× realtime, jedan CPU
  jezgar, numpy 2.3.5) — ponovo, blok struktura je izrađena uz nisku
  kašnjenost gi-factory firmware (5 ms horizon, 64 frejma/blok).
- Svjesno ograničenje: stvarni ROM PCM ne ulazi u paket — tonalni i noise
  slojevi se sintetski rekonstrue po semantičkoj ulozi (SLAP/SLIDE/
  DEAD/MUTE/HARMONIC/STOP…). Rezultat je auditabilan, reproduktivan i
  po ponašanju vjerojem factory sistemu.

## 7. Veza sa pa800_midi_app

Direktno vezivanje: `sources.load_smf(path)` koristi
`baja_pa_manager.midi.optimizer.parse_smf` iz `pa800_midi_app` paketa (isti
event model + parser koji je verificiran round-trip-om u paketu od 51
testa). Ako `baja_pa_manager` nije importabilan, `load_smf` baca jasan
`RuntimeError` sa uputama — sva ostala funkcionalnost engine-a radi
nezavisno.

## 8. Korištenje (API)

```python
from pa800_engine import Pa800Engine
from pa800_engine.events import EventKind, RawEvent

engine = Pa800Engine(sample_rate=48_000, block_size=64, voices=78)

events = [
    RawEvent(0, 0, EventKind.META_TEMPO, value=600000.0),       # 100 BPM
    RawEvent(1, 0, EventKind.CONTROL_CHANGE, 0, 0, 121),        # RX banka
    RawEvent(2, 0, EventKind.CONTROL_CHANGE, 0, 32, 14),
    RawEvent(3, 0, EventKind.PROGRAM_CHANGE, 0, 28),            # Clean Guitar RX1
    RawEvent(4, 0, EventKind.NOTE_ON, 0, 60, 90),
    RawEvent(5, 240, EventKind.NOTE_OFF, 0, 60, 0),
    RawEvent(6, 200, EventKind.NOTE_ON, 0, 96, 100),            # C7 fret noise
    RawEvent(7, 320, EventKind.NOTE_OFF, 0, 96, 0),
]
prepared = engine.ingest_events(events, tpq=480, name="demo")
result = engine.render(prepared)
result.write_wav("demo.wav")
result.write_report("demo.report.json")
print(result.articulation_report["by_rule"])
```

## 9. Test suite

```bash
cd /home/user/pa800_engine && python3 -m pytest tests/ -q
```

- **51 test, 0 skipped** (SMF round-trip test traži `pa800_midi_app` u
  istom korijenskom folderu; inače se preskače).
- Pokriveno: CC mapa, key imena, TempoMap/MasterClock preciznost,
  analyzer (binding commit, frazni kontekst, nezatvorene note), scheduler
  (monotoni sampleovi, window, lookahead), katalog (sve evidence, fallback
  lanci, windows NE-promoviranje), zone Picked Bass RX (harmonic/stop/gliss/
  working po LOW/HIGH stranama), drum per-key mapiranje, legato glide, DNC
  augmentacija, release & damper trigaderi, pressure, ovojnice
  (AHDSR/gate/choke), alokator (steal, legato retarget, drum choke,
  noise_only, sustain/release ponovljivost), mixer soft clip,
  end-to-end determinizam, WAV čitanje, SMF round-trip, TempoMap ritard.

## 10. Pravila koja engine honoriruje (iz master source-a)

- MIDI note tick/pitch/redoslijed su **immutable** — Song Prepare nikada ne
  mijenja polazne događaje (sve se čita; sintetički note-off se emituje kao
  dodatni događaj, nikad kao zamjena postojećeg).
- **Address-first** rezolucija zvuka (numerički MSB/LSB/PC pobjeđuje ime).
- Nepoznati regioni evidencije su **preserve-only**: `window_proven_sounds=10`
  guard drži 34 UNRESOLVED_PRESERVE identiteta izvan velocity mapa.
- Arhitektonska čistota: nema `TODO/FIXME/HACK` komentara, nema skeletona,
  sve jedinice su kompletne.
