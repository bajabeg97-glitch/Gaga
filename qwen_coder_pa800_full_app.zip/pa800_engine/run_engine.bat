@echo off
REM ============================================================
REM  PA800 Engine - CLI sinteza (MAX DEMO po defaultu)
REM ============================================================
setlocal
cd /d "%~dp0"
cd ..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
title PA800 Engine - CLI
python -m pa800_engine %*
echo.
pause
