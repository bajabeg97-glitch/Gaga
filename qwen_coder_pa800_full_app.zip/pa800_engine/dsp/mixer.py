"""Mixer — prealocirani stereo bufferi, soft-clip, master gain."""
from __future__ import annotations

import numpy as np


class Mixer:
    """Stalni izlazni stepen: glasovi sabiraju u L/R, master soft clip."""

    def __init__(self, block_size: int, master_gain: float = 0.9):
        self.block_size = int(block_size)
        self.master_gain = float(master_gain)
        self._l = np.zeros(self.block_size, dtype=np.float64)
        self._r = np.zeros(self.block_size, dtype=np.float64)
        self.peak = 0.0

    def buffers(self) -> tuple[np.ndarray, np.ndarray]:
        self._l.fill(0.0)
        self._r.fill(0.0)
        return self._l, self._r

    def sum_voice(self, sig_l: np.ndarray, sig_r: np.ndarray) -> None:
        n = min(len(sig_l), self.block_size)
        self._l[:n] += sig_l[:n]
        self._r[:n] += sig_r[:n]

    def master(self) -> np.ndarray:
        """Soft clip: x / (1 + |x|) — glatka saturacija bez hard clippinga."""
        gl = self._l * self.master_gain
        gr = self._r * self.master_gain
        out_l = gl / (1.0 + np.abs(gl))
        out_r = gr / (1.0 + np.abs(gr))
        interleaved = np.empty(2 * self.block_size, dtype=np.float64)
        interleaved[0::2] = out_l
        interleaved[1::2] = out_r
        peak = float(np.max(np.abs(interleaved))) if interleaved.size else 0.0
        self.peak = max(self.peak, peak)
        return interleaved

    def master_int16(self) -> np.ndarray:
        data = self.master()
        return np.clip(data * 32767.0, -32768.0, 32767.0).astype(np.int16)
