"""Segmentne ovojnice (A/H/D/S/R + gate) — sample-tačno, bez alokacija.

Svaka ovojnica drži svoje stanje (faza + pozicija + vrijednost) i renderuje
po bloku; `note_off()` prebacuje u RELEASE počevši od trenutne vrijednosti.
"""
from __future__ import annotations

from enum import Enum

import numpy as np


class EnvStage(str, Enum):
    IDLE = "IDLE"
    ATTACK = "ATTACK"
    HOLD = "HOLD"
    DECAY = "DECAY"
    SUSTAIN = "SUSTAIN"
    RELEASE = "RELEASE"
    DONE = "DONE"


class SegmentEnvelope:
    """AHDSR ovojnica za tonalne slojeve."""

    __slots__ = ("attack_s", "hold_s", "decay_s", "sustain", "release_s",
                 "stage", "value", "stage_pos", "release_start", "sr")

    def __init__(self, sr: int, attack_s: float = 0.003, hold_s: float = 0.0,
                 decay_s: float = 0.25, sustain: float = 1.0,
                 release_s: float = 0.18):
        self.sr = sr
        self.attack_s = max(1e-4, float(attack_s))
        self.hold_s = max(0.0, float(hold_s))
        self.decay_s = max(1e-3, float(decay_s))
        self.sustain = max(0.0, min(1.0, float(sustain)))
        self.release_s = max(5e-4, float(release_s))
        self.stage = EnvStage.IDLE
        self.value = 0.0
        self.stage_pos = 0
        self.release_start = 0.0

    # ------------------------------------------------------------ kontrola
    def start(self) -> None:
        self.stage = EnvStage.ATTACK
        self.value = 0.0
        self.stage_pos = 0
        self.release_start = 0.0

    def note_off(self) -> None:
        if self.stage not in (EnvStage.DONE, EnvStage.IDLE):
            self.release_start = self.value
            self.stage = EnvStage.RELEASE
            self.stage_pos = 0

    def choke(self) -> None:
        if self.stage not in (EnvStage.DONE, EnvStage.IDLE):
            self.release_start = self.value
            self.stage = EnvStage.RELEASE
            self.stage_pos = 0
            self.release_s = min(self.release_s, 0.012)

    def is_done(self) -> bool:
        return self.stage in (EnvStage.DONE, EnvStage.IDLE)

    # ------------------------------------------------------------ render
    def render(self, n: int) -> np.ndarray:
        out = np.empty(n, dtype=np.float64)
        attack_n = max(1, int(self.attack_s * self.sr))
        hold_n = int(self.hold_s * self.sr)
        decay_n = max(1, int(self.decay_s * self.sr))
        release_n = max(1, int(self.release_s * self.sr))
        for i in range(n):
            if self.stage is EnvStage.ATTACK:
                self.stage_pos += 1
                self.value = min(1.0, self.stage_pos / attack_n)
                if self.stage_pos >= attack_n:
                    self.stage = EnvStage.HOLD
                    self.stage_pos = 0
            elif self.stage is EnvStage.HOLD:
                self.value = 1.0
                self.stage_pos += 1
                if self.stage_pos >= hold_n:
                    self.stage = EnvStage.DECAY
                    self.stage_pos = 0
            elif self.stage is EnvStage.DECAY:
                self.stage_pos += 1
                t = min(1.0, self.stage_pos / decay_n)
                self.value = 1.0 + (self.sustain - 1.0) * t
                if self.stage_pos >= decay_n:
                    self.stage = EnvStage.SUSTAIN
            elif self.stage is EnvStage.SUSTAIN:
                self.value = self.sustain
            elif self.stage is EnvStage.RELEASE:
                self.stage_pos += 1
                t = min(1.0, self.stage_pos / release_n)
                self.value = self.release_start * (1.0 - t)
                if self.stage_pos >= release_n:
                    self.stage = EnvStage.DONE
                    self.value = 0.0
            else:
                self.value = 0.0
            out[i] = self.value
        return out


class GateEnvelope:
    """Jednokratni eksponencijalni decay za noise burstove."""

    __slots__ = ("decay_s", "sr", "pos", "done")

    def __init__(self, sr: int, decay_s: float):
        self.decay_s = max(5e-4, float(decay_s))
        self.sr = sr
        self.pos = 0
        self.done = False

    def render(self, n: int) -> np.ndarray:
        total = max(1, int(self.decay_s * self.sr))
        idx = np.arange(self.pos, self.pos + n, dtype=np.float64)
        env = np.exp(-3.2 * np.minimum(idx, total) / total)
        env[idx >= total] = 0.0
        self.pos += n
        if self.pos >= total:
            self.done = True
        return env

    def is_done(self) -> bool:
        return self.done
