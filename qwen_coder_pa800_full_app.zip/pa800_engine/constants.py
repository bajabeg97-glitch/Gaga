"""Globalne konstante engine-a (vremena, kanali, registri)."""
from __future__ import annotations

# --- audio / takt -----------------------------------------------------------
SAMPLE_RATE_DEFAULT = 48_000
BLOCK_SIZE_DEFAULT = 64                 # frejmova po bloku (1.33 ms @ 48 kHz)
LOOKAHEAD_MS_DEFAULT = 5.0              # compute-ahead margina kontrolne niti
VOICE_POOL_DEFAULT = 78                 # Pa800 klasa polifonije (62+rezerva)
DEFAULT_TEMPO_US_PER_QN = 500_000       # 120 BPM

# --- MIDI raspon ------------------------------------------------------------
TONAL_KEY_MAX = 95                      # B6  — gornja tonalna dirka
NOISE_REGISTER_MIN = 96                 # C7  — RX noise trigger registar
MIDI_KEY_MAX = 127

DRUM_CHANNEL = 9                        # MIDI kanal 10 (0-bazirano: 9)
RX_BANK_MSB = 121                       # CC0 koji označava RX/DNC banke
DRUM_BANK_MSB = 120                     # CC0 za drum kitove
GM_BANK = (0, 0)

# --- kontroleri -------------------------------------------------------------
CC_BANK_MSB = 0
CC_MOD = 1
CC_VOLUME = 7
CC_PAN = 10
CC_EXPRESSION = 11
CC_BANK_LSB = 32
CC_DAMPER = 64
CC_REVERB = 91
CC_CHORUS = 93
CC_ALL_SOUND_OFF = 120
CC_ALLNOTES_OFF = 123

# --- imenovani opsezi tonova (Pa800 dokumentacija) ---------------------------
KEY_NAMES = (
    "C-1 C#-1 D-1 D#-1 E-1 F-1 F#-1 G-1 G#-1 A-1 A#-1 B-1 "
    "C0 C#0 D0 D#0 E0 F0 F#0 G0 G#0 A0 A#0 B0 "
    "C1 C#1 D1 D#1 E1 F1 F#1 G1 G#1 A1 A#1 B1 "
    "C2 C#2 D2 D#2 E2 F2 F#2 G2 G#2 A2 A#2 B2 "
    "C3 C#3 D3 D#3 E3 F3 F#3 G3 G#3 A3 A#3 B3 "
    "C4 C#4 D4 D#4 E4 F4 F#4 G4 G#4 A4 A#4 B4 "
    "C5 C#5 D5 D#5 E5 F5 F#5 G5 G#5 A5 A#5 B5 "
    "C6 C#6 D6 D#6 E6 F6 F#6 G6 G#6 A6 A#6 B6 "
    "C7 C#7 D7 D#7 E7 F7 F#7 G7 G#7 A7 A#7 B7 "
    "C8 C#8 D8 D#8 E8 F8 F#8 G8 G#8 A8 A#8 B8 "
    "C9 C#9 D9 D#9 E9 F9 F#9 G9"
).split()


def key_name(note: int) -> str:
    if 0 <= note < len(KEY_NAMES):
        return KEY_NAMES[note]
    return f"#{note}"


def key_index(name: str) -> int:
    """'C7' → 96, 'B6' → 95, 'C-1' → 0 (isti opsezi kao u HW profilima)."""
    name = name.strip()
    if name in KEY_NAMES:
        return KEY_NAMES.index(name)
    octave_raw = name.rsplit(" ", 1)[0]
    if len(name) >= 2 and name[-2].isdigit() is False and name[-2] == "-":
        body, octave = name[:-2], -int(name[-1])
    elif name[-2:].lstrip("#").isdigit():
        body, octave = name[:-2], int(name[-2:])
    elif name[-1].isdigit():
        body, octave = name[:-1], int(name[-1])
    else:
        raise ValueError(f"Nepoznata dirka: {name!r}")
    semitones = {"C": 0, "C#": 1, "D": 2, "D#": 3, "E": 4, "F": 5, "F#": 6,
                 "G": 7, "G#": 8, "A": 9, "A#": 10, "B": 11}
    _ = octave_raw
    return semitones[body] + (octave + 1) * 12


def midi_to_hz(note: float) -> float:
    return 440.0 * (2.0 ** ((note - 69.0) / 12.0))


def velocity_gain(velocity: float, exponent: float = 1.6, headroom: float = 0.85) -> float:
    v = max(0.0, min(127.0, velocity)) / 127.0
    return (v ** exponent) * headroom
