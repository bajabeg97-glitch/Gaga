"""Vremenska osnova: TempoMap (tick→µs, takt) i MasterClock (sample brojač).

Firmware pravilo: sva konverzija tick→vrijeme radi se JEDNOM u Song Prepare
fazi (unaprijed), audio nit više ne dira tempomapu — nema rezhenja po bloku,
nema drifta. Sve vrijeme je apsolutno (int64 sample).
"""
from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass, field

from .constants import DEFAULT_TEMPO_US_PER_QN


@dataclass
class TempoMap:
    """Sortirana mapa (tick, µs/četvrtina) + mapa mjere (tick, num, den_pow)."""
    tpq: int
    tempo_points: list[tuple[int, int]] = field(default_factory=lambda: [(0, DEFAULT_TEMPO_US_PER_QN)])
    sig_points: list[tuple[int, int, int]] = field(default_factory=list)  # (tick, numerator, denom)

    def add_tempo(self, tick: int, us_per_qn: int) -> None:
        if us_per_qn <= 0:
            raise ValueError("tempo mora biti > 0")
        for i, (t, _) in enumerate(self.tempo_points):
            if t == tick:
                self.tempo_points[i] = (tick, us_per_qn)
                self._finalize()
                return
        self.tempo_points.append((tick, us_per_qn))
        self._finalize()

    def add_timesig(self, tick: int, numerator: int, denominator: int) -> None:
        self.sig_points.append((tick, numerator, denominator))
        self.sig_points.sort()

    def _finalize(self) -> None:
        self.tempo_points.sort()
        if self.tempo_points[0][0] != 0:
            self.tempo_points.insert(0, (0, DEFAULT_TEMPO_US_PER_QN))
        ticks = [t for t, _ in self.tempo_points]
        us = [u for _, u in self.tempo_points]
        self._ticks, self._us = ticks, us
        starts = [0]
        acc = 0.0
        for i in range(1, len(ticks)):
            acc += (ticks[i] - ticks[i - 1]) * (us[i - 1] / self.tpq)
            starts.append(acc)
        self._us_at = starts
        self._sig_final()

    def _sig_final(self) -> None:
        if not self.sig_points:
            self.sig_points = [(0, 4, 4)]

    def tick_to_us(self, tick: int) -> float:
        i = bisect_right(self._ticks, tick) - 1
        if i < 0:
            i = 0
        return self._us_at[i] + (tick - self._ticks[i]) * (self._us[i] / self.tpq)

    def us_to_tick(self, us: float) -> float:
        i = bisect_right(self._us_at, us) - 1
        if i < 0:
            i = 0
        if self._us[i] <= 0:
            return float(self._ticks[i])
        return self._ticks[i] + (us - self._us_at[i]) / (self._us[i] / self.tpq)

    def bpm_at(self, tick: int) -> float:
        i = bisect_right(self._ticks, tick) - 1
        if i < 0:
            i = 0
        return 60_000_000.0 / self._us[i]

    def signature_at(self, tick: int) -> tuple[int, int]:
        pts = self.sig_points
        i = bisect_right([t for t, _, _ in pts], tick) - 1
        if i < 0:
            i = 0
        _, num, den = pts[i]
        return num, den

    def transport(self, tick: int) -> tuple[int, int, float]:
        """(bar, beat, beat_phase) — 1-bazirani bar/beat, faza 0..1."""
        num, den = self.signature_at(tick)
        ticks_per_bar = self.tpq * num * 4 // den
        bar = tick // max(1, ticks_per_bar) + 1
        in_bar = tick - (bar - 1) * max(1, ticks_per_bar)
        beat = in_bar // self.tpq + 1
        phase = (in_bar % self.tpq) / self.tpq
        return bar, beat, phase


class MasterClock:
    """Apsolutni sample brojač render putanje — jedini izvor istine."""

    __slots__ = ("sample_rate", "position")

    def __init__(self, sample_rate: int):
        if sample_rate <= 0:
            raise ValueError("sample_rate mora biti > 0")
        self.sample_rate = int(sample_rate)
        self.position = 0

    def us_to_sample(self, us: float) -> int:
        return int(round(us * self.sample_rate / 1_000_000.0))

    def sample_to_us(self, sample: int) -> float:
        return sample * 1_000_000.0 / self.sample_rate

    def advance(self, frames: int) -> int:
        self.position += int(frames)
        return self.position

    def reset(self) -> None:
        self.position = 0
