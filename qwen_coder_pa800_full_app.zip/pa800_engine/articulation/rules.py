"""Deterministička trigger pravila RX/DNC artikulacija.

Redoslijed evaluacije je fiksan (kao u firmware-u):

    1. noise registar (C7+)          → eksplicitni RX noise trigger, bez tona
    2. hardware velocity zona        → izbor oscilator layera (dokazano)
    3. vel_switch_l_to_h             → LOW/HIGH strana layera po pragu
    4. kontekst fraze (Song Prepare) → pomoćna pravila: kratka nata → DEAD,
                                       veliki interval + jako → SLIDE strana,
                                       mekano + interval → GLISS,
                                       legato (overlap) → GLIDE umjesto re-attacka
    5. DNC augmentacija              → attack/release click, damper, breath
    6. drum kanal                    → per-key layer (RX kit)

Pravila su čiste funkcije nad ArticulationContext-om; nema slučajnosti,
nema side-effects — odluka je potpuno reproducibilna.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..constants import key_name
from .profiles import (
    DncBehavior, NoiseKind, MsRef, OscLayer, SoundKind, SoundProfile, SwitchSide,
)


@dataclass(frozen=True, slots=True)
class NoiseTrigger:
    kind: NoiseKind
    gain: float                       # 0..1 — skalira se velocity krivuljom
    reason: str


@dataclass(slots=True)
class ArticulationContext:
    """Ulaz u pravila — kompletan kontekst iz Song Prepare faze + stanje kanala."""
    note: int
    velocity: int
    channel: int
    is_drum: bool
    profile: SoundProfile
    # fraza
    prev_note: int | None = None
    interval: int | None = None
    interval_dir: int = 0
    gap_ticks: int | None = None
    duration_ticks: int = 0
    simultaneous_on: int = 1
    legato_candidate: bool = False
    ticks_per_beat: int = 480
    # stanje kanala u trenutku note-on
    damper: bool = False
    mod: float = 0.0
    bend_semitones: float = 0.0


@dataclass(slots=True)
class Decision:
    """Kompletna odluka za jedan note-on (spremna za VoiceAllocator)."""
    region: str                       # "TONAL" | "NOISE_REGISTER" | "DRUM"
    semantic: str                     # npr. "working", "dead", "slap→slide"
    rule: str                         # ime pravila koje je odlučilo
    layer: OscLayer | None = None
    side: SwitchSide | None = None
    ms_ref: MsRef | None = None
    noise: list[NoiseTrigger] = field(default_factory=list)
    legato_from_note: int | None = None
    glide_ms: float = 0.0
    velocity_scale: float = 1.0
    drum_layer_name: str = ""
    notes: list[str] = field(default_factory=list)

    def label(self) -> str:
        side = f"/{self.side.value}" if self.side else ""
        return f"{self.semantic}{side}"


# -------------------------------------------------------------------- pomoćne
def _is_guitar(profile: SoundProfile) -> bool:
    return profile.family.casefold() in {"guitar"}


def _is_bass(profile: SoundProfile) -> bool:
    return profile.family.casefold() in {"bass"}


def _semantic_label(layer: OscLayer, side: SwitchSide | None) -> str:
    role = layer.role
    pairs = {
        "SLAP_TO_SLIDE": "slap/slide", "DEAD_TO_MUTE": "dead/mute",
        "HARMONIC_TO_GHOST": "harmonic/ghost", "WORKING_CLEAN_GUITAR": "working",
        "WORKING_BASS": "working", "WORKING_PICK_BASS": "working",
        "WORKING_SLAP_BASS": "working+slap", "HARMONIC": "harmonic",
        "STOP": "stop", "STOP_LH_RH": "stop-lh/rh", "GLISS": "gliss",
        "SLAP": "slap", "TONAL": "tonal",
    }
    base = pairs.get(role, role.casefold().replace("_", " "))
    if role == "SLAP_TO_SLIDE" and side:
        return "slap" if side is SwitchSide.LOW else "slide"
    if role == "DEAD_TO_MUTE" and side:
        return "dead" if side is SwitchSide.LOW else "mute"
    if role == "HARMONIC_TO_GHOST" and side:
        return "ghost" if side is SwitchSide.LOW else "harmonic"
    if role == "STOP_LH_RH" and side:
        return "stop-lh" if side is SwitchSide.LOW else "stop-rh"
    return base


# -------------------------------------------------------------------- pravila
def rule_noise_register(ctx: ArticulationContext) -> Decision | None:
    """1) C7+ registar: čisti RX noise trigger (bez tonalnog sloja)."""
    if ctx.note < 96 or ctx.is_drum:
        return None
    profile = ctx.profile
    layer = profile.noise_layer
    if profile.kind is not SoundKind.RX and profile.kind is not SoundKind.DNC:
        return None
    gain = min(1.0, 0.35 + ctx.velocity / 127.0 * 0.65)
    return Decision(
        region="NOISE_REGISTER",
        semantic=f"noise-register {key_name(ctx.note)}",
        rule="RX_NOISE_REGISTER",
        layer=layer, noise=[NoiseTrigger(NoiseKind.RX_REGISTER, gain,
                                         f"C7+ trigger: {key_name(ctx.note)}")],
        notes=[f"registar C7+; velocity={ctx.velocity}"],
    )


def rule_drum_key(ctx: ArticulationContext) -> Decision | None:
    """1b) Drum kanal: per-key layer (RX kit / GM kit).

    Ako kit nosi verificirane velocity pod-slojeve (Pop Std. Kit RX
    HARDWWARE_OBSERVED), decision dobije i pod-sloj semantiku (pp/p/mp/mf/f/ff).
    """
    if not ctx.is_drum:
        return None
    layer = ctx.profile.drum_layer(ctx.note)
    name = layer.name if layer else "Drum"
    semantic = f"drum {name}".casefold()
    notes = [f"kit={ctx.profile.name}", f"key={key_name(ctx.note)}"]
    drum_sub: tuple[int, str] = (0, "")
    if layer is not None and layer.vel_layers:
        drum_sub = layer.sub_for(ctx.velocity)
        semantic += f" {drum_sub[1]}"
        notes.append(f"velocity layer {drum_sub[0] + 1}/{len(layer.vel_layers)} "
                     f"({drum_sub[1]}, osc={layer.osc_count})")
    return Decision(
        region="DRUM", semantic=semantic,
        rule="DRUM_KEY_LAYER", drum_layer_name=name,
        noise=[NoiseTrigger(NoiseKind.RX_REGISTER, min(1.0, ctx.velocity / 127.0),
                            "djelimični noise sadržaj kit sloja")],
        notes=notes,
    )


def rule_hardware_window(ctx: ArticulationContext) -> Decision | None:
    """2) Tonalni dio: hardware-verified velocity/key zona bira layer."""
    profile = ctx.profile
    layer = profile.layer_at(ctx.note, ctx.velocity)
    if layer is None:
        return None
    side = layer.side_for(ctx.velocity)
    ctx_note = _semantic_label(layer, side)
    decision = Decision(
        region="TONAL", semantic=ctx_note, rule="HW_VELOCITY_ZONE",
        layer=layer, side=side, ms_ref=layer.ref_for(side),
    )
    # 3) pomoćne modulacije iz konteksta (Song Prepare)
    if _is_guitar(profile):
        _apply_guitar_context(ctx, layer, side, decision)
    elif _is_bass(profile):
        _apply_bass_context(ctx, layer, side, decision)
    decision.notes.append(
        f"zone=[{layer.vel_lo},{layer.vel_hi}] switch={layer.switch} "
        f"vel={ctx.velocity}")
    return decision


def _apply_guitar_context(ctx: ArticulationContext, layer: OscLayer,
                          side: SwitchSide, decision: Decision) -> None:
    short = 0 < ctx.duration_ticks <= max(1, ctx.ticks_per_beat // 4)
    big_leap = ctx.interval is not None and ctx.interval >= 5
    # kratka niska nota u dead/mute zoni → DEAD strana (štucnuta artikulacija)
    if layer.role == "DEAD_TO_MUTE" and short and ctx.velocity <= 45:
        decision.side = SwitchSide.LOW
        decision.semantic = "dead"
        decision.ms_ref = layer.ref_for(SwitchSide.LOW) or decision.ms_ref
        decision.notes.append("kratka nota → dead strana (palm-mute porodica)")
    # nagli interval uz jaku dinamiku → eksplicitni SLIDE noise uz slide hi stranu
    if layer.role == "SLAP_TO_SLIDE" and big_leap and ctx.velocity >= (layer.switch or 114):
        decision.noise.append(NoiseTrigger(NoiseKind.SLIDE, min(1.0, ctx.velocity / 127.0),
                                           f"akcenat + skok {ctx.interval} polustepena"))
        decision.notes.append("interval≥5 + jako → slide noise augment")
    # solo fast run u working zoni → blagi fret squeal na prijelazima
    if layer.role.startswith("WORKING") and big_leap and ctx.gap_ticks is not None and ctx.gap_ticks <= ctx.ticks_per_beat // 2:
        decision.noise.append(NoiseTrigger(NoiseKind.FRET, 0.25 + 0.5 * ctx.velocity / 127.0,
                                           "brza solaža: prijelazni fret squeal"))


def _apply_bass_context(ctx: ArticulationContext, layer: OscLayer,
                        side: SwitchSide, decision: Decision) -> None:
    short = 0 < ctx.duration_ticks <= max(1, ctx.ticks_per_beat // 4)
    big_leap = ctx.interval is not None and ctx.interval >= 5
    soft = ctx.velocity <= max(5, layer.vel_lo + 4)
    tight = ctx.gap_ticks is not None and ctx.gap_ticks <= ctx.ticks_per_beat
    if layer.role == "GLISS" and big_leap and tight:
        decision.noise.append(NoiseTrigger(NoiseKind.SLIDE, 0.18 + 0.5 * ctx.velocity / 127.0,
                                           f"mekani skok {ctx.interval} → gliss scrape"))
        decision.notes.append("gliss zona + interval≥5 → scrape augment")
    elif layer.role.startswith("STOP") and short:
        decision.noise.append(NoiseTrigger(NoiseKind.STOP_SCRAPE, 0.2 + 0.5 * ctx.velocity / 127.0,
                                           "kratka stop nota → tail scrape"))
    elif layer.role == "HARMONIC" and big_leap and ctx.gap_ticks is not None and ctx.gap_ticks <= ctx.ticks_per_beat * 2:
        decision.notes.append("akcenat + skok u harmonic zoni → prirodni harmonik")


def rule_legato(ctx: ArticulationContext, decision: Decision | None) -> Decision | None:
    """4) Legato: preklopljene note istog kanala → GLIDE bez novog attacka."""
    if decision is None or decision.region != "TONAL":
        return decision
    if not ctx.legato_candidate or ctx.prev_note is None:
        return decision
    if ctx.profile.kind not in (SoundKind.RX, SoundKind.DNC):
        return decision
    decision.legato_from_note = ctx.prev_note
    decision.glide_ms = min(120.0, 34.0 + (ctx.interval or 0) * 6.0)
    decision.notes.append(f"legato: glide iz {key_name(ctx.prev_note)} ({decision.glide_ms:.0f} ms)")
    # bez novog attack noise triggera iz konteksta — gliss/slide šum ostaje
    decision.noise = [n for n in decision.noise
                      if n.kind not in (NoiseKind.KEY_CLICK_ATTACK, NoiseKind.BREATH)]
    return decision


def rule_dnc_augment(ctx: ArticulationContext, decision: Decision | None) -> Decision | None:
    """5) DNC augmentacija: attack click / breath / fret-release ulazak."""
    if decision is None or decision.region == "NOISE_REGISTER":
        return decision
    dnc = ctx.profile.dnc
    if dnc is None:
        return decision
    if dnc.attack_click:
        decision.noise.append(NoiseTrigger(
            NoiseKind.KEY_CLICK_ATTACK, 0.25 + 0.45 * ctx.velocity / 127.0 * dnc.noise_gain,
            "DNC key-click attack"))
    if dnc.breath_attack:
        decision.noise.append(NoiseTrigger(
            NoiseKind.BREATH, 0.20 + 0.40 * ctx.velocity / 127.0 * dnc.noise_gain,
            "DNC breath attack"))
    return decision


DEFAULT_CHAIN = (
    rule_noise_register,
    rule_drum_key,
    rule_hardware_window,
)


def decide(ctx: ArticulationContext) -> Decision:
    """Kompletan lanac odluke za jedan note-on. Redoslijed je fiksan."""
    decision: Decision | None = None
    for rule in DEFAULT_CHAIN:
        decision = rule(ctx)
        if decision is not None:
            break
    if decision is None:
        # bez dokaza: fallback tonalni sloj (GM ili nepotpun RX binding)
        profile = ctx.profile
        layer = profile.tonal_layers()[0] if profile.tonal_layers() else None
        decision = Decision(
            region="TONAL", semantic="tonal", rule="FALLBACK_TONAL",
            layer=layer, side=SwitchSide.HIGH,
            ms_ref=layer.ref_for(SwitchSide.HIGH) if layer else None,
            notes=[f"nema pokrivajućeg RX layera (vel={ctx.velocity})"],
        )
    decision = rule_legato(ctx, decision) or decision
    decision = rule_dnc_augment(ctx, decision) or decision
    return decision


# ------------------------------------------------------------ release/damper
def release_triggers(profile: SoundProfile, note: int, velocity_on: int,
                     duration_ticks: int, ticks_per_beat: int) -> list[NoiseTrigger]:
    """Key-click / fret-release šumovi na note-off.

    Osnuti na ponašanju DNC zvukova (release_noise / fret_release) i RX
    gitarsko-bas porodici (kratke staccato note imaju čujniji release šum).
    """
    out: list[NoiseTrigger] = []
    hold = max(1, duration_ticks) / max(1, ticks_per_beat)
    body = min(1.0, 0.55 + 0.18 * hold)          # duže držanje → čujniji release
    staccato = duration_ticks <= max(1, ticks_per_beat // 4)
    dnc = profile.dnc
    if dnc and dnc.release_noise:
        out.append(NoiseTrigger(
            NoiseKind.KEY_CLICK_RELEASE,
            min(1.0, body * dnc.noise_gain) * (0.5 + 0.5 * velocity_on / 127.0),
            "DNC key-click release"))
    if dnc and dnc.fret_release:
        out.append(NoiseTrigger(
            NoiseKind.FRET,
            min(1.0, (0.45 if staccato else 0.25) * dnc.noise_gain + 0.25 * velocity_on / 127.0),
            "DNC fret squeal na release" + (" (staccato)" if staccato else "")))
    if profile.kind is SoundKind.RX and profile.family.casefold() in {"guitar", "bass"}:
        layerish = next((l for l in profile.tonal_layers()
                         if l.vel_lo <= velocity_on <= l.vel_hi), None)
        if layerish and staccato:
            out.append(NoiseTrigger(
                NoiseKind.FRET, 0.22 + 0.33 * velocity_on / 127.0,
                f"staccato release ({layerish.role})"))
    return out


def damper_triggers(profile: SoundProfile, pressed: bool, velocity_hint: int = 96) -> list[NoiseTrigger]:
    """CC64 prijelaz → damper šum (EP+Damper DNC porodica)."""
    dnc = profile.dnc
    if dnc is None or not dnc.damper_noise:
        return []
    kind = NoiseKind.DAMPER_DOWN if pressed else NoiseKind.DAMPER_UP
    return [NoiseTrigger(kind, min(1.0, (0.55 if pressed else 0.38) * dnc.noise_gain
                                   + 0.20 * velocity_hint / 127.0),
                         f"CC64 {'press' if pressed else 'release'} → damper noise")]


def pressure_response(profile: SoundProfile, value: float) -> dict:
    """Pritisak dirki (channel pressure) → modulacija timbra u realnom vremenu.

    Za Harmonica/DNC duvačke: growl koeficijent; za ostale: brightness
    (LP simulacija) — mapiranje je linearno po dokazanom opsegu 0..1.
    """
    value = max(0.0, min(1.0, value))
    dnc = profile.dnc
    response = {"brightness": 0.5 + 0.5 * value, "growl": 0.0}
    if dnc and dnc.pressure_kind == "growl":
        response["growl"] = round(value * dnc.noise_gain, 4)
    return response
