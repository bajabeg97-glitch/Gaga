"""RX/DNC Articulation & Noise Engine — odluke u realnom vremenu.

Dizajn:
  * čiste funkcije (bez I/O, bez alokacija u audio niti — sve je pripremljeno
    u Song Prepare fazi i injectah ovdje kao ArticulationContext),
  * evidence-driven profili (SoundCatalog),
  * potpuno reproducibilne odluke (isti ulaz → ista odluka),
  * svaka odluka je auditima: rule name + notes + evidence binding.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..constants import NOISE_REGISTER_MIN
from ..songprepare.report import NoteContext
from ..voice.channel import ChannelState
from .catalog import SoundCatalog
from .profiles import SoundProfile
from .rules import (
    ArticulationContext, Decision, NoiseTrigger, damper_triggers, decide,
    pressure_response, release_triggers,
)


@dataclass(slots=True)
class ArticulationRecord:
    """Audit zapis jedne note-on odluke (upisuje se u render izvještaj)."""
    seq: int
    sample: int
    tick: int
    channel: int
    note: int
    velocity: int
    binding: tuple[int, int, int]
    profile: str
    rule: str
    semantic: str
    side: str | None
    ms_ref: str
    noise: list[str]
    legato: str
    glide_ms: float
    context: dict

    def to_dict(self) -> dict:
        return {
            "seq": self.seq, "sample": self.sample, "tick": self.tick,
            "channel": self.channel + 1, "note": self.note, "velocity": self.velocity,
            "binding": list(self.binding), "profile": self.profile,
            "rule": self.rule, "articulation": self.semantic,
            "side": self.side, "multisample": self.ms_ref,
            "noise_triggers": self.noise, "legato": self.legato,
            "glide_ms": round(self.glide_ms, 2), "context": self.context,
        }


class ArticulationEngine:
    """Stalna instanca: katalog + odluke. Bez side-effects izvan zapisa."""

    def __init__(self, catalog: SoundCatalog, ticks_per_beat: int = 480):
        self.catalog = catalog
        self.ticks_per_beat = int(ticks_per_beat)
        self.records: list[ArticulationRecord] = []

    # ------------------------------------------------------------- decisions
    def decide_note(self, ctx: NoteContext, channel: ChannelState,
                    sample: int = 0) -> tuple[Decision, SoundProfile]:
        profile = channel.profile_for(ctx)
        actx = ArticulationContext(
            note=ctx.note, velocity=ctx.velocity_on, channel=ctx.channel,
            is_drum=ctx.is_drum, profile=profile,
            prev_note=ctx.prev_note, interval=ctx.interval,
            interval_dir=ctx.interval_dir, gap_ticks=ctx.gap_ticks,
            duration_ticks=ctx.duration_ticks(),
            simultaneous_on=ctx.simultaneous_on,
            legato_candidate=ctx.legato_candidate,
            ticks_per_beat=self.ticks_per_beat,
            damper=channel.damper, mod=channel.mod, bend_semitones=channel.bend,
        )
        decision = decide(actx)
        self.records.append(ArticulationRecord(
            seq=ctx.seq, sample=sample, tick=ctx.tick, channel=ctx.channel,
            note=ctx.note, velocity=ctx.velocity_on,
            binding=(ctx.cc00, ctx.cc32, ctx.program),
            profile=profile.name, rule=decision.rule,
            semantic=decision.semantic,
            side=decision.side.value if decision.side else None,
            ms_ref=decision.ms_ref.name if decision.ms_ref else "",
            noise=[f"{n.kind}:{n.gain:.2f} ({n.reason})" for n in decision.noise],
            legato=(f"from {decision.legato_from_note}" if decision.legato_from_note is not None else ""),
            glide_ms=decision.glide_ms,
            context={
                "interval": ctx.interval, "gap_ticks": ctx.gap_ticks,
                "duration_ticks": ctx.duration_ticks(),
                "simultaneous_on": ctx.simultaneous_on,
                "noise_register": ctx.note >= NOISE_REGISTER_MIN,
                "bar": ctx.bar, "beat": ctx.beat,
            },
        ))
        return decision, profile

    def decide_release(self, profile: SoundProfile, note: int, velocity_on: int,
                       duration_ticks: int) -> list[NoiseTrigger]:
        return release_triggers(profile, note, velocity_on,
                                duration_ticks, self.ticks_per_beat)

    def decide_damper(self, profile: SoundProfile, pressed: bool,
                      velocity_hint: int) -> list[NoiseTrigger]:
        return damper_triggers(profile, pressed, velocity_hint)

    def pressure(self, profile: SoundProfile, value: float) -> dict:
        return pressure_response(profile, value)

    # ---------------------------------------------------------------- report
    def report(self) -> dict:
        from collections import Counter
        semantics = Counter(r.semantic for r in self.records)
        rules = Counter(r.rule for r in self.records)
        noise = Counter(n.split(":")[0] for r in self.records for n in r.noise)
        return {
            "decisions": len(self.records),
            "by_rule": dict(rules.most_common()),
            "by_semantic": dict(semantics.most_common()),
            "noise_triggers": dict(noise.most_common()),
            "records": [r.to_dict() for r in self.records],
        }

    def clear_records(self) -> None:
        self.records.clear()
