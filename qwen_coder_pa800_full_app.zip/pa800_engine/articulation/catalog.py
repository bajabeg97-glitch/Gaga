"""SoundCatalog — učitava dokazne registre u okidne profile (immutable)."""
from __future__ import annotations

import json
import os
from pathlib import Path

from ..constants import key_index
from .profiles import (
    DncBehavior, DrumKeyLayer, FallbackProfile, MsRef, OscLayer,
    SoundKind, SoundProfile,
)

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def _data_path(name: str) -> Path:
    env = os.environ.get("PA800_ENGINE_DATA")
    if env and (Path(env) / name).is_file():
        return Path(env) / name
    return DATA_DIR / name


def _key_zone(zone) -> tuple[int, int]:
    if not zone or len(zone) != 2:
        return (0, 127)
    try:
        return key_index(str(zone[0])), key_index(str(zone[1]))
    except ValueError:
        return (0, 127)


def _family_for(name: str, pc: int) -> str:
    n = name.casefold()
    if "guitar" in n or "gtr" in n:
        return "GUITAR"
    if "bass" in n or pc in (32, 33, 34, 35, 36, 37, 38, 39):
        return "BASS"
    if "organ" in n:
        return "ORGAN"
    if "piano" in n or "ep" in n or "e.p" in n:
        return "PIANO"
    if "harmonica" in n or "sax" in n or "trumpet" in n or "cornet" in n or "trombone" in n or "clarinet" in n or "flute" in n or "whistle" in n:
        return "WIND"
    if "str" in n or "scat" in n:
        return "ENSEMBLE"
    return "GENERAL"


class SoundCatalog:
    """Dokazane mape:

    * 10 RX zvuka sa HW profilima (layer po layer),
    * 23 DNC zvuka (noise ponašanje po imenu/porodici),
    * 21 RX drum kit (per-key decay slojevi),
    * fallback GM profili za ostala bindinga.
    """

    def __init__(self, data_dir: Path | None = None):
        self.data_dir = data_dir or DATA_DIR
        self._by_binding: dict[tuple[int, int, int], SoundProfile] = {}
        self._kits: dict[tuple[int, int, int], SoundProfile] = {}
        self.evidence: list[str] = []
        self._factory_names: dict[tuple[int, int, int], str] = {}
        self._popstd_vel: dict[int, dict] = {}
        self._load()

    # ------------------------------------------------------------ load
    def _load(self) -> None:
        special = self._read("PA800_FACTORY_SPECIAL_REGISTRY_v2.json", required=False)
        osc_reg = self._read("RX_OSCILLATOR_REGISTRY_v3.json", required=False)
        hw = self._read("PA800_HARDWARE_VERIFIED_OSC_PROFILES.json", required=False)
        caps = self._read("RX_SOUND_CAPABILITIES_v1.json", required=False)
        factory_list = self._read("PA800_FACTORY_SOUND_LIST_v1.json", required=False)
        popstd = self._read("PA800_DRUM_KIT_POP_STD_VEL_LAYERS_v1.json", required=False)

        # 0) Factory sound lista (1003 bindinga) → imena za fallback profilovanje
        for row in factory_list.get("bindings", []):
            self._factory_names[(int(row["cc00"]), int(row["cc32"]), int(row["pc"]))] = \
                str(row["name"])
        self.evidence.append(f"factory sound list: {len(self._factory_names)} bindings")

        # 0b) Pop Std. Kit RX — verificirani per-key velocity layer-i sa uređaja
        if popstd.get("kit", {}).get("pc") == 4:
            for key in popstd.get("keys", []):
                self._popstd_vel[int(key["note"])] = key
            self.evidence.append(
                f"pop std kit vel layers: {len(self._popstd_vel)} keys (HARDWARE_OBSERVED)")

        # 1) RX zvukovi sa hardware-verified layer profilima
        for key, prof in hw.items():
            ident = prof.get("identity", {})
            cc00, cc32, pc = (int(ident.get("cc00", 0)), int(ident.get("cc32", 0)),
                              int(ident.get("pc", 0)))
            layers: list[OscLayer] = []
            for osc in prof.get("oscillators", []):
                vel = osc.get("velocity_zone") or [1, 127]
                kz = _key_zone(osc.get("key_zone"))
                low = osc.get("low") or None
                high = osc.get("high") or None
                layers.append(OscLayer(
                    slot=int(osc.get("osc", 0)),
                    role=str(osc.get("semantic_role", "TONAL")),
                    vel_lo=int(vel[0]), vel_hi=int(vel[1]),
                    key_lo=kz[0], key_hi=kz[1],
                    switch=osc.get("vel_switch_l_to_h"),
                    low=MsRef(low.get("id"), low.get("name", "?"),
                              tuple(low.get("tags") or ())) if low else None,
                    high=MsRef(high.get("id"), high.get("name", "?"),
                               tuple(high.get("tags") or ())) if high else None,
                ))
            layers.sort(key=lambda l: l.slot)
            self._by_binding[(cc00, cc32, pc)] = SoundProfile(
                name=ident.get("name", key), cc00=cc00, cc32=cc32, pc=pc,
                kind=SoundKind.RX,
                family=next((r.get("family") for r in special.get("rx_sounds", [])
                             if (r.get("cc00"), r.get("cc32"), r.get("pc")) == (cc00, cc32, pc)),
                            _family_for(ident.get("name", ""), pc)),
                voice_assign=str(prof.get("voice_assign") or "Poly"),
                layers=tuple(layers),
                status=str(prof.get("status", "")),
            )
        self.evidence.append(f"hardware profiles: {len(hw)}")

        # 2) DNC zvukovi — okidno ponašanje iz imena/porodice
        for row in special.get("dnc_sounds", []):
            cc00, cc32, pc = int(row["cc00"]), int(row["cc32"]), int(row["pc"])
            name = str(row.get("name", "?"))
            fam = _family_for(name, pc)
            layers = tuple([OscLayer(1, "TONAL", 1, 127, 0, 95, None,
                                     MsRef(None, f"{name} Tonal"), MsRef(None, f"{name} Tonal"))])
            self._by_binding[(cc00, cc32, pc)] = SoundProfile(
                name=name, cc00=cc00, cc32=cc32, pc=pc, kind=SoundKind.DNC,
                family=fam, voice_assign="Poly", layers=layers,
                dnc=self._dnc_behavior(name, fam), status="FACTORY_CATALOG_VERIFIED",
            )
        self.evidence.append(f"dnc sounds: {len(special.get('dnc_sounds', []))}")

        # 3) RX drum kitovi — eksaktne adrese iz factory korpusa
        drum_evidence = osc_reg.get("drum_key_layer_evidence", {})
        for row in special.get("rx_drum_kits", []):
            if row.get("factory_address_status") != "EXACT_FACTORY_CORPUS":
                continue
            binding = (int(row["factory_corpus_cc00"]), int(row["factory_corpus_cc32"]),
                       int(row["factory_corpus_pc"]))
            self._kits[binding] = SoundProfile(
                name=str(row.get("name", "RX Kit")), cc00=binding[0], cc32=binding[1],
                pc=binding[2], kind=SoundKind.RX_DRUM_KIT, family="DRUMS",
                voice_assign="Poly", layers=(),
                drum_layers=self._drum_layers(str(row.get("name", "")), drum_evidence),
                status=str(row.get("evidence_status_v2", "")),
            )
        self.evidence.append(f"rx drum kits: {len(self._kits)}")

        # 4) RX velocity-window kandidati bez HW profila → čuvamo kao fallback
        #    (windows su PRAZNE za UNRESOLVED_PRESERVE — engine ih NE promovira)
        self._window_stats = {
            "rx_capability_identities": len(caps.get("sounds", [])),
            "window_proven_sounds": sum(1 for s in caps.get("sounds", []) if s.get("windows")),
        }

    def _dnc_behavior(self, name: str, family: str) -> DncBehavior:
        n = name.casefold()
        if "damper" in n:
            return DncBehavior(damper_noise=True, release_noise=True, noise_gain=1.0)
        if "organ" in n:
            return DncBehavior(attack_click=True, release_noise=True, noise_gain=0.9)
        if family == "GUITAR":
            return DncBehavior(fret_release=True, release_noise=True, noise_gain=0.8)
        if family == "WIND" or "harmonica" in n:
            return DncBehavior(breath_attack=True, pressure_kind="growl", release_noise=True, noise_gain=0.85)
        if family == "ENSEMBLE":
            return DncBehavior(release_noise=True, noise_gain=0.5)
        return DncBehavior(release_noise=True, noise_gain=0.6)

    def _drum_layers(self, kit_name: str, evidence: dict) -> tuple[DrumKeyLayer, ...]:
        n = kit_name.casefold()
        brush = "brush" in n
        # Pop Std. Kit RX: verificirana per-key mapa → tačni slojevi po noti
        if "pop std" in n and self._popstd_vel:
            return self._drum_layers_popstd()
        # GM-konformni opsezi (Korg kitovi slijede iste core opsege)
        layers: list[DrumKeyLayer] = [
            DrumKeyLayer(0, 34, None, 180.0, 0.35, "Perc Attack"),
            DrumKeyLayer(35, 36, 52.0 if not brush else 88.0, 520.0, 0.22, "Kick"),
            DrumKeyLayer(37, 37, 180.0, 160.0, 0.62, "Cross Stick"),
            DrumKeyLayer(38, 40, 190.0, 200.0, 0.82 if brush else 0.66, "Snare"),
            DrumKeyLayer(41, 41, 100.0, 330.0, 0.30, "Low Tom"),
            DrumKeyLayer(42, 42, None, 90.0, 0.75, "HiHat Closed"),
            DrumKeyLayer(43, 43, 105.0, 320.0, 0.32, "Tom"),
            DrumKeyLayer(44, 44, None, 140.0, 0.60, "HiHat Pedal"),
            DrumKeyLayer(45, 45, 110.0, 320.0, 0.34, "Tom"),
            DrumKeyLayer(46, 46, None, 420.0, 0.85, "HiHat Open"),
            DrumKeyLayer(47, 48, 130.0, 300.0, 0.40, "Mid Tom"),
            DrumKeyLayer(49, 49, None, 800.0, 0.95, "Crash"),
            DrumKeyLayer(50, 50, 160.0, 270.0, 0.45, "High Tom"),
            DrumKeyLayer(51, 51, None, 900.0, 0.90, "Ride"),
            DrumKeyLayer(52, 57, None, 640.0, 0.78, "Crash/Splash"),
            DrumKeyLayer(58, 59, 320.0, 260.0, 0.55, "Agogo/Tri"),
            DrumKeyLayer(60, 76, 300.0, 150.0, 0.50, "Hi Perc"),
            DrumKeyLayer(77, 127, None, 220.0, 0.58, "Perc Noise"),
        ]
        return tuple(layers)

    def _drum_layers_popstd(self) -> tuple[DrumKeyLayer, ...]:
        """Pop Std. Kit RX: per-key slojevi isključivo iz verificirane mape.

        Taste koje mapa ne pokriva čuva GM-isklopljeni opseg (iste bande
        kao i u opštoj mapi) — ništa se ne umanjuje, samo se precizira.
        """
        tone_map = {
            "kick": 52.0, "snare": 190.0, "rim": 210.0, "hat": None,
            "ride": None, "crash": None, "tom": 140.0,
        }
        decay_map = {
            "kick": 520.0, "snare": 210.0, "rim": 150.0, "hat": 110.0,
            "ride": 900.0, "crash": 800.0, "tom": 300.0,
        }
        bright_map = {
            "kick": 0.22, "snare": 0.66, "rim": 0.58, "hat": 0.78,
            "ride": 0.90, "crash": 0.92, "tom": 0.40,
        }

        def style(label: str) -> str:
            l = label.casefold()
            if "kick" in l:
                return "kick"
            if "rim" in l or "edge" in l:
                return "rim"
            if "snare" in l:
                return "snare"
            if "hat" in l or "hi-hat" in l:
                return "hat"
            if "ride" in l:
                return "ride"
            if "crash" in l:
                return "crash"
            if "tom" in l:
                return "tom"
            return "hat"

        layers: list[DrumKeyLayer] = []
        covered: set[int] = set()
        for note in sorted(self._popstd_vel.keys()):
            key = self._popstd_vel[note]
            label = str(key["label"])
            st = style(label)
            vel_layers = tuple((int(lo), int(hi), str(sub))
                               for lo, hi, sub in key.get("vel_layers", []))
            layers.append(DrumKeyLayer(
                note_lo=note, note_hi=note,
                tone_hz=tone_map[st],
                decay_ms=decay_map[st],
                noise_brightness=bright_map[st],
                name=label,
                osc_count=int(key.get("osc_count", 1)),
                vel_layers=vel_layers,
            ))
            covered.add(note)

        # ostatak mapa po istoj GM shemi (samostalni bandovi u opšteju mapi)
        for lo, hi, tone_hz, decay_ms, bright, name in [
            (0, 34, None, 180.0, 0.35, "Perc Attack"),
            (37, 37, 180.0, 160.0, 0.62, "Cross Stick"),
            (39, 39, 180.0, 160.0, 0.62, "Hand Clap"),
            (42, 42, None, 90.0, 0.75, "HiHat Closed GM"),
            (46, 46, None, 420.0, 0.85, "HiHat Open GM"),
            (49, 49, None, 800.0, 0.95, "Crash GM"),
            (51, 54, None, 640.0, 0.78, "Crash/Splash"),
            (55, 57, None, 640.0, 0.78, "Crash/Splash 2"),
            (58, 59, 320.0, 260.0, 0.55, "Agogo/Tri"),
            (60, 76, 300.0, 150.0, 0.50, "Hi Perc"),
            (77, 127, None, 220.0, 0.58, "Perc Noise"),
        ]:
            if lo == hi and lo in covered:
                continue
            layers.append(DrumKeyLayer(lo, hi, tone_hz, decay_ms, bright, name))
        return tuple(sorted(layers, key=lambda l: (l.note_lo, l.note_hi)))

    def _read(self, name: str, required: bool) -> dict:
        path = _data_path(name)
        if not path.is_file():
            if required:
                raise FileNotFoundError(f"Evidence fajl nedostaje: {path}")
            return {}
        return json.loads(path.read_text(encoding="utf-8"))

    # ------------------------------------------------------------ API
    def profile(self, cc00: int, cc32: int, pc: int, drum_channel: bool = False) -> SoundProfile:
        binding = (int(cc00), int(cc32), int(pc))
        if drum_channel and binding in self._kits:
            return self._kits[binding]
        prof = self._by_binding.get(binding)
        if prof is not None:
            return prof
        if drum_channel:
            return self._kits.get((120, 0, 4)) or SoundProfile(
                name="GM Drums", cc00=120, cc32=0, pc=0, kind=SoundKind.RX_DRUM_KIT,
                family="DRUMS", drum_layers=self._drum_layers("", {}))
        factory_name = self._factory_names.get(binding)
        if factory_name is not None:
            family = self._family_guess(factory_name, pc)
            return FallbackProfile(pc, name=factory_name, family=family,
                                   cc00=cc00, cc32=cc32, factory_exact=True)
        return FallbackProfile(pc)

    def _family_guess(self, name: str, pc: int) -> str:
        """Family procjena iz factory imena + GM PC grupa (za fallback profile)."""
        by_name = _family_for(name, pc)
        if by_name != "GENERAL":
            return by_name
        # GM band mapa (pc grupa, 8 programa po grupi)
        band = [
            "PIANO", "KEYBOARD", "ORGAN", "GUITAR",
            "BASS", "STRINGS", "ENSEMBLE", "BRASS",
            "WIND", "PIPE", "SYNTH", "SYNTH",
            "SYNTH", "SYNTH", "ETHNIC", "PERC",
        ]
        return band[min(15, pc // 8)]

    def factory_name(self, cc00: int, cc32: int, pc: int) -> str | None:
        return self._factory_names.get((int(cc00), int(cc32), int(pc)))

    def rx_profiles(self) -> list[SoundProfile]:
        return [p for p in self._by_binding.values() if p.kind is SoundKind.RX]

    def dnc_profiles(self) -> list[SoundProfile]:
        return [p for p in self._by_binding.values() if p.kind is SoundKind.DNC]

    def kits(self) -> list[SoundProfile]:
        return list(self._kits.values())

    def stats(self) -> dict:
        return {
            "profiles": len(self._by_binding),
            "rx": len(self.rx_profiles()),
            "dnc": len(self.dnc_profiles()),
            "kits": len(self._kits),
            "evidence": list(self.evidence),
            **self._window_stats,
        }
