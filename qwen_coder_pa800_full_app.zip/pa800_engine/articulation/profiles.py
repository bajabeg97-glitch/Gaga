"""Model zvuka za Articulation Engine — vjerni preslik dokazanih HW profila.

Izvori (read-only evidence u `pa800_engine/data/`):
  * PA800_HARDWARE_VERIFIED_OSC_PROFILES.json — oscilatori, velocity zone,
    key zone (C-1..B6 tonalno / C7..G9 noise), vel_switch_l_to_h, multisample
    identiteti sa tagovima (SLAP/SLIDE/DEAD/MUTE/HARMONIC/PICK/GLISS/…)
  * RX_SOUND_CAPABILITIES_v1.json            — 10 zvuka sa dokazanim zonama
  * PA800_FACTORY_SPECIAL_REGISTRY_v2.json   — 44 RX + 23 DNC + 21 RX kit
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class SwitchSide(str, Enum):
    LOW = "LOW"
    HIGH = "HIGH"


class SoundKind(str, Enum):
    RX = "RX"
    DNC = "DNC"
    RX_DRUM_KIT = "RX_DRUM_KIT"
    FALLBACK = "FALLBACK"


class NoiseKind(str, Enum):
    """Mehanički šumovi koje engine zna okinuti (odvojeni od tona)."""
    FRET = "fret-noise"
    SLIDE = "slide-noise"
    HARMONIC_NOISE = "harmonic-noise"
    STOP_SCRAPE = "stop-scrape"
    KEY_CLICK_ATTACK = "key-click-attack"
    KEY_CLICK_RELEASE = "key-click-release"
    DAMPER_DOWN = "damper-down-noise"
    DAMPER_UP = "damper-up-noise"
    BREATH = "breath-noise"
    GROWL = "growl-noise"
    RX_REGISTER = "rx-register-noise"      # C7+ eksplicitni trigger


@dataclass(frozen=True, slots=True)
class NoiseSpec:
    """DSP opis jednog šuma — render je determinističan (seed po događaju)."""
    kind: NoiseKind
    center_hz: float
    decay_ms: float
    brightness: float        # 0..1 — otvaranje LP simulacije
    gain: float              # osnovno pojačanje relativno prema 0..1


NOISE_TABLE: dict[NoiseKind, NoiseSpec] = {
    NoiseKind.FRET:              NoiseSpec(NoiseKind.FRET, 1_800.0,  90.0, 0.55, 0.34),
    NoiseKind.SLIDE:             NoiseSpec(NoiseKind.SLIDE, 2_400.0, 320.0, 0.65, 0.30),
    NoiseKind.HARMONIC_NOISE:    NoiseSpec(NoiseKind.HARMONIC_NOISE, 4_100.0, 400.0, 0.80, 0.22),
    NoiseKind.STOP_SCRAPE:       NoiseSpec(NoiseKind.STOP_SCRAPE, 1_200.0, 110.0, 0.40, 0.26),
    NoiseKind.KEY_CLICK_ATTACK:  NoiseSpec(NoiseKind.KEY_CLICK_ATTACK, 3_200.0,  45.0, 0.70, 0.20),
    NoiseKind.KEY_CLICK_RELEASE: NoiseSpec(NoiseKind.KEY_CLICK_RELEASE, 2_600.0,  70.0, 0.60, 0.16),
    NoiseKind.DAMPER_DOWN:       NoiseSpec(NoiseKind.DAMPER_DOWN, 900.0, 650.0, 0.45, 0.30),
    NoiseKind.DAMPER_UP:         NoiseSpec(NoiseKind.DAMPER_UP, 1_100.0, 400.0, 0.50, 0.22),
    NoiseKind.BREATH:            NoiseSpec(NoiseKind.BREATH, 5_000.0, 240.0, 0.85, 0.18),
    NoiseKind.GROWL:             NoiseSpec(NoiseKind.GROWL, 260.0, 600.0, 0.30, 0.40),
    NoiseKind.RX_REGISTER:       NoiseSpec(NoiseKind.RX_REGISTER, 2_000.0, 180.0, 0.60, 0.50),
}


@dataclass(frozen=True, slots=True)
class MsRef:
    """Referenca na multisample (naziv/id/tagovi iz HW dokaza)."""
    id: int | None
    name: str
    tags: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class OscLayer:
    """Jedan oscilator unutar RX zvuka (dokazana zona + opciono switch spajanje)."""
    slot: int                    # 1..5
    role: str                    # npr. WORKING_CLEAN_GUITAR
    vel_lo: int
    vel_hi: int
    key_lo: int
    key_hi: int
    switch: int | None = None    # vel_switch_l_to_h: <N → LOW, >=N → HIGH
    low: MsRef | None = None
    high: MsRef | None = None

    def matches(self, note: int, velocity: int) -> bool:
        return self.vel_lo <= velocity <= self.vel_hi and self.key_lo <= note <= self.key_hi

    def side_for(self, velocity: int) -> SwitchSide:
        if self.switch is None:
            return SwitchSide.HIGH
        return SwitchSide.LOW if velocity < self.switch else SwitchSide.HIGH

    def ref_for(self, side: SwitchSide) -> MsRef | None:
        return self.low if side is SwitchSide.LOW else self.high


@dataclass(frozen=True, slots=True)
class DncBehavior:
    """Ponašanje DNC zvuka (noise slojevi okinuti izvedbom, ne velocity mapom)."""
    attack_click: bool = False      # key-click na attack (orgulje)
    release_noise: bool = False     # key-click / fret release na note-off
    damper_noise: bool = False      # CC64 prijelazi okidaju damper šum
    fret_release: bool = False      # gitarski fret squeal na note-off
    breath_attack: bool = False     # duvački noise u attack fazi
    pressure_kind: str = ""         # "growl" | "vibrato" | "" — channel pressure mapiranje
    noise_gain: float = 1.0


@dataclass(frozen=True, slots=True)
class DrumKeyLayer:
    """Per-note drum sloj. Za verificirane kitove može nositi i diskretne
    velocity pod-slojeve (`vel_layers`: [(lo, hi, label), ...]) po dokazu
    sa hardware-a (npr. Snare: 6 slojeva pp..ff)."""
    note_lo: int
    note_hi: int
    tone_hz: float | None          # None → čisti noise (činela/hat)
    decay_ms: float
    noise_brightness: float
    name: str = ""
    osc_count: int = 1             # broj oscillatora (dokaz sa uređaja; 1 = bez pod-slojeva)
    vel_layers: tuple[tuple[int, int, str], ...] = ()

    def sub_for(self, velocity: int) -> tuple[int, str]:
        """(index, label) pod-sloja po velocity-ju. Bez pod-slojeva → (0, '')."""
        for idx, (lo, hi, label) in enumerate(self.vel_layers):
            if lo <= velocity <= hi:
                return idx, label
        return (len(self.vel_layers) - 1, "") if self.vel_layers else (0, "")

    def sub_brightness(self, velocity: int) -> float:
        """Deterministička relativna svjetlina pod-sloja (pp=mekše, ff=svjetlije)."""
        if not self.vel_layers or len(self.vel_layers) < 2:
            return self.noise_brightness
        idx, _ = self.sub_for(velocity)
        t = idx / max(1, len(self.vel_layers) - 1)
        return self.noise_brightness * (0.62 + 0.38 * t)

    @property
    def vel_switch_points(self) -> tuple[int, ...]:
        return tuple(lo for lo, _, _ in self.vel_layers[1:])


@dataclass(slots=True)
class SoundProfile:
    """Kompletan okidni profil jednog zvuka na jednoj adresi (cc00.cc32.pc)."""
    name: str
    cc00: int
    cc32: int
    pc: int
    kind: SoundKind
    family: str = "GENERAL"
    voice_assign: str = "Poly"
    layers: tuple[OscLayer, ...] = ()
    dnc: DncBehavior | None = None
    drum_layers: tuple[DrumKeyLayer, ...] = ()
    status: str = ""

    @property
    def binding(self) -> tuple[int, int, int]:
        return (self.cc00, self.cc32, self.pc)

    @property
    def is_rx(self) -> bool:
        return self.kind is SoundKind.RX

    @property
    def noise_layer(self) -> OscLayer | None:
        for layer in self.layers:
            if layer.role.startswith("RX_NOISE"):
                return layer
        return None

    def tonal_layers(self) -> tuple[OscLayer, ...]:
        return tuple(l for l in self.layers if not l.role.startswith("RX_NOISE"))

    def layer_at(self, note: int, velocity: int) -> OscLayer | None:
        best: OscLayer | None = None
        for layer in self.tonal_layers():
            if layer.matches(note, velocity):
                if best is None or (layer.key_hi - layer.key_lo) < (best.key_hi - best.key_lo):
                    best = layer
        return best

    def drum_layer(self, note: int) -> DrumKeyLayer | None:
        for layer in self.drum_layers:
            if layer.note_lo <= note <= layer.note_hi:
                return layer
        return None


@dataclass(slots=True)
class FallbackProfile(SoundProfile):
    """Zvuk bez RX dokaza — jedan tonalni sloj, bez šumova.

    Ako binding postoji u factory sound listi (PA800_FACTORY_SOUND_LIST_v1),
    profil dobije pravo ime i family procjenu — ipak ostaje FALLBACK
    (oscillator struktura je nepoznata, dokaz nije nadodan).
    """

    brightness: float = 0.5

    def __init__(self, pc: int, name: str | None = None, family: str | None = None,
                 cc00: int = 0, cc32: int = 0, factory_exact: bool = False):
        brightness = 0.45 + 0.5 * (1.0 - abs(pc - 48) / 127.0)
        label = name or f"GM Program {pc}"
        super().__init__(
            name=label, cc00=cc00, cc32=cc32, pc=pc,
            kind=SoundKind.FALLBACK, family=family or "GM", voice_assign="Poly",
            layers=(OscLayer(1, "TONAL", 1, 127, 0, 127, None,
                             MsRef(None, label), MsRef(None, label)),),
            dnc=None, drum_layers=(),
            status="FALLBACK_FACTORY_EXACT" if factory_exact else "FALLBACK",
        )
        object.__setattr__(self, "brightness", brightness)


def spec_for(kind: "NoiseKind") -> "NoiseSpec":
    """Vraća akustičku specifikaciju za datu vrstu RX/DNC šuma."""
    return NOISE_TABLE[kind]
