"""PA800 Engine — Tkinter GUI (direktno vezan na pipeline).

Tabovi:
  1. Render       — MAX DEMO ili SMF ulaz → render → WAV + report
  2. Izvještaj    — prepared summary + articulation brojači + voice stats
  3. Rekordi      — tabularni pregled svake odluke (binding, rule, sem,
                    side, multisample, noise trigaderi, legato, glide)
  4. Katalog      — RX/DNC/kit listing uz dokazno porijeklo

GUI je čist "view + orchestrator": sav posao ide u pozadinsku nit,
rezultat se vraća u glavnu (Tk) nit preko `after` pollinga.
"""
from __future__ import annotations

import json
import threading
import traceback
import wave
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import numpy as np

from .demo import build_max_demo
from .engine import Pa800Engine, RenderResult
from .constants import (
    BLOCK_SIZE_DEFAULT, LOOKAHEAD_MS_DEFAULT, SAMPLE_RATE_DEFAULT,
    VOICE_POOL_DEFAULT, key_name,
)

APP_TITLE = "Baja Music — PA800 Engine Studio"
_GREY = "#1e1f24"
_PANEL = "#26282e"
_TEXT = "#e8e8ea"
_ACCENT = "#4f9dff"
_OK = "#8fd18a"


class EngineStudioApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1180x780")
        self.minsize(1000, 640)
        self._style()
        self.engine = Pa800Engine()
        self.prepared = None
        self.result: RenderResult | None = None
        self.midi_path = tk.StringVar(value="")
        self.out_path = tk.StringVar(value="max_demo.wav")
        self.status = tk.StringVar(value="Spremno.")
        self._worker: threading.Thread | None = None
        self._build_tabs()
        self._build_status()

    # ------------------------------------------------------------ stil
    def _style(self) -> None:
        self.configure(bg=_GREY)
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("TFrame", background=_GREY)
        st.configure("TLabel", background=_GREY, foreground=_TEXT)
        st.configure("TButton", background=_ACCENT, foreground="white",
                     padding=6, relief="flat")
        st.map("TButton", background=[("active", "#3677d4")])
        st.configure("TNotebook", background=_GREY)
        st.configure("TNotebook.Tab", background=_PANEL, foreground=_TEXT,
                     padding=["12", "6"])
        st.map("TNotebook.Tab", background=[("selected", _ACCENT)],
               foreground=[("selected", "white")])
        st.configure("Treeview", background=_PANEL, foreground=_TEXT,
                     fieldbackground=_PANEL, rowheight=22)
        st.configure("Treeview.Heading", background="#34363d", foreground=_TEXT)

    def _build_status(self) -> None:
        bar = ttk.Frame(self)
        bar.pack(side=tk.BOTTOM, fill=tk.X)
        ttk.Label(bar, textvariable=self.status, anchor=tk.W,
                  padding=("10", "6")).pack(fill=tk.X)

    def _build_tabs(self) -> None:
        nb = ttk.Notebook(self)
        nb.pack(fill=tk.BOTH, expand=True)
        self._tab_render(nb)
        self._tab_report(nb)
        self._tab_records(nb)
        self._tab_catalog(nb)

    # ------------------------------------------------------------ tab 1: render
    def _tab_render(self, nb: ttk.Notebook) -> None:
        f = ttk.Frame(nb)
        nb.add(f, text="  Render  ")
        top = ttk.Frame(f)
        top.pack(fill=tk.X, padx=10, pady=10)

        ttk.Button(top, text="▶ Render: MAX DEMO", command=self.on_render_demo
                   ).grid(row=0, column=0, padx=4)
        ttk.Button(top, text="▶ Render: brza varijanta (simple)",
                   command=lambda: self.on_render_demo(simple=True)
                   ).grid(row=0, column=1, padx=4)
        ttk.Button(top, text="Učitaj SMF…", command=self.on_pick_midi
                   ).grid(row=0, column=2, padx=4)
        ttk.Button(top, text="▶ Render SMF", command=self.on_render_midi
                   ).grid(row=0, column=3, padx=4)
        ttk.Button(top, text="Snimi izvještaj…", command=self.on_save_report
                   ).grid(row=0, column=4, padx=4)

        row = ttk.Frame(f)
        row.pack(fill=tk.X, padx=10)
        ttk.Label(row, text="SMF ulaz:").pack(side=tk.LEFT)
        ttk.Entry(row, textvariable=self.midi_path, width=70).pack(side=tk.LEFT, padx=6)
        row2 = ttk.Frame(f)
        row2.pack(fill=tk.X, padx=10, pady=6)
        ttk.Label(row2, text="Izlazni WAV:").pack(side=tk.LEFT)
        ttk.Entry(row2, textvariable=self.out_path, width=70).pack(side=tk.LEFT, padx=6)

        self.txt_render = tk.Text(f, bg=_PANEL, fg=_TEXT, relief="flat",
                                  font=("Consolas", 10), state=tk.DISABLED)
        self.txt_render.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def _log(self, text: str) -> None:
        self.txt_render.configure(state=tk.NORMAL)
        self.txt_render.insert(tk.END, text + "\n")
        self.txt_render.see(tk.END)
        self.txt_render.configure(state=tk.DISABLED)

    # ------------------------------------------------------------ tab 2: report
    def _tab_report(self, nb: ttk.Notebook) -> None:
        f = ttk.Frame(nb)
        nb.add(f, text="  Izvještaj  ")
        self.txt_report = tk.Text(f, bg=_PANEL, fg=_TEXT, relief="flat",
                                  font=("Consolas", 10), state=tk.DISABLED)
        self.txt_report.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

    def _report_text(self) -> None:
        self.txt_report.configure(state=tk.NORMAL)
        self.txt_report.delete("1.0", tk.END)
        if self.result is None:
            self.txt_report.insert(tk.END, "Nema renderanog rezultata.")
        else:
            d = self.result.report_dict()
            self.txt_report.insert(tk.END, json.dumps(d, indent=2, ensure_ascii=False))
        self.txt_report.configure(state=tk.DISABLED)

    # ------------------------------------------------------------ tab 3: records
    def _tab_records(self, nb: ttk.Notebook) -> None:
        f = ttk.Frame(nb)
        nb.add(f, text="  Rekordi (odluke)  ")
        cols = ("sample", "tick", "ch", "note", "vel", "binding", "profile",
                "rule", "sem", "side", "ms", "noise", "legato", "glide")
        self.tree = ttk.Treeview(f, columns=cols, show="headings")
        widths = (90, 70, 40, 50, 40, 90, 190, 150, 150, 50, 180, 100, 70, 60)
        names = ("Sample", "Tick", "Kanal", "Nota", "Vel", "Binding",
                 "Profil", "Rule", "Semantika", "Side", "Multisample",
                 "Noise", "Legato", "Glide ms")
        for col, w, n in zip(cols, widths, names):
            self.tree.heading(col, text=n)
            self.tree.column(col, width=w, anchor=tk.W)
        sb = ttk.Scrollbar(f, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(10, 0), pady=10)
        sb.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 10), pady=10)

    def _fill_records(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)
        if self.result is None:
            return
        for r in self.result.articulation_report["records"]:
            self.tree.insert("", tk.END, values=(
                r["sample"], r["tick"], r["channel"], key_name(r["note"]),
                r["velocity"], "-".join(str(x) for x in r["binding"]),
                r["profile"], r["rule"], r["articulation"],
                r["side"] or "-", r["multisample"] or "-",
                len(r["noise_triggers"]), r["legato"] or "-",
                r["glide_ms"] or "-",
            ))

    # ------------------------------------------------------------ tab 4: katalog
    def _tab_catalog(self, nb: ttk.Notebook) -> None:
        f = ttk.Frame(nb)
        nb.add(f, text="  Katalog  ")
        self.txt_catalog = tk.Text(f, bg=_PANEL, fg=_TEXT, relief="flat",
                                   font=("Consolas", 10), state=tk.NORMAL)
        self.txt_catalog.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        stats = self.engine.catalog_stats()
        rows = [f"Ukupno profila: {stats['profiles']}  "
                f"(RX={stats['rx']}, DNC={stats['dnc']}, kitovi={stats['kits']})",
                f"Evidence: {', '.join(stats['evidence'])}",
                f"Identiteta u capability registryju: {stats['rx_capability_identities']}  "
                f"| velocity windows potvrđeno: {stats['window_proven_sounds']}",
                ""]
        for p in self.engine.catalog.rx_profiles():
            rows.append(f"  RX    {p.cc00}.{p.cc32}.{p.pc:<3}  {p.name:<24} layers={len(p.layers)}"
                        f" status={p.status}")
        for p in self.engine.catalog.dnc_profiles():
            rows.append(f"  DNC   {p.cc00}.{p.cc32}.{p.pc:<3}  {p.name:<24} family={p.family}")
        for p in self.engine.catalog.kits():
            rows.append(f"  KIT   {p.cc00}.{p.cc32}.{p.pc:<3}  {p.name}")
        self.txt_catalog.insert(tk.END, "\n".join(rows))
        self.txt_catalog.configure(state=tk.DISABLED)

    # ------------------------------------------------------------ akcije
    def on_pick_midi(self) -> None:
        path = filedialog.askopenfilename(
            title="Odaberi SMF fajl",
            filetypes=[("Standard MIDI File", "*.mid *.smf"), ("Svi fajlovi", "*.*")])
        if path:
            self.midi_path.set(path)
            self.status.set(f"SMF: {path}")

    def on_render_demo(self, simple: bool = False) -> None:
        if self._worker and self._worker.is_alive():
            return
        tpq, events, name = build_max_demo(simple=simple)
        self.status.set("Renderujem demo…")
        self._start_worker(lambda eng: (eng.ingest_events(events, tpq=tpq, name=name), name))

    def on_render_midi(self) -> None:
        if self._worker and self._worker.is_alive():
            return
        path = self.midi_path.get().strip()
        if not path:
            messagebox.showwarning(APP_TITLE, "Najprije učitaj SMF fajl.")
            return
        self.status.set("Renderujem SMF…")
        self._start_worker(lambda eng: (eng.ingest_smf(path), Path(path).name))

    def on_save_report(self) -> None:
        if self.result is None:
            messagebox.showwarning(APP_TITLE, "Nema renderanog rezultata.")
            return
        path = filedialog.asksaveasfilename(
            title="Snimi izvještaj", defaultextension=".json",
            filetypes=[("JSON", "*.json"), ("Svi fajlovi", "*.*")])
        if path:
            self.result.write_report(path)
            self.status.set(f"Izvještaj snimljen: {path}")

    # ------------------------------------------------------------ samo radnja
    def _start_worker(self, make_prepared) -> None:
        self._log("┏ Počinjem render…")
        self.result = None
        self.engine = Pa800Engine()

        def work() -> None:
            try:
                prepared, name = make_prepared(self.engine)
                result = self.engine.render(prepared)
                self.after(0, self._worker_done, result, name, None)
            except Exception:
                self.after(0, self._worker_done, None, "", traceback.format_exc())

        self.prepared = None
        self._worker = threading.Thread(target=work, daemon=True)
        self._worker.start()

    def _worker_done(self, result: RenderResult | None, name: str,
                     error: str | None) -> None:
        if error:
            self._log("✗ Greška u renderu:\n" + error)
            self.status.set("Greška.")
            return
        assert result is not None
        self.result = result
        out = self.out_path.get().strip() or "max_demo.wav"
        result.write_wav(out)
        res = len(result.samples) / 2 / result.sample_rate
        ratio = res / max(result.wall_seconds, 1e-9)
        vs = result.voice_stats
        ar = result.articulation_report
        self._log(f"  ulaz: {name}")
        self._log(f"  render: {res:.2f} s u {result.wall_seconds:.2f} s "
                  f"({ratio:.1f}× realtime), peak={result.peak:.3f}")
        self._log(f"  voice: peak_poly={vs['peak_polyphony']} steals={vs['steals']} "
                  f"noise_voice={vs['noise_voices']} blocks={vs['blocks_rendered']}")
        self._log(f"  notes={result.prepare_summary.get('notes')}, "
                  f"odluka={ar['decisions']}")
        for rule, count in ar["by_rule"].items():
            self._log(f"    {rule:<26} {count}")
        self._log(f"  WAV: {out}")
        self._log("┗ OK")
        self.status.set(f"Gotovo — {out}")
        self._report_text()
        self._fill_records()


def run() -> None:
    app = EngineStudioApp()
    app.mainloop()


if __name__ == "__main__":
    run()
