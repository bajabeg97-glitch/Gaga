@echo off
REM ============================================================
REM  PA800 Engine - test suite (51 test)
REM ============================================================
setlocal
cd /d "%~dp0"
cd ..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
title PA800 Engine - tests
python -m pytest pa800_engine\tests\ -q
pause
