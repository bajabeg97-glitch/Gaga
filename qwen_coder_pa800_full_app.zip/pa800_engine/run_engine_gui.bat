@echo off
REM ============================================================
REM  PA800 Engine - GUI studio
REM ============================================================
setlocal
cd /d "%~dp0"
cd ..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
title PA800 Engine - GUI
python -c "from pa800_engine.gui import run; run()"
if errorlevel 1 (
    echo GRESKA pri pokretanju GUI-a (Tkinter treba biti dostupan).
    pause
)
