"""SongPrepareAnalyzer — analiza MIDI/Event strima prije sinteze.

Po uzoru na logiku Korg RX/DNC Factory "MAX DEMO" pjesme: prepare faza ne
mijenja nijednu izvornu notu; ona **uparuje** note-on/off, računa **frazeni
kontekst** (interval, gap, simultane note, takt/otkucaj), prati **commit
bindinga** (CC0/CC32 → PC) i **kontrolne lanes** (bend, damper, pressure,
mod, volume) — sve što RX/DNC artikulacijski engine treba da odluči koji se
layer / mehanički šum okida.

Dva prolaza: (1) pairing + binding + lanes, (2) kontekst po kanalu.
Nula mutacije ulaza: svaki RawEvent ostaje identičan.
"""
from __future__ import annotations

from collections import defaultdict

from ..constants import (
    CC_BANK_LSB, CC_BANK_MSB, CC_MOD, CC_VOLUME, CC_EXPRESSION,
    CC_PAN, CC_DAMPER, CC_REVERB, CC_CHORUS, DRUM_CHANNEL,
    NOISE_REGISTER_MIN,
)
from ..events import EventKind, RawEvent
from ..clock import TempoMap
from .report import (
    ChannelPrepare, ControlLanePoint, NoteContext, PreparedSong,
)

_TRACKED_CC = {
    CC_VOLUME: "cc7",
    CC_PAN: "cc10",
    CC_EXPRESSION: "cc11",
    CC_REVERB: "cc91",
    CC_CHORUS: "cc93",
}


class SongPrepareAnalyzer:
    """Čist, deterministički analizator strima (bez mutacije ulaza)."""

    def __init__(self, tpq: int = 480):
        if tpq <= 0 or tpq & 0x8000:
            raise ValueError("tpq mora biti pozitivna PPQ vrijednost")
        self.tpq = int(tpq)

    # ------------------------------------------------------------------ API
    def analyze(self, events: list[RawEvent], name: str = "") -> PreparedSong:
        events = sorted(events, key=lambda e: (e.tick, e.seq))
        tempo = TempoMap(self.tpq)
        for e in events:
            if e.kind is EventKind.META_TEMPO:
                tempo.add_tempo(e.tick, int(e.value))
            elif e.kind is EventKind.META_TIMESIG:
                num = int(e.data1) or 4
                den = int(e.data2) or 4
                tempo.add_timesig(e.tick, num, den)
        tempo._finalize()

        channels: dict[int, ChannelPrepare] = {
            ch: ChannelPrepare(ch) for ch in range(16)
        }
        pending_bank: dict[int, list[int]] = defaultdict(lambda: [0, 0])
        active_binding: dict[int, tuple[int, int, int]] = defaultdict(lambda: (0, 0, 0))
        open_notes: dict[tuple[int, int], list[NoteContext]] = defaultdict(list)
        notes: list[NoteContext] = []
        duration_ticks = 0

        for e in events:
            duration_ticks = max(duration_ticks, e.tick)
            if e.kind is EventKind.CONTROL_CHANGE:
                ch = e.channel
                if e.data1 == CC_BANK_MSB:
                    pending_bank[ch][0] = e.data2
                elif e.data1 == CC_BANK_LSB:
                    pending_bank[ch][1] = e.data2
                lanes = channels[ch].lane
                if e.data1 in _TRACKED_CC:
                    lanes.append(ControlLanePoint(
                        e.tick, e.seq, ch, _TRACKED_CC[e.data1], e.data2 / 127.0))
                elif e.data1 == CC_MOD:
                    lanes.append(ControlLanePoint(e.tick, e.seq, ch, "mod", e.data2 / 127.0))
                elif e.data1 == CC_DAMPER:
                    lanes.append(ControlLanePoint(e.tick, e.seq, ch, "damper", 1.0 if e.data2 >= 64 else 0.0))
            elif e.kind is EventKind.PROGRAM_CHANGE:
                ch = e.channel
                pc = e.data1
                bank = pending_bank[ch]
                active_binding[ch] = (bank[0], bank[1], pc)
                channels[ch].bindings.add(active_binding[ch])
            elif e.kind is EventKind.PITCH_BEND:
                channels[e.channel].lane.append(
                    ControlLanePoint(e.tick, e.seq, e.channel, "bend", e.value))
            elif e.kind is EventKind.CHANNEL_PRESSURE:
                channels[e.channel].lane.append(
                    ControlLanePoint(e.tick, e.seq, e.channel, "pressure_ch", e.value))
            elif e.kind is EventKind.POLY_PRESSURE:
                channels[e.channel].lane.append(
                    ControlLanePoint(e.tick, e.seq, e.channel, f"pressure_poly.{e.data1}", e.value))
            elif e.kind is EventKind.NOTE_ON and e.data2 > 0:
                ch = e.channel
                binding = active_binding[ch]
                ctx = NoteContext(
                    seq=e.seq, tick=e.tick, end_tick=e.tick, channel=ch,
                    note=e.data1, velocity_on=e.data2,
                    cc00=binding[0], cc32=binding[1], program=binding[2],
                    bar=1, beat=1,
                    is_noise_register=e.data1 >= NOISE_REGISTER_MIN,
                    is_drum=ch == DRUM_CHANNEL,
                )
                b, bt, ph = tempo.transport(e.tick)
                ctx.bar, ctx.beat, ctx.beat_phase = b, bt, ph
                open_notes[(ch, e.data1)].append(ctx)
                channels[ch].notes.append(ctx)
                notes.append(ctx)
            elif e.kind is EventKind.NOTE_OFF or (e.kind is EventKind.NOTE_ON and e.data2 == 0):
                ch = e.channel
                stack = open_notes.get((ch, e.data1))
                if stack:
                    ctx = stack.pop(0)
                    ctx.end_tick = max(ctx.tick, e.tick)
                    ctx.velocity_off = e.data2 if e.kind is EventKind.NOTE_OFF else 0

        # nezatvorene note: kraj pjesme (hardware ponašanje — ništa ne visi)
        for stack in open_notes.values():
            for ctx in stack:
                ctx.end_tick = max(duration_ticks, ctx.tick)
                ctx.velocity_off = 0

        # drugi prolaz: kontekst fraze po kanalu
        for chp in channels.values():
            chp.notes.sort(key=lambda n: (n.tick, n.seq))
            tick_counts: dict[int, int] = defaultdict(int)
            on_ticks = sorted({n.tick for n in chp.notes})
            for n in chp.notes:
                tick_counts[n.tick] += 1
            tonal = [n for n in chp.notes if not n.is_noise_register]
            prev: NoteContext | None = None
            for n in tonal:
                n.simultaneous_on = tick_counts[n.tick]
                if prev is not None:
                    n.prev_note = prev.note
                    n.interval = abs(n.note - prev.note)
                    n.interval_dir = 0 if n.note == prev.note else (1 if n.note > prev.note else -1)
                    n.gap_ticks = n.tick - prev.end_tick
                    if n.tick > prev.tick or prev is None:
                        prev = n
                else:
                    prev = n
        stats = self._stats(notes, channels, tempo)
        return PreparedSong(
            name=name, tpq=self.tpq, events=events, notes=notes,
            channels={ch: c for ch, c in channels.items() if c.note_count or c.lane},
            tempo_points=list(tempo.tempo_points),
            sig_points=list(tempo.sig_points),
            duration_ticks=duration_ticks, stats=stats,
        )

    # ------------------------------------------------------------ internals
    def _stats(self, notes: list[NoteContext],
               channels: dict[int, ChannelPrepare], tempo: TempoMap) -> dict:
        vel_hist: dict[str, dict[int, int]] = {}
        for n in notes:
            key = f"{n.cc00}.{n.cc32}.{n.program}"
            bucket = vel_hist.setdefault(key, {})
            bucket[n.velocity_on] = bucket.get(n.velocity_on, 0) + 1
        noise_notes = sum(1 for n in notes if n.is_noise_register)
        legato = sum(1 for n in notes if n.legato_candidate)
        chords = sum(1 for n in notes if n.simultaneous_on > 1)
        return {
            "note_on": len(notes),
            "noise_register_notes": noise_notes,
            "legato_candidate_notes": legato,
            "chord_notes": chords,
            "velocity_histogram_by_binding": {
                k: dict(sorted(v.items())) for k, v in sorted(vel_hist.items())
            },
            "tempo_bpm_initial": round(tempo.bpm_at(0), 3),
            "tempo_points": len(tempo.tempo_points),
        }
