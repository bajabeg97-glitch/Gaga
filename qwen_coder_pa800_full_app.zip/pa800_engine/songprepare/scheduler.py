"""PreScheduler — pre-skedžuliranje događaja prije slanja u sintezu.

Kao u Korg firmware-u: kontrolna nit radi unaprijed (compute-ahead), audio
nit samo konzumira. PreScheduler:

1. razrješava SVE tickove u apsolutne sample indekse (TempoMap + MasterClock),
2. emituje stabilno sortiran redoslijed (sample, seq), bez nagomilavanja,
3. daje lookahead prozor (`window`) — RenderLoop uvijek radi s događajima
   koji su već spremni; audio nit ne čeka i ne računa ništa novo.
"""
from __future__ import annotations

from ..clock import MasterClock, TempoMap
from ..events import EventKind, RawEvent, ScheduledEvent
from .report import NoteContext, PreparedSong


class PreScheduler:
    def __init__(self, song: PreparedSong, sample_rate: int):
        self.song = song
        self.clock = MasterClock(sample_rate)
        self.tempo = TempoMap(song.tpq)
        for tick, us in song.tempo_points[1:] if song.tempo_points and song.tempo_points[0][0] == 0 else song.tempo_points:
            self.tempo.add_tempo(tick, us)
        for tick, num, den in song.sig_points:
            if tick != 0 or num != 4 or den != 4:
                self.tempo.add_timesig(tick, num, den)
        self.tempo._finalize()
        self._schedule: list[ScheduledEvent] = []
        self._cursor = 0
        self._build()

    # ------------------------------------------------------------ build
    def tick_to_sample(self, tick: int) -> int:
        return self.clock.us_to_sample(self.tempo.tick_to_us(tick))

    def _build(self) -> None:
        by_seq = {n.seq: n for n in self.song.notes}
        sched: list[ScheduledEvent] = []
        last = 0
        for e in self.song.events:
            sample = self.tick_to_sample(e.tick)
            sample = max(sample, last)          # monotone apsolutno vrijeme
            last = sample
            ctx = by_seq.get(e.seq) if e.kind is EventKind.NOTE_ON else None
            sched.append(ScheduledEvent(sample, e.seq, e, ctx))
            if e.kind is EventKind.NOTE_ON and ctx is not None:
                off_sample = self.tick_to_sample(ctx.end_tick)
                off = ScheduledEvent(off_sample, ctx.seq + (1 << 32),
                                     RawEvent.note_off(
                                         ctx.seq + (1 << 32), ctx.end_tick, ctx.channel, ctx.note, ctx.velocity_off),
                                     ctx)
                sched.append(off)
                last = max(last, off_sample)
        sched.sort(key=lambda s: (s.sample, s.seq))
        self._schedule = sched

    # ------------------------------------------------------------ API
    @property
    def total_samples(self) -> int:
        if not self._schedule:
            return 0
        tail = self._schedule[-1].sample
        return tail + max(1, self.clock.sample_rate // 4)   # rep (release tail)

    @property
    def total_us(self) -> float:
        return self.tempo.tick_to_us(self.song.duration_ticks)

    def window(self, cursor_sample: int, horizon_sample: int) -> list[ScheduledEvent]:
        """Sve spremne događaje u [cursor, horizon) — kursor se pomiče naprijed."""
        out: list[ScheduledEvent] = []
        i = self._cursor
        n = len(self._schedule)
        while i < n and self._schedule[i].sample < cursor_sample:
            i += 1
        self._cursor = i
        while i < n and self._schedule[i].sample < horizon_sample:
            out.append(self._schedule[i])
            i += 1
        self._cursor = i
        return out

    def remaining(self) -> int:
        return len(self._schedule) - self._cursor

    def reset(self) -> None:
        self._cursor = 0

    def lookahead_voice_hint(self, cursor_sample: int, horizon_sample: int) -> int:
        """Maksimalni broj istovremenih nota unutar prozora (za rezervaciju glasova)."""
        active = peak = 0
        events: list[tuple[int, int]] = []
        for s in self._schedule:
            if s.event.kind is EventKind.NOTE_ON and s.sample < horizon_sample and s.sample >= cursor_sample:
                end = self.tick_to_sample(s.note_ctx.end_tick) if s.note_ctx else s.sample + 1
                events.append((s.sample, 1))
                events.append((max(end, s.sample + 1), -1))
        events.sort()
        for _, d in events:
            active = max(0, active + d)
            peak = max(peak, active)
        return peak
