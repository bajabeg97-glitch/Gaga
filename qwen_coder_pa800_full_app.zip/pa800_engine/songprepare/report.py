"""Strukture Song Prepare izvještaja (konteksti, lanes, statistike)."""
from __future__ import annotations

from dataclasses import dataclass, field

from ..events import RawEvent


@dataclass(slots=True)
class NoteContext:
    """Sve što Articulation Engine treba znati o JEDNOJ noti — unaprijed.

    Popunjava se u Song Prepare fazi; audio nit više ne računa ništa od ovoga.
    """
    seq: int                       # seq polaznog NOTE_ON događaja
    tick: int
    end_tick: int
    channel: int
    note: int
    velocity_on: int
    velocity_off: int = 0

    # binding zvuka u trenutku note-on (dokazana semantika: PC komitira banku)
    cc00: int = 0
    cc32: int = 0
    program: int = 0

    # transport
    bar: int = 1
    beat: int = 1
    beat_phase: float = 0.0

    # lokalni kontekst fraze (po kanalu)
    prev_note: int | None = None
    interval: int | None = None            # |note - prev_note| u polustepenima
    interval_dir: int = 0                  # -1 down / 0 none / +1 up
    gap_ticks: int | None = None          # tick - prev_end_tick (<=0 = overlap)
    simultaneous_on: int = 1               # note-on događaja na istom ticku
    is_noise_register: bool = False        # nota u C7+ (RX noise) registru
    is_drum: bool = False

    # usporede s dokazanim RX zonama popunjava Articulation, ne Prepare
    def duration_ticks(self) -> int:
        return max(0, self.end_tick - self.tick)

    @property
    def legato_candidate(self) -> bool:
        return self.gap_ticks is not None and self.gap_ticks <= 0


@dataclass(slots=True)
class ControlLanePoint:
    tick: int
    seq: int
    channel: int
    control: str                 # "cc7" | "cc64" | "bend" | "pressure_ch" | "pressure_poly" | ...
    value: float                 # normalizirano (0..1) osim bend (semitoni)


@dataclass
class ChannelPrepare:
    channel: int
    notes: list[NoteContext] = field(default_factory=list)
    lane: list[ControlLanePoint] = field(default_factory=list)
    bindings: set[tuple[int, int, int]] = field(default_factory=set)

    @property
    def note_count(self) -> int:
        return len(self.notes)

    @property
    def chord_ratio(self) -> float:
        total = len(self.notes)
        if not total:
            return 0.0
        chords = sum(1 for n in self.notes if n.simultaneous_on > 1)
        return chords / total

    @property
    def legato_ratio(self) -> float:
        total = len(self.notes)
        if not total:
            return 0.0
        return sum(1 for n in self.notes if n.legato_candidate) / total


@dataclass
class PreparedSong:
    """Kompletan rezultat Song Prepare faze — spreman za PreScheduler."""
    name: str
    tpq: int
    events: list[RawEvent]                 # svi događaji (sortirano)
    notes: list[NoteContext]               # uparene note (sortirano)
    channels: dict[int, ChannelPrepare]
    tempo_points: list[tuple[int, int]]
    sig_points: list[tuple[int, int, int]]
    duration_ticks: int
    stats: dict = field(default_factory=dict)

    def summary(self) -> dict:
        return {
            "name": self.name,
            "tpq": self.tpq,
            "events": len(self.events),
            "notes": len(self.notes),
            "channels": {
                ch: {
                    "notes": c.note_count,
                    "chord_ratio": round(c.chord_ratio, 4),
                    "legato_ratio": round(c.legato_ratio, 4),
                    "bindings": sorted(c.bindings),
                }
                for ch, c in sorted(self.channels.items())
                if c.note_count
            },
            "duration_ticks": self.duration_ticks,
            "stats": self.stats,
        }
