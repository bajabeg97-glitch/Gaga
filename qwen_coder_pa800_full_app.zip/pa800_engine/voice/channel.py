"""ChannelState — stanje MIDI kanala u realnom vremenu.

Dokazana semantika bindinga: CC0/CC32 su pending dok Program Change ne
komitira novu adresu; kasnija promjena banke bez novog PC-a NE mijenja zvuk.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..songprepare.report import NoteContext
from ..articulation.profiles import SoundProfile


@dataclass
class ChannelState:
    index: int
    catalog: object  # SoundCatalog — tipizacija kruži (engine ↔ catalog)

    pending_cc00: int = 0
    pending_cc32: int = 0
    binding: tuple[int, int, int] = (0, 0, 0)
    profile: SoundProfile | None = None

    volume: float = 100 / 127.0
    expression: float = 1.0
    pan: float = 0.0                    # -1 lijevo .. +1 desno
    damper: bool = False
    mod: float = 0.0                    # 0..1 (JS+/vibrato)
    bend: float = 0.0                   # semitoni (±2 default raspon)
    bend_range: float = 2.0
    pressure: float = 0.0               # channel pressure 0..1
    poly_pressure: dict[int, float] = field(default_factory=dict)
    reverb: float = 0.0
    chorus: float = 0.0

    held_notes: list[tuple[int, int]] = field(default_factory=list)  # (note, voice_id)

    def __post_init__(self) -> None:
        self.refresh_profile()

    def reset_runtime(self) -> None:
        """Vrati runtime stanje na početak pjesme (kontroleri, pedala, nota)."""
        self.pending_cc00 = 0
        self.pending_cc32 = 0
        self.binding = (0, 0, 0)
        self.refresh_profile()
        self.volume = 100 / 127.0
        self.expression = 1.0
        self.pan = 0.0
        self.damper = False
        self.mod = 0.0
        self.bend = 0.0
        self.pressure = 0.0
        self.poly_pressure.clear()
        self.reverb = 0.0
        self.chorus = 0.0
        self.held_notes.clear()

    # ------------------------------------------------------------ binding
    def set_bank(self, cc00: int, cc32: int) -> None:
        self.pending_cc00 = cc00 & 0x7F
        self.pending_cc32 = cc32 & 0x7F

    def commit_program(self, pc: int) -> bool:
        """Program Change komitira pending banku. Vraća True ako se zvuk mijenja."""
        new_binding = (self.pending_cc00, self.pending_cc32, pc & 0x7F)
        if new_binding == self.binding and self.profile is not None:
            return False
        self.binding = new_binding
        self.refresh_profile()
        return True

    def refresh_profile(self) -> None:
        drum = self.index == 9
        self.profile = self.catalog.profile(*self.binding, drum_channel=drum)

    def profile_for(self, ctx: NoteContext) -> SoundProfile:
        """Profil koji važi za dati note-on (po commit semantici iz pjesme)."""
        drum = ctx.channel == 9
        binding = (ctx.cc00, ctx.cc32, ctx.program)
        if binding == self.binding and self.profile is not None and not (
            drum and self.profile and self.profile.cc00 != ctx.cc00
        ):
            return self.profile
        return self.catalog.profile(*binding, drum_channel=drum)

    # ------------------------------------------------------------ control
    def set_volume(self, value: int) -> None:
        self.volume = (value & 0x7F) / 127.0

    def set_expression(self, value: int) -> None:
        self.expression = (value & 0x7F) / 127.0

    def set_pan(self, value: int) -> None:
        self.pan = ((value & 0x7F) - 64) / 64.0

    def set_damper(self, value: int) -> bool:
        """Vraća True na prijelazu stanja pedale."""
        new = (value & 0x7F) >= 64
        changed = new != self.damper
        self.damper = new
        return changed

    def set_mod(self, value: int) -> None:
        self.mod = (value & 0x7F) / 127.0

    def set_bend_value(self, value14: int) -> None:
        self.bend = ((value14 - 8192) / 8192.0) * self.bend_range

    def set_pressure(self, value: float) -> None:
        self.pressure = max(0.0, min(1.0, value))

    def set_poly_pressure(self, note: int, value: float) -> None:
        self.poly_pressure[note & 0x7F] = max(0.0, min(1.0, value))

    def output_gain(self) -> float:
        return self.volume * self.expression
