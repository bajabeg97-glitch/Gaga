"""Voice — jedna aktivna nota u sintezi (tonalni sloj + noise slojevi + glide)."""
from __future__ import annotations

import numpy as np

from ..constants import midi_to_hz, velocity_gain
from ..articulation.profiles import (
    NoiseKind, SoundKind, SoundProfile, SwitchSide, spec_for,
)
from ..dsp.envelope import GateEnvelope, SegmentEnvelope
from .source import (
    NoiseBurstSource, TonalSource, make_seed, noise_source_for,
    tonal_brightness_for,
)
from .channel import ChannelState

# stabilan indeks vrste šuma (hash() varira po procesu — nedozvoljeno
# za determinističku sintezu)
_NOISE_KIND_INDEX = {kind: i for i, kind in enumerate(NoiseKind)}


class LayerVoice:
    """Jedan tonalni oscilator sloj (izvor + ovojnica + strana)."""

    __slots__ = ("source", "env", "side", "role", "gain", "brightness",
                 "drum_tone_hz")

    def __init__(self, sr: int, source: TonalSource, env: SegmentEnvelope,
                 side: SwitchSide | None, role: str, gain: float, brightness: float):
        self.source = source
        self.env = env
        self.side = side
        self.role = role
        self.gain = gain
        self.brightness = brightness
        self.drum_tone_hz: float | None = None


class NoiseVoicePart:
    """Jedan noise burst vezan uz glas (attack/release/augment šum)."""

    __slots__ = ("kind", "source", "env", "gain", "start_sample", "decay_ms")

    def __init__(self, sr: int, kind: NoiseKind, gain: float,
                 start_sample: int, seed: int):
        spec = spec_for(kind)
        self.kind = kind
        self.source: NoiseBurstSource = noise_source_for(kind, seed)
        self.env = GateEnvelope(sr, spec.decay_ms / 1000.0)
        self.gain = gain * spec.gain
        self.start_sample = start_sample
        self.decay_ms = spec.decay_ms


class Voice:
    """Aktivan glas: freq trajektorija + glide + slojevi + noise dijelovi."""

    __slots__ = (
        "id", "sr", "channel", "note", "velocity", "start_sample", "sample_rate",
        "profile", "semantic", "layer_voices", "noise_parts", "pan",
        "gain", "phase", "released", "finished", "age", "glide_from_note",
        "glide_ms", "glide_from_hz", "note_end_sample", "region",
        "pressure", "growl_part", "vibrato_phase", "damper_owned",
        "darkening", "drum_layer", "sustain_held", "release_note_value",
    )

    def __init__(self, voice_id: int, sr: int):
        self.id = voice_id
        self.sr = sr
        self.sample_rate = sr
        self.reset()

    # ------------------------------------------------------------ lifecycle
    def reset(self) -> None:
        self.channel = -1
        self.note = -1
        self.velocity = 0
        self.start_sample = 0
        self.profile: SoundProfile | None = None
        self.semantic = ""
        self.layer_voices: list[LayerVoice] = []
        self.noise_parts: list[NoiseVoicePart] = []
        self.pan = 0.0
        self.gain = 0.0
        self.phase = 0.0
        self.released = False
        self.finished = True
        self.age = 0
        self.glide_from_note = None
        self.glide_ms = 0.0
        self.glide_from_hz: float | None = None
        self.note_end_sample = -1
        self.region = "TONAL"
        self.pressure = 0.0
        self.growl_part: NoiseVoicePart | None = None
        self.vibrato_phase = 0.0
        self.damper_owned = False
        self.darkening = 0.0
        self.drum_layer = None
        self.sustain_held = False
        self.release_note_value = 0.0

    # ------------------------------------------------------------ otklanjanje
    def _build_layers(self, sr: int, decision, ctx_note: int, velocity: int,
                      channel: ChannelState) -> None:
        profile = self.profile
        if profile is None or decision.layer is None:
            self.layer_voices = []
            return
        layer = decision.layer
        side = decision.side or SwitchSide.HIGH
        ms_ref = layer.ref_for(side)
        ms_name = ms_ref.name if ms_ref else layer.role
        tags = ms_ref.tags if ms_ref else ()
        brightness = tonal_brightness_for(ms_name, tuple(tags), side is SwitchSide.HIGH)
        # envelope parametri po semantičkoj ulozi
        role = layer.role
        if role in ("DEAD_TO_MUTE", "STOP", "STOP_LH_RH"):
            env = SegmentEnvelope(sr, attack_s=0.0015, hold_s=0.0,
                                  decay_s=0.09, sustain=0.0, release_s=0.06)
        elif role in ("HARMONIC", "HARMONIC_TO_GHOST"):
            env = SegmentEnvelope(sr, attack_s=0.008, hold_s=0.0,
                                  decay_s=0.35, sustain=0.75, release_s=0.25)
        elif role == "GLISS":
            env = SegmentEnvelope(sr, attack_s=0.002, hold_s=0.0,
                                  decay_s=0.20, sustain=0.55, release_s=0.12)
        elif profile.kind is SoundKind.DNC and profile.dnc and profile.dnc.attack_click:
            env = SegmentEnvelope(sr, attack_s=0.0008, hold_s=0.0,
                                  decay_s=0.05, sustain=0.9, release_s=0.05)
        else:
            env = SegmentEnvelope(sr, attack_s=0.003, hold_s=0.0,
                                  decay_s=0.22, sustain=0.92, release_s=0.14)
        env.start()
        self.layer_voices = [LayerVoice(
            sr, TonalSource(brightness=brightness), env, side, role,
            gain=1.0, brightness=brightness)]

    def _build_noise_parts(self, sr: int, decision, seq: int) -> None:
        self.noise_parts = []
        for trig in decision.noise:
            seed = make_seed(self.note, self.velocity, seq,
                             _NOISE_KIND_INDEX.get(trig.kind, 0))
            self.noise_parts.append(NoiseVoicePart(
                sr, trig.kind, trig.gain, self.start_sample, seed))

    def start(self, sample: int, ctx_note: int, velocity: int,
              channel: ChannelState, decision, profile: SoundProfile,
              seq: int) -> None:
        self.reset()
        self.channel = channel.index
        self.note = ctx_note
        self.velocity = velocity
        self.start_sample = sample
        self.profile = profile
        self.semantic = decision.semantic
        self.region = decision.region
        self.released = False
        self.finished = False
        self.gain = velocity_gain(velocity) * decision.velocity_scale
        self.pan = channel.pan
        self.pressure = channel.pressure
        self.release_note_value = 64.0
        if decision.legato_from_note is not None:
            self.glide_from_note = decision.legato_from_note
            self.glide_from_hz = midi_to_hz(float(decision.legato_from_note))
            self.glide_ms = decision.glide_ms
        self._build_layers(self.sr, decision, ctx_note, velocity, channel)
        self._build_noise_parts(self.sr, decision, seq)

    def start_drum(self, sample: int, note: int, velocity: int,
                   channel: ChannelState, profile: SoundProfile,
                   drum_layer, seq: int) -> None:
        self.reset()
        self.channel = channel.index
        self.note = note
        self.velocity = velocity
        self.start_sample = sample
        self.profile = profile
        self.semantic = f"drum {drum_layer.name}".casefold()
        self.region = "DRUM"
        self.released = False
        self.finished = False
        self.gain = (velocity / 127.0) ** 1.4 * 0.9
        self.pan = channel.pan
        self.drum_layer = drum_layer
        decay_s = (drum_layer.decay_ms / 1000.0) if drum_layer else 0.2
        sr = self.sr
        # tijelo (tone) + šum (snare/činela) — kao aditivni drum glas
        tone_hz = drum_layer.tone_hz if drum_layer else None
        if tone_hz is not None:
            env = SegmentEnvelope(sr, attack_s=0.0005, hold_s=0.0,
                                  decay_s=decay_s * 0.85, sustain=0.0,
                                  release_s=0.02)
            env.start()
            src = TonalSource(brightness=0.5, detune_cents=0.0, harmonic_boost=0.0)
            layer = LayerVoice(sr, src, env, SwitchSide.HIGH, "DRUM_TONE",
                               gain=0.9, brightness=0.5)
            layer.drum_tone_hz = tone_hz
            self.layer_voices = [layer]
        else:
            self.layer_voices = []
        seed = make_seed(note, velocity, seq, 0xD005)
        if drum_layer is not None and drum_layer.vel_layers:
            noise_gain = drum_layer.sub_brightness(velocity)
            self.semantic += f" {drum_layer.sub_for(velocity)[1]}"
        else:
            noise_gain = (drum_layer.noise_brightness if drum_layer else 0.6)
        part = NoiseVoicePart(sr, NoiseKind.GROWL if tone_hz is None else NoiseKind.FRET,
                              gain=0.0, start_sample=sample, seed=seed)
        part.gain = 0.85 * noise_gain ** 1.2
        part.env = GateEnvelope(sr, max(0.03, decay_s))
        self.noise_parts = [part]

    # ------------------------------------------------------------ kontrola
    def note_off(self, sample: int, velocity_off: int = 64) -> None:
        if self.released or self.finished:
            return
        self.released = True
        self.note_end_sample = sample
        self.release_note_value = velocity_off
        for lv in self.layer_voices:
            lv.env.note_off()

    def sustain_hold(self) -> None:
        self.sustain_held = True

    def sustain_release(self, sample: int) -> None:
        if self.sustain_held:
            self.sustain_held = False
            self.note_off(sample, int(self.release_note_value))

    def choke(self) -> None:
        for lv in self.layer_voices:
            lv.env.choke()
        self.note_parts_choke()
        self.released = True

    def note_parts_choke(self) -> None:
        self.noise_parts = [p for p in self.noise_parts if p.kind in ()]

    def set_pressure(self, value: float) -> None:
        self.pressure = max(0.0, min(1.0, value))

    def glide_target(self, to_note: int, glide_ms: float) -> None:
        self.glide_from_note = self.note
        self.glide_from_hz = midi_to_hz(float(self.note))
        self.note = to_note
        self.glide_ms = glide_ms

    # ------------------------------------------------------------ render
    def _freq_traj(self, n: int, bend: float, mod: float) -> np.ndarray:
        base = midi_to_hz(float(self.note))
        freqs = np.full(n, base, dtype=np.float64)
        if self.glide_from_hz and self.glide_ms > 0:
            glide_n = max(1, int(self.glide_ms / 1000.0 * self.sr))
            t = np.arange(n, dtype=np.float64)
            frac = np.clip(t / glide_n, 0.0, 1.0)
            freqs = self.glide_from_hz + (freqs - self.glide_from_hz) * frac
        if bend:
            freqs = freqs * (2.0 ** (bend / 12.0))
        if mod > 0.02:
            lfo_hz = 5.6
            depth = 0.35 * mod
            t = np.arange(n, dtype=np.float64) / self.sr + self.vibrato_phase
            freqs = freqs * (2.0 ** ((depth * np.sin(2 * np.pi * lfo_hz * t)) / 12.0))
            self.vibrato_phase = float((t[-1] + 1.0 / self.sr) % 1.0)
        return freqs

    def render(self, out_l: np.ndarray, out_r: np.ndarray,
               block_start: int, n: int, channel: ChannelState) -> None:
        if self.finished:
            return
        drum_tone_only = self.region == "DRUM"
        rel = self.start_sample - block_start
        # glas se budi tek na svom start sample-u
        start = rel if rel > 0 else 0
        count = n - start
        if count <= 0:
            return
        bend = channel.bend
        mod = channel.mod if self.profile and self.profile.kind is SoundKind.FALLBACK else channel.mod * 0.6
        dst_l = out_l[start:start + count]
        dst_r = out_r[start:start + count]

        # --- tonalni slojevi -------------------------------------------------
        for lv in self.layer_voices:
            if drum_tone_only:
                freq = np.full(count, getattr(lv, "drum_tone_hz", midi_to_hz(self.note)),
                               dtype=np.float64)
            else:
                freq = self._freq_traj(count, bend, mod)
            sig, self.phase = lv.source.render(count, freq, self.phase, self.sr)
            env = lv.env.render(count)
            bright_mod = 1.0
            if self.pressure > 0.0 and self.profile is not None:
                bright_mod += 0.25 * self.pressure * lv.brightness
            render_sig = sig * env * (self.gain * lv.gain * bright_mod * channel.output_gain())
            l_g, r_g = _equal_power(self.pan)
            dst_l += render_sig * l_g
            dst_r += render_sig * r_g

        # --- noise dijelovi ---------------------------------------------------
        keep_parts = []
        for part in self.noise_parts:
            p_rel = part.start_sample - block_start
            p_start = p_rel if p_rel > start else start
            p_count = n - p_start
            if p_count <= 0 or part.env.is_done():
                if not part.env.is_done():
                    keep_parts.append(part)
                continue
            sig = part.source.render(p_count, self.sr)
            env = part.env.render(p_count)
            out_l[p_start:p_start + p_count] += sig * env * part.gain * self._noise_master(channel)
            out_r[p_start:p_start + p_count] += sig * env * part.gain * self._noise_master(channel)
            if not part.env.is_done():
                keep_parts.append(part)
        self.noise_parts = keep_parts

        if self.region == "NOISE_REGISTER" and not self.noise_parts:
            self.finished = True

        # kraj glasa?
        tonal_alive = any(not lv.env.is_done() for lv in self.layer_voices)
        if not tonal_alive and not self.noise_parts:
            self.finished = True

    def _noise_master(self, channel: ChannelState) -> float:
        pan = self.pan
        if channel.damper and self.profile and self.profile.dnc and self.profile.dnc.damper_noise:
            return 0.9 + 0.4 * channel.pressure
        return 1.0

    def is_active(self) -> bool:
        return not self.finished


def _equal_power(pan: float) -> tuple[float, float]:
    p = max(-1.0, min(1.0, pan))
    angle = (p + 1.0) * np.pi / 4.0
    return float(np.cos(angle) * 1.05), float(np.sin(angle) * 1.05)
