"""VoiceAllocator — pool glasova, mono/legato linije, LRU steal.

Kao u firmware-u: pool je prealocirane veličine; steal politika je LRU sa
prioritetom otpuštenih glasova. Legato prelazi retarget-uju postojeći glas
(mono linija) umjesto da pale novi — to je temelj Korg RX ponašanja za
bas/gitaru.
"""
from __future__ import annotations

from ..articulation.profiles import SoundKind, SoundProfile
from ..articulation.rules import Decision
from ..songprepare.report import NoteContext
from .channel import ChannelState
from .voice import Voice


class VoiceAllocator:
    def __init__(self, sr: int, pool_size: int = 78):
        if pool_size < 8:
            raise ValueError("voice pool premalen (min 8)")
        self.pool = [Voice(i, sr) for i in range(pool_size)]
        self.sr = sr
        self._tick = 0
        self.steals = 0
        self.noise_voice_count = 0

    # ------------------------------------------------------------- pool
    def active_voices(self) -> list[Voice]:
        return [v for v in self.pool if v.is_active()]

    def active_count(self) -> int:
        return sum(1 for v in self.pool if v.is_active())

    def _acquire(self) -> Voice:
        self._tick += 1
        for v in self.pool:
            if not v.is_active():
                v.age = self._tick
                return v
        # LRU steal: najstariji (po age), prioritet RELEASED glasova
        candidates = sorted(self.pool, key=lambda v: (not v.released, v.age))
        victim = candidates[0]
        victim.choke()
        victim.finished = True
        self.steals += 1
        victim.age = self._tick
        return victim

    # ------------------------------------------------------------- note-on
    def note_on(self, sample: int, ctx: NoteContext, channel: ChannelState,
                decision: Decision, profile: SoundProfile) -> Voice:
        legato_from = decision.legato_from_note
        if legato_from is not None:
            donor = self._find_legato_donor(ctx.channel, legato_from)
            if donor is not None:
                return self._retarget_legato(donor, sample, ctx, channel, decision, profile)
        voice = self._acquire()
        voice.start(sample, ctx.note, ctx.velocity_on, channel, decision, profile, ctx.seq)
        return voice

    def noise_only(self, sample: int, ctx: NoteContext, channel: ChannelState,
                   decision: Decision, profile: SoundProfile) -> Voice:
        voice = self._acquire()
        fake_decision = Decision(
            region=decision.region, semantic=decision.semantic,
            rule=decision.rule, noise=list(decision.noise),
            velocity_scale=decision.velocity_scale,
        )
        voice.start(sample, ctx.note, max(1, ctx.velocity_on), channel, fake_decision,
                    profile, ctx.seq)
        voice.layer_voices = []
        self.noise_voice_count += 1
        return voice

    def drum_note_on(self, sample: int, note: int, velocity: int,
                     channel: ChannelState, profile: SoundProfile,
                     drum_layer, seq: int) -> Voice:
        # mono choke grupe: kick/hat se ne gomilaju (HW ponašanje kitova)
        for v in self.active_voices():
            if v.region == "DRUM" and v.drum_layer is not None and drum_layer is not None \
               and v.drum_layer.name == drum_layer.name:
                v.choke()
        voice = self._acquire()
        voice.start_drum(sample, note, velocity, channel, profile, drum_layer, seq)
        return voice

    # ------------------------------------------------------------- legato
    def _find_legato_donor(self, channel_index: int, from_note: int) -> Voice | None:
        best = None
        for v in self.pool:
            if not v.is_active() or v.channel != channel_index:
                continue
            if v.region != "TONAL" or v.note != from_note:
                continue
            if best is None or v.age > best.age:
                best = v
        return best

    def _retarget_legato(self, voice: Voice, sample: int, ctx: NoteContext,
                         channel: ChannelState, decision: Decision,
                         profile: SoundProfile) -> Voice:
        # mono/legato linija: uvijek ide novi tonalni sloj u istom glasu;
        # dokumentirano Korg RX ponašanje (pitch se vuče, attack je mekši)
        was_released = voice.released
        if was_released:
            for lv in voice.layer_voices:
                lv.env.start()
        voice.released = False
        voice.glide_target(ctx.note, decision.glide_ms or 60.0)
        voice.velocity = ctx.velocity_on
        voice.gain = max(voice.gain, 0.35)
        voice.start_sample = min(voice.start_sample, sample)
        voice.profile = profile
        voice.semantic = decision.semantic
        for trig in decision.noise:
            from .voice import NoiseVoicePart, _NOISE_KIND_INDEX
            from .source import make_seed
            part = NoiseVoicePart(self.sr, trig.kind, trig.gain, sample,
                                  make_seed(ctx.note, ctx.velocity_on, ctx.seq,
                                            _NOISE_KIND_INDEX.get(trig.kind, 0)))
            voice.noise_parts.append(part)
        return voice

    # ------------------------------------------------------------- note-off
    def note_off(self, sample: int, channel_index: int, note: int,
                 velocity_off: int = 64, damper_held: bool = False) -> list[Voice]:
        released: list[Voice] = []
        for v in self.pool:
            if not v.is_active() or v.channel != channel_index or v.note != note:
                continue
            if v.released or v.sustain_held:
                # idempotentno: isti off ne smije dvaput otvoriti release
                continue
            if damper_held and v.region == "TONAL":
                v.sustain_hold()
                released.append(v)
            else:
                v.note_off(sample, velocity_off)
                released.append(v)
        return released

    def damper_up_release(self, sample: int, channel_index: int) -> None:
        for v in self.pool:
            if v.is_active() and v.channel == channel_index and v.sustain_held:
                v.sustain_release(sample)

    def all_notes_off(self, channel_index: int | None = None) -> None:
        for v in self.pool:
            if not v.is_active():
                continue
            if channel_index is None or v.channel == channel_index:
                v.choke()

    # ------------------------------------------------------------- render
    def render_block(self, out_l, out_r, block_start: int, n: int,
                     channels: list[ChannelState]) -> None:
        for v in self.pool:
            if not v.is_active():
                continue
            ch = channels[v.channel] if 0 <= v.channel < 16 else None
            if ch is None:
                v.choke()
                v.finished = True
                continue
            v.render(out_l, out_r, block_start, n, ch)

    def stats(self) -> dict:
        return {
            "pool": len(self.pool),
            "active": self.active_count(),
            "steals": self.steals,
            "peak": max((len(self.active_voices()), 0)) if self.pool else 0,
        }
