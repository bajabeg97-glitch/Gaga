"""Izvori signala za glasove (numpy, blok-render).

Bez stvarnog PCM-a iz paketa, svaki multisample sloj se mapira na
deterministički sintetizirani izvor po semantičkoj ulozi/tagovima
(dokazane oznake iz HW profila: SLAP/SLIDE/DEAD/MUTE/HARMONIC/…).
Tonalni sloj = aditivna sinteza sa brojem parcijala po "brightness" param.
Noise sloj = oblikovani pseudo-šum (PRNG sa sjemenom događaja → 100%
reproducibilnost).
"""
from __future__ import annotations

import numpy as np

from ..articulation.profiles import NoiseKind, spec_for

_TWO_PI = 2.0 * np.pi


def make_seed(*parts: int) -> int:
    h = 0x9E3779B9
    for p in parts:
        h = (h ^ (int(p) & 0xFFFFFFFF)) * 0x85EBCA6B & 0xFFFFFFFF
        h ^= h >> 13
    return h & 0x7FFFFFFF or 1


class TonalSource:
    """Aditivni izvor: K parcijala sa eksponencijalnim opadanjem amplitude."""

    __slots__ = ("brightness", "detune_cents", "harmonic_boost")

    def __init__(self, brightness: float = 0.6, detune_cents: float = 0.0,
                 harmonic_boost: float = 0.0):
        self.brightness = max(0.05, min(1.0, brightness))
        self.detune_cents = detune_cents
        self.harmonic_boost = harmonic_boost

    def render(self, n: int, freq_traj: np.ndarray, phase0: float,
               sr: int) -> tuple[np.ndarray, float]:
        """Vraća (mono signal n frejmova, završnu fazu)."""
        freq = np.asarray(freq_traj, dtype=np.float64)
        det = 2.0 ** (self.detune_cents / 1200.0)
        freqs = freq * det
        k = 1 + int(round(self.brightness * 7)) + int(round(self.harmonic_boost * 4))
        out = np.zeros(n, dtype=np.float64)
        dt = 1.0 / sr
        for h in range(1, k + 1):
            amp = (1.0 / (h ** (1.1 + 0.8 * (1.0 - self.brightness))))
            if h == 1:
                amp = 1.0
            phases = phase0 * h + _TWO_PI * h * np.cumsum(freqs) * dt
            out += amp * np.sin(phases)
        out /= max(1.0, k * 0.55)
        end_phase = float((phase0 + _TWO_PI * np.sum(freqs) * dt) % _TWO_PI)
        return out, end_phase


class NoiseBurstSource:
    """Oblikovani šum: determinističan PRNG + LP/HP formiranje po svjetlini.

    `color` kontroliše nagib: više = svjetliji šum (slide/breath);
    niže = topliji/tamniji (damper/growl). Render je u potpunosti
    određen sjemenskom vrijednošću (isti događaj → isti šum).
    """

    __slots__ = ("color", "seed")

    def __init__(self, color: float = 0.6, seed: int = 1):
        self.color = max(0.05, min(1.0, color))
        self.seed = int(seed) & 0x7FFFFFFF or 1

    def render(self, n: int, sr: int) -> np.ndarray:
        rng = np.random.default_rng(self.seed)
        noise = rng.standard_normal(n).astype(np.float64)
        alpha_lp = 0.04 + 0.30 * self.color
        hp_coeff = 1.0 - 0.55 * self.color
        out = np.empty(n, dtype=np.float64)
        lp = 0.0
        prev_lp = 0.0
        for i in range(n):
            lp += alpha_lp * (noise[i] - lp)
            out[i] = lp - prev_lp * hp_coeff
            prev_lp = lp
        peak = float(np.max(np.abs(out)))
        if peak > 0.0:
            out /= peak
        return out * self._rms_target(sr)

    @staticmethod
    def _rms_target(sr: int) -> float:
        return 3.0  # vraća šum na upotrebljivu dinamiku za mixer


def noise_source_for(kind: NoiseKind, seed: int) -> NoiseBurstSource:
    spec = spec_for(kind)
    return NoiseBurstSource(color=spec.brightness, seed=seed)


def tonal_brightness_for(ms_name: str, tags: tuple[str, ...], side_high: bool) -> float:
    """Mapiranje dokazanih tagova na svjetlinu tonalnog izvora."""
    t = {x.upper() for x in tags}
    name = (ms_name or "").casefold()
    if "SLAP" in t:
        return 0.92
    if "SLIDE" in t:
        return 0.78
    if "DEAD" in t or "MUTE" in t:
        return 0.28
    if "HARMONIC" in t or "harmon" in name:
        return 0.96
    if "PICK" in t:
        return 0.85
    if "GLISS" in t:
        return 0.60
    if "stop" in name:
        return 0.30
    return 0.62 if side_high else 0.50
