"""Učitavanje SMF/kanala → RawEvent tok — direktno vezano na
``baja_pa_manager.midi.optimizer`` SMF parser (isti event model, istan
parser koji već verificira round-trip).
"""
from __future__ import annotations

from pathlib import Path

from .constants import DEFAULT_TEMPO_US_PER_QN
from .events import EventKind, RawEvent


def load_smf(path: str | Path) -> tuple[int, list[RawEvent]]:
    """Vraća (tpq, sortirani RawEvent-ovi)."""
    try:
        from baja_pa_manager.midi.optimizer import parse_smf  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            "SMF ulaz traži baja_pa_manager paket (pa800_midi_app). "
            "Postavi PYTHONPATH na workspace root ili dodaj pa800_midi_app u sys.path."
        ) from exc

    parsed = parse_smf(Path(path))
    tpq = int(parsed["division"])
    if tpq & 0x8000:
        raise ValueError("SMPTE division nije podržan (koristi PPQ fajlove)")
    events: list[RawEvent] = []
    seq = 0
    for track in parsed["tracks"]:
        for e in track:
            if e.kind == "meta-51" and len(e.data) == 3:
                events.append(RawEvent(seq, e.tick, EventKind.META_TEMPO,
                                       value=float(int.from_bytes(e.data, "big"))))
                seq += 1
                continue
            if e.kind == "meta-58" and len(e.data) >= 2:
                events.append(RawEvent(seq, e.tick, EventKind.META_TIMESIG,
                                       data1=e.data[0], data2=1 << e.data[1]))
                seq += 1
                continue
            if e.kind == "meta-06":
                events.append(RawEvent(seq, e.tick, EventKind.META_MARKER,
                                       meta=e.data.decode("latin1", errors="replace")))
                seq += 1
                continue
            if e.kind != "channel":
                continue
            status = e.status
            family = status & 0xF0
            channel = status & 0x0F
            d = e.data
            if family == 0x90:
                kind = EventKind.NOTE_ON if d[1] > 0 else EventKind.NOTE_OFF
                events.append(RawEvent(seq, e.tick, kind, channel, d[0], d[1]))
            elif family == 0x80:
                events.append(RawEvent(seq, e.tick, EventKind.NOTE_OFF, channel, d[0], d[1]))
            elif family == 0xB0:
                events.append(RawEvent(seq, e.tick, EventKind.CONTROL_CHANGE, channel, d[0], d[1]))
            elif family == 0xC0:
                events.append(RawEvent(seq, e.tick, EventKind.PROGRAM_CHANGE, channel, d[0]))
            elif family == 0xE0:
                value14 = d[0] | (d[1] << 7)
                semitones = (value14 - 8192) / 8192.0 * 2.0
                events.append(RawEvent(seq, e.tick, EventKind.PITCH_BEND, channel,
                                       value=semitones))
            elif family == 0xA0:
                events.append(RawEvent(seq, e.tick, EventKind.POLY_PRESSURE, channel,
                                       d[0], d[1], value=d[1] / 127.0))
            elif family == 0xD0:
                events.append(RawEvent(seq, e.tick, EventKind.CHANNEL_PRESSURE, channel,
                                       value=d[0] / 127.0))
            else:
                continue
            seq += 1
    events.sort(key=lambda e: (e.tick, e.seq))
    # default tempo ako pjesma nema tempo event
    if not any(e.kind is EventKind.META_TEMPO for e in events):
        events.insert(0, RawEvent(-1, 0, EventKind.META_TEMPO,
                                  value=float(DEFAULT_TEMPO_US_PER_QN)))
    return tpq, events
