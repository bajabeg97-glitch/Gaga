"""Osnovni event model engine-a.

`RawEvent` je normalizirani događaj na ulazu (tick + kanal + podaci);
`ScheduledEvent` je isti događaj nakon Song Prepare faze — sa apsolutnim
sample-vremenom spremnim za RenderLoop. Redoslijed je uvijek
(sample, seq), čime je deterministička obrada zagarantirana.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class EventKind(str, Enum):
    NOTE_ON = "NOTE_ON"
    NOTE_OFF = "NOTE_OFF"
    CONTROL_CHANGE = "CONTROL_CHANGE"
    PROGRAM_CHANGE = "PROGRAM_CHANGE"
    PITCH_BEND = "PITCH_BEND"
    POLY_PRESSURE = "POLY_PRESSURE"
    CHANNEL_PRESSURE = "CHANNEL_PRESSURE"
    META_TEMPO = "META_TEMPO"
    META_TIMESIG = "META_TIMESIG"
    META_MARKER = "META_MARKER"
    SYSTEM_EXCLUSIVE = "SYSTEM_EXCLUSIVE"


@dataclass(frozen=True, slots=True)
class RawEvent:
    """Normalizirani ulazni događaj (tick domen)."""
    seq: int                       # globalni redni broj (stabilan ordering)
    tick: int                      # SMF tick (tpq skala)
    kind: EventKind
    channel: int = -1              # -1 = meta/sistemski događaj
    data1: int = 0                 # note / CC broj / program
    data2: int = 0                 # velocity / vrijednost
    value: float = 0.0             # tempo µs, bend semitoni, pressure 0..1
    meta: str = ""

    @staticmethod
    def note_on(seq: int, tick: int, channel: int, note: int, velocity: int) -> "RawEvent":
        return RawEvent(seq, tick, EventKind.NOTE_ON, channel, note, velocity)

    @staticmethod
    def note_off(seq: int, tick: int, channel: int, note: int, velocity: int = 0) -> "RawEvent":
        return RawEvent(seq, tick, EventKind.NOTE_OFF, channel, note, velocity)

    @staticmethod
    def control_change(seq: int, tick: int, channel: int, control: int, value: int) -> "RawEvent":
        return RawEvent(seq, tick, EventKind.CONTROL_CHANGE, channel, control, value)

    @staticmethod
    def program_change(seq: int, tick: int, channel: int, program: int) -> "RawEvent":
        return RawEvent(seq, tick, EventKind.PROGRAM_CHANGE, channel, program)


@dataclass(slots=True)
class ScheduledEvent:
    """Event nakon PreScheduler-a: apsolutno sample-vrijeme + kontekst."""
    sample: int                    # apsolutni sample indeks (>= 0)
    seq: int                       # stabilni tie-breaker
    event: RawEvent
    note_ctx: Any = None           # NoteContext za NOTE_ON (SongPrepare)

    def ordering(self) -> tuple[int, int]:
        return self.sample, self.seq


@dataclass(slots=True)
class Transport:
    """Transport pozicija koju Song Prepare računa za svaki kontekst."""
    tick: int
    us: int
    sample: int
    bar: int = 0                   # 1-bazirano
    beat: int = 0                  # 1-bazirano unutar takta
    beat_phase: float = 0.0        # 0..1 faza unutar otkucaja


def sort_by_time(events: list[ScheduledEvent]) -> list[ScheduledEvent]:
    events.sort(key=lambda e: (e.sample, e.seq))
    return events
