"""Pa800Engine — vrh sistemske arhitekture.

Pipeline:

    ingest (SMF/live) → SongPrepareAnalyzer → PreScheduler (compute-ahead)
      → po bloku: kontrolni događaji (CC/PC/bend/pressure) u ChannelState
      → note-on:  ArticulationEngine.decide_note → VoiceAllocator
      → note-off: release + release-noise glasovi
      → damper prijelazi: damper noise + sustain logika
      → mixer blok → izlazni buffer

Sve je deterministično: isti ulaz → bitno isti izlaz (PRNG seedovani po
događaju, nema zidnog sata u odlukama).
"""
from __future__ import annotations

import json
import time
import wave
from pathlib import Path

import numpy as np

from .articulation import ArticulationEngine, NoiseKind, SoundCatalog
from .clock import MasterClock
from .constants import (
    BLOCK_SIZE_DEFAULT, CC_ALLNOTES_OFF, CC_ALL_SOUND_OFF, CC_BANK_LSB,
    CC_BANK_MSB, CC_CHORUS, CC_DAMPER, CC_EXPRESSION, CC_MOD, CC_PAN,
    CC_REVERB, CC_VOLUME, LOOKAHEAD_MS_DEFAULT, SAMPLE_RATE_DEFAULT,
    VOICE_POOL_DEFAULT,
)
from .dsp import Mixer
from .events import EventKind, RawEvent
from .songprepare import PreScheduler, PreparedSong, SongPrepareAnalyzer
from .voice import ChannelState, VoiceAllocator


class RenderResult:
    """Izlaz rendera: int16 stereo PCM + kompletan izvještaj odluka."""

    def __init__(self, sample_rate: int, samples: np.ndarray,
                 prepared: PreparedSong, articulation: ArticulationEngine,
                 voice_stats: dict, wall_seconds: float, peak: float):
        self.sample_rate = sample_rate
        self.samples = samples
        self.prepared = prepared
        self.articulation_report = articulation.report()
        self.voice_stats = voice_stats
        self.wall_seconds = wall_seconds
        self.peak = peak
        self.prepare_summary = prepared.summary() if prepared else {}

    def write_wav(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(path), "wb") as handle:
            handle.setnchannels(2)
            handle.setsampwidth(2)
            handle.setframerate(self.sample_rate)
            handle.writeframes(self.samples.astype("<i2").tobytes())
        return path

    def write_report(self, path: str | Path) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.report_dict(), indent=2, ensure_ascii=False),
                        encoding="utf-8")
        return path

    def report_dict(self) -> dict:
        return {
            "engine": "pa800_engine",
            "sample_rate": self.sample_rate,
            "duration_seconds": round(len(self.samples) / 2 / self.sample_rate, 3),
            "peak": round(self.peak, 4),
            "render_wall_seconds": round(self.wall_seconds, 3),
            "voices": self.voice_stats,
            "prepare": self.prepare_summary,
            "articulation": self.articulation_report,
        }


class Pa800Engine:
    """Kompletna sinteza: prepare → schedule → articulation → voices → mix."""

    def __init__(self, sample_rate: int = SAMPLE_RATE_DEFAULT,
                 block_size: int = BLOCK_SIZE_DEFAULT,
                 voices: int = VOICE_POOL_DEFAULT,
                 lookahead_ms: float = LOOKAHEAD_MS_DEFAULT,
                 data_dir: Path | None = None,
                 seed_salt: int = 0):
        self.sample_rate = int(sample_rate)
        self.block_size = int(block_size)
        self.lookahead_samples = max(self.block_size,
                                     int(self.sample_rate * lookahead_ms / 1000.0))
        self.catalog = SoundCatalog(data_dir)
        self.articulation = ArticulationEngine(self.catalog)
        self.allocator = VoiceAllocator(self.sample_rate, voices)
        self.mixer = Mixer(self.block_size)
        self.clock = MasterClock(self.sample_rate)
        self.channels = [ChannelState(i, self.catalog) for i in range(16)]
        self.seed_salt = int(seed_salt)
        self._voice_peak = 0
        self._blocks = 0
        self._scheduled_total = 0
        self._samples: list[np.ndarray] = []

    # ------------------------------------------------------------ ingest
    def ingest_events(self, events: list[RawEvent], tpq: int = 480,
                      name: str = "") -> PreparedSong:
        analyzer = SongPrepareAnalyzer(tpq)
        prepared = analyzer.analyze(events, name=name)
        return prepared

    def ingest_smf(self, path: str | Path) -> PreparedSong:
        from .sources import load_smf
        tpq, events = load_smf(path)
        return self.ingest_events(events, tpq=tpq, name=Path(path).name)

    # ------------------------------------------------------------ control
    def _handle_control(self, event: RawEvent, sample: int) -> None:
        ch = self.channels[event.channel]
        if event.kind is EventKind.CONTROL_CHANGE:
            cc, value = event.data1, event.data2
            if cc == CC_BANK_MSB:
                ch.set_bank(value, ch.pending_cc32)
            elif cc == CC_BANK_LSB:
                ch.set_bank(ch.pending_cc00, value)
            elif cc == CC_VOLUME:
                ch.set_volume(value)
            elif cc == CC_PAN:
                ch.set_pan(value)
            elif cc == CC_EXPRESSION:
                ch.set_expression(value)
            elif cc == CC_DAMPER:
                self._handle_damper(ch, value, sample)
            elif cc == CC_MOD:
                ch.set_mod(value)
            elif cc == CC_REVERB:
                ch.reverb = value / 127.0
            elif cc == CC_CHORUS:
                ch.chorus = value / 127.0
            elif cc in (CC_ALLNOTES_OFF, CC_ALL_SOUND_OFF):
                self.allocator.all_notes_off(ch.index)
        elif event.kind is EventKind.PROGRAM_CHANGE:
            ch.commit_program(event.data1)
        elif event.kind is EventKind.PITCH_BEND:
            ch.bend = event.value
        elif event.kind is EventKind.CHANNEL_PRESSURE:
            self._handle_pressure(ch, event.value, sample)
        elif event.kind is EventKind.POLY_PRESSURE:
            ch.set_poly_pressure(event.data1, event.value)
            for v in self.allocator.active_voices():
                if v.channel == ch.index and v.note == event.data1:
                    v.set_pressure(event.value)

    def _handle_damper(self, ch: ChannelState, value: int, sample: int) -> None:
        pressed = value >= 64
        changed = ch.set_damper(value)
        if not changed:
            return
        # damper noise za DNC profile (EP+Damper porodica)
        if ch.profile is not None:
            hints = self.articulation.decide_damper(ch.profile, pressed, 96)
            if hints:
                from .songprepare.report import NoteContext
                from .articulation.rules import Decision
                pseudo = NoteContext(seq=-(abs(sample) + 1), tick=0, end_tick=0,
                                     channel=ch.index, note=69 if pressed else 67,
                                     velocity_on=int(96 * (hints[0].gain)),
                                     cc00=ch.binding[0], cc32=ch.binding[1], program=ch.binding[2])
                decision = Decision(region="NOISE_REGISTER",
                                    semantic=f"damper-{('down' if pressed else 'up')}",
                                    rule="DNC_DAMPER_TRANSITION", noise=hints)
                self.allocator.noise_only(sample, pseudo, ch, decision, ch.profile)
        if not pressed:
            self.allocator.damper_up_release(sample, ch.index)

    def _handle_pressure(self, ch: ChannelState, value: float, sample: int) -> None:
        growl_before = ch.pressure >= 0.5
        profile = ch.profile
        ch.set_pressure(value)
        for v in self.allocator.active_voices():
            if v.channel == ch.index:
                v.set_pressure(value)
        if profile is None:
            return
        resp = self.articulation.pressure(profile, value)
        growl_now = resp.get("growl", 0.0) > 0.0 and value >= 0.5
        if growl_now and not growl_before:
            # uključi growl noise sloj na svim aktivnim DNC duvačkim glasovima
            from .voice.voice import NoiseVoicePart
            from .voice.source import make_seed
            for v in self.allocator.active_voices():
                if v.channel == ch.index and v.profile is profile and v.region == "TONAL":
                    part = NoiseVoicePart(self.sample_rate, NoiseKind.GROWL,
                                          resp["growl"], sample,
                                          make_seed(v.note, v.velocity, v.id, 0xAB))
                    v.noise_parts.append(part)
        elif not growl_now and growl_before:
            for v in self.allocator.active_voices():
                if v.channel == ch.index:
                    v.noise_parts = [p for p in v.noise_parts if p.kind is not NoiseKind.GROWL]

    # ------------------------------------------------------------ note događaji
    def _handle_note_on(self, event: RawEvent, ctx, sample: int) -> None:
        ch = self.channels[event.channel]
        if ctx is None:
            return
        decision, profile = self.articulation.decide_note(ctx, ch, sample)
        if decision.region == "DRUM":
            layer = profile.drum_layer(ctx.note)
            self.allocator.drum_note_on(sample, ctx.note, ctx.velocity_on,
                                        ch, profile, layer, ctx.seq)
            return
        if decision.region == "NOISE_REGISTER":
            self.allocator.noise_only(sample, ctx, ch, decision, profile)
            return
        self.allocator.note_on(sample, ctx, ch, decision, profile)

    def _handle_note_off(self, event: RawEvent, ctx, sample: int) -> None:
        ch = self.channels[event.channel]
        note = event.data1
        released = self.allocator.note_off(sample, event.channel, note,
                                           event.data2, damper_held=ch.damper)
        if not released:
            return
        profile = ch.profile
        if profile is None:
            return
        duration_ticks = ctx.duration_ticks() if ctx is not None else 480
        triggers = self.articulation.decide_release(profile, note,
                                                    event.data2 or 64,
                                                    duration_ticks)
        if not triggers:
            return
        from .articulation.rules import Decision
        decision = Decision(region="NOISE_REGISTER", semantic="release-noise",
                            rule="RELEASE_NOISE", noise=triggers)
        self.allocator.noise_only(sample, _pseudo_ctx(sample, event, ch),
                                  ch, decision, profile)

    # ------------------------------------------------------------ render petlja
    def _run(self, prepared: PreparedSong, realtime: bool = False,
             block_cb=None) -> RenderResult:
        self.articulation.clear_records()
        for ch in self.channels:
            ch.reset_runtime()
        self.allocator = VoiceAllocator(self.sample_rate, len(self.allocator.pool))
        self.mixer = Mixer(self.block_size)
        self.clock.reset()
        self._voice_peak = 0
        self._blocks = 0
        self._scheduled_total = 0
        self._samples = []

        scheduler = PreScheduler(prepared, self.sample_rate)
        total = scheduler.total_samples
        started = time.perf_counter()
        block_start = 0
        next_wall = time.perf_counter()
        while block_start < total or self.allocator.active_count() > 0 and block_start < total + self.sample_rate * 2:
            horizon = block_start + self.block_size + self.lookahead_samples
            events = scheduler.window(block_start, horizon)
            for sev in events:
                self._scheduled_total += 1
                if sev.event.kind in (EventKind.META_TEMPO, EventKind.META_TIMESIG,
                                      EventKind.META_MARKER, EventKind.SYSTEM_EXCLUSIVE):
                    continue
                if sev.event.kind is EventKind.NOTE_ON:
                    self._handle_note_on(sev.event, sev.note_ctx, sev.sample)
                elif sev.event.kind is EventKind.NOTE_OFF:
                    self._handle_note_off(sev.event, sev.note_ctx, sev.sample)
                else:
                    self._handle_control(sev.event, sev.sample)
            l_buf, r_buf = self.mixer.buffers()
            self.allocator.render_block(l_buf, r_buf, block_start,
                                        self.block_size, self.channels)
            block = self.mixer.master_int16()
            self._samples.append(block)
            active = self.allocator.active_count()
            self._voice_peak = max(self._voice_peak, active)
            self._blocks += 1
            if block_cb is not None:
                block_cb(block_start, block)
            if realtime:
                next_wall += self.block_size / self.sample_rate
                delay = next_wall - time.perf_counter()
                if delay > 0:
                    time.sleep(delay)
            block_start += self.block_size
        wall = time.perf_counter() - started
        samples = np.concatenate(self._samples) if self._samples else np.zeros(0, dtype=np.int16)
        peak = float(np.max(np.abs(samples)) / 32768.0) if samples.size else 0.0
        voice_stats = {
            "pool_size": len(self.allocator.pool),
            "peak_polyphony": self._voice_peak,
            "steals": self.allocator.steals,
            "noise_voices": self.allocator.noise_voice_count,
            "blocks_rendered": self._blocks,
            "block_size": self.block_size,
            "lookahead_samples": self.lookahead_samples,
            "scheduled_events": self._scheduled_total,
        }
        self.mixer.peak = peak
        return RenderResult(self.sample_rate, samples, prepared,
                            self.articulation, voice_stats, wall, peak)

    def render(self, prepared: PreparedSong) -> RenderResult:
        """Offline render (determinističan, bez zidnog sata)."""
        return self._run(prepared, realtime=False)

    def run_realtime(self, prepared: PreparedSong, block_cb=None) -> RenderResult:
        """Real-time simulacija: blokovi dolaze na zidni sat (za audio backend)."""
        return self._run(prepared, realtime=True, block_cb=block_cb)

    def catalog_stats(self) -> dict:
        return self.catalog.stats()


def _pseudo_ctx(sample: int, event: RawEvent, ch: ChannelState):
    from .songprepare.report import NoteContext
    return NoteContext(seq=-(abs(sample) + 7), tick=event.tick, end_tick=event.tick,
                       channel=event.channel, note=event.data1, velocity_on=64,
                       cc00=ch.binding[0], cc32=ch.binding[1], program=ch.binding[2])
