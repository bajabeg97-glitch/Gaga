"""MAX DEMO pjesma — višetaktačna faza koja pokreće SVE sisteme engine-a.

Modelirano po Korg Factory MAX DEMO SONG pristupu: svaka sekcija
namjerno provocira tačno određeni RX/DNC sistem (zone, smooth runs,
staccato, gliss, akcenti, legato, kontroleri) da se u izvještaju vide
sve odluke Articulation Engine-a.

Sekcije:
  A) Standard Kit RX1 groove + Picked Bassthrough baz linija
  B) Clean Gitar RX1 ritam + legato solo sa bendom (C7+ noise kanali!)
  C) Finger Bso + SlapFing bas (zone: stop/harmonic/slap)
  D) Jimmy Organ DNC akordi (key-click attack/release)
  E) EP+Damper DNC sa CC64 prijelazima (damper šum oba smjera)
  F) Harmonica DNC solo sa channel-pressure growl + pitch bend
  G) Nylon Guitar DNC arpeggio (fret squeal na release)
"""
from __future__ import annotations

from .events import EventKind, RawEvent

TPQ = 480
BAR = TPQ * 4

# adrese iz evidencije (EXACT): (cc00, cc32, pc)
GTR_RX1 = (121, 14, 28)       # Clean Guitar RX1
GTR_RX3 = (121, 16, 28)       # Clean Guitar RX3
BASS_PICKED = (121, 10, 34)   # Picked Bass RX
BASS_FINGER = (121, 13, 33)   # Finger Bass RX
BASS_SLAP_F = (121, 4, 36)    # SlapFing Bass RX
BASS_SLAP_P = (121, 5, 36)    # SlapPick Bass RX
ORGAN_JIMMY = (121, 13, 18)   # Jimmy Organ DNC
EP_DAMPER1 = (121, 25, 4)     # EP+Damper1 DNC
HARMONICA = (121, 5, 22)      # Harmonica DNC
NYLON = (121, 18, 24)         # Nylon Guitar DNC
STEEL = (121, 35, 25)         # Steel Gtr DNC
TRUMPET = (121, 24, 56)       # Trumpet DNC
ALTO_SAX = (121, 12, 65)      # Alto Sax DNC
TROMBONE = (121, 13, 57)      # Trombone DNC
CLARINET = (121, 13, 71)      # Clarinet DNC
FLUTE = (121, 11, 73)         # Flute DNC
DRUM_STD_RX1 = (120, 0, 5)    # Standard Kit RX1


class DemoBuilder:
    def __init__(self, tpq: int = TPQ, tempo_us: int = 500_000):
        self.tpq = tpq
        self.tempo_us = tempo_us
        self.events: list[RawEvent] = []
        self._seq = 0

    # ------------------------------------------------------------ osnovno
    def _push(self, tick: int, kind: EventKind, channel: int = 0,
              d1: int = 0, d2: int = 0, *, value: float = 0.0,
              meta: str = "") -> None:
        self.events.append(RawEvent(self._seq, tick, kind, channel, d1, d2,
                                    value=value, meta=meta))
        self._seq += 1

    def tempo(self, tick: int, us_per_qn: int) -> "DemoBuilder":
        self._push(tick, EventKind.META_TEMPO, value=float(us_per_qn))
        return self

    def timesig(self, tick: int, num: int, den: int) -> "DemoBuilder":
        self._push(tick, EventKind.META_TIMESIG, d1=num, d2=den)
        return self

    def marker(self, tick: int, name: str) -> "DemoBuilder":
        self._push(tick, EventKind.META_MARKER, meta=name)
        return self

    def bind(self, tick: int, channel: int, binding: tuple[int, int, int]) -> "DemoBuilder":
        cc00, cc32, pc = binding
        self._push(tick, EventKind.CONTROL_CHANGE, channel, 0, cc00)
        self._push(tick, EventKind.CONTROL_CHANGE, channel, 32, cc32)
        self._push(tick, EventKind.PROGRAM_CHANGE, channel, pc)
        return self

    def note(self, tick: int, channel: int, note: int, velocity: int,
             dur_ticks: int, vel_off: int = 0) -> "DemoBuilder":
        dur_ticks = max(1, int(dur_ticks))
        self._push(tick, EventKind.NOTE_ON, channel, note, velocity)
        self._push(tick + dur_ticks, EventKind.NOTE_OFF, channel, note, vel_off)
        return self

    def cc(self, tick: int, channel: int, cc: int, value: int) -> "DemoBuilder":
        self._push(tick, EventKind.CONTROL_CHANGE, channel, cc, value)
        return self

    def pressure(self, tick: int, channel: int, value: float) -> "DemoBuilder":
        self._push(tick, EventKind.CHANNEL_PRESSURE, channel, value=value)
        return self

    def bend(self, tick: int, channel: int, semitones: float) -> "DemoBuilder":
        self._push(tick, EventKind.PITCH_BEND, channel, value=semitones)
        return self

    def finish(self) -> list[RawEvent]:
        out = sorted(self.events, key=lambda e: (e.tick, e.seq))
        return out


def build_max_demo(simple: bool = False, tpq: int = TPQ,
                   tempo_us: int = 500_000) -> tuple[int, list[RawEvent], str]:
    """Cijela MAX DEMO sekvenca. Vraća (tpq, events, ime)."""
    b = DemoBuilder(tpq=tpq, tempo_us=tempo_us)
    t = 0
    b.timesig(0, 4, 4).tempo(0, tempo_us)

    # --- kanali / bindinge ---------------------------------------------------
    CH_GTR, CH_BASS1, CH_BASS2, CH_BASS3, CH_SOLO = 0, 1, 2, 3, 4
    CH_ORGAN, CH_EP, CH_HARMO, CH_NYLON = 5, 6, 7, 8
    b.bind(0, CH_GTR, GTR_RX1).bind(0, CH_BASS1, BASS_PICKED)
    b.bind(0, CH_BASS2, BASS_FINGER).bind(0, CH_BASS3, BASS_SLAP_F)
    b.bind(0, CH_SOLO, GTR_RX3)
    b.bind(0, CH_ORGAN, ORGAN_JIMMY).bind(0, CH_EP, EP_DAMPER1)
    b.bind(0, CH_HARMO, HARMONICA).bind(0, CH_NYLON, NYLON)
    b.bind(0, 9, DRUM_STD_RX1)
    b.cc(0, CH_GTR, 7, 100).cc(0, CH_BASS1, 7, 104).cc(0, 9, 7, 96)

    bars = 2 if simple else 4
    beat = tpq

    # SEKCIJA A: groove — kick/snare/hats + picked bassthrough walking
    b.marker(t, "A: groove + picked bassthrough")
    for bar in range(bars):
        base = t + bar * BAR
        for step in range(8):  # osmice
            s = base + step * (beat // 2)
            b.note(s, 9, 36 if step % 4 == 0 else 38, 108 if step % 2 == 0 else 92, tpq // 12)
            b.note(s + tpq // 4, 9, 42, 72 if step % 2 else 88, tpq // 16)
        notes = [40, 43, 36, 43, 45, 43, 40, 38]
        vels = [70, 64, 76, 60, 88, 72, 66, 58]
        for i, (n, v) in enumerate(zip(notes, vels)):
            b.note(base + i * (beat // 2), CH_BASS1, n, v, int(beat * 0.42), 0)
    t += bars * BAR

    # SEKCIJA B: Clean Gitar RX1 — akordi + staccato + slide akcenat
    b.marker(t, "B: clean gitara staccato + slide")
    for bar in range(bars):
        base = t + bar * BAR
        chords = ([60, 64, 67], [58, 62, 65], [55, 59, 62], [57, 60, 64])
        for i, chord in enumerate(chords):
            s = base + i * beat
            dur = tpq // 8 if i % 2 == 0 else int(tpq * 0.72)
            vel = 44 if i % 2 == 0 else 84      # miješamo short/dead + working zone
            for n in chord:
                b.note(s, CH_GTR, n, vel, dur, 0)
        # slide akcenat u sljedeći bar
        b.note(base + 3 * beat, CH_GTR, 65, 118, tpq // 3, 0)
        b.note(base + 3 * beat + tpq // 3 + 6, CH_GTR, 70, 122, int(tpq * 0.5), 0)
        b.note(base + 3 * beat + int(tpq * 0.85), CH_GTR, 96, 110, tpq // 6, 0)  # C7 fret noise
        for i in range(8):
            s = base + i * (beat // 2)
            b.note(s, 9, 45 if i % 4 < 2 else 38, 96, tpq // 14)
    t += bars * BAR

    # SEKCIJA C: bass zone (stop / harmonic / slap / gliss)
    b.marker(t, "C: bas zone (stop/harmonic/slap)")
    prog = [(CH_BASS2, BASS_FINGER), (CH_BASS3, BASS_SLAP_F)]
    for bar in range(bars):
        base = t + bar * BAR
        ch, _ = prog[bar % 2]
        pattern = [(40, 30, tpq // 6), (40, 30, tpq // 6), (42, 118, tpq // 3),
                   (45, 52, tpq // 5), (43, 88, tpq // 2), (40, 126, tpq // 6),
                   (36, 24, tpq // 5), (38, 12, tpq // 3)]
        for i, (n, v, d) in enumerate(pattern):
            b.note(base + i * (beat // 2), ch, n, v, d, 0)
        for i in range(8):
            s = base + i * (beat // 2)
            b.note(s, 9, 36, 100, tpq // 12)
            b.note(s + tpq // 4, 9, 42, 66, tpq // 16)
    t += bars * BAR

    # SEKCIJA D: Jimmy Organ DNC — key click attack/release
    b.marker(t, "D: jimmy organ dnc (key-click)")
    for bar in range(2 if simple else 2):
        base = t + bar * BAR
        voicings = ([48, 55, 60, 63], [46, 53, 58, 62])
        for i, vs in enumerate(voicings):
            s = base + i * 2 * beat
            for j, n in enumerate(vs):
                b.note(s + (0 if j == 0 else 4), CH_ORGAN, n, 88 + 8 * j, int(beat * 1.7), 0)
        for i in range(8):
            s = base + i * (beat // 2)
            b.note(s, 9, 38, 90, tpq // 12)
    t += (2 if simple else 2) * BAR

    # SEKCIJA E: EP+Damper DNC — CC64 press/release (damper šum oba smjera)
    b.marker(t, "E: ep+damper dnc + cc64")
    ep_bars = 2 if simple else 2
    for bar in range(ep_bars):
        base = t + bar * BAR
        b.cc(base, CH_EP, 64, 127)                       # pedalu dolje → damper down
        comp = ([60, 64, 69, 72], [58, 62, 67, 70], [60, 64, 67, 71])
        for i, vs in enumerate(comp):
            s = base + i * beat + (beat // 2 if i else 0)
            for j, n in enumerate(vs):
                b.note(s, CH_EP, n, 62 + 4 * j, int(beat * (0.9 if i < 2 else 1.4)), 0)
        b.cc(base + 3 * beat + tpq // 2, CH_EP, 64, 0)   # pedalu gore → damper up
        for i in range(4):
            b.note(base + i * beat, 9, 42, 58 + i * 8, tpq // 16)
    t += ep_bars * BAR

    # SEKCIJA F: Harmonica DNC — breath attack + growl pressure + bend
    b.marker(t, "F: harmonica dnc (breath + growl + bend)")
    har_bars = 2 if simple else 3
    line = [(69, 0.92), (67, 0.5), (69, 0.48), (72, 1.6), (74, 0.5), (72, 0.52),
            (69, 0.9), (67, 0.5), (64, 1.48), (67, 0.45), (69, 1.9)]
    s = t
    for i, (n, frac) in enumerate(line):
        dur = int(beat * frac)
        vel = 78 + (i % 3) * 9
        b.note(s, CH_HARMO, n, vel, max(tpq // 8, dur - 4), 0)
        if i in (3, 6, 10):  # swell growl: pressure ramp unutar note
            for k in range(1, 6):
                b.pressure(s + k * max(1, dur // 6), CH_HARMO, 0.25 + 0.14 * k)
            b.pressure(s + max(1, dur - 8), CH_HARMO, 0.10)
        if i in (4,):        # bend dip-unutar licka
            b.bend(s, CH_HARMO, -0.9)
            b.bend(s + dur // 2, CH_HARMO, 0.60)
            b.bend(s + dur - max(4, dur // 4), CH_HARMO, 0.0)
        s += dur
    for i in range(12):
        b.note(t + i * beat, 9, 45, 84, tpq // 14)
        b.note(t + i * beat + tpq // 2, 9, 42, 60, tpq // 16)
    t = t + sum(int(beat * f) for _, f in line)
    t = ((t + BAR - 1) // BAR) * BAR   # zaokruži na bar

    # SEKCIJA G: Nylon DNC fingerstyle (fret squeal na release) + Steel DNC
    b.marker(t, "G: nylon dnc arpeggio (fret release)")
    ny_bars = 2 if simple else 3
    arpeggio = [(48, 0), (52, 1), (55, 2), (60, 3), (59, 4), (55, 5), (52, 6), (48, 7)]
    for bar in range(ny_bars):
        base = t + bar * BAR
        for i, (n, _) in enumerate(arpeggio):
            s_tick = base + i * (beat // 2)
            b.note(s_tick, CH_NYLON, n + (12 if bar % 3 == 2 else 0),
                   64 + (i % 4) * 7, max(tpq // 6, (beat // 2) - 8), 0)
        b.note(base + 2 * beat, CH_NYLON, 57, 96, tpq // 10, 0)   # staccato → squeal
        b.note(base + 2 * beat + tpq // 3, CH_NYLON, 55, 88, tpq // 10, 0)
    t += ny_bars * BAR

    # smanji tempo blizu kraja da TempoMap radi sa dvije tačke
    b.tempo(t, int(tempo_us * 1.25))
    b.marker(t, "H: finale (tempo-rall)")
    b.bind(t, CH_SOLO, GTR_RX1)
    finale = [(60, 74, 1.0), (64, 92, 0.996), (67, 104, 1.02), (72, 120, 1.5)]
    s = t
    for i, (n, v, frac) in enumerate(finale):
        dur = int(beat * frac)
        # namjerno preklapanje → legato glide (gap < 0)
        b.note(s, CH_SOLO, n + (12 if i == 3 else 0), v, dur + 10, 0)
        s += dur - 6
    b.bend(t + 2 * beat, CH_SOLO, 0.75)
    b.bend(t + 3 * beat, CH_SOLO, 0.0)
    # padni sviraj — drums fill
    for i in range(8):
        b.note(t + i * (beat // 2), 9, 38, 100 + (i % 4) * 6, tpq // 12)
        b.note(t + i * (beat // 2) + tpq // 4, 9, 42, 70, tpq // 16)
    b.note(s + tpq, 9, 36, 100, tpq // 3)
    end_tick = s + 2 * beat + tpq
    b.marker(end_tick, "END")
    return b.tpq, b.finish(), "MAX DEMO (pa800_engine)"
