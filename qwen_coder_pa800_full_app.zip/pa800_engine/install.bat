@echo off
REM ============================================================
REM  PA800 Engine - instalacija okruzenja (venv + paketi)
REM  Pokrenuti bilo odakle; skripta sama nalazi paket pored sebe.
REM ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
cd ..
title PA800 Engine - instalacija

echo.
echo [1/4] Provjera Python instalacije...
where python >nul 2>&1
if errorlevel 1 (
    echo GRESKA: Python nije na PATH-u.
    echo Preuzmi sa https://www.python.org/downloads/ ^(3.10 ili noviji^),
    echo pri instalaciji oznaci "Add Python to PATH".
    pause
    exit /b 1
)
python --version

echo.
echo [2/4] Virtuelno okruzenje (.venv)...
if not exist .venv (
    python -m venv .venv
    echo     Kreirano: .venv
) else (
    echo     Postoji: .venv
)
call .venv\Scripts\activate.bat

echo.
echo [3/4] Instalacija paketa (numpy, pytest)...
python -m pip install --upgrade pip >nul
python -m pip install numpy pytest
if errorlevel 1 (
    echo GRESKA pri instalaciji paketa (provjeri internet konekciju).
    pause
    exit /b 1
)

echo.
echo [4/4] Provjera paketa...
python -c "import pa800_engine; print('pa800_engine', pa800_engine.__version__, '- OK')"
if errorlevel 1 (
    echo GRESKA: paket se ne moze ucitati.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Gotovo. Dalje mozes koristiti:
echo    run_engine.bat      - CLI sinteza MAX DEMO pjesme
echo    run_engine_gui.bat  - GUI studio (Tkinter)
echo    run_tests.bat       - test suite
echo ============================================================
pause
