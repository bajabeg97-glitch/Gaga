"""CLI demo: python3 -m pa800_engine [--simple] [--sr 48000] [--out out.wav]

Sintetizuje MAX DEMO pjesmu kroz cijeli lanac:
    ingestion → Song Prepare → PreScheduler → Articulation Engine →
    Voice Pool (aditivna + noise sinteza) → Mixer (soft clip) → WAV
i ispisuje kompletne izvještaje (prepare summary, articulation mapa,
voice statistika) — sve je 100% deterministic.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .constants import BLOCK_SIZE_DEFAULT, LOOKAHEAD_MS_DEFAULT, \
    SAMPLE_RATE_DEFAULT, VOICE_POOL_DEFAULT, key_name, midi_to_hz
from .demo import build_max_demo
from .engine import Pa800Engine


def build_arg_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(
        prog="pa800_engine", description=__doc__.splitlines()[0])
    ap.add_argument("--simple", action="store_true",
                    help="skraćena varijanta demo pjesme (brže za test)")
    ap.add_argument("--sr", type=int, default=SAMPLE_RATE_DEFAULT,
                    help="sample rate (default 48000)")
    ap.add_argument("--block", type=int, default=BLOCK_SIZE_DEFAULT,
                    help="veličina audio bloka (default 64)")
    ap.add_argument("--voices", type=int, default=VOICE_POOL_DEFAULT,
                    help="veličina voice poola (default 78)")
    ap.add_argument("--lookahead", type=float, default=LOOKAHEAD_MS_DEFAULT,
                    help="lookahead u ms (default 5)")
    ap.add_argument("--out", type=str, default="max_demo.wav",
                    help="izlazni WAV fajl")
    ap.add_argument("--report", type=str, default="",
                    help="ako je zadano, arhivira JSON izvještaj")
    ap.add_argument("--midi", type=str, default="",
                    help="opciono: SMF fajl za sintezu umjesto demo pjesme")
    ap.add_argument("--records", type=int, default=0,
                    help="broj tablabanih rekorda koji se ispisuju (0=bez)")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    engine = Pa800Engine(sample_rate=args.sr, block_size=args.block,
                         voices=args.voices, lookahead_ms=args.lookahead)
    print("┏ PA800 Engine — deterministička sinteza", flush=True)
    print(f"  sample_rate={engine.sample_rate}  block={engine.block_size}"
          f"  pool={len(engine.allocator.pool)}  lookahead={args.lookahead} ms")
    stats = engine.catalog_stats()
    print(f"  katalog: {stats['rx']} RX + {stats['dnc']} DNC zvukova,"
          f" {stats['kits']} RX kitova (evidence: "
          f"{', '.join(stats['evidence'])})")

    if args.midi:
        prepared = engine.ingest_smf(args.midi)
        print(f"  ulaz SMF: {args.midi}")
    else:
        tpq, events, name = build_max_demo(simple=args.simple)
        prepared = engine.ingest_events(events, tpq=tpq, name=name)
        print("  ulaz: ugrađena MAX DEMO pjesma")

    summary = prepared.summary()
    print(f"  prepare: {summary['notes']} nota, {len(summary['channels'])} taktova,")
    print(f"  trajanje: {summary['duration_ticks']} tickova (tpq={summary['tpq']})")

    result = engine.render(prepared)
    out_path = result.write_wav(args.out)
    print(f"  render: {len(result.samples) // 2 / engine.sample_rate:.2f} s "
          f"u {result.wall_seconds:.2f} s "
          f"({(len(result.samples) / 2 / engine.sample_rate) / max(result.wall_seconds, 1e-9):.1f}× realtime),"
          f" peak={result.peak:.3f}")
    vs = result.voice_stats
    print(f"  voice: peak_poly={vs['peak_polyphony']}  steals={vs['steals']} "
          f" noise_voice={vs['noise_voices']}  blocks={vs['blocks_rendered']}")

    ar = result.articulation_report
    print(f"  articulation: {ar['decisions']} odluka")
    if ar["by_rule"]:
        for rule, count in ar["by_rule"].items():
            print(f"    {rule:<26} {count}")
    if ar["noise_triggers"]:
        print("  noise triggers:")
        for kind, count in ar["noise_triggers"].items():
            print(f"    {kind:<26} {count}")
    if ar["by_semantic"]:
        top = list(ar["by_semantic"].items())[:12]
        print(f"  top semantika: " + ", ".join(f"{s}×{c}" for s, c in top))

    if args.records:
        print(f"  prvih {args.records} rekorda:")
        for r in ar["records"][:args.records]:
            print(f"    t={r['sample']:>8} ch{r['channel']:<2} {key_name(r['note']):<4}"
                  f" rule={r['rule']:<18} sem={r['articulation']:<16}"
                  f" leg={r['legato'] or '-':<8} noise={len(r['noise_triggers'])}")

    report_path = args.report or str(Path(args.out).with_suffix(".report.json"))
    result.write_report(report_path)
    print(f"  report: {report_path}", flush=True)
    print("┗ OK — sinteza završena", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
