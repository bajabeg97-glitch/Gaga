"""Voice pool: alokacija, legato, drum choke, noise-only, damper flow."""
import numpy as np

from pa800_engine.articulation import SoundCatalog
from pa800_engine.articulation.rules import Decision
from pa800_engine.songprepare.report import NoteContext
from pa800_engine.voice import ChannelState, VoiceAllocator
from pa800_engine.voice.voice import Voice
from pa800_engine.dsp import Mixer


BASS = (121, 10, 34)
GTR = (121, 14, 28)
KIT = (120, 0, 5)


def _ctx(note=40, vel=90, ch=1, seq=1, **kw):
    return NoteContext(seq=seq, tick=0, end_tick=480, channel=ch, note=note,
                       velocity_on=vel, cc00=BASS[0], cc32=BASS[1], program=BASS[2],
                       **kw)


def _decision(semantic="working", legato_from=None, glide_ms=0.0, region="TONAL"):
    from pa800_engine.articulation.profiles import MsRef, OscLayer, SwitchSide
    layer = OscLayer(1, "WORKING_PICK_BASS", 53, 113, 0, 95, 94,
                     MsRef(370, "E.Bass3 p"), MsRef(373, "E.Bass4 Pick"))
    return Decision(region=region, semantic=semantic, rule="HW_VELOCITY_ZONE",
                    layer=layer, side=SwitchSide.HIGH,
                    ms_ref=layer.ref_for(SwitchSide.HIGH),
                    legato_from_note=legato_from, glide_ms=glide_ms)


def test_pool_alokira_i_otpusta():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(1, c)
    v = alloc.note_on(0, _ctx(), ch, _decision(), c.profile(*BASS))
    assert v.is_active() and alloc.active_count() == 1
    v.note_off(100, 64)
    assert v.released


def test_steal_lru():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(1, c)
    prof = c.profile(*BASS)
    for i in range(8):
        alloc.note_on(i * 1000, _ctx(note=40 + i, seq=i + 1), ch, _decision(), prof)
    assert alloc.active_count() == 8
    alloc.note_on(9_000, _ctx(note=53, seq=99), ch, _decision(), prof)
    assert alloc.steals == 1


def test_legato_retarget_ne_alocira_novi_glas():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(1, c)
    prof = c.profile(*BASS)
    v1 = alloc.note_on(0, _ctx(note=40, seq=1), ch, _decision(), prof)
    assert alloc.active_count() == 1
    d2 = _decision(legato_from=40, glide_ms=58.0)
    v2 = alloc.note_on(500, _ctx(note=43, seq=2, prev_note=40), ch, d2, prof)
    assert v2 is v1
    assert alloc.active_count() == 1
    assert v1.note == 43


def test_drum_mono_choke():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(9, c)
    prof = c.profile(*KIT, drum_channel=True)
    layer = prof.drum_layer(36)
    a = alloc.drum_note_on(0, 36, 120, ch, prof, layer, seq=1)
    b = alloc.drum_note_on(100, 36, 120, ch, prof, layer, seq=2)
    assert a is not b
    assert all(not lv.env.is_done() for lv in b.layer_voices)


def test_noise_only_glas():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(0, c)
    from pa800_engine.articulation.profiles import NoiseKind
    from pa800_engine.articulation.rules import NoiseTrigger
    d = Decision(region="NOISE_REGISTER", semantic="rx", rule="RX_NOISE_REGISTER",
                 noise=[NoiseTrigger(NoiseKind.RX_REGISTER, 1.0, "test")])
    ctx = NoteContext(seq=5, tick=0, end_tick=200, channel=0, note=96,
                      velocity_on=100, cc00=GTR[0], cc32=GTR[1], program=GTR[2],
                      is_noise_register=True)
    v = alloc.noise_only(0, ctx, ch, d, c.profile(*GTR))
    assert v.layer_voices == [] and v.noise_parts


def test_render_blok_sadrzi_audio_nakon_note_on():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(1, c)
    channels = [ChannelState(i, c) for i in range(16)]
    prof = c.profile(*BASS)
    alloc.note_on(0, _ctx(), ch, _decision(), prof)
    l = np.zeros(64); r = np.zeros(64)
    for block in range(30):
        channels[1].set_expression(127)
        alloc.render_block(l, r, block * 64, 64, channels)
    assert np.max(np.abs(l)) > 0.0 and np.max(np.abs(r)) > 0.0


def test_note_off_release_doci_glas_do_tisine():
    c = SoundCatalog()
    alloc = VoiceAllocator(48_000, pool_size=8)
    ch = ChannelState(1, c)
    channels = [ChannelState(i, c) for i in range(16)]
    prof = c.profile(*BASS)
    v = alloc.note_on(0, _ctx(), ch, _decision(), prof)
    l = np.zeros(64); r = np.zeros(64)
    for block in range(4):
        alloc.render_block(l, r, block * 64, 64, channels)
    alloc.note_off(4 * 64, 1, 40, damper_held=False)
    for block in range(4, 400):
        alloc.render_block(l, r, block * 64, 64, channels)
    assert not v.is_active()


def test_mixer_soft_clip_ne_prelazi_jedinicu():
    m = Mixer(64, master_gain=10.0)
    l, r = m.buffers()
    l[:] = 8.0
    r[:] = 8.0
    out = m.master_int16()
    assert np.max(np.abs(out.astype(np.float64) / 32768.0)) < 1.0


def test_voice_glide_frekvencija():
    v = Voice(0, 48_000)
    v.glide_from_hz = 261.626
    v.note = 64
    v.glide_ms = 60.0
    traj = v._freq_traj(4800, 0.0, 0.0)
    assert traj[0] < traj[-1]   # ide nagore kroz trajanje glidea
    assert abs(traj[-1] - 329.628) < 1.0   # nakon 60 ms frekvencija je E4
