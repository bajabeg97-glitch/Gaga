"""Song Prepare: uparivanje nota, frazni kontekst, binding semantika, scheduler."""
from pa800_engine.events import EventKind, RawEvent
from pa800_engine.songprepare.analyzer import SongPrepareAnalyzer
from pa800_engine.songprepare.scheduler import PreScheduler


def _events():
    seq = 0
    out = []
    def push(tick, kind, ch=0, d1=0, d2=0, value=0.0):
        nonlocal seq
        out.append(RawEvent(seq, tick, kind, ch, d1, d2, value=value)); seq += 1
    push(0, EventKind.META_TEMPO, value=500_000)
    push(0, EventKind.CONTROL_CHANGE, 0, 0, 121)
    push(0, EventKind.CONTROL_CHANGE, 0, 32, 14)
    push(0, EventKind.PROGRAM_CHANGE, 0, 28)
    push(0, EventKind.NOTE_ON, 0, 60, 80)
    push(180, EventKind.NOTE_OFF, 0, 60, 0)
    push(180, EventKind.NOTE_ON, 0, 64, 90)
    push(240, EventKind.NOTE_OFF, 0, 64, 0)
    push(360, EventKind.NOTE_ON, 0, 64, 90)
    push(480, EventKind.NOTE_OFF, 0, 64, 0)
    push(480, EventKind.NOTE_ON, 0, 96, 100)
    push(600, EventKind.NOTE_OFF, 0, 96, 0)
    push(0, EventKind.NOTE_ON, 9, 36, 100)
    push(24, EventKind.NOTE_OFF, 9, 36, 0)
    return sorted(out, key=lambda e: (e.tick, e.seq))


def test_analyzer_ne_mutira_ulaz():
    events = _events()
    original = list(events)
    SongPrepareAnalyzer(480).analyze(events)
    assert events == original


def test_analyzer_pairing_i_bind_context():
    prepared = SongPrepareAnalyzer(480).analyze(_events())
    tonal = [n for n in prepared.notes if n.channel == 0 and n.note < 96]
    assert len(tonal) == 3
    first = tonal[0]
    assert (first.cc00, first.cc32, first.program) == (121, 14, 28)
    assert first.duration_ticks() == 180
    assert first.gap_ticks is None
    second = tonal[1]
    assert second.prev_note == 60
    assert second.interval == 4
    assert second.interval_dir == 1
    assert second.gap_ticks == 0
    third = tonal[2]
    assert third.gap_ticks == 120


def test_analyzer_legato_flag_i_noise_register_i_drum():
    prepared = SongPrepareAnalyzer(480).analyze(_events())
    by_note = {(n.tick, n.note): n for n in prepared.notes}
    assert by_note[(180, 64)].legato_candidate
    noise = by_note[(480, 96)]
    assert noise.is_noise_register
    drum = [n for n in prepared.notes if n.channel == 9]
    assert drum and drum[0].is_drum


def test_analyzer_unclosed_note_ends_at_song_end():
    events = _events() + [RawEvent(999, 1000, EventKind.NOTE_ON, 2, 55, 90)]
    prepared = SongPrepareAnalyzer(480).analyze(events)
    tail = [n for n in prepared.notes if n.channel == 2][0]
    assert tail.end_tick >= prepared.duration_ticks


def test_scheduler_apsolutni_samplei_monotoni():
    prepared = SongPrepareAnalyzer(480).analyze(_events())
    sched = PreScheduler(prepared, 48_000)
    samples = [s.sample for s in sched._schedule]
    assert samples == sorted(samples)
    assert sched.total_samples > 0
    window = sched.window(0, sched.total_samples)
    seen_seq = [s.seq for s in window]
    assert len(seen_seq) >= len(prepared.events)
    assert sched.remaining() == 0


def test_scheduler_lookahead_hint():
    prepared = SongPrepareAnalyzer(480).analyze(_events())
    sched = PreScheduler(prepared, 48_000)
    hint = sched.lookahead_voice_hint(0, sched.total_samples)
    assert hint >= 1


def test_prepared_summary_je_serializabilan():
    import json
    prepared = SongPrepareAnalyzer(480).analyze(_events(), name="t")
    json.dumps(prepared.summary())
