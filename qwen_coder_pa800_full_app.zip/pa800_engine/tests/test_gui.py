"""GUI modul: import radi i bez $DISPLAY; mainloop se ne pokreće u testu."""
import os

import pytest


def test_gui_import_bez_displeja():
    # u headless sandboxu nema DISPLAY; tkinter import ipak mora raditi
    import pa800_engine.gui as gui
    assert gui.APP_TITLE
    assert hasattr(gui, "EngineStudioApp")
    assert callable(gui.run)


@pytest.mark.skipif(not os.environ.get("DISPLAY") and os.name != "nt",
                    reason="bez displeja (sandbox) — ne otvarati prozor")
def test_gui_instanse_se_kreira():
    from pa800_engine.gui import EngineStudioApp
    app = EngineStudioApp()
    app.update_idletasks()
    assert app.engine is not None
    app.destroy()
