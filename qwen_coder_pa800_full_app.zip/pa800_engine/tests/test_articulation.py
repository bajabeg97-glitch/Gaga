"""RX/DNC Articulation Engine — zone, semantika, noise trigaderi, release/damper/pressure."""
from pa800_engine.articulation import (
    ArticulationContext, ArticulationEngine, SoundCatalog, decide,
    damper_triggers, pressure_response, release_triggers,
)
from pa800_engine.articulation.profiles import NOISE_TABLE, NoiseKind


def _ctx(catalog, binding, note=60, vel=90, drum=False, **kw):
    profile = catalog.profile(*binding, drum_channel=drum)
    base = dict(note=note, velocity=vel, channel=9 if drum else 0,
                is_drum=drum, profile=profile)
    base.update(kw)
    return ArticulationContext(**base)


GTR = (121, 14, 28)     # Clean Guitar RX1
BASS = (121, 10, 34)    # Picked Bass RX
ORGAN = (121, 13, 18)   # Jimmy Organ DNC (attack click)
HARMO = (121, 5, 22)    # Harmonica DNC (breath + growl)
EP = (121, 25, 4)       # EP+Damper1 DNC (damper noise)
KIT = (120, 0, 5)       # Standard Kit RX1


def test_catalog_ucitava_sve_evidence():
    c = SoundCatalog()
    stats = c.stats()
    assert stats["rx"] == 10
    assert stats["dnc"] == 23
    assert stats["kits"] == 17
    assert set() | {("Picked Bass RX", c.profile(*BASS).name)} is not None


def test_profile_lookup_fallback_lanca():
    c = SoundCatalog()
    assert c.profile(*GTR).kind.name == "RX"
    assert c.profile(*ORGAN).kind.name == "DNC"
    assert c.profile(0, 0, 0).kind.name == "FALLBACK"
    assert c.profile(0, 0, 0, drum_channel=True).kind.name == "RX_DRUM_KIT"
    assert c.profile(*KIT, drum_channel=True).name == "Standard Kit RX1"


def test_hardware_zone_ekzaktne():
    c = SoundCatalog()
    d_w = decide(_ctx(c, GTR, vel=90))
    assert d_w.rule == "HW_VELOCITY_ZONE" and d_w.semantic == "working"
    d_dead = decide(_ctx(c, GTR, vel=30))
    assert d_dead.semantic in ("dead", "mute")
    d_slide = decide(_ctx(c, GTR, vel=120))
    assert d_slide.semantic in ("slap", "slide")
    d_harm = decide(_ctx(c, BASS, vel=125))
    assert d_harm.semantic == "harmonic"
    d_stop = decide(_ctx(c, BASS, vel=30))
    assert d_stop.semantic.startswith("stop")
    d_gliss = decide(_ctx(c, BASS, vel=5))
    assert d_gliss.semantic == "gliss"


def test_vel_switch_stranice():
    c = SoundCatalog()
    low = decide(_ctx(c, BASS, vel=60))
    high = decide(_ctx(c, BASS, vel=100))
    assert low.side is not None and high.side is not None
    assert low.side.name == "LOW" and high.side.name == "HIGH"
    assert low.ms_ref.name.endswith("p") or "Bass3" in low.ms_ref.name
    assert "Pick" in high.ms_ref.name


def test_noise_register_samo_rx_dnc():
    c = SoundCatalog()
    d_rx = decide(_ctx(c, GTR, note=100, vel=100))
    assert d_rx.rule == "RX_NOISE_REGISTER"
    assert d_rx.region == "NOISE_REGISTER"
    assert not d_rx.noise == []
    d_fb = decide(_ctx(c, (0, 0, 0), note=100, vel=100))
    assert d_fb.rule != "RX_NOISE_REGISTER"


def test_drum_per_key():
    c = SoundCatalog()
    d = decide(_ctx(c, KIT, note=36, vel=110, drum=True))
    assert d.region == "DRUM" and "kick" in d.semantic
    d2 = decide(_ctx(c, KIT, note=38, vel=90, drum=True))
    assert "snare" in d2.semantic


def test_legato_glide():
    c = SoundCatalog()
    reg_decision = decide(_ctx(c, GTR, prev_note=60, interval=4,
                               gap_ticks=-20, duration_ticks=450,
                               legato_candidate=True, velocity=90))
    assert reg_decision.legato_from_note == 60
    assert 34.0 <= reg_decision.glide_ms <= 120.0
    assert not any(n.kind in (NoiseKind.KEY_CLICK_ATTACK, NoiseKind.BREATH)
                   for n in reg_decision.noise)


def test_dnc_augmentacija():
    c = SoundCatalog()
    d_organ = decide(_ctx(c, ORGAN, vel=95))
    assert any(n.kind is NoiseKind.KEY_CLICK_ATTACK for n in d_organ.noise)
    d_harmo = decide(_ctx(c, HARMO, vel=80))
    assert any(n.kind is NoiseKind.BREATH for n in d_harmo.noise)


def test_release_i_damper_triggers():
    c = SoundCatalog()
    organ = c.profile(*ORGAN)
    triggers = release_triggers(organ, 60, 90, 240, 480)
    assert any(t.kind is NoiseKind.KEY_CLICK_RELEASE for t in triggers)
    ep = c.profile(*EP)
    up = damper_triggers(ep, False)
    down = damper_triggers(ep, True)
    assert any(t.kind is NoiseKind.DAMPER_UP for t in up)
    assert any(t.kind is NoiseKind.DAMPER_DOWN for t in down)
    assert damper_triggers(c.profile(*GTR), True) == []


def test_pressure_response():
    c = SoundCatalog()
    harmo = c.profile(*HARMO)
    r = pressure_response(harmo, 0.8)
    assert r["growl"] > 0.0
    gtr = c.profile(*GTR)
    r2 = pressure_response(gtr, 0.8)
    assert r2["growl"] == 0.0 and 0.9 <= r2["brightness"] <= 1.0


def test_noise_spec_tablica_je_popunjena():
    assert set(NOISE_TABLE.keys()) == set(NoiseKind)
    for spec in NOISE_TABLE.values():
        assert spec.decay_ms > 0 and 0 < spec.gain <= 1.05


def test_articulation_engine_audit_trail():
    from pa800_engine.songprepare.report import NoteContext
    from pa800_engine.voice.channel import ChannelState

    c = SoundCatalog()
    engine = ArticulationEngine(c)
    ch = ChannelState(0, c)
    ch.commit_program(28)
    ch.set_bank(121, 14)
    ch.commit_program(28)
    ctx = NoteContext(seq=1, tick=0, end_tick=480, channel=0, note=60,
                      velocity_on=90, cc00=121, cc32=14, program=28)
    decision, profile = engine.decide_note(ctx, ch, sample=0)
    assert profile.name.startswith("Clean Guitar RX1")
    assert engine.records and engine.records[-1].rule == decision.rule
    engine.clear_records()
    assert engine.records == []
