"""DSP primitivne: ovojnice, izvori, izlazno ograničenje."""
import numpy as np

from pa800_engine.dsp import EnvStage, GateEnvelope, Mixer, SegmentEnvelope
from pa800_engine.voice.source import (
    TonalSource, make_seed, noise_source_for, tonal_brightness_for,
)
from pa800_engine.articulation.profiles import NoiseKind
from pa800_engine.constants import midi_to_hz


def test_segment_envelope_punog_tijela():
    env = SegmentEnvelope(48_000, attack_s=0.01, hold_s=0.0,
                          decay_s=0.05, sustain=0.5, release_s=0.1)
    env.start()
    buf = env.render(480 + 480 + 4800)   # attack + decay + sustain dio
    assert buf[479] > 0.95
    assert any(v < 0.7 for v in buf[960:2000])
    assert abs(buf[-1] - 0.5) < 0.05
    env.note_off()
    tail = env.render(4800 * 2)
    assert tail[-1] < 0.02 or env.is_done()


def test_choke_dramski_skracuje_release():
    env = SegmentEnvelope(48_000, attack_s=0.001, hold_s=0.0,
                          decay_s=0.2, sustain=0.9, release_s=1.0)
    env.start()
    env.render(480)
    env.choke()
    out = env.render(600)
    assert out[-1] < 0.01
    assert env.release_s <= 0.012 + 1e-9


def test_gate_envelope_done():
    g = GateEnvelope(48_000, 0.05)
    out = g.render(2401)
    assert out[0] <= 1.0 and out[-1] == 0.0
    assert g.is_done()


def test_tonal_source_determinističan_i_u_rezimu():
    src = TonalSource(brightness=0.7)
    n = 96
    freq = np.full(n, midi_to_hz(60))
    out1, ph1 = src.render(n, freq, 0.0, 48_000)
    out2, ph2 = src.render(n, freq, 0.0, 48_000)
    assert np.array_equal(out1, out2)
    assert ph1 == ph2
    assert np.max(np.abs(out1)) <= 1.0 + 1e-6
    assert np.count_nonzero(out1) > n * 0.6


def test_noise_source_deterministicki():
    s = noise_source_for(NoiseKind.SLIDE, make_seed(96, 100, 7, 1))
    a = s.render(128, 48_000)
    s2 = noise_source_for(NoiseKind.SLIDE, make_seed(96, 100, 7, 1))
    b = s2.render(128, 48_000)
    assert np.array_equal(a, b)
    s3 = noise_source_for(NoiseKind.SLIDE, make_seed(96, 100, 7, 2))
    c = s3.render(128, 48_000)
    assert not np.array_equal(a, c)


def test_tonal_brightness_mapa_tagova():
    assert tonal_brightness_for("x", ("SLAP",), True) > 0.9
    assert tonal_brightness_for("stop", (), False) < 0.35
    hi = tonal_brightness_for("E.Bass4 Pick", ("PICK",), True)
    assert hi > 0.8


def test_mixer_je_determinističan():
    m1, m2 = Mixer(64), Mixer(64)
    for l1, r1 in [m1.buffers()]:
        l1[:] = 0.3
    for l2, r2 in [m2.buffers()]:
        l2[:] = 0.3
    assert np.array_equal(m1.master_int16(), m2.master_int16())
