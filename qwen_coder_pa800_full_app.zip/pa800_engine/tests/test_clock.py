"""TempoMap + MasterClock: deterministička mapa vremena."""
from pa800_engine.clock import MasterClock, TempoMap


def test_tempo_map_120bpm_jedan_tick():
    tm = TempoMap(tpq=480)
    tm.add_tempo(0, 500_000)
    tm.add_timesig(0, 4, 4)
    tm._finalize()
    assert abs(tm.tick_to_us(480) - 500_000.0) < 1e-6
    assert tm.bpm_at(0) == 120.0
    bar, beat, phase = tm.transport(480 * 4 + 240)
    assert bar == 2 and beat == 1 and 0 <= phase < 0.5 + 1e-9


def test_tempo_map_promjena_po_strojoj_granici():
    tm = TempoMap(tpq=480)
    tm.add_tempo(0, 500_000)
    tm.add_tempo(960, 250_000)
    tm._finalize()
    assert abs(tm.tick_to_us(960) - 960 / 480 * 500_000) < 1e-6
    assert abs(tm.tick_to_us(1200) - (960 / 480 * 500_000 + 240 / 480 * 250_000)) < 1e-6


def test_us_to_tick_obrnuto():
    tm = TempoMap(tpq=480)
    tm.add_tempo(0, 500_000)
    tm._finalize()
    assert abs(tm.us_to_tick(250_000.0) - 240.0) < 1e-6


def test_master_clock_int_preciznost():
    mc = MasterClock(48_000)
    assert mc.us_to_sample(1_000_000) == 48_000
    mc.advance(100)
    assert mc.position == 100
    mc.reset()
    assert mc.position == 0
