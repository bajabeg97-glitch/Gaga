"""Konstante: CC mapa, key imena, konverzije."""
from pa800_engine.constants import (
    CC_ALLNOTES_OFF, CC_BANK_LSB, CC_BANK_MSB, CC_DAMPER, CC_MOD,
    CC_PAN, CC_VOLUME, DRUM_BANK_MSB, DRUM_CHANNEL, NOISE_REGISTER_MIN,
    RX_BANK_MSB, TONAL_KEY_MAX, key_index, key_name, midi_to_hz,
    velocity_gain,
)


def test_cc_mapa_tacne_vrijednosti():
    assert CC_BANK_MSB == 0
    assert CC_MOD == 1
    assert CC_VOLUME == 7
    assert CC_PAN == 10
    assert CC_BANK_LSB == 32
    assert CC_DAMPER == 64
    assert CC_ALLNOTES_OFF == 123


def test_channel_i_bank_konstante():
    assert DRUM_CHANNEL == 9
    assert RX_BANK_MSB == 121
    assert DRUM_BANK_MSB == 120
    assert TONAL_KEY_MAX == 95
    assert NOISE_REGISTER_MIN == 96


def test_key_index_i_key_name_konzistentni():
    assert key_index("C-1") == 0
    assert key_index("A4") == 69
    tabela = {"C-1": 0, "G9": 127, "C7": 96, "B6": 95, "C4": 60, "A4": 69}
    for ime, idx in tabela.items():
        assert key_index(ime) == idx
    for idx in range(128):
        ime = key_name(idx)
        assert key_index(ime) == idx


def test_midi_to_hz_poznate_vrijednosti():
    assert abs(midi_to_hz(69) - 440.0) < 1e-9
    assert abs(midi_to_hz(60) - 261.6255653005986) < 1e-6
    assert abs(midi_to_hz(21) - 27.5) < 1e-6


def test_velocity_gain_monotona_i_ograničena():
    v0 = velocity_gain(1)
    v64 = velocity_gain(64)
    v127 = velocity_gain(127)
    assert 0.0 < v0 < v64 < v127 <= 1.0
