"""SMF ulaz (baja_pa_manager parser) → RawEvent-ovi bez gubitka semantike."""
import sys
from pathlib import Path

import pytest

from pa800_engine.constants import DRUM_CHANNEL
from pa800_engine.events import EventKind
from pa800_engine.sources import load_smf

_SIBLING_APP = Path(__file__).resolve().parents[2] / "pa800_midi_app"
if _SIBLING_APP.is_dir() and str(_SIBLING_APP) not in sys.path:
    sys.path.insert(0, str(_SIBLING_APP))


def _have_baja() -> bool:
    try:
        import baja_pa_manager.midi.optimizer  # noqa: F401
        return True
    except Exception:
        return False


pytestmark = pytest.mark.skipif(not _have_baja(),
                                reason="baja_pa_manager nije dostupan u okruženju")


def test_smf_load_sadrzi_tempo_i_binding(tmp_path):
    if not _have_baja():
        pytest.skip("nema baja")
    from baja_pa_manager.midi.optimizer import Event, write_smf  # type: ignore

    def ch(status_kind: int, channel: int) -> int:
        return status_kind | channel

    tracks = [
        [  # track 0: tempo + meta marker
            Event(0, "meta-51", 0xFF, bytes([0x07, 0xA1, 0x20])),
            Event(0, "meta-06", 0xFF, b"A"),
        ],
        [  # track 1: gitara kanal 0
            Event(0, "channel", 0xB0, bytes([0x00, 0x79])),
            Event(0, "channel", 0xB0, bytes([0x20, 0x0E])),
            Event(0, "channel", 0xC0, bytes([0x1C])),
            Event(0, "channel", 0x90, bytes([0x3C, 0x5A])),
            Event(240, "channel", 0x80, bytes([0x3C, 0x00])),
            Event(240, "channel", 0x90, bytes([0x40, 0x64])),
            Event(360, "channel", 0x80, bytes([0x40, 0x00])),
        ],
        [
            Event(0, "channel", ch(0xB0, DRUM_CHANNEL), bytes([0x00, 0x78])),
            Event(0, "channel", ch(0xB0, DRUM_CHANNEL), bytes([0x20, 0x00])),
            Event(0, "channel", ch(0xC0, DRUM_CHANNEL), bytes([0x05])),
            Event(0, "channel", ch(0x90, DRUM_CHANNEL), bytes([0x24, 0x6E])),
            Event(12, "channel", ch(0x80, DRUM_CHANNEL), bytes([0x24, 0x00])),
        ],
    ]
    path = tmp_path / "rnd.mid"
    write_smf(path, fmt=1, division=480, tracks=tracks)
    tpq, events = load_smf(path)
    assert tpq == 480
    kinds = {e.kind for e in events}
    assert EventKind.META_TEMPO in kinds
    assert EventKind.CONTROL_CHANGE in kinds
    assert EventKind.NOTE_ON in kinds and EventKind.NOTE_OFF in kinds
    tempo = [e for e in events if e.kind is EventKind.META_TEMPO]
    assert tempo and abs(tempo[0].value - 500_000.0) < 1e-9
    drums = [e for e in events if e.channel == DRUM_CHANNEL]
    assert drums and all(e.kind in (EventKind.CONTROL_CHANGE, EventKind.PROGRAM_CHANGE,
                                    EventKind.NOTE_ON, EventKind.NOTE_OFF,
                                    EventKind.CHANNEL_PRESSURE, EventKind.PITCH_BEND,
                                    EventKind.POLY_PRESSURE)
                         for e in drums)
