"""Pa800Engine end-to-end: determinizam, WAV, izvještaj, MIDI ulaz, kontroleri."""
import json

import numpy as np

from pa800_engine.demo import build_max_demo
from pa800_engine.engine import Pa800Engine, RenderResult
from pa800_engine.events import EventKind, RawEvent


def _demo_prepared(sr=48_000):
    engine = Pa800Engine(sample_rate=sr, block_size=64, voices=32)
    tpq, events, name = build_max_demo(simple=True)
    prepared = engine.ingest_events(events, tpq=tpq, name=name)
    return engine, prepared


def test_render_demo_deterministički():
    e1, p1 = _demo_prepared()
    r1 = e1.render(p1)
    e2, p2 = _demo_prepared()
    r2 = e2.render(p2)
    assert np.array_equal(r1.samples, r2.samples)
    assert r1.peak == r2.peak
    assert r1.articulation_report["decisions"] == r2.articulation_report["decisions"]


def test_wav_zapis_i_citanje(tmp_path):
    import wave
    e, p = _demo_prepared()
    r = e.render(p)
    out = r.write_wav(tmp_path / "demo.wav")
    assert out.stat().st_size > 44
    with wave.open(str(out), "rb") as h:
        assert h.getnchannels() == 2 and h.getsampwidth() == 2
        assert h.getframerate() == 48_000
        assert h.getnframes() == len(r.samples) // 2


def test_report_sadrzi_sve_ključne_brojače():
    e, p = _demo_prepared()
    r = e.render(p)
    d = r.report_dict()
    js = json.dumps(d)
    assert "by_rule" in d["articulation"] and d["articulation"]["by_rule"]
    assert "records" in d["articulation"]
    assert d["voices"]["blocks_rendered"] > 0
    assert d["prepare"]["notes"] > 100
    assert len(js) > 16_000


def test_peak_i_polyfonia_u_ocekivanim_granicama():
    e, p = _demo_prepared()
    r = e.render(p)
    assert 0.05 < r.peak <= 1.0
    assert 4 <= r.voice_stats["peak_polyphony"] <= 32
    assert r.voice_stats["noise_voices"] > 0


def test_semantic_baza_obuhvata_sve_dokazane_zone():
    e, p = _demo_prepared()
    r = e.render(p)
    sem_sve = set(r.articulation_report["by_semantic"].keys())
    ocekivano = {"working", "harmonic", "stop", "gliss", "slap", "slide",
                 "dead", "mute"}
    assert sem_sve & ocekivano
    assert r.articulation_report["by_rule"].get("RX_NOISE_REGISTER", 0) >= 1
    assert r.articulation_report["by_rule"].get("DRUM_KEY_LAYER", 0) > 4


def test_makeri_i_tempo_mapa_se_citaju_u_renderu():
    engine = Pa800Engine(sample_rate=48_000, block_size=64)

    state = {"seq": 0, "events": []}
    def push(tick, kind, ch=0, d1=0, d2=0, value=0.0):
        state["events"].append(RawEvent(state["seq"], tick, kind, ch, d1, d2,
                                        value=value))
        state["seq"] += 1

    push(0, EventKind.META_TEMPO, value=500_000)
    push(480 * 4, EventKind.META_TEMPO, value=250_000)   # ritard u bar 2
    push(0, EventKind.CONTROL_CHANGE, 0, 0, 121)
    push(0, EventKind.CONTROL_CHANGE, 0, 32, 14)
    push(0, EventKind.PROGRAM_CHANGE, 0, 28)
    push(0, EventKind.NOTE_ON, 0, 60, 90)
    push(480, EventKind.NOTE_OFF, 0, 60, 0)
    push(480 * 4, EventKind.NOTE_ON, 0, 64, 100)
    push(480 * 6, EventKind.NOTE_OFF, 0, 64, 0)
    state["events"].sort(key=lambda e: (e.tick, e.seq))
    prepared = engine.ingest_events(state["events"], tpq=480)
    render = engine.render(prepared)
    # druga faza (spora) treba biti audibilno duža
    assert render.peak > 0.01
    assert len(render.samples) // 2 > 48_000 * 2
