"""Novi dokazi iz master dosjea 2026-09-22:

1. PA800_FACTORY_SOUND_LIST (1003 identiteta, PUNI imena, CC00/CC32/PC)
2. PA800_DRUM_KIT_POP_STD_VEL_LAYERS (13 verificiranih ključeva, HARDWARE_OBSERVED)
3. Profil fallback familija iz factory imena + GM PC grupe
"""
import json

from pa800_engine.articulation import SoundCatalog, decide
from pa800_engine.articulation.profiles import SoundKind
from pa800_engine.articulation.rules import ArticulationContext


C = SoundCatalog()


def _ctx(binding, note=38, vel=79, drum=True):
    return ArticulationContext(
        note=note, velocity=vel, channel=9 if drum else 0, is_drum=drum,
        profile=C.profile(*binding, drum_channel=drum), ticks_per_beat=480)


# ------------------------------------------------------------- factory lista
def test_factory_lista_sve_1003_bindinga():
    assert len(C._factory_names) == 1003


def test_factory_lista_tacne_adrese():
    known = {
        (121, 0, 0): "AcousticPiano GM",
        (121, 4, 0): "Classic Piano",
        (121, 13, 18): "Jimmy Organ DNC",
        (121, 25, 4): "EP+Damper1 DNC",
        (121, 5, 22): "Harmonica DNC",
        (121, 9, 0): "Grand&MovingPad",
    }
    for binding, ime in known.items():
        assert C.factory_name(*binding) == ime, (binding, C.factory_name(*binding))


def test_factory_lista_pokriva_sve_bass_i_gitar_bindinge():
    bass_hits = sum(1 for (c0, c1, pc), n in C._factory_names.items() 
                    if "bass" in n.casefold())
    gtr_hits = sum(1 for (c0, c1, pc), n in C._factory_names.items()
                   if ("guitar" in n.casefold() or "gtr" in n.casefold()))
    assert bass_hits >= 60
    assert gtr_hits >= 30


def test_fallback_dobije_ime_i_family_iz_liste():
    p = C.profile(121, 0, 0)
    assert p.kind is SoundKind.FALLBACK
    assert p.name == "AcousticPiano GM"
    assert p.family == "PIANO"
    assert p.status == "FALLBACK_FACTORY_EXACT"
    p2 = C.profile(121, 13, 18)
    # poznata DNC adresa -> ne prepisuje DNC profil (binding érvrsten)
    assert p2.kind is SoundKind.DNC
    p3 = C.profile(121, 0, 8)   # Celesta GM
    assert p3.family in ("KEYBOARD", "PIANO", "KEYBOARD")


def test_nepoznat_binding_ostaje_tihi_fallback():
    p = C.profile(0, 0, 99)
    assert p.name == "GM Program 99"
    assert p.family == "GM"
    assert p.status == "FALLBACK"


# ------------------------------------------------------------- pop std kit
POP = (120, 0, 4)


def test_popstd_kit_nosi_verificiranu_mapu():
    kit = C.profile(*POP, drum_channel=True)
    assert kit.name == "Pop Std. Kit RX"
    kick = kit.drum_layer(35)
    assert kick is not None and kick.name == "Acoustic Kick"
    assert kick.osc_count == 1
    # jedan layer koji pokriva cijeli opseg = semantika "bez switch-a"
    assert all(lo <= 1 and hi == 127 for lo, hi, _ in kick.vel_layers)
    assert kick.sub_for(1)[1] == "sample" and kick.sub_for(127)[1] == "sample"


def test_popstd_snare_sest_layera_tocne_granice():
    kit = C.profile(*POP, drum_channel=True)
    snare = kit.drum_layer(38)
    assert snare.name == "Snare"
    assert snare.osc_count == 6
    assert snare.vel_switch_points == (26, 47, 68, 89, 110)
    ocekivano = {1: ("pp", 0), 25: ("pp", 0), 26: ("p", 1), 46: ("p", 1),
                 47: ("mp", 2), 67: ("mp", 2), 68: ("mf", 3), 88: ("mf", 3),
                 89: ("f", 4), 109: ("f", 4), 110: ("ff", 5), 127: ("ff", 5)}
    for vel, (label, idx) in ocekivano.items():
        got_idx, got_label = snare.sub_for(vel)
        assert got_label == label and got_idx == idx, (vel, got_label, got_idx)


def test_popstd_structured_labels_za_sve_13_kljuceva():
    kit = C.profile(*POP, drum_channel=True)
    wanted = {
        35: ("Acoustic Kick", 1), 36: ("Electric Kick", 1),
        38: ("Snare", 6), 40: ("Snare Rim/Edge", 6),
        42: ("Closed Hi-Hat", 4), 44: ("Open Hi-Hat", 2),
        46: ("Hi-Hat Pedal", 2), 41: ("Crash", 1), 43: ("Ride", 1),
        45: ("Tom Hi", 1), 47: ("Tom Mid", 1), 48: ("Tom Low", 1),
        50: ("Crash 2", 1),
    }
    for note, (label, osc) in wanted.items():
        layer = kit.drum_layer(note)
        assert layer is not None, note
        assert layer.name == label and layer.osc_count == osc, (note, layer.name)


def test_popstd_decision_uzme_sub_semantiku():
    d_pp = decide(_ctx(POP, note=38, vel=15))
    d_ff = decide(_ctx(POP, note=38, vel=120))
    assert d_pp.semantic == "drum snare pp"
    assert d_ff.semantic == "drum snare ff"
    d_hat = decide(_ctx(POP, note=42, vel=100))
    assert d_hat.semantic == "drum closed hi-hat mp"


def test_popstd_semantika_verificirana_u_bazi_ne_jeonkruzu():
    kit = C.profile(*POP, drum_channel=True)
    # unutar pokrivenih kljuceva semantic dolazi od verificirane mape
    for note in (35, 36, 38, 40, 42, 44, 45, 46, 47, 48, 50):
        assert kit.drum_layer(note).name, note
    # 41 F2 = Crash iz mape; izmedju -> GM srednja banda (npr. 66 Hi Perc bez dodira)
    assert kit.drum_layer(66) is not None
    assert "perc" in kit.drum_layer(66).name.casefold()


def test_sub_brightness_raste_prema_ff_i_je_monotona():
    kit = C.profile(*POP, drum_channel=True)
    snare = kit.drum_layer(38)
    vals = [snare.sub_brightness(v) for v in (10, 30, 50, 70, 95, 120)]
    assert all(v2 >= v1 for v1, v2 in zip(vals, vals[1:])), vals
    assert vals[0] < vals[-1]


def test_ostali_kitovi_ostaju_na_gm_mapu_bez_vel_layers():
    std = C.profile(120, 0, 5, drum_channel=True)
    assert std.name == "Standard Kit RX1"
    kick = std.drum_layer(36)
    assert kick is not None and kick.vel_layers == ()
