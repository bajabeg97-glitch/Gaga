"""Korg Pa800 Sound Engine — produkcijska implementacija.

Pipeline (kao na fabričkom firmware-u):

    SMF / live strim
      → SongPrepare    (analiza strima: note, kontekst, fraze, binding)
      → PreScheduler   (tempo-map → sample-vrijeme, lookahead prozor)
      → ArticulationEngine (RX/DNC odluke: zone, strane, šumovi, legato)
      → VoiceAllocator (mono/legato linije, LRU steal, noise glasovi)
      → RenderLoop     (blokovi, mixer, soft-clip, WAV/realtime izlaz)

Sve odluke o artikulaciji bazirane su na dokazanim hardverskim profilima
(RX_OSCILLATOR_REGISTRY_v3, PA800_HARDWARE_VERIFIED_OSC_PROFILES,
RX_SOUND_CAPABILITIES_v1, PA800_FACTORY_SPECIAL_REGISTRY_v2).
"""
from __future__ import annotations

__version__ = "1.1.0"

from .constants import (  # noqa: F401
    SAMPLE_RATE_DEFAULT, BLOCK_SIZE_DEFAULT, LOOKAHEAD_MS_DEFAULT,
    VOICE_POOL_DEFAULT, TONAL_KEY_MAX, NOISE_REGISTER_MIN,
    DRUM_CHANNEL, RX_BANK_MSB, DRUM_BANK_MSB,
)
from .events import EventKind, RawEvent, ScheduledEvent  # noqa: F401
from .clock import TempoMap, MasterClock  # noqa: F401
from .engine import Pa800Engine, RenderResult  # noqa: F401
