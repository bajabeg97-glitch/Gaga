@echo off
REM ============================================================
REM  Baja Music - meni: odaberi sta pokreces
REM ============================================================
setlocal
cd /d "%~dp0"
title Baja Music - FULL bundle

:menu
cls
echo ============================================================
echo   BAJA MUSIC - Korg Pa800 FULL bundle
echo ============================================================
echo.
echo   1. PA800 Engine - CLI sinteza (MAX DEMO)
echo   2. PA800 Engine - GUI studio
echo   3. Baja MIDI Studio - CLI
echo   4. Baja MIDI Studio - GUI
echo   5. Test suite (oba paketa)
echo   6. Izlaz
echo.
set /p choice="  Odaberi [1-6]: "

if "%choice%"=="1" goto engine_cli
if "%choice%"=="2" goto engine_gui
if "%choice%"=="3" goto midi_cli
if "%choice%"=="4" goto midi_gui
if "%choice%"=="5" goto tests
if "%choice%"=="6" goto end
goto menu

:engine_cli
call run_engine.bat
goto menu

:engine_gui
call run_engine_gui.bat
goto menu

:midi_cli
call run_midi_app.bat
goto menu

:midi_gui
call run_midi_gui.bat
goto menu

:tests
call run_tests.bat
goto menu

:end
endlocal
