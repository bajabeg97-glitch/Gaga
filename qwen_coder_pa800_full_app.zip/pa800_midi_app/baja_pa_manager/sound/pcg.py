from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class Program:
    name: str
    payload: bytes
    version: int = 0
    oscillator_count: int = 0
    category: int | None = None
    size: int | None = None


class PCGParser:
    def parse(self, payload: bytes, name: str = "") -> Program:
        # Preserve-first parser: version/OSC fields should be populated only
        # when a fixture-backed map is attached.
        return Program(name=name, payload=bytes(payload))

    def build(self, program: Program) -> bytes:
        return bytes(program.payload)


@dataclass
class PCGFile:
    """Rezultat direktnog native PCG parsiranja (KORF katalog + OC32 zapisi)."""
    path: str
    programs: list[Program] = field(default_factory=list)
    catalog_names: list[str] = field(default_factory=list)

    @property
    def named(self) -> list[Program]:
        return [p for p in self.programs if p.name]


class NativePCGReader:
    """Direktno vezanje na dokazani ``native.pcg.KorgPCG`` parser.

    Adrese (cc00/cc32/pc) se NE izvode iz imena — address-first politika
    ostaje na SoundResolver-u; ovdje se čita samo ono što je dokazano
    (KORF katalog imena + OC32 program zapisi sa kategorijom).
    """

    def read(self, path) -> PCGFile:
        from ..native.pcg import KorgPCG
        from pathlib import Path
        path = Path(path)
        parsed = KorgPCG.from_file(path)
        programs = [
            Program(
                name=p.name,
                payload=bytes(p.raw_data),
                category=p.category,
                size=p.size,
            )
            for p in parsed.programs
        ]
        return PCGFile(str(path), programs, list(parsed.program_names))
