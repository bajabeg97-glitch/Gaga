from __future__ import annotations
from dataclasses import dataclass
from enum import Enum

from .catalog import SoundAddress, SoundCatalog, SoundEntry


class MatchState(str, Enum):
    FACTORY = "FACTORY"
    SAME = "SAME"
    MISSING = "MISSING"
    USER_UNMAPPED = "USER_UNMAPPED"


@dataclass(slots=True)
class ResolveResult:
    state: MatchState
    source: SoundEntry | None
    target: SoundEntry | None
    reason: str


class SoundResolver:
    def resolve(self, source: SoundEntry, target_catalog: SoundCatalog) -> ResolveResult:
        exact = target_catalog.get(source.address)
        if exact:
            state = MatchState.FACTORY if exact.factory else MatchState.SAME
            return ResolveResult(state, source, exact, "numeric address match")

        same_name = next((e for e in target_catalog.entries if e.name == source.name), None)
        if same_name:
            return ResolveResult(MatchState.SAME, source, same_name, "name fallback")

        if not source.factory:
            return ResolveResult(MatchState.USER_UNMAPPED, source, None, "user sound has no target mapping")
        return ResolveResult(MatchState.MISSING, source, None, "no target mapping")

    def remap(self, source: SoundEntry, replacement: SoundEntry) -> None:
        # Explicit operation; caller owns the audit trail.
        if replacement is None:
            raise ValueError("replacement required")
