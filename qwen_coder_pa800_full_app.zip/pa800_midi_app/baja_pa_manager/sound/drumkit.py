from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class DrumKey:
    note: int
    payload: bytes


@dataclass(slots=True)
class DrumKit:
    name: str
    keys: list[DrumKey]
    raw: bytes


class DrumKitParser:
    def parse(self, payload: bytes, name: str = "") -> DrumKit:
        return DrumKit(name=name, keys=[], raw=bytes(payload))

    def build(self, kit: DrumKit) -> bytes:
        if kit.raw and not kit.keys:
            return kit.raw
        raise ValueError("DrumKit key writer needs proven descriptor layout")
