from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SoundAddress:
    msb: int
    lsb: int
    program: int

    def tuple(self) -> tuple[int, int, int]:
        return self.msb, self.lsb, self.program


@dataclass(slots=True)
class SoundEntry:
    address: SoundAddress
    name: str
    family: str | None = None
    factory: bool = True


class SoundCatalog:
    def __init__(self, entries: list[SoundEntry] | None = None):
        self.entries = entries or []
        self.by_address = {e.address.tuple(): e for e in self.entries}

    def add(self, entry: SoundEntry) -> None:
        self.entries.append(entry)
        self.by_address[entry.address.tuple()] = entry

    def get(self, address: SoundAddress):
        return self.by_address.get(address.tuple())

    @classmethod
    def from_special_registry(cls, registry: dict) -> "SoundCatalog":
        """Direktno veže RX/DNC evidence registry na address-first katalog."""
        catalog = cls()
        for row in registry.get("rx_sounds", []) + registry.get("dnc_sounds", []):
            if all(row.get(k) is not None for k in ("cc00", "cc32", "pc")):
                catalog.add(SoundEntry(
                    SoundAddress(int(row["cc00"]), int(row["cc32"]), int(row["pc"])),
                    row.get("name", "?"), row.get("kind"), True,
                ))
        return catalog
