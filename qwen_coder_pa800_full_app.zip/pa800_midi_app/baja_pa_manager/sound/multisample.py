from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class SampleRef:
    sample_id: int
    name: str
    size: int


@dataclass(slots=True)
class Multisample:
    name: str
    samples: list[SampleRef] = field(default_factory=list)
    raw: bytes = b""


class MultisampleManager:
    def referenced_bytes(self, ms: Multisample) -> int:
        return sum(s.size for s in ms.samples)

    def can_fit(self, ms: Multisample, budget_bytes: int) -> bool:
        return self.referenced_bytes(ms) <= budget_bytes
