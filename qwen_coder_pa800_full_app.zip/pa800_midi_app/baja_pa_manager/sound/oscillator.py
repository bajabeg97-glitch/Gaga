from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class Oscillator:
    index: int
    payload: bytes
    version: int = 0


class OscillatorSerializer:
    SUPPORTED_VERSIONS = set(range(4, 10))

    def parse(self, payload: bytes, version: int) -> Oscillator:
        if version not in self.SUPPORTED_VERSIONS:
            raise ValueError(f"Unsupported oscillator version: {version}")
        return Oscillator(index=0, payload=bytes(payload), version=version)

    def build(self, osc: Oscillator) -> bytes:
        # Unknown leaf semantics preserved exactly.
        return osc.payload
