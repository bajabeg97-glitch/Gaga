"""Baja Music — Korg Pa800 MIDI Studio (Tkinter GUI).

Tabovi direktno vežu sve module:
  1. SET Manager      — otvori SET direktorij + probe resursa (native parseri)
  2. MIDI Optimizer   — audit / konzervativna optimizacija (svi engine-i)
  3. STY Explorer     — KBEG/KEND resursi + style sekcije (BANK01 demo)
  4. Sound Catalog    — PCG programi + RX/DNC registry adresiranje
  5. Live MIDI        — portovi, slanje PC na Pa800, playback SMF-a
  6. Evidence         — registry pravila + validator smoke report
"""
from __future__ import annotations

import json
import threading
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

from ..core.models import TargetModel
from ..core.evidence import EvidenceRegistry
from ..core.validator import Validator
from ..set_manager import SetManager

APP_TITLE = "Baja Music — Korg Pa800 MIDI Studio"


def run() -> None:
    app = Pa800StudioApp()
    app.mainloop()


class Pa800StudioApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.workspace = None
        self._style_probe = None
        self._pcg_file = None
        self._build_ui()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        top = ttk.Frame(self)
        top.pack(fill="x", padx=8, pady=(8, 0))
        ttk.Label(top, text="Baja Music — Korg Pa800 MIDI Studio",
                  font=("Segoe UI", 15, "bold")).pack(side="left")
        self.status = tk.StringVar(value="Spremno. Svi moduli direktno vezani.")
        ttk.Label(top, textvariable=self.status, foreground="#555").pack(side="right")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)
        self._build_set_tab(nb)
        self._build_optimizer_tab(nb)
        self._build_sty_tab(nb)
        self._build_sound_tab(nb)
        self._build_live_tab(nb)
        self._build_evidence_tab(nb)

    def _scrolled(self, parent) -> tk.Text:
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)
        text = tk.Text(frame, wrap="none", font=("Consolas", 10))
        sy = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        sx = ttk.Scrollbar(frame, orient="horizontal", command=text.xview)
        text.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        text.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return text

    def _set_text(self, widget: tk.Text, content: str) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", content)
        widget.configure(state="disabled")

    def _report_error(self, title: str, exc: BaseException) -> None:
        messagebox.showerror(title, f"{exc}\n\n{traceback.format_exc(limit=3)}")

    # ------------------------------------------------------------ 1) SET
    def _build_set_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" SET Manager ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="Otvori SET…", command=self._open_set).pack(side="left", padx=4)
        ttk.Button(bar, text="Probe resursa (native parseri)", command=self._probe_set).pack(side="left", padx=4)
        self.set_info = tk.StringVar(value="SET nije učitan.")
        ttk.Label(bar, textvariable=self.set_info).pack(side="left", padx=12)
        self.set_output = self._scrolled(tab)

    def _open_set(self) -> None:
        folder = filedialog.askdirectory(title="Otvori SET direktorij")
        if not folder:
            return
        try:
            self.workspace = SetManager(TargetModel.PA800).open_set(Path(folder))
            groups = {k: len(v) for k, v in self.workspace.resources.items()}
            self.set_info.set(f"{self.workspace.source}  |  {groups}")
            lines = [f"SET: {self.workspace.source}\n"]
            for group, files in self.workspace.resources.items():
                lines.append(f"[{group}] {len(files)} fajlova")
                for f in files:
                    lines.append(f"    {f.name}  ({f.stat().st_size:,} B)")
            self._set_text(self.set_output, "\n".join(lines) if len(lines) > 1 else "Prazan SET.")
            self.status.set("SET učitan.")
        except Exception as exc:
            self._report_error("SET greška", exc)

    def _probe_set(self) -> None:
        if self.workspace is None:
            messagebox.showinfo("Probe", "Prvo otvori SET direktorij.")
            return
        try:
            probes = SetManager(TargetModel.PA800).probe_workspace(self.workspace)
            self._set_text(self.set_output, json.dumps(probes, indent=2, ensure_ascii=False))
            self.status.set(f"Probe gotov: {len(probes)} resursa.")
        except Exception as exc:
            self._report_error("Probe greška", exc)

    # ------------------------------------------------------ 2) Optimizer
    def _build_optimizer_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" MIDI Optimizer ")

        left = ttk.Frame(tab)
        left.pack(side="left", fill="y", padx=(0, 8), pady=4)
        self.opt_output = self._scrolled(tab)

        row = ttk.Frame(left)
        row.pack(fill="x", pady=2)
        ttk.Button(row, text="MIDI fajl…", command=self._pick_midi).pack(side="left")
        self.midi_path = tk.StringVar(value="(nije odabran)")
        ttk.Label(left, textvariable=self.midi_path, wraplength=300).pack(fill="x", pady=2)

        opts = ttk.LabelFrame(left, text="Engine opcije (konzervativno)")
        opts.pack(fill="x", pady=6)
        self.var_velocity = tk.IntVar(value=0)
        self.var_drums = tk.BooleanVar(value=False)
        self.var_rx = tk.BooleanVar(value=False)
        self.var_art = tk.BooleanVar(value=False)
        self.var_art_int = tk.IntVar(value=35)
        self.var_cross = tk.BooleanVar(value=False)
        self.var_cross_amt = tk.IntVar(value=35)
        self.var_inst = tk.BooleanVar(value=False)
        self.var_inst_int = tk.IntVar(value=35)
        self.var_kit = tk.StringVar(value="")

        self._scale(opts, "Velocity strength", self.var_velocity)
        ttk.Checkbutton(opts, text="Uključi bubnjeve (ch10) u velocity", variable=self.var_drums).pack(anchor="w")
        ttk.Checkbutton(opts, text="Preferiraj RX/DNC zvukove (isti GM program)", variable=self.var_rx).pack(anchor="w")
        ttk.Checkbutton(opts, text="RX articulation engine (hardware zone)", variable=self.var_art).pack(anchor="w")
        self._scale(opts, "Articulation intensity", self.var_art_int)
        ttk.Checkbutton(opts, text="Cross-delay echo track (BPM sync)", variable=self.var_cross).pack(anchor="w")
        self._scale(opts, "Cross-delay amount", self.var_cross_amt)
        ttk.Checkbutton(opts, text="Instrument mix engine (samo nedostajući CC)", variable=self.var_inst).pack(anchor="w")
        self._scale(opts, "Instrument intensity", self.var_inst_int)

        kit_row = ttk.Frame(left)
        kit_row.pack(fill="x", pady=4)
        ttk.Label(kit_row, text="RX kit:").pack(side="left")
        self.kit_combo = ttk.Combobox(kit_row, textvariable=self.var_kit, state="readonly", width=28)
        self.kit_combo.pack(side="left", padx=4)
        ttk.Button(kit_row, text="Učitaj kitove", command=self._load_kits).pack(side="left")

        btns = ttk.Frame(left)
        btns.pack(fill="x", pady=8)
        ttk.Button(btns, text="AUDIT (read-only)", command=self._audit_midi).pack(side="left", padx=4)
        ttk.Button(btns, text="OPTIMIZUJ", command=self._optimize_midi).pack(side="left", padx=4)

    def _scale(self, parent, label, var) -> None:
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=1)
        ttk.Label(row, text=f"{label}: ").pack(side="left")
        lbl = ttk.Label(row, textvariable=var, width=4)
        lbl.pack(side="right")
        ttk.Scale(row, from_=0, to=100, variable=var,
                  orient="horizontal").pack(side="left", fill="x", expand=True)

    def _pick_midi(self) -> None:
        path = filedialog.askopenfilename(
            title="Odaberi MIDI fajl",
            filetypes=[("MIDI", "*.mid *.MID *.midi"), ("Sve", "*.*")])
        if path:
            self.midi_path.set(path)

    def _load_kits(self) -> None:
        try:
            from ..midi import available_rx_kits
            kits = available_rx_kits()
            self.kit_combo["values"] = [""] + kits
            self.status.set(f"RX kitova dokazano: {len(kits)}")
        except Exception as exc:
            self._report_error("RX kitovi", exc)

    def _audit_midi(self) -> None:
        path = Path(self.midi_path.get())
        if not path.is_file():
            messagebox.showinfo("Audit", "Odaberi MIDI fajl.")
            return

        def work():
            try:
                from ..midi import audit
                result = audit(path)
                brief = {
                    "file": result["path"], "format": result["format"],
                    "tracks": result["parsed_tracks"], "division": result["division"],
                    "issues": result["issues"],
                    "pa800_safe_to_transform": result["pa800_safe_to_transform"],
                    "duration_seconds": result["song_profile"]["duration_seconds"],
                    "tempo": result["song_profile"]["tempo_events"][:4],
                    "special_sounds": result["special_sound_usage"]["unique_names"],
                    "channels": result["song_profile"]["channels"],
                }
                text = json.dumps(brief, indent=2, ensure_ascii=False)
                self.after(0, lambda: self._set_text(self.opt_output, text))
                self.after(0, lambda: self.status.set(f"Audit gotov: {path.name}"))
            except Exception as exc:
                self.after(0, lambda: self._report_error("Audit greška", exc))

        self.status.set("Audit u toku…")
        threading.Thread(target=work, daemon=True).start()

    def _optimize_midi(self) -> None:
        path = Path(self.midi_path.get())
        if not path.is_file():
            messagebox.showinfo("Optimize", "Odaberi MIDI fajl.")
            return
        destination = filedialog.asksaveasfilename(
            title="Novi (optimizirani) fajl — postojeći se ne prepisuje",
            defaultextension=".MID",
            initialfile=path.stem + "_PA800_OPTIMIZED.MID",
            filetypes=[("MIDI", "*.mid *.MID")])
        if not destination:
            return
        options = dict(
            velocity_strength=int(self.var_velocity.get()),
            include_drums_velocity=self.var_drums.get(),
            prefer_rx_dnc=self.var_rx.get(),
            rx_kit_name=self.var_kit.get() or None,
            articulation_engine=self.var_art.get(),
            articulation_intensity=int(self.var_art_int.get()),
            cross_delay_engine=self.var_cross.get(),
            cross_delay_amount=int(self.var_cross_amt.get()),
            instrument_engine=self.var_inst.get(),
            instrument_intensity=int(self.var_inst_int.get()),
        )

        def work():
            try:
                from ..midi.safety import guard_optimize
                report = guard_optimize(path, Path(destination), **options)
                brief = {
                    "destination": report["destination"],
                    "total_changes": report["total_changes"],
                    "removed_CC": report["removed_cc_events"],
                    "velocity_changes": report["changed_velocity_events"],
                    "special_sound_changes": report["special_sound_changes"],
                    "articulation_changes": report["articulation_velocity_changes"],
                    "instrument_mix_changes": report["instrument_mix_changes"],
                    "cross_delay_notes": report["cross_delay_note_events"],
                    "verification": report["verification"],
                }
                text = json.dumps(brief, indent=2, ensure_ascii=False)
                self.after(0, lambda: self._set_text(self.opt_output, text))
                self.after(0, lambda: self.status.set(f"Optimizirano → {destination}"))
            except Exception as exc:
                self.after(0, lambda: self._report_error("Optimize greška", exc))

        self.status.set("Optimizacija u toku…")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------ 3) STY tab
    def _build_sty_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" STY Explorer ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="Otvori .STY…", command=self._open_sty).pack(side="left", padx=4)
        demo = self._find_demo_sty()
        if demo:
            ttk.Button(bar, text="Učitaj BANK01_DECOMP demo",
                       command=lambda d=demo: self._load_sty(d)).pack(side="left", padx=4)
        self.sty_info = tk.StringVar(value="STY nije učitan.")
        ttk.Label(bar, textvariable=self.sty_info).pack(side="left", padx=12)
        paned = ttk.PanedWindow(tab, orient="horizontal")
        paned.pack(fill="both", expand=True)
        left = ttk.Frame(paned)
        right = ttk.Frame(paned)
        paned.add(left, weight=1)
        paned.add(right, weight=3)
        self.sty_list = tk.Listbox(left, font=("Consolas", 10))
        self.sty_list.pack(fill="both", expand=True)
        self.sty_list.bind("<<ListboxSelect>>", self._sty_selected)
        self.sty_detail = self._scrolled(right)

    @staticmethod
    def _find_demo_sty() -> Path | None:
        candidates = [
            Path("/home/user/pa800_checkpoint/PA800_REVERSE_CHECKPOINT_2026-09-16/SOURCES/BANK01_DECOMP.STY"),
            Path(__file__).resolve().parents[3] / "SOURCES" / "BANK01_DECOMP.STY",
        ]
        for c in candidates:
            if c.is_file():
                return c
        return None

    def _open_sty(self) -> None:
        path = filedialog.askopenfilename(
            title="Otvori STY banku",
            filetypes=[("Korg STY", "*.sty *.STY"), ("Sve", "*.*")])
        if path:
            self._load_sty(Path(path))

    def _load_sty(self, path: Path) -> None:
        try:
            from ..style.serializer import StyleInspector
            self._style_probe = StyleInspector().probe(path)
            probe = self._style_probe
            self.sty_info.set(
                f"{path.name}  |  {probe.size:,} B  |  resursi: {probe.resources.get('resources', '?')} "
                f"(style={probe.resources.get('styles', '?')}, companion={probe.resources.get('companions', '?')})  |  "
                f"sekcije: {len(probe.sections)}  PC={probe.total_program_changes}  note={probe.total_note_events}"
            )
            self.sty_list.delete(0, "end")
            for section in probe.sections:
                self.sty_list.insert("end", f"[{section['idx']:02d}] {section['name'] or '(bez imena)'}"
                                           f"  {section['size']:>7,} B")
            self._set_text(self.sty_detail, "Odaberi sekciju lijevo…")
            self.status.set(f"STY učitan: {path.name}")
        except Exception as exc:
            self._report_error("STY greška", exc)

    def _sty_selected(self, _event) -> None:
        if self._style_probe is None:
            return
        selection = self.sty_list.curselection()
        if not selection:
            return
        section = self._style_probe.sections[selection[0]]
        lines = [
            f"Sekcija {section['idx']}: {section['name'] or '(bez imena)'}",
            f"  veličina:        {section['size']:,} B",
            f"  program change:  {section['program_changes']}",
            f"  note događaji:   {section['note_events']}",
            "",
            "Resursna mapa banke (PROVEN walker):",
        ]
        records = self._style_probe.resources.get("records") or []
        for r in records[:50]:
            lines.append(
                f"  @{r['offset']:#08x} [{r['index']:02d}] {r['type_name']:18s} "
                f"flags={r['flags']:#04x} size={r['payload_size']:,}"
                + ("  OC20" if r["compressed"] else ""))
        self._set_text(self.sty_detail, "\n".join(lines))

    # ------------------------------------------------------ 4) Sound tab
    def _build_sound_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Sound Catalog ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="Otvori .PCG…", command=self._open_pcg).pack(side="left", padx=4)
        ttk.Button(bar, text="RX/DNC registry (dokazano)", command=self._show_registry).pack(side="left", padx=4)
        self.sound_info = tk.StringVar(value="Katalog nije učitan.")
        ttk.Label(bar, textvariable=self.sound_info).pack(side="left", padx=12)
        filter_row = ttk.Frame(tab)
        filter_row.pack(fill="x")
        ttk.Label(filter_row, text="Filter: ").pack(side="left")
        self.sound_filter = tk.StringVar()
        self.sound_filter.trace_add("write", lambda *_: self._refresh_sound_list())
        ttk.Entry(filter_row, textvariable=self.sound_filter, width=30).pack(side="left")
        self.sound_output = self._scrolled(tab)

    def _open_pcg(self) -> None:
        path = filedialog.askopenfilename(
            title="Otvori PCG",
            filetypes=[("Korg PCG", "*.pcg *.PCG"), ("Sve", "*.*")])
        if not path:
            return
        try:
            from ..sound.pcg import NativePCGReader
            self._pcg_file = NativePCGReader().read(Path(path))
            self.sound_info.set(
                f"{Path(path).name}  |  programa: {len(self._pcg_file.programs)}  "
                f"|  imenovanih: {len(self._pcg_file.named)}  "
                f"|  KORF zapisa: {len(self._pcg_file.catalog_names)}")
            self._refresh_sound_list()
        except Exception as exc:
            self._report_error("PCG greška", exc)

    def _refresh_sound_list(self) -> None:
        needle = self.sound_filter.get().casefold()
        lines = []
        if self._pcg_file is not None:
            for i, program in enumerate(self._pcg_file.programs):
                name = program.name or "(bez imena)"
                if needle and needle not in name.casefold():
                    continue
                lines.append(f"[{i:4d}] {name:24s} kat={program.category if program.category is not None else '?':>3} "
                             f"size={program.size or 0:5d}")
        if not lines:
            lines.append("(nema rezultata — otvori PCG ili promijeni filter)")
        self._set_text(self.sound_output, "\n".join(lines[:2000]))

    def _show_registry(self) -> None:
        try:
            from ..midi import load_special_registry
            registry = load_special_registry()
            if not registry["available"]:
                messagebox.showinfo("Registry", "RX/DNC registry nije pronađen u data direktoriju.")
                return
            lines = [f"Registry: {registry['path']}", ""]
            for group in ("rx_sounds", "dnc_sounds"):
                lines.append(f"== {group.upper()} ({len(registry[group])}) ==")
                for row in registry[group]:
                    if all(row.get(k) is not None for k in ("cc00", "cc32", "pc")):
                        lines.append(f"  CC0={row['cc00']:3d} CC32={row['cc32']:3d} PC={row['pc']:3d}  {row['name']}")
            lines.append(f"\n== RX DRUM KITS ({len(registry['rx_drum_kits'])}) ==")
            for row in registry["rx_drum_kits"]:
                if row.get("factory_address_status") == "EXACT_FACTORY_CORPUS":
                    lines.append(f"  CC0={row['factory_corpus_cc00']:3d} CC32={row['factory_corpus_cc32']:3d} "
                                 f"PC={row['factory_corpus_pc']:3d}  {row['name']}")
            self.sound_info.set("RX/DNC registry — address-first (dokazano).")
            self._set_text(self.sound_output, "\n".join(lines))
        except Exception as exc:
            self._report_error("Registry greška", exc)

    # ------------------------------------------------------ 5) Live tab
    def _build_live_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Live MIDI ")
        left = ttk.Frame(tab)
        left.pack(side="left", fill="y", padx=(0, 8), pady=4)
        self.live_output = self._scrolled(tab)

        ttk.Button(left, text="Osvježi portove", command=self._refresh_ports).pack(fill="x", pady=2)
        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(left, textvariable=self.port_var, state="readonly", width=34)
        self.port_combo.pack(fill="x", pady=2)

        pcbox = ttk.LabelFrame(left, text="Address-first program select → Pa800")
        pcbox.pack(fill="x", pady=6)
        self.var_cc00 = tk.IntVar(value=121)
        self.var_cc32 = tk.IntVar(value=10)
        self.var_pc = tk.IntVar(value=0)
        self.var_channel = tk.IntVar(value=1)
        for label, var in (("CC0 (MSB)", self.var_cc00), ("CC32 (LSB)", self.var_cc32),
                           ("PC", self.var_pc), ("Kanal (1-16)", self.var_channel)):
            row = ttk.Frame(pcbox)
            row.pack(fill="x")
            ttk.Label(row, text=label, width=12).pack(side="left")
            ttk.Spinbox(row, from_=0, to=127 if var is not self.var_channel else 16,
                        textvariable=var, width=6).pack(side="left")
        ttk.Button(pcbox, text="Pošalji na Pa800", command=self._send_pc).pack(fill="x", pady=4)
        ttk.Button(pcbox, text="Odaberi po imenu iz registryja…", command=self._send_named).pack(fill="x")
        ttk.Button(left, text="Panic (All Notes Off)", command=self._panic).pack(fill="x", pady=6)
        ttk.Button(left, text="Sviraj učitani MIDI fajl", command=self._play_current).pack(fill="x", pady=2)

    def _live_log(self, text: str) -> None:
        self.live_output.configure(state="normal")
        self.live_output.insert("end", text + "\n")
        self.live_output.see("end")
        self.live_output.configure(state="disabled")

    def _refresh_ports(self) -> None:
        from ..midi import live
        info = live.list_ports()
        self.port_combo["values"] = info.get("outputs", [])
        if info.get("outputs"):
            suggested = (info.get("pa800_candidates") or info["outputs"])[0]
            self.port_var.set(suggested)
        self._live_log(json.dumps(info, indent=2, ensure_ascii=False))

    def _link_or_none(self):
        from ..midi.live import Pa800Link
        name = self.port_var.get()
        if not name:
            self._live_log("Nema odabranog porta → dry-run (nema slanja na hardware).")
            return None
        try:
            return Pa800Link(name).open()
        except Exception as exc:
            self._live_log(f"Port nije dostupan ({exc}) → dry-run.")
            return None

    def _send_pc(self) -> None:
        from ..midi.live import Pa800Link, select_program_messages, describe_event
        cc00, cc32, pc = int(self.var_cc00.get()), int(self.var_cc32.get()), int(self.var_pc.get())
        channel = max(0, min(15, int(self.var_channel.get()) - 1))
        events = select_program_messages(cc00, cc32, pc, channel)
        link = self._link_or_none()
        try:
            for event in events:
                if link is not None:
                    link.send_raw(event)
                self._live_log("→ " + describe_event(event))
            self.status.set(f"PC poslan (CC0={cc00}, CC32={cc32}, PC={pc})")
        finally:
            if link is not None:
                link.close()

    def _send_named(self) -> None:
        from ..midi.live import registry_sounds, Pa800Link, describe_event
        sounds = registry_sounds()
        picker = tk.Toplevel(self)
        picker.title("RX/DNC zvukovi (dokazano)")
        picker.geometry("460x420")
        listbox = tk.Listbox(picker, font=("Consolas", 10))
        listbox.pack(fill="both", expand=True)
        for s in sounds:
            listbox.insert("end", f"{s['name']:32s} {s['kind']}  CC0={s['cc00']} CC32={s['cc32']} PC={s['pc']}")

        def choose(_=None):
            sel = listbox.curselection()
            if not sel:
                return
            sound = sounds[sel[0]]
            self.var_cc00.set(sound["cc00"])
            self.var_cc32.set(sound["cc32"])
            self.var_pc.set(sound["pc"])
            picker.destroy()
            self._send_pc()

        ttk.Button(picker, text="Pošalji odabrano", command=choose).pack(fill="x")
        listbox.bind("<Double-Button-1>", choose)

    def _panic(self) -> None:
        from ..midi.live import Pa800Link, OutboundEvent, describe_event
        link = self._link_or_none()
        try:
            for channel in range(16):
                for cc in (123, 120):
                    event = OutboundEvent(0, 0xB0 | channel, bytes((cc, 0)))
                    if link is not None:
                        link.send_raw(event)
            self._live_log("→ PANIC: All Notes Off / All Sound Off na svih 16 kanala")
        finally:
            if link is not None:
                link.close()

    def _play_current(self) -> None:
        path = Path(self.midi_path.get())
        if not path.is_file():
            messagebox.showinfo("Playback", "Odaberi MIDI fajl u Optimizer tabu.")
            return
        link = self._link_or_none()
        if link is None:
            return

        def work():
            try:
                report = link.play_smf(path)
                self.after(0, lambda: self._live_log(json.dumps(report, indent=2)))
            except Exception as exc:
                self.after(0, lambda: self._report_error("Playback", exc))
            finally:
                link.close()

        self.status.set(f"Playback: {path.name}…")
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------ 6) Evidence
    def _build_evidence_tab(self, nb) -> None:
        tab = ttk.Frame(nb)
        nb.add(tab, text=" Evidence ")
        bar = ttk.Frame(tab)
        bar.pack(fill="x", pady=4)
        ttk.Button(bar, text="Self-test (validator)", command=self._self_test).pack(side="left", padx=4)
        ttk.Button(bar, text="Prikaži evidence registry", command=self._show_evidence).pack(side="left", padx=4)
        self.evidence_output = self._scrolled(tab)
        self._show_evidence()

    def _self_test(self) -> None:
        report = Validator(EvidenceRegistry.default()).smoke_report()
        self._set_text(self.evidence_output, report.format())
        self.status.set("Self-test: " + ("PASS" if report.ok else "FAIL"))

    def _show_evidence(self) -> None:
        registry = EvidenceRegistry.default()
        lines = ["EVIDENCE REGISTRY — šta smije, šta ne smije aplikacija:\n"]
        for module in registry.modules():
            for rule in registry.by_module(module):
                lines.append(f"[{rule.area:11s}] {rule.app_module:22s} {rule.policy.value:18s} "
                             f"{rule.confidence:26s} {rule.feature}")
                if rule.caveat:
                    lines.append(f"{'':36s}↳ {rule.caveat}")
        self._set_text(self.evidence_output, "\n".join(lines))


if __name__ == "__main__":
    run()
