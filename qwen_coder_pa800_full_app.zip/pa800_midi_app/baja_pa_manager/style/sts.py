from __future__ import annotations
from dataclasses import dataclass


@dataclass(slots=True)
class STSRecord:
    version_family: str
    payload: bytes
    raw: bytes


class STSAdapter:
    KNOWN_COMPANION_SIZES = {881, 921}

    def parse(self, payload: bytes) -> STSRecord:
        version = "unknown"
        if len(payload) in self.KNOWN_COMPANION_SIZES:
            version = f"known-size-{len(payload)}"
        return STSRecord(version, bytes(payload), bytes(payload))

    def compatible(self, a: STSRecord, b: STSRecord) -> bool:
        return a.version_family == b.version_family

    def build(self, record: STSRecord) -> bytes:
        return record.raw if record.raw else record.payload
