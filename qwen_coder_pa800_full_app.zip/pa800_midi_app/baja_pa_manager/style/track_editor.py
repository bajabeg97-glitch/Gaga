from __future__ import annotations
from copy import deepcopy

from .models import Style, TrackInfo


class StyleTrackEditor:
    def original_sounds(self, style: Style) -> dict[str, dict[int, TrackInfo]]:
        out: dict[str, dict[int, TrackInfo]] = {}
        for element_name, element in style.elements.items():
            out[element_name] = deepcopy(element.tracks)
        return out

    def apply_sounds_to_all_elements(
        self, style: Style, source_element: str, original: dict[str, dict[int, TrackInfo]]
    ) -> None:
        if source_element not in style.elements:
            raise KeyError(source_element)
        src = style.elements[source_element].tracks
        for name, element in style.elements.items():
            if name == source_element:
                continue
            element.tracks = deepcopy(src)

    def restore_original_sounds(
        self, style: Style, original: dict[str, dict[int, TrackInfo]]
    ) -> None:
        for name, tracks in original.items():
            if name in style.elements:
                style.elements[name].tracks = deepcopy(tracks)
