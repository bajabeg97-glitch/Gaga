from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

from ..core.binary import BinaryReader, BinaryWriter
from .models import Style, StyleElement, StyleCV, PatternEvent, TrackInfo


@dataclass(slots=True)
class ParsedType06:
    events: list[PatternEvent]
    raw: bytes


class Type06Codec:
    """Evidence-gated Type-06 codec.

    The event stream is treated as an opaque native region unless a concrete
    field map is supplied by a regression fixture.
    """

    def parse(self, payload: bytes) -> ParsedType06:
        return ParsedType06(events=[], raw=bytes(payload))

    def build(self, parsed: ParsedType06) -> bytes:
        if parsed.events:
            raise ValueError("No proven Type-06 event writer registered")
        return parsed.raw


class TrackInfoCodec:
    """Semantic TrackInfo facade; binary offset map must be injected by a
    native regression fixture before writing fields.
    """

    def parse(self, payload: bytes) -> TrackInfo:
        return TrackInfo(raw=bytes(payload))

    def build(self, info: TrackInfo) -> bytes:
        if info.raw:
            return info.raw
        raise ValueError("TrackInfo requires preserved native payload")


@dataclass
class StyleProbe:
    """Read-only uvid u STY banku — direktno iz dokazanog native parsera."""
    path: str
    size: int
    style_names: list[str] = field(default_factory=list)
    sections: list[dict] = field(default_factory=list)
    resources: dict = field(default_factory=dict)

    @property
    def total_program_changes(self) -> int:
        return sum(s["program_changes"] for s in self.sections)

    @property
    def total_note_events(self) -> int:
        return sum(s["note_events"] for s in self.sections)


class StyleInspector:
    """Direktno vezivanje dokazanih nativnih čitača na Style domenu.

    - ``native.resources`` (PROVEN KBEG/KEND walker) → resursna mapa banke
    - ``native.sty.KorgStyle`` (KORF/KBEG/OC31 scan) → sekcije, PC i note brojači

    Čitanje je IMPLEMENT (evidence rule "KBEG/KEND + OC20/OC31 native read").
    Pisanje ostaje IMPLEMENT_GUARDED na StyleSerializer-u.
    """

    def probe(self, path: Path) -> StyleProbe:
        path = Path(path)
        data = path.read_bytes()
        probe = StyleProbe(str(path), len(data))
        # 1) PROVEN resursni walker (41-ref struktura za BANK01_DECOMP)
        try:
            from ..native import walk_resources, summary, decompress_report
            records = walk_resources(data)
            probe.resources = summary(records)
            probe.resources["records"] = [
                {
                    "index": r.index, "offset": r.offset, "type": r.type,
                    "type_name": r.type_name, "flags": r.flags,
                    "payload_size": r.payload_size, "compressed": r.compressed,
                }
                for r in records
            ]
            probe.resources["decompression"] = decompress_report(data)
        except Exception as exc:
            probe.resources = {"error": str(exc)}
        # 2) KorgStyle KORF/KBEG/OC31 scan
        try:
            from ..native.sty import KorgStyle
            parsed = KorgStyle.from_file(path)
            probe.style_names = list(parsed.style_names)
            probe.sections = [
                {
                    "idx": s.idx, "name": s.name, "size": s.size,
                    "program_changes": len(s.program_changes),
                    "note_events": len(s.note_events),
                }
                for s in parsed.sections
            ]
        except Exception as exc:
            probe.resources.setdefault("sty_error", str(exc))
        return probe


class StyleSerializer:
    def parse(self, data: bytes, name: str = "") -> Style:
        # Preserve-first shell. Exact native parser belongs here when the
        # concrete fixture set is wired into production.
        return Style(name=name, version=0, raw=bytes(data))

    def build(self, style: Style) -> bytes:
        if style.raw and not style.elements:
            return style.raw
        raise ValueError("Safe writer needs proven native Style fixture map")
