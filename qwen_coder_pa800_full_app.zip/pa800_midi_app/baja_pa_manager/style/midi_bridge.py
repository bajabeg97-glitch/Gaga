from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path


class MidiSafetyError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class NoteFingerprint:
    channel: int
    note: int
    tick: int
    ordinal: int


def _iter_note_events(midi):
    # Optional mido dependency. We keep the import local.
    try:
        import mido
    except ImportError as exc:
        raise RuntimeError("Install optional dependency: pip install '.[midi]'") from exc
    absolute = 0
    ordinal = 0
    for track in midi.tracks:
        absolute = 0
        for msg in track:
            absolute += msg.time
            if msg.type in ("note_on", "note_off"):
                yield msg.channel, msg.note, absolute, ordinal, msg
                ordinal += 1


def snapshot_note_structure(midi) -> list[NoteFingerprint]:
    return [
        NoteFingerprint(ch, note, tick, ordinal)
        for ch, note, tick, ordinal, _ in _iter_note_events(midi)
    ]


def assert_note_structure_unchanged(before, after) -> None:
    a = snapshot_note_structure(before)
    b = snapshot_note_structure(after)
    if a != b:
        raise MidiSafetyError("Existing MIDI note timing/order/pitch changed")


class MidiBridge:
    def load(self, path: Path):
        try:
            import mido
        except ImportError as exc:
            raise RuntimeError("Install optional dependency: pip install '.[midi]'") from exc
        return mido.MidiFile(path)

    def save_checked(self, midi, path: Path, before_snapshot) -> None:
        # before_snapshot is a pre-edit MidiFile object.
        assert_note_structure_unchanged(before_snapshot, midi)
        midi.save(path)
