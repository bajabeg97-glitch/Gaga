from __future__ import annotations
from copy import deepcopy
from dataclasses import dataclass

from .models import Style


@dataclass
class StyleWorkspace:
    original: Style
    working: Style

    @classmethod
    def from_style(cls, style: Style) -> "StyleWorkspace":
        return cls(original=deepcopy(style), working=deepcopy(style))

    def update(self) -> Style:
        self.original = deepcopy(self.working)
        return self.working

    def reset(self) -> Style:
        self.working = deepcopy(self.original)
        return self.working
