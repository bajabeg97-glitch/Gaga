from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass(slots=True)
class TrackInfo:
    sound_msb: int = 0
    sound_lsb: int = 0
    program: int = 0
    volume: int = 100
    expression: int = 127
    pan: int = 64
    chorus: int = 0
    reverb: int = 0
    min_key: int = 0
    max_key: int = 127
    ntt_type: int = 0
    ntr: int = 0
    raw: bytes = b""


@dataclass(slots=True)
class PatternEvent:
    tick: int
    status: int
    data: bytes


@dataclass(slots=True)
class StyleCV:
    index: int
    events: list[PatternEvent] = field(default_factory=list)
    raw: bytes = b""


@dataclass(slots=True)
class StyleElement:
    name: str
    cvs: list[StyleCV] = field(default_factory=list)
    tracks: dict[int, TrackInfo] = field(default_factory=dict)
    raw: bytes = b""


@dataclass(slots=True)
class Style:
    name: str
    version: int
    elements: dict[str, StyleElement] = field(default_factory=dict)
    raw: bytes = b""
    unknown_regions: list[tuple[int, bytes]] = field(default_factory=list)
