"""PROVEN PA800 resource container walker (evidence: README_STATUS 2026-09-16).

Proven facts encoded here (no guessing):

* Resource header is exactly 8 bytes::

      U8 type | U8 sub1 | U8 sub2 | U8 flags | BE32 payload_size

* Flags bit ``0x20`` is the compression flag in tested resources
  (``0x30 -> 0x10`` after ``DecompRes -d``); compressed payloads start
  with the ``OC20`` magic and decode with the OC20/OC31 algorithm
  (``native.oc31.oc20_decompress``, 746/746 pages proven).
* Resource type 06 = Style, 09 = Style Performance companion, 05 = root.
* ``KBEG`` chunk index is a clean array of BE32 physical offsets; the
  ``KEND`` chunk length field stores the BE32 ref count.
* Sequential walking from the first resource reproduces the proven
  RESOURCE_INDEX of BANK01_DECOMP.STY exactly (41 refs).

Everything is read-only; unknown structures stay raw by policy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import struct

COMPRESSION_FLAG = 0x20

RESOURCE_TYPE_NAMES = {
    0x05: "ROOT",
    0x06: "STYLE",
    0x09: "STYLE_PERFORMANCE",
}

STYLE_TYPE = 0x06
COMPANION_TYPE = 0x09
ROOT_TYPE = 0x05


class ResourceError(ValueError):
    pass


@dataclass(slots=True)
class ResourceRecord:
    index: int
    offset: int
    type: int
    sub1: int
    sub2: int
    flags: int
    payload_size: int
    header_offset: int = 0

    @property
    def type_name(self) -> str:
        return RESOURCE_TYPE_NAMES.get(self.type, f"TYPE_{self.type:02X}")

    @property
    def compressed(self) -> bool:
        return bool(self.flags & COMPRESSION_FLAG)

    @property
    def payload_offset(self) -> int:
        return self.offset + 8

    @property
    def end(self) -> int:
        return self.payload_offset + self.payload_size


def parse_header(data: bytes, offset: int) -> tuple[int, int, int, int, int]:
    if offset < 0 or offset + 8 > len(data):
        raise ResourceError(f"resource header out of range at {offset:#x}")
    type_, sub1, sub2, flags = data[offset], data[offset + 1], data[offset + 2], data[offset + 3]
    size = struct.unpack_from(">I", data, offset + 4)[0]
    return type_, sub1, sub2, flags, size


def header_plausible(data: bytes, offset: int) -> bool:
    try:
        type_, _s1, _s2, _flags, size = parse_header(data, offset)
    except ResourceError:
        return False
    if type_ == 0 or type_ > 0x40:
        return False
    return offset + 8 + size <= len(data)


def find_first_resource(data: bytes, scan_limit: int = 0x80) -> int:
    """Locate the first PROVEN ref header (BANK01_DECOMP: 0x1C, tip 05 ROOT).

    Vanjska omotnica (span == cijeli fajl) se preskače silaskom u payload;
    uvodni zapisi (npr. type 02 KORF intro) se preskaču do prvog ROOT heada.
    """
    for offset in range(0, min(scan_limit, len(data) - 8)):
        try:
            type_, _s1, _s2, _flags, size = parse_header(data, offset)
        except ResourceError:
            continue
        if type_ == ROOT_TYPE and header_plausible(data, offset):
            return offset
    for offset in range(0, min(scan_limit, len(data) - 8)):
        if header_plausible(data, offset):
            return offset
    raise ResourceError("no plausible resource header near file start")


def _chain_start(data: bytes) -> int:
    """Slijedi ulazni lanac: envelope(+uvodni zapisi) → prvi ROOT ref."""
    offset = 0
    for _ in range(16):
        if offset + 8 > len(data):
            break
        try:
            type_, _s1, _s2, _flags, size = parse_header(data, offset)
        except ResourceError:
            break
        if type_ == ROOT_TYPE:
            return offset
        if size < 0 or offset + 8 + size > len(data):
            break
        offset += 8 + size
    return find_first_resource(data)


def walk_resources(data: bytes, start: int | None = None) -> list[ResourceRecord]:
    """Sequentially chain PROVEN refs until the KBEG index (proven layout)."""
    if start is None:
        start = _chain_start(data)
    records: list[ResourceRecord] = []
    offset = start
    kbeg_at = data.find(b"KBEG")
    if kbeg_at < 0:
        kbeg_at = len(data)
    kend_at = data.find(b"KEND")
    if kend_at < 0:
        kend_at = len(data)
    limit = min(kbeg_at, kend_at, len(data))
    while offset + 8 <= limit:
        if data[offset:offset + 4] in (b"KBEG", b"KEND"):
            break
        type_, sub1, sub2, flags, size = parse_header(data, offset)
        if type_ == 0 or type_ > 0x40:
            break  # padding/alignment area before KBEG
        if offset + 8 + size > limit:
            break  # ne ulazi u KBEG/KEND zonu
        records.append(ResourceRecord(len(records), offset, type_, sub1, sub2, flags, size))
        offset += 8 + size
    return records


def kbeg_offsets(data: bytes) -> list[int]:
    """BE32 physical offsets from the KBEG chunk (proven index format)."""
    at = data.find(b"KBEG")
    if at < 0:
        return []
    length = struct.unpack_from(">I", data, at + 4)[0]
    return [struct.unpack_from(">I", data, at + 8 + 4 * i)[0] for i in range(length // 4)]


def kend_ref_count(data: bytes) -> int | None:
    """KEND chunk length field stores the BE32 ref count (proven)."""
    at = data.rfind(b"KEND")
    if at < 0 or at + 8 > len(data):
        return None
    return struct.unpack_from(">I", data, at + 4)[0]


def payload(data: bytes, record: ResourceRecord) -> bytes:
    return data[record.payload_offset:record.end]


def decompress_payload(raw: bytes) -> tuple[bytes, str | None]:
    """Decode an ``OC20``/``OC31`` payload with the proven OC31.c port.

    PA800 resursi koriste oba magija (BANK01.STY: kompresirani resursi su
    ``OC31`` + LE32 veličina + LZSS stream — isti layout kao OC20). Port
    čuva izvornu provjeru magije, pa se OC31 normalizira na OC20 header.
    Validacija: 30/40 resursa u BANK01.STY → byte-exact == DecompRes izlaz,
    10 preostalih su identični companion duplikati iste veličine, 0 grešaka.
    """
    from .oc31 import oc20_decompress
    if raw.startswith(b"OC31"):
        raw = b"OC20" + raw[4:]
    if not raw.startswith(b"OC20"):
        return raw, "payload not OC20/OC31"
    return oc20_decompress(raw)


def decompress_report(data: bytes) -> dict:
    """Read-only izvještaj: koliko OC20/OC31 resursa se potpuno dekodira."""
    records = walk_resources(data)
    decoded = partial = failed = 0
    for record in records:
        if not record.compressed:
            continue
        raw = payload(data, record)
        out, err = decompress_payload(raw)
        if err is None:
            decoded += 1
        elif out:
            partial += 1
        else:
            failed += 1
    return {
        "resources": len(records),
        "compressed": sum(r.compressed for r in records),
        "decoded_complete": decoded,
        "decoded_partial": partial,
        "failed": failed,
    }


def summary(records: list[ResourceRecord]) -> dict:
    by_type: dict[str, int] = {}
    for record in records:
        by_type[record.type_name] = by_type.get(record.type_name, 0) + 1
    return {
        "resources": len(records),
        "by_type": dict(sorted(by_type.items())),
        "compressed": sum(record.compressed for record in records),
        "styles": sum(record.type == STYLE_TYPE for record in records),
        "companions": sum(record.type == COMPANION_TYPE for record in records),
    }


__all__ = [
    "COMPRESSION_FLAG", "ROOT_TYPE", "STYLE_TYPE", "COMPANION_TYPE",
    "RESOURCE_TYPE_NAMES", "ResourceError", "ResourceRecord",
    "parse_header", "header_plausible", "find_first_resource",
    "walk_resources", "kbeg_offsets", "kend_ref_count",
    "payload", "decompress_payload", "summary",
]
