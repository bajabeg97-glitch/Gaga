"""Native PA800 parseri — direktno iz reverse-engineering checkpointa.

* ``resources`` — PROVEN 8-byte header + KBEG/KEND walker (+OC20 hook)
* ``oc31``      — OC20/OC31 dekompresor (port iz KORG-Tools oc31.c)
* ``sty``       — KorgStyle STY parser (KORF/KBEG/OC31 sekcije, PC/note scan)
* ``pcg``       — KorgPCG parser (KORF katalog + OC32 programi)
* ``pad``       — KorgPad parser (imena padova)
"""
from .resources import (
    ResourceError, ResourceRecord, walk_resources, kbeg_offsets,
    kend_ref_count, payload, decompress_payload, decompress_report, summary,
    COMPRESSION_FLAG, STYLE_TYPE, COMPANION_TYPE, ROOT_TYPE,
)
from .oc31 import oc20_decompress

__all__ = [
    "ResourceError", "ResourceRecord", "walk_resources", "kbeg_offsets",
    "kend_ref_count", "payload", "decompress_payload", "decompress_report",
    "summary", "COMPRESSION_FLAG", "STYLE_TYPE", "COMPANION_TYPE", "ROOT_TYPE",
    "oc20_decompress",
]
