from __future__ import annotations
from dataclasses import dataclass

from ..core.models import TargetModel


@dataclass(frozen=True, slots=True)
class ModelCapabilities:
    model: TargetModel
    user_dk_banks: int
    notes: str = ""


DEFAULT_CAPABILITIES = {
    TargetModel.PA800: ModelCapabilities(TargetModel.PA800, user_dk_banks=64, notes="safe default"),
    TargetModel.PA80: ModelCapabilities(TargetModel.PA80, user_dk_banks=64),
    TargetModel.PA1X: ModelCapabilities(TargetModel.PA1X, user_dk_banks=64),
    TargetModel.PA2X: ModelCapabilities(TargetModel.PA2X, user_dk_banks=64),
    TargetModel.PA3X: ModelCapabilities(TargetModel.PA3X, user_dk_banks=64),
    TargetModel.PA4X: ModelCapabilities(TargetModel.PA4X, user_dk_banks=64),
}


class ModelAdapter:
    def __init__(self, source: TargetModel, target: TargetModel):
        self.source = source
        self.target = target

    def address_crosswalk(self, msb: int, lsb: int, program: int) -> tuple[int, int, int]:
        # Address-first policy. Special-case mappings should be loaded from
        # an evidence DB rather than guessed here.
        return msb, lsb, program
