from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path

from .core.models import TargetModel
from .core.container import ContainerReader, NativeContainer


@dataclass
class SetWorkspace:
    source: Path
    target_model: TargetModel
    root: Path
    resources: dict[str, list[Path]] = field(default_factory=dict)
    original_snapshots: dict[str, bytes] = field(default_factory=dict)
    probes: dict[str, dict] = field(default_factory=dict)

    def reset_resource(self, key: str) -> None:
        # Concrete resource engines perform the actual rollback.
        self.original_snapshots.pop(key, None)

    def manifest(self) -> dict:
        return {k: [str(p) for p in v] for k, v in self.resources.items()}


class SetManager:
    RESOURCE_DIRS = ("STYLE", "PAD", "PERFORM", "SOUND", "PCM", "GLOBAL")
    PROBE_SUFFIXES = {".STY", ".PCG", ".PAD"}

    def __init__(self, model: TargetModel = TargetModel.PA800):
        self.model = model
        self.reader = ContainerReader()

    def open_set(self, path: Path) -> SetWorkspace:
        path = Path(path).resolve()
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(path)
        ws = SetWorkspace(path, self.model, path)
        for name in self.RESOURCE_DIRS:
            folder = path / name
            if folder.exists():
                ws.resources[name] = sorted(folder.iterdir())
        return ws

    def new_set(self, path: Path) -> SetWorkspace:
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        for name in self.RESOURCE_DIRS:
            (path / name).mkdir(exist_ok=True)
        return self.open_set(path)

    def probe_workspace(self, ws: SetWorkspace) -> dict[str, dict]:
        """Direktno (read-only) ispitaj sve poznate resursne fajlove u SET-u
        dokazanim native parserima — STY banke, PCG programe, PAD imena."""
        from .style.serializer import StyleInspector
        from .sound.pcg import NativePCGReader
        from .native.pad import KorgPad
        inspector = StyleInspector()
        pcg_reader = NativePCGReader()
        for group, files in ws.resources.items():
            for file_path in files:
                suffix = file_path.suffix.upper()
                if suffix not in self.PROBE_SUFFIXES:
                    continue
                key = f"{group}/{file_path.name}"
                try:
                    if suffix == ".STY":
                        probe = inspector.probe(file_path)
                        ws.probes[key] = {
                            "kind": "STY",
                            "size": probe.size,
                            "style_names": probe.style_names[:16],
                            "style_name_count": len(probe.style_names),
                            "sections": len(probe.sections),
                            "program_changes": probe.total_program_changes,
                            "note_events": probe.total_note_events,
                            "resources": {k: v for k, v in probe.resources.items() if k != "records"},
                        }
                    elif suffix == ".PCG":
                        pcg = pcg_reader.read(file_path)
                        ws.probes[key] = {
                            "kind": "PCG",
                            "programs": len(pcg.programs),
                            "named": len(pcg.named),
                            "catalog_names": pcg.catalog_names[:16],
                        }
                    elif suffix == ".PAD":
                        pad = KorgPad.from_file(file_path)
                        ws.probes[key] = {
                            "kind": "PAD",
                            "size": pad.size,
                            "names": pad.names[:16],
                        }
                except Exception as exc:
                    ws.probes[key] = {"kind": suffix.lstrip("."), "error": str(exc)}
        return ws.probes
