"""Baja Music — Korg Pa800 Manager & MIDI Studio.

Paket direktno veže:
  * core    — modeli, evidence registry, validator, binarni alati
  * native  — dokazani PA800 parseri (KBEG/KEND, OC20/OC31, STY, PCG, PAD)
  * midi    — konzervativni MIDI optimizer/auditor + RX/DNC evidence
  * gui     — Tkinter aplikacija (``python main.py gui``)
"""
from __future__ import annotations

__version__ = "1.1.0"
TARGET_MODEL = "PA800"

from .core.models import TargetModel, WritePolicy, ValidationReport, ValidationIssue  # noqa: F401
from .core.evidence import EvidenceRegistry, EvidenceRule  # noqa: F401
