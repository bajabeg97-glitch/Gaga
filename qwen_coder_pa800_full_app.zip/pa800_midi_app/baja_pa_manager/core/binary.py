from __future__ import annotations

import struct
from dataclasses import dataclass


class BinaryError(ValueError):
    pass


@dataclass
class BinaryReader:
    data: bytes
    pos: int = 0

    def remaining(self) -> int:
        return len(self.data) - self.pos

    def take(self, n: int) -> bytes:
        if n < 0 or self.pos + n > len(self.data):
            raise BinaryError(f"Out of bounds read: pos={self.pos} n={n} size={len(self.data)}")
        out = self.data[self.pos:self.pos+n]
        self.pos += n
        return out

    def u8(self) -> int:
        return self.take(1)[0]

    def i8(self) -> int:
        return struct.unpack("<b", self.take(1))[0]

    def u16le(self) -> int:
        return struct.unpack("<H", self.take(2))[0]

    def u32le(self) -> int:
        return struct.unpack("<I", self.take(4))[0]

    def i16le(self) -> int:
        return struct.unpack("<h", self.take(2))[0]

    def i32le(self) -> int:
        return struct.unpack("<i", self.take(4))[0]

    def bytes_at(self, offset: int, n: int) -> bytes:
        if offset < 0 or offset + n > len(self.data):
            raise BinaryError("bytes_at out of range")
        return self.data[offset:offset+n]


class BinaryWriter:
    def __init__(self, initial: bytes = b""):
        self.buf = bytearray(initial)

    def write_at(self, offset: int, data: bytes) -> None:
        if offset < 0:
            raise BinaryError("negative offset")
        end = offset + len(data)
        if end > len(self.buf):
            self.buf.extend(b"\x00" * (end - len(self.buf)))
        self.buf[offset:end] = data

    def u8_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<B", value & 0xFF))

    def u16le_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<H", value & 0xFFFF))

    def u32le_at(self, offset: int, value: int) -> None:
        self.write_at(offset, struct.pack("<I", value & 0xFFFFFFFF))

    def build(self) -> bytes:
        return bytes(self.buf)
