from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable

from .models import WritePolicy


@dataclass(frozen=True, slots=True)
class EvidenceRule:
    area: str
    feature: str
    app_module: str
    policy: WritePolicy
    confidence: str
    caveat: str


class EvidenceRegistry:
    def __init__(self, rules: Iterable[EvidenceRule]):
        self._rules = list(rules)

    @classmethod
    def default(cls) -> "EvidenceRegistry":
        return cls([
            EvidenceRule("SET", "Load/New/Save As", "SetManager", WritePolicy.IMPLEMENT, "HIGH", "Resource writers remain resource-specific."),
            EvidenceRule("STYLE", "Original/Working/Reset", "StyleWorkspace", WritePolicy.IMPLEMENT, "HIGH", "Working copy is explicit."),
            EvidenceRule("STYLE", "TrackInfo/Sound selector", "StyleTrackEditor", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Write only proven fields."),
            EvidenceRule("STYLE", "STS version compatibility", "STSAdapter", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Unknown leafs remain raw."),
            EvidenceRule("STYLE", "CV/Pattern/Type06", "StyleSerializer", WritePolicy.IMPLEMENT_GUARDED, "HIGH_SOFTWARE", "Use native writer authority."),
            EvidenceRule("STYLE", "KBEG/KEND + OC20/OC31 native read", "NativeParsers", WritePolicy.IMPLEMENT, "PROVEN", "8-byte resource header; 0x20 compression bit; OC20 decoder 746/746."),
            EvidenceRule("SOUND", "Address-first resolver", "SoundResolver", WritePolicy.IMPLEMENT, "VERY_HIGH", "Name is secondary when numeric address exists."),
            EvidenceRule("SOUND", "Oscillator unknown leaves", "OscillatorEditor", WritePolicy.PRESERVE_ONLY, "HIGH", "Do not synthesize unknown bytes."),
            EvidenceRule("MIDI", "RX/DNC identity select", "MidiOptimizer", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Catalog-verified bindings only."),
            EvidenceRule("MIDI", "RX articulation working zones", "MidiOptimizer", WritePolicy.IMPLEMENT_GUARDED, "HARDWARE_OBSERVED_PARTIAL", "Only proven windows; candidates audit-only."),
            EvidenceRule("MIDI", "Existing note timing/pitch", "MidiSafety", WritePolicy.IMPLEMENT, "PROJECT_HARD_RULE", "No quantize, snap, humanize or pitch mutation."),
            EvidenceRule("PERFORMANCE", "Release2/Release3 preservation", "PerformanceSerializer", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Preserve unknown extension regions."),
            EvidenceRule("BKP", "ALL/dependency graph", "DependencyResolver", WritePolicy.IMPLEMENT_GUARDED, "VERY_HIGH", "Unknown edge types stay opaque."),
            EvidenceRule("PCM", "Compression writer", "PCMManager", WritePolicy.LATER, "HIGH", "Read/preserve first; no unproven codec writer."),
        ])

    def by_module(self, module: str) -> list[EvidenceRule]:
        return [r for r in self._rules if r.app_module == module]

    def modules(self) -> list[str]:
        return sorted({r.app_module for r in self._rules})
