from __future__ import annotations

from .evidence import EvidenceRegistry
from .models import ValidationReport


class Validator:
    def __init__(self, evidence: EvidenceRegistry):
        self.evidence = evidence

    def validate_nonempty(self, name: str, value: object) -> ValidationReport:
        r = ValidationReport()
        if value is None or value == "" or value == b"":
            r.add("ERROR", "EMPTY", f"{name} is empty")
        return r

    def smoke_report(self) -> ValidationReport:
        r = ValidationReport()
        required = {
            "SetManager", "StyleWorkspace", "StyleTrackEditor",
            "SoundResolver", "PerformanceSerializer", "DependencyResolver"
        }
        available = set(self.evidence.modules())
        missing = sorted(required - available)
        if missing:
            r.add("ERROR", "MODULE_EVIDENCE", f"Missing evidence entries: {missing}")
        r.add("INFO", "POLICY", "Unknown fields are preserve-only by design")
        r.add("INFO", "MIDI", "Existing note positions and pitches are immutable")
        return r
