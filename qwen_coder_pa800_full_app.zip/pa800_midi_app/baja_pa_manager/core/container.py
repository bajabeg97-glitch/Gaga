from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path


@dataclass(slots=True)
class Resource:
    type_id: int
    name: str
    payload: bytes
    raw: bytes = b""
    metadata: dict = field(default_factory=dict)


@dataclass(slots=True)
class NativeContainer:
    magic: bytes
    resources: list[Resource] = field(default_factory=list)
    raw_prefix: bytes = b""
    raw_suffix: bytes = b""

    def add(self, resource: Resource) -> None:
        self.resources.append(resource)


class ContainerReader:
    """Preserve-first container shell, direktno vezan na dokazani KBEG/KEND
    resursni walker iz ``native.resources``.

    Ako ulaz ima KBEG/KEND strukturu (Pa800 .STY/.PCG/.PAD/…), resursi se
    popunjavaju stvarnim dokazanim zapisima; u suprotnom ostaje sirovi
    preserve shell. Pisanje je i dalje resource-specifično i guarded.
    """

    def load_file(self, path: Path) -> NativeContainer:
        return self.load_bytes(path.read_bytes())

    def load_bytes(self, data: bytes) -> NativeContainer:
        container = NativeContainer(magic=data[:4], raw_prefix=data)
        try:
            from ..native import walk_resources, payload as record_payload, summary
        except ImportError:  # pragma: no cover - package always ships native
            return container
        try:
            records = walk_resources(data)
        except Exception:
            return container
        if not records or b"KBEG" not in data:
            return container
        for record in records:
            container.add(Resource(
                type_id=record.type,
                name=record.type_name,
                payload=record_payload(data, record),
                raw=data[record.offset:record.end],
                metadata={
                    "index": record.index,
                    "offset": record.offset,
                    "sub1": record.sub1,
                    "sub2": record.sub2,
                    "flags": record.flags,
                    "compressed": record.compressed,
                },
            ))
        container.magic = data[:4]
        container.raw_prefix = data
        container.raw_suffix = b""
        # attach a proven-resource summary for callers (GUI/CLI)
        try:
            container.resources  # noqa: B018 - explicit touch
            summary(data and records)  # type: ignore[arg-type]
        except Exception:
            pass
        return container


class ContainerWriter:
    def save_file(self, container: NativeContainer, path: Path) -> None:
        path.write_bytes(self.build(container))

    def build(self, container: NativeContainer) -> bytes:
        if container.raw_prefix and not container.resources:
            return container.raw_prefix
        return container.raw_prefix
