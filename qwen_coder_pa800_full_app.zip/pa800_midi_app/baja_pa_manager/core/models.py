from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TargetModel(str, Enum):
    PA800 = "PA800"
    PA80 = "PA80"
    PA1X = "PA1X"
    PA2X = "PA2X"
    PA3X = "PA3X"
    PA4X = "PA4X"


class WritePolicy(str, Enum):
    IMPLEMENT = "IMPLEMENT"
    IMPLEMENT_GUARDED = "IMPLEMENT_GUARDED"
    PRESERVE_ONLY = "PRESERVE_ONLY"
    READ_ONLY = "READ_ONLY"
    HARDWARE_GATE = "HARDWARE_GATE"
    LATER = "LATER"


@dataclass(slots=True)
class RawRegion:
    offset: int
    data: bytes
    label: str = "unknown"

    @property
    def end(self) -> int:
        return self.offset + len(self.data)


@dataclass(slots=True)
class ResourceRef:
    resource_type: str
    name: str
    index: int | None = None
    address: tuple[int, int, int] | None = None
    size: int | None = None
    exists: bool | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ValidationIssue:
    level: str
    code: str
    message: str
    path: str | None = None


@dataclass(slots=True)
class ValidationReport:
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not any(i.level == "ERROR" for i in self.issues)

    def add(self, level: str, code: str, message: str, path: str | None = None) -> None:
        self.issues.append(ValidationIssue(level, code, message, path))

    def format(self) -> str:
        if not self.issues:
            return "VALIDATION: PASS"
        lines = ["VALIDATION: " + ("PASS" if self.ok else "FAIL")]
        for item in self.issues:
            where = f" [{item.path}]" if item.path else ""
            lines.append(f"{item.level} {item.code}{where}: {item.message}")
        return "\n".join(lines)
