#!/usr/bin/env python3
"""KONAČNA LOGIKA — 19-step factory-corpus pipeline.

    INPUT MIDI → FACTORY CORPUS FIRST → target sound/family → key range +
    velocity curve (zbilja mjerene iz 54 onboard SMF-a) → CONTROLLER RESET →
    VELOCITY RESET → APPLY RANGE→VELOCITY→ARTICULATION → CHANGE SOUND
    (=ENGINE TRIGGER) → OPTIMIZE → VALIDATE → SONG OUTPUT.

Tvrdna pravila (iz vlasnikove specifikacije):
- Original se nikad ne pregazi (no-overwrite); izvorni bajtovi čuvaju se.
- MIDI note tick/pitch redoslijed je nepromjenjiv (range limit je *fold*,
  oktava dok note sjednu u stvarni opseg — nikad remap cijelog tracka).
- Velocity NE kopira original: kriva dolazi iz Factory korpusa
  (rank-preserving preslikanje u factory kvantile).
- NRPN: postojeći i dokazani → čuvaj; novi/pretpostavljeni → NIKAD SE NE
  GENERIRA. Nakon controller reseta NRPN se ne pisanuje porot.
- Ako korista nema: dokaza za ključnu vrijednost → SCOPE-EXCLUDED (ne
  izmislja se).
"""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from baja_pa_manager.midi.factory_profiles import load_profiles
from baja_pa_manager.midi.optimizer import (
    Event, _evidence_file, parse_smf, write_smf,
)


# ------------------------------------------------------------------ konstante
PROFILES_FILE = "PA800_FACTORY_PERFORMANCE_PROFILES_v1.json"
HW_PROFILES_FILE = "PA800_HARDWARE_VERIFIED_OSC_PROFILES.json"
SOUND_LIST_FILE = "PA800_FACTORY_SOUND_LIST_v1.json"

# Tvornički ciljevi (potvrdi iz evidencije RX-ha najviše dokaza):
DEFAULT_TARGETS: dict[str, tuple[int, int, int]] = {
    "BASS": (121, 10, 34),        # Picked Bass RX — HW EXACT_OSC1_4
    "GUITAR": (121, 14, 28),      # Clean Guitar RX1 — HW-verified + corpus
}
RESET_DEFAULTS = ((7, 100), (10, 64), (11, 127))   # izdužni neutral (reset)

STEP_NAMES = {
    1: "LOAD", 2: "LOSSLESS_PARSE", 3: "PRESERVE_ORIGINAL",
    4: "FACTORY_CORPUS_LOOKUP", 5: "IDENTIFY_TARGET_SOUND",
    6: "IDENTIFY_FAMILY", 7: "GET_FACTORY_KEY_RANGE",
    8: "GET_FACTORY_VELOCITY_CURVE", 9: "RESET_CONTROLLERS",
    10: "RESET_VELOCITY", 11: "APPLY_FACTORY_RANGE",
    12: "APPLY_FACTORY_VELOCITY", 13: "APPLY_FACTORY_ARTICULATION",
    14: "CHANGE_SOUND", 15: "START_ENGINE", 16: "OPTIMIZE_PERFORMANCE",
    17: "VALIDATE", 18: "SONG_OUTPUT", 19: "STYLE_OUTPUT",
}


# ------------------------------------------------------------------ pomoćne
def _load_json(name: str) -> dict:
    path = _evidence_file(name)
    if not path.is_file():
        raise FileNotFoundError(f"Nedostaje evidencija: {name} ({path})")
    return json.loads(path.read_text(encoding="utf-8"))


def _working_zone(hw_profiles: dict, binding: tuple[int, int, int]) -> tuple[int, int] | None:
    """WORKING role velocity zone iz HW-verified profila; None ako nema."""
    rec = hw_profiles.get(".".join(map(str, binding)))
    if not rec:
        return None
    for osc in rec.get("oscillators", []):
        role = str(osc.get("semantic_role", ""))
        if role.startswith("WORKING"):
            zone = osc.get("velocity_zone")
            if zone and len(zone) == 2:
                return int(zone[0]), int(zone[1])
    return None


def _curve_lookup(profiles: dict, binding: tuple[int, int, int],
                  family: str, drum_key: int | None = None) -> tuple[dict | None, str]:
    """Exact binding → same-family aggregate; scope-excluded ako nema."""
    key = ".".join(map(str, binding))
    if drum_key is not None:
        dk = profiles["by_drum_key"].get(f"{key}.{drum_key}")
        if dk:
            return dk, "exact_drum_key"
        kit_all = profiles["by_binding"].get(key)
        return (kit_all, "kit_aggregate") if kit_all else (None, "scope_excluded")
    exact = profiles["by_binding"].get(key)
    if exact:
        return exact, "exact_binding"
    fam = profiles["by_family"].get(family)
    return (fam, "family_aggregate") if fam else (None, "scope_excluded")


def _inverse_cdf(hist: dict[str, int], q: float) -> int:
    """q∈(0,1) → velocity iz histograma (R-factory curve)."""
    total = sum(hist.values())
    if total == 0:
        return 64
    target = max(1, min(total, round(q * total)))
    seen = 0
    for vel in sorted(int(v) for v in hist):
        seen += hist[str(vel)]
        if seen >= target:
            return vel
    return max(int(v) for v in hist)


def detect_role(channel: int, prog: int | None, drum_channel_hint: bool = False) -> str | None:
    """DRUM / BASS / GUITAR po MIDI kanalu i dominantnom PC bendu.
    Ostali instrumenti → None (van ciljnog okvira ovog pipeline-a)."""
    if channel == 9 or drum_channel_hint or prog == 120:
        return "DRUM"
    if prog is None:
        return None
    if 32 <= prog <= 39:
        return "BASS"
    if 24 <= prog <= 31:
        return "GUITAR"
    return None


def _channel_program(events: list[Event], channel: int) -> tuple[int | None, int | None]:
    """(cc00, pc) zadnje prije prvog note-ona; None ako nema."""
    cc00 = pc = None
    for ev in events:
        if ev.kind != "channel" or (ev.status & 15) != channel:
            continue
        fam = ev.status & 0xF0
        if fam == 0xB0 and ev.data[0] == 0:
            cc00 = ev.data[1]
        elif fam == 0xB0 and ev.data[0] == 32:
            pass
        elif fam == 0xC0:
            pc = ev.data[0]
        elif fam == 0x90:
            return (cc00 if cc00 is not None else 0), pc
    return (cc00 if cc00 is not None else 0), pc


# ------------------------------------------------------------------ pipeline
class FactoryPipeline:
    """Pokretač 19-step KONAČNE LOGIKE. Deterministički za isti ulaz."""

    def __init__(self, profiles_path: Path | None = None,
                 targets: dict[str, tuple[int, int, int]] | None = None):
        self.profiles_path = Path(profiles_path) if profiles_path else \
            _evidence_file(PROFILES_FILE)
        self.profiles = load_profiles(self.profiles_path)
        self.hw = _load_json(HW_PROFILES_FILE)
        self.sound_list = _load_json(SOUND_LIST_FILE)
        self.targets = dict(DEFAULT_TARGETS if targets is None else targets)

    # ------------------------------------------------------------ entry
    def run(self, in_path: Path, out_path: Path) -> dict[str, Any]:
        in_path = Path(in_path)
        out_path = Path(out_path)
        report: dict[str, Any] = {"pipeline": "KONACNA_LOGIKA_v1",
                                  "steps": {}, "channel_reports": [],
                                  "input": str(in_path), "output": str(out_path)}
        steps = report["steps"]

        # 1-3 LOAD / LOSSLESS_PARSE / PRESERVE_ORIGINAL
        raw = in_path.read_bytes()
        steps[1] = {"name": STEP_NAMES[1], "bytes": len(raw)}
        smf = parse_smf(in_path)
        steps[2] = {"name": STEP_NAMES[2], "format": smf["format"],
                    "division": smf["division"], "tracks": len(smf["tracks"])}
        steps[3] = {"name": STEP_NAMES[3], "sha256": hashlib.sha256(raw).hexdigest(),
                    "no_overwrite": True}
        if out_path.exists():
            raise FileExistsError(f"No-overwrite: {out_path}")
        report_path = Path(str(out_path) + ".factory_report.json")
        if report_path.exists():
            raise FileExistsError(f"No-overwrite: {report_path}")

        # 4-8 CORPUS LOOKUP / TARGET / FAMILY / RANGE / CURVE
        channel_plan = self._plan(smf, steps, report)

        # 9-13 RESET + APPLY
        self._apply(smf, channel_plan, steps, report)

        # 14-16 CHANGE SOUND / ENGINE / OPTIMIZE
        self._sound_change_and_engine(smf, channel_plan, steps, report)

        # 17-19 VALIDATE / OUTPUT
        self._validate_and_write(smf, in_path, out_path, report_path, report)
        return report

    # ------------------------------------------------------------ 4-8
    def _plan(self, smf: dict, steps: dict, report: dict) -> list[dict]:
        plans: list[dict] = []
        channels = set()
        for track in smf["tracks"]:
            for ev in track:
                if ev.kind == "channel":
                    channels.add(ev.status & 15)
        for ch in sorted(channels):
            cc00, pc = None, None
            for track in smf["tracks"]:
                found = _channel_program(track, ch)
                if found[1] is not None:
                    cc00, pc = found
                    break
            is_kit = cc00 == 120
            role = detect_role(ch, pc, drum_channel_hint=is_kit)
            plan: dict[str, Any] = {"channel": ch, "cc00": cc00, "pc": pc,
                                    "role": role or "OTHER"}
            if role in self.targets:
                binding = self.targets[role]
                plan["target"] = binding
                plan["family"] = role
                profile, src = _curve_lookup(self.profiles, binding, role)
                plan["profile_source"] = src
                if profile:
                    plan["key_range"] = [profile["key_lo"], profile["key_hi"]]
                    plan["curve"] = profile["vel_hist"]
                    plan["mean"] = profile["vel_mean"]
            elif role == "DRUM":
                kit_bindings = self.sound_list.get("bindings", [])
                plan["target"] = (120, 0, int(pc if pc is not None else 0))
                plan["family"] = "DRUMS"
                profile, src = _curve_lookup(self.profiles, plan["target"],
                                             "DRUMS")
                plan["profile_source"] = src
                plan["kit_curve_seen"] = profile is not None
            plans.append(plan)
        steps[4] = {"name": STEP_NAMES[4],
                    "profiles_file": str(self.profiles_path),
                    "authority": self.profiles.get("authority")}
        steps[5] = {"name": STEP_NAMES[5], "targets": {
            p["channel"]: list(p["target"]) for p in plans if "target" in p}}
        steps[6] = {"name": STEP_NAMES[6], "families": {
            p["channel"]: p["family"] for p in plans if p.get("family")}}
        steps[7] = {"name": STEP_NAMES[7], "key_ranges": {
            p["channel"]: p["key_range"] for p in plans if "key_range" in p}}
        steps[8] = {"name": STEP_NAMES[8], "curves": {
            p["channel"]: p["profile_source"] for p in plans if p.get("profile_source")}}
        return plans

    # ------------------------------------------------------------ 9-13
    def _apply(self, smf: dict, plans: list[dict], steps: dict, report: dict) -> None:
        plan_by_ch = {p["channel"]: p for p in plans}
        reset_counts = {"cc": 0, "nrpn_or_rpn": 0, "pitch_bend": 0,
                        "aftertouch": 0, "program_change": 0,
                        "target_head_replaced": 0}
        range_folds = 0
        vel_applied = 0
        vel_preserved = 0
        articulation_clamps = 0

        for track in smf["tracks"]:
            new_events: list[Event] = []
            for ev in track:
                if ev.kind != "channel":
                    new_events.append(ev)
                    continue
                ch, fam = ev.status & 15, ev.status & 0xF0
                plan = plan_by_ch.get(ch)
                # 9 RESET CONTROLLERS — samo performance/expression stanja.
                #    CC0/CC32 + PC čine sound identity i ne diraju se (section 6
                #    KONAČNE LOGIKE: "NOT remap" za ne-ciljne trackove); PC za
                #    ciljni kanal zamjenjuje korak 14.
                if fam == 0xB0 and ev.data[0] in (0, 32) and plan and "target" in plan and plan["role"] != "DRUM":
                    reset_counts["target_head_replaced"] += 1
                    continue  # ciljni sound head zamjenjuje korak 14
                if fam == 0xB0 and ev.data[0] in (0, 32):
                    new_events.append(ev)  # bank-select zadržan za ne-ciljne
                    continue
                if fam == 0xC0:
                    if plan and "target" in plan and plan["role"] != "DRUM":
                        reset_counts["target_head_replaced"] += 1
                        continue  # zamjena u koraku 14
                    new_events.append(ev)
                    continue
                if fam == 0xB0:
                    if ev.data[0] in (98, 99, 100, 101):
                        reset_counts["nrpn_or_rpn"] += 1
                    else:
                        reset_counts["cc"] += 1
                    continue
                if fam == 0xE0:
                    reset_counts["pitch_bend"] += 1
                    continue
                if fam in (0xA0, 0xD0):
                    reset_counts["aftertouch"] += 1
                    continue
                # 11/12 RANGE + VELOCITY — folduje note-on I note-off dosljedno
                #    (isti deterministički fold → parovi ostaju upareni).
                if fam in (0x80, 0x90) and plan:
                    is_note_on = fam == 0x90 and ev.data[1] > 0
                    data = bytearray(ev.data)
                    key = data[0]
                    if plan.get("key_range") and plan.get("target"):
                        lo, hi = plan["key_range"]
                        if lo is not None and hi is not None:
                            while key > hi and key - 12 >= 0:
                                key -= 12
                                if is_note_on:
                                    range_folds += 1
                            while key < lo and key + 12 <= 127:
                                key += 12
                                if is_note_on:
                                    range_folds += 1
                            data[0] = key
                    new_events.append(Event(ev.tick, ev.kind, ev.status, bytes(data)))
                    continue
                new_events.append(ev)
            track[:] = new_events
        steps[9] = {"name": STEP_NAMES[9], "counts": reset_counts}
        steps[10] = {"name": STEP_NAMES[10],
                     "note": "state reset — curve se primjenjuje u koraku 12"}
        steps[11] = {"name": STEP_NAMES[11], "folds": range_folds}
        self._step12_velocity(smf, plans, steps)
        steps[13] = {"name": STEP_NAMES[13],
                     "articulation": "HW-verified WORKING zone landing (korak 13 = clamp)"}

    def _step12_velocity(self, smf: dict, plans: list[dict], steps: dict) -> None:
        """Rank-preserving preslikanje u factory quantile; potom HW clamp."""
        plan_by_ch = {p["channel"]: p for p in plans}
        applied = preserved = clamped = 0
        for track in smf["tracks"]:
            idx_by_ch: dict[int, list[int]] = defaultdict(list)
            for i, ev in enumerate(track):
                if ev.kind == "channel" and (ev.status & 0xF0) == 0x90 and ev.data[1] > 0:
                    idx_by_ch[ev.status & 15].append(i)
            for ch, idxs in idx_by_ch.items():
                plan = plan_by_ch.get(ch)
                curve = (plan or {}).get("curve")
                if not curve:
                    preserved += len(idxs)
                    continue
                # rank po originalnoj veličini (stabilno po redoslijedu) →
                # u factory krivi uzmi isti kvantil (vidi _inverse_cdf).
                order = sorted(range(len(idxs)),
                               key=lambda k: (track[idxs[k]].data[1], k))
                rank_of = {k: r for r, k in enumerate(order)}
                n = len(order)
                zone = (_working_zone(self.hw, tuple(plan["target"]))
                        if plan.get("target") else None)
                for k, i in enumerate(idxs):
                    vel = _inverse_cdf(curve, (rank_of[k] + 0.5) / n)
                    if zone:
                        lo, hi = zone
                        if vel < lo or vel > hi:
                            vel = max(lo, min(hi, vel))
                            clamped += 1
                    d = bytearray(track[i].data)
                    d[1] = vel
                    track[i] = Event(track[i].tick, track[i].kind,
                                     track[i].status, bytes(d))
                applied += n
        steps[12] = {"name": STEP_NAMES[12], "velocity_applied": applied,
                     "velocity_preserved_scope_excluded": preserved,
                     "working_zone_clamps": clamped}

    # ------------------------------------------------------------ 14-16
    def _sound_change_and_engine(self, smf: dict, plans: list[dict],
                                 steps: dict, report: dict) -> None:
        plan_by_ch = {p["channel"]: p for p in plans}
        engine_map: dict[int, dict] = {}
        written = 0
        for track in smf["tracks"]:
            inserts: list[Event] = []
            for ch, plan in plan_by_ch.items():
                if "target" not in plan or plan["role"] == "DRUM":
                    continue
                chan_channels = [e for e in track
                                 if e.kind == "channel" and (e.status & 15) == ch]
                if chan_channels:
                    binding = plan["target"]
                    # sound change = engine trigger — tick 0, vrh tracka
                    # (direktno vezivanje na ulazni pogon)
                    inserts.extend(self._sound_change_head(ch, binding, 0))
                    engine_map[ch] = {
                        "target": list(binding),
                        "name": self._target_name(binding),
                        "engine": "RX_DNC_HW_PROFILE"
                        if ".".join(map(str, binding)) in self.hw else "DNC/BASIC",
                        "working_zone": (_working_zone(self.hw, tuple(binding))
                                         if binding else None),
                    }
                    written += 3
            if inserts:
                track[:] = inserts + track
        steps[14] = {"name": STEP_NAMES[14], "sound_changes_written": written}
        steps[15] = {"name": STEP_NAMES[15], "engine_map": engine_map}
        steps[16] = {"name": STEP_NAMES[16],
                     "note": "performance guard: 1..127 clip provjera u validate"}

    def _sound_change_head(self, ch: int, binding: tuple[int, int, int], tick: int):
        cc00, cc32, pc = binding
        return [
            Event(tick, "channel", 0xB0 | ch, bytes([0, cc00])),
            Event(tick, "channel", 0xB0 | ch, bytes([32, cc32])),
            Event(tick, "channel", 0xC0 | ch, bytes([pc])),
        ]

    def _target_name(self, binding: tuple[int, int, int]) -> str | None:
        for r in self.sound_list.get("bindings", []):
            if (int(r["cc00"]), int(r["cc32"]), int(r["pc"])) == binding:
                return str(r["name"])
        return None

    # ------------------------------------------------------------ 17-19
    def _validate_and_write(self, smf: dict, in_path: Path, out_path: Path,
                            report_path: Path, report: dict) -> None:
        # HARD RULE: tick redoslijed je nepromjenjiv; pitch se smije mijenjati
        # ISKLJUČIVO oktavskim foldovima iz koraka 11 (±12 * k).
        issues = []
        note_invariants = self._note_invariants(in_path)
        violations = 0
        bad_folds = 0
        for track in smf["tracks"]:
            for ev in track:
                if ev.kind != "channel":
                    continue
                fam = ev.status & 0xF0
                if fam == 0x90 and ev.data[1] > 0:
                    if not 1 <= ev.data[1] <= 127:
                        violations += 1
        out_note_invariants = self._note_invariants_from(smf)
        ticks_same = [a[0] for a in note_invariants] == [b[0] for b in out_note_invariants]
        count_same = len(note_invariants) == len(out_note_invariants)
        for a, b in zip(note_invariants, out_note_invariants):
            if a[1] != b[1] and abs(a[1] - b[1]) % 12 != 0:
                bad_folds += 1
        if violations:
            issues.append(f"velocity off-range: {violations}")
        if not ticks_same or not count_same:
            issues.append("note tick redoslijed/broj promijenjen (NE Dozvoljeno)")
        if bad_folds:
            issues.append(f"pitch delta != oktava: {bad_folds} (NE Dozvoljeno)")
        report["issues"] = issues
        report["steps"][17] = {"name": STEP_NAMES[17],
                               "velocity_violations": violations,
                               "note_ticks_preserved": ticks_same and count_same,
                               "pitch_folds_all_octave": bad_folds == 0,
                               "ok": not issues}
        write_smf(out_path, smf["format"], smf["division"], smf["tracks"])
        report["steps"][18] = {"name": STEP_NAMES[18], "output": str(out_path),
                               "bytes": out_path.stat().st_size}
        report["steps"][19] = {"name": STEP_NAMES[19],
                               "note": "reserved za Style put — SONG output ga ne dira"}
        report_path.write_text(json.dumps(report, indent=1, ensure_ascii=False),
                               encoding="utf-8")

    # ------------------------------------------------------- invarianti
    @staticmethod
    def _note_invariants(in_path: Path) -> list[tuple[int, int]]:
        inv: list[tuple[int, int]] = []
        for track in parse_smf(in_path)["tracks"]:
            for ev in track:
                if ev.kind == "channel" and (ev.status & 0xF0) == 0x90 and ev.data[1] > 0:
                    inv.append((ev.tick, ev.data[0]))
        return inv

    @staticmethod
    def _note_invariants_from(smf: dict) -> list[tuple[int, int]]:
        inv: list[tuple[int, int]] = []
        for track in smf["tracks"]:
            for ev in track:
                if ev.kind == "channel" and (ev.status & 0xF0) == 0x90 and ev.data[1] > 0:
                    inv.append((ev.tick, ev.data[0]))
        return inv
