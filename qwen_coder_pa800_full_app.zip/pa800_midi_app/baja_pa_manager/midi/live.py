"""Live MIDI I/O za Korg Pa800 (USB MIDI) — direktno vezano na optimizer
SMF parser i RX/DNC evidence registry.

Sve funkcije rade i bez instaliranog ``mido`` (onda jave šta bi poslale),
a sa ``mido`` + sistemskim MIDI portom šalju direktno na klavijaturu.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable


def _try_mido():
    try:
        import mido  # noqa: F401
        return mido
    except ImportError:
        return None


def mido_available() -> bool:
    return _try_mido() is not None


def list_ports() -> dict[str, Any]:
    mido = _try_mido()
    if mido is None:
        return {
            "available": False,
            "reason": "mido nije instaliran (pip install mido python-rtmidi)",
            "inputs": [], "outputs": [],
        }
    try:
        inputs = list(mido.get_input_names())
        outputs = list(mido.get_output_names())
    except Exception as exc:  # no backend / no ports on this machine
        return {"available": False, "reason": str(exc), "inputs": [], "outputs": []}
    pa800 = [p for p in outputs if "pa800" in p.casefold() or "korg" in p.casefold()]
    return {"available": True, "inputs": inputs, "outputs": outputs, "pa800_candidates": pa800}


@dataclass(slots=True)
class OutboundEvent:
    """Jedna MIDI poruka spremna za slanje (encode je ista kao u optimizeru)."""
    tick: int
    status: int
    data: bytes
    track: int = 0

    @property
    def channel(self) -> int:
        return self.status & 0x0F

    def as_bytes(self) -> bytes:
        return bytes([self.status]) + self.data


def select_program_messages(cc00: int, cc32: int, pc: int, channel: int = 0) -> list[OutboundEvent]:
    """Address-first odabir zvuka na Pa800: CC0 (MSB) → CC32 (LSB) → PC."""
    if not all(0 <= v <= 127 for v in (cc00, cc32, pc)) or not 0 <= channel <= 15:
        raise ValueError("cc00/cc32/pc/channel moraju biti 0-127 / 0-15")
    return [
        OutboundEvent(0, 0xB0 | channel, bytes((0, cc00))),
        OutboundEvent(0, 0xB0 | channel, bytes((32, cc32))),
        OutboundEvent(0, 0xC0 | channel, bytes((pc,))),
    ]


def registry_sounds() -> list[dict[str, Any]]:
    """Svi kataloški dokazani RX/DNC zvukovi + RX bubnjevi sa adresama."""
    from .optimizer import load_special_registry
    registry = load_special_registry()
    sounds: list[dict[str, Any]] = []
    for row in registry.get("rx_sounds", []) + registry.get("dnc_sounds", []):
        if all(row.get(k) is not None for k in ("cc00", "cc32", "pc")):
            sounds.append({
                "name": row["name"], "kind": row.get("kind"),
                "cc00": int(row["cc00"]), "cc32": int(row["cc32"]), "pc": int(row["pc"]),
            })
    for row in registry.get("rx_drum_kits", []):
        if row.get("factory_address_status") == "EXACT_FACTORY_CORPUS":
            sounds.append({
                "name": row["name"], "kind": "RX_DRUM_KIT",
                "cc00": int(row["factory_corpus_cc00"]),
                "cc32": int(row["factory_corpus_cc32"]),
                "pc": int(row["factory_corpus_pc"]),
            })
    return sounds


class Pa800Link:
    """Jednostavan izlazni link prema midi out portu (ili suhi ispis)."""

    def __init__(self, port_name: str | None = None, sender: Callable[[OutboundEvent], None] | None = None):
        self.port_name = port_name
        self._sender = sender
        self._port = None
        self.sent: list[OutboundEvent] = []

    @property
    def connected(self) -> bool:
        return self._port is not None or self._sender is not None

    def open(self) -> "Pa800Link":
        if self._sender is not None:
            return self
        mido = _try_mido()
        if mido is None:
            raise RuntimeError("mido nije instaliran; link radi samo u dry-run režimu")
        name = self.port_name
        if name is None:
            candidates = list_ports().get("pa800_candidates") or list_ports().get("outputs") or []
            if not candidates:
                raise RuntimeError("nema dostupnih MIDI out portova")
            name = candidates[0]
        self._port = mido.open_output(name)
        self.port_name = name
        return self

    def close(self) -> None:
        if self._port is not None:
            self._port.close()
            self._port = None

    def send_raw(self, event: OutboundEvent) -> None:
        self.sent.append(event)
        if self._sender is not None:
            self._sender(event)
            return
        if self._port is not None:
            from mido import Message
            family = event.status & 0xF0
            channel = event.status & 0x0F
            if family == 0xB0:
                self._port.send(Message("control_change", channel=channel,
                                        control=event.data[0], value=event.data[1]))
            elif family == 0xC0:
                self._port.send(Message("program_change", channel=channel, program=event.data[0]))
            elif family == 0x90:
                self._port.send(Message("note_on", channel=channel,
                                        note=event.data[0], velocity=event.data[1]))
            elif family == 0x80:
                self._port.send(Message("note_off", channel=channel,
                                        note=event.data[0], velocity=event.data[1]))
            elif family == 0xE0:
                value = event.data[0] | (event.data[1] << 7)
                self._port.send(Message("pitchwheel", channel=channel, pitch=value - 8192))
            elif family == 0xD0:
                self._port.send(Message("aftertouch", channel=channel, value=event.data[0]))
            elif family == 0xA0:
                self._port.send(Message("polytouch", channel=channel,
                                        note=event.data[0], value=event.data[1]))

    # -- visoki nivo ---------------------------------------------------------
    def select_program(self, cc00: int, cc32: int, pc: int, channel: int = 0) -> list[OutboundEvent]:
        events = select_program_messages(cc00, cc32, pc, channel)
        for event in events:
            self.send_raw(event)
        return events

    def select_named_sound(self, name: str, channel: int = 0) -> list[OutboundEvent]:
        match = next((s for s in registry_sounds() if s["name"].casefold() == name.casefold()), None)
        if match is None:
            raise KeyError(f"Zvuk nije u dokazanom registryju: {name}")
        return self.select_program(match["cc00"], match["cc32"], match["pc"], channel)

    def play_notes_preview(self, notes: Iterable[int] = (60, 64, 67), channel: int = 0,
                           velocity: int = 100, seconds: float = 0.25) -> None:
        for note in notes:
            self.send_raw(OutboundEvent(0, 0x90 | channel, bytes((note, velocity))))
            time.sleep(seconds)
            self.send_raw(OutboundEvent(0, 0x80 | channel, bytes((note, 0))))

    def play_smf(self, path: Path, speed: float = 1.0,
                 clock: Callable[[float], None] = time.sleep) -> dict[str, Any]:
        """Sviraj SMF direktno preko optimizer parsera (isti event model)."""
        from .optimizer import parse_smf
        parsed = parse_smf(Path(path))
        division = parsed["division"]
        if division & 0x8000:
            raise ValueError("SMPTE division nije podržan za live playback")
        merged: list[tuple[int, int, OutboundEvent]] = []
        tempo_map: list[tuple[int, int]] = [(0, 500_000)]
        for track_index, events in enumerate(parsed["tracks"]):
            for event in events:
                if event.kind == "meta-51" and len(event.data) == 3:
                    tempo_map.append((event.tick, int.from_bytes(event.data, "big")))
                elif event.kind == "channel":
                    merged.append((event.tick, track_index, OutboundEvent(
                        event.tick, event.status, event.data, track_index)))
        merged.sort(key=lambda row: (row[0], row[1], row[2].as_bytes()))
        tempo_map.sort()

        def tick_to_seconds(tick: int) -> float:
            seconds = 0.0
            last_tick, last_tempo = tempo_map[0]
            for tempo_tick, tempo in tempo_map[1:]:
                if tempo_tick >= tick:
                    break
                seconds += (tempo_tick - last_tick) / division * last_tempo / 1_000_000
                last_tick, last_tempo = tempo_tick, tempo
            seconds += (tick - last_tick) / division * last_tempo / 1_000_000
            return seconds

        schedule = [(tick_to_seconds(tick), order, event)
                    for order, (tick, _track, event) in enumerate(merged)]
        schedule.sort(key=lambda row: (row[0], row[1]))
        started = time.monotonic()
        sent = 0
        for seconds, _order, event in schedule:
            delay = seconds / max(speed, 1e-6) - (time.monotonic() - started)
            if delay > 0:
                clock(delay)
            self.send_raw(event)
            sent += 1
        return {"sent": sent, "file": str(path), "port": self.port_name, "connected": self.connected}


def describe_event(event: OutboundEvent) -> str:
    family = event.status & 0xF0
    ch = event.channel + 1
    if family == 0xB0:
        return f"ch{ch:02d} CC{event.data[0]}={event.data[1]}"
    if family == 0xC0:
        return f"ch{ch:02d} PC={event.data[0]}"
    if family == 0x90:
        return f"ch{ch:02d} NOTE_ON {event.data[0]} vel={event.data[1]}"
    if family == 0x80:
        return f"ch{ch:02d} NOTE_OFF {event.data[0]}"
    return f"ch{ch:02d} status={event.status:#04x} data={event.data.hex()}"
