"""RX sound coverage engine for the Korg Pa800 optimizer.

Reconstructed module required by ``baja_pa_manager.midi.optimizer`` and
``baja_pa_manager.midi.factory_reference`` (the original checkpoint imported it
as ``rx_coverage_engine`` but the file itself was not part of the checkpoint;
its exact behaviour is fixed here against ``tests/test_rx_coverage_engine.py``
and the shipped ``RX_SOUND_CAPABILITIES_v1.json`` evidence).

Policy: STRICTLY READ-ONLY. Candidate velocity switches from the oscillator
join are audit-only material and are never silently promoted to exact zones.
"""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

CAPABILITIES_FILE = "RX_SOUND_CAPABILITIES_v1.json"
CAPABILITIES_FORMAT = "pa800-rx-sound-capabilities"


def _default_capabilities_path() -> Path:
    here = Path(__file__).resolve().parent
    return here.parent / "data" / CAPABILITIES_FILE


def _validate_windows(sound: dict[str, Any], source: Path) -> None:
    name = sound.get("name", "<unnamed>")
    windows = sound.get("windows") or []
    # Evidence je eksplicitna: samo HARDWARE_OBSERVED_PARTIAL zvukovi (10)
    # smiju imati velocity zone; UNRESOLVED_PRESERVE (34) ostaje bez zona.
    unresolved = str(sound.get("velocity_status", "")).upper().startswith("UNRESOLVED")
    if unresolved and windows:
        raise ValueError(
            f"Candidate switches cannot be promoted silently "
            f"({name} in {source}); velocity zone evidence is unresolved."
        )
    for window in windows:
        v_min = window.get("velocity_min")
        v_max = window.get("velocity_max")
        if not isinstance(v_min, int) or not isinstance(v_max, int) or not (1 <= v_min <= v_max <= 127):
            raise ValueError(
                f"Bad velocity zone data for {name}: [{v_min}, {v_max}] in {source}"
            )
        k_min = window.get("key_min", 0) or 0
        k_max = window.get("key_max", 127) or 127
        if not (0 <= k_min <= k_max <= 127):
            raise ValueError(f"Bad key zone data for {name}: [{k_min}, {k_max}] in {source}")


def load_capabilities(path: Path | str | None = None) -> dict[str, Any]:
    """Load the RX sound capability evidence (44 factory RX identities).

    Raises:
        ValueError: if the file format is unknown, a velocity/key zone is
            malformed, or audit-only candidate switches were silently
            promoted into windows.
    """
    source = Path(path) if path is not None else _default_capabilities_path()
    raw = json.loads(Path(source).read_text(encoding="utf-8"))
    if raw.get("format") != CAPABILITIES_FORMAT:
        raise ValueError(f"Unknown RX capabilities format: {source}")
    sounds = raw.get("sounds")
    if not isinstance(sounds, list):
        raise ValueError(f"RX capabilities without sound list: {source}")
    for sound in sounds:
        if not all(key in sound for key in ("name", "cc00", "cc32", "pc")):
            raise ValueError(f"Incomplete RX identity in {source}: {sound!r}")
        sound.setdefault("windows", [])
        sound.setdefault("oscillators", [])
        _validate_windows(sound, source)
    return raw


def _candidate_switches(sound: dict[str, Any]) -> list[int]:
    switches = set()
    for osc in sound.get("oscillators") or []:
        status = str(osc.get("switch_status", ""))
        value = osc.get("possible_internal_switch")
        if status.startswith("CANDIDATE") and isinstance(value, int):
            switches.add(value)
    return sorted(switches)


def _matched_window(sound: dict[str, Any], note: int, velocity: int) -> dict[str, Any] | None:
    for window in sound.get("windows") or []:
        if not int(window["velocity_min"]) <= velocity <= int(window["velocity_max"]):
            continue
        key_min = int(window.get("key_min") or 0)
        key_max = int(window.get("key_max") or 127)
        if key_min <= note <= key_max:
            return window
    return None


def audit_rx_tracks(
    tracks: Iterable[Iterable[Any]],
    capabilities: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Audit RX identity coverage per track/channel without mutating events.

    Only a Program Change commits a pending Bank Select; a later bank nibble
    without a new Program Change never re-binds the channel. Channels owned by
    more than one track are reported as shared and are never guessed.
    """
    data = capabilities or load_capabilities()
    index = {}
    for sound in data["sounds"]:
        key = (int(sound["cc00"]), int(sound["cc32"]), int(sound["pc"]))
        index[key] = sound

    tracks = [list(events) for events in tracks]

    owners: dict[int, set[int]] = defaultdict(set)
    for track_index, events in enumerate(tracks):
        for event in events:
            if getattr(event, "kind", None) == "channel":
                owners[event.status & 15].add(track_index)
    shared = sorted(channel + 1 for channel, tids in owners.items() if len(tids) > 1)
    blocked = {channel - 1 for channel in shared}

    detected: "dict[tuple[int, int, tuple[int, int, int]], dict[str, Any]]" = {}
    order: list[tuple[int, int, tuple[int, int, int]]] = []
    for track_index, events in enumerate(tracks):
        pending: dict[int, list[int | None]] = defaultdict(lambda: [None, None])
        active: dict[int, tuple[int, int, int] | None] = {}
        for event in events:
            if event.kind == "sysex" or event.kind in {"meta-20", "meta-21"}:
                active.clear()
                pending.clear()
                continue
            if event.kind != "channel":
                continue
            channel, family = event.status & 15, event.status & 0xF0
            if channel in blocked:
                continue
            if family == 0xB0 and event.data[0] in {0, 32}:
                pending[channel][0 if event.data[0] == 0 else 1] = event.data[1]
            elif family == 0xC0:
                bank = pending[channel]
                active[channel] = (
                    (int(bank[0]), int(bank[1]), int(event.data[0]))
                    if bank[0] is not None and bank[1] is not None
                    else None
                )
            elif family == 0x90 and event.data[1] > 0:
                binding = active.get(channel)
                if binding is None or binding not in index:
                    continue
                sound = index[binding]
                row_key = (track_index, channel, binding)
                row = detected.get(row_key)
                if row is None:
                    row = detected[row_key] = {
                        "track": track_index,
                        "channel": channel + 1,
                        "name": sound["name"],
                        "cc00": binding[0],
                        "cc32": binding[1],
                        "pc": binding[2],
                        "velocity_status": sound.get("velocity_status", "UNKNOWN"),
                        "windows_proven": bool(sound.get("windows")),
                        "known_window_events": 0,
                        "unresolved_window_events": 0,
                        "semantics": Counter(),
                        "candidate_switches_audit_only": _candidate_switches(sound),
                        "notes": 0,
                    }
                    order.append(row_key)
                row["notes"] += 1
                window = _matched_window(sound, event.data[0], event.data[1])
                if window is not None:
                    row["known_window_events"] += 1
                    row["semantics"][str(window["semantic"])] += 1
                else:
                    row["unresolved_window_events"] += 1

    rows = []
    for key in order:
        row = detected[key]
        cooked = dict(row)
        cooked["semantics"] = dict(sorted(row["semantics"].items()))
        rows.append(cooked)
    return {
        "format": "pa800-rx-coverage-audit",
        "capabilities": str(data.get("version", "v1")),
        "detected": rows,
        "shared_channels_not_guessed": shared,
        "rx_identities": len(index),
        "policy": "READ_ONLY_AUDIT; CANDIDATES_ARE_AUDIT_ONLY; NEVER_PROMOTED_SILENTLY",
    }


__all__ = ["load_capabilities", "audit_rx_tracks", "CAPABILITIES_FILE", "CAPABILITIES_FORMAT"]
