"""MIDI podsistem — konzervativni Pa800 optimizer + RX evidence + live I/O."""
from .optimizer import (  # noqa: F401
    Event, parse_track, parse_smf, serialize_track, write_smf,
    audit, optimize, song_profile, audit_track,
    optimize_track, optimize_velocities,
    apply_special_sound_preferences, apply_articulation_engine,
    apply_instrument_intelligence, add_cross_delay_echo_track,
    special_sound_usage, available_rx_kits,
    load_special_registry, load_oscillator_registry,
    load_native_oscillator_catalog, load_native_style_catalog,
    note_structure_counter, counter_is_subset,
    fingerprint_events, critical_performance_counter, midi_quality_report,
    instrument_family, INSTRUMENT_FAMILIES, VERSION as OPTIMIZER_VERSION,
)
from .rx_coverage import load_capabilities, audit_rx_tracks  # noqa: F401
from .safety import (  # noqa: F401
    MidiSafetyError, guard_optimize,
    assert_smf_note_structure_preserved, assert_mido_note_structure_unchanged,
)
