#!/usr/bin/env python3
"""Factory Corpus performance extractor — prvi izvor istine.

Ulaz: PA800 onboard DEMOSONG corpus (54 EXACT_DECODED_SMF iz originalnog
Pa800_os_res_v202.pkg). Authority: ORIGINAL_PA800_PKG_OC20_DECODE.

Za svaki (cc00, cc32, pc) binding skuplja DIREKTNO mjerene podatke:
- velocity histogram (1..127)  → factory velocity curves
- key range              → observed playable/working range
- per-drum-key          → kit element velocity profiles (120.x.y)

Nista se ne izmislja: ako binding nema zapis, profil ne postoji.
"""
from __future__ import annotations

import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

from baja_pa_manager.midi.optimizer import parse_smf

FORMAT_ID = "pa800-factory-performance-profiles-v1"
AUTHORITY = "ORIGINAL_PA800_PKG_OC20_DECODE"
PERCENTILES = (1, 5, 10, 25, 50, 75, 90, 95, 99)


# ------------------------------------------------------------- family model
def family_of(name: str | None, cc00: int, pc: int) -> str:
    """Family po factory imenu; fallback na GM PC grupu. cc00==120 → DRUMS."""
    if cc00 == 120:
        return "DRUMS"
    n = (name or "").casefold()
    tok = (
        ("BASS", ("bass",)) if "bass drum" not in n else (None, ()),
        ("GUITAR", ("gtr", "guitar", "mandolin", "banjo", "ukulele")),
        ("PIANO", ("piano", "stein", "ep.", "e.piano", "clav", "harpsi", "grand")),
        ("ORGAN", ("organ", "drawbar", "rotary", "gospel")),
        ("STRINGS", ("string", "violin", "viola", "cello", "harp", "orchestr")),
        ("BRASS", ("brass", "trumpet", "trombon", "horn", "tuba", "marching")),
        ("WIND", ("sax", "clarinet", "flute", "oboe", "bassoon", "whistle",
                  "ocarina", "harmonica", "pan flu", "recorder")),
        ("VOCAL", ("choir", "vocal", "voice", "vox", "scat")),
        ("SYNTH", ("synth", "seq.", "analog", "wave", "pad", "techno",
                   "electro", "digi", "lead")),
        ("PERC", ("drum", "perc", "conga", "bongo", "timpani", "marimba",
                  "vib", "xylo", "agogo", "tamb")),
    )
    for fam, keys in tok:
        if fam and any(k in n for k in keys):
            return fam
    band = ("KEYS", "CHROMATIC", "ORGAN", "GUITAR",
            "BASS", "STRINGS", "ENSEMBLE", "BRASS",
            "WIND", "WIND", "SYNTH", "SYNTH",
            "EFFECTS", "ETHNIC", "PERCUSSIVE", "SFX")
    return band[min(15, pc // 8)]


def _percentile(sorted_vals: list[int], p: int) -> int:
    """Linearno interpolirani postotak (R-7 / numpy 'linear')."""
    if not sorted_vals:
        return 0
    n = len(sorted_vals)
    if n == 1:
        return sorted_vals[0]
    rank = (p / 100) * (n - 1)
    lo = int(rank)
    hi = min(n - 1, lo + 1)
    frac = rank - lo
    return round(sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * frac)


def _cilj(data: dict, key: str) -> dict:
    return data.setdefault(key, {"notes": 0, "vel_hist": defaultdict(int),
                                 "keys": set(), "hist_vel_deg2": 0})


def _finalize(entry: dict) -> dict:
    keys = sorted(entry["keys"])
    hist = entry["vel_hist"]
    ordered: list[int] = []
    for vel in sorted(hist):
        ordered.extend([vel] * hist[vel])
    return {
        "notes": entry["notes"],
        "key_lo": keys[0] if keys else None,
        "key_hi": keys[-1] if keys else None,
        "vel_min": ordered[0] if ordered else None,
        "vel_max": ordered[-1] if ordered else None,
        "vel_mean": round(sum(v * c for v, c in hist.items()) / entry["notes"], 3) if entry["notes"] else None,
        "percentiles": {str(p): _percentile(ordered, p) for p in PERCENTILES},
        "vel_hist": {str(v): hist[v] for v in sorted(hist)},
    }


def extract_corpus(corpus_dir: Path, manifest_path: Path | None = None) -> dict[str, Any]:
    """Ekstrakcija svih .mid/.MID zapisa — deterministički (sortirana lista)."""
    corpus_dir = Path(corpus_dir)
    files = sorted(
        [p for p in corpus_dir.iterdir() if p.suffix.casefold() in (".mid", ".midi")],
        key=lambda p: p.name.casefold(),
    )
    if not files:
        raise FileNotFoundError(f"Nema .mid fajlova u {corpus_dir}")

    manifest = {}
    if manifest_path is None:
        cand = corpus_dir / "manifest.json"
        manifest_path = cand if cand.is_file() else None
    if manifest_path and manifest_path.is_file():
        raw = json.loads(manifest_path.read_text(encoding="utf-8"))
        for rec in raw.get("records", []):
            manifest[Path(rec["output"]).name] = rec

    by_binding: dict[str, dict] = {}
    by_drum_key: dict[str, dict] = {}
    by_family: dict[str, dict] = {}
    used_files: dict[str, dict] = {}

    for path in files:
        data = path.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        manifest_rec = manifest.get(path.name)
        verify = None
        if manifest_rec is not None:
            verify = "MATCH" if manifest_rec.get("sha256") == sha else "MISMATCH"
        used_files[path.name] = {"sha256": sha, "bytes": len(data),
                                 "manifest_verify": verify}

        smf = parse_smf(path)
        for track in smf["tracks"]:
            pending: dict[int, list[int | None]] = {}
            active: dict[int, tuple[int, int, int]] = {}
            for ev in track:
                if ev.kind != "channel":
                    continue
                ch, fam = ev.status & 15, ev.status & 0xF0
                if fam == 0xB0 and ev.data[0] in (0, 32):
                    pending.setdefault(ch, [None, None])[0 if ev.data[0] == 0 else 1] = ev.data[1]
                elif fam == 0xC0:
                    p2 = pending.get(ch, [None, None])
                    active[ch] = (p2[0] if p2[0] is not None else 0,
                                  p2[1] if p2[1] is not None else 0,
                                  ev.data[0])
                elif fam == 0x90 and ev.data[1] > 0:
                    binding = active.get(ch)
                    if binding is None or None in binding:
                        continue
                    name = BINDING_NAMES.get(binding)
                    fam_name = family_of(name, binding[0], binding[2])
                    key = int(ev.data[0])
                    vel = int(ev.data[1])
                    bkey = ".".join(map(str, binding))
                    if binding[0] == 120:
                        dkey = f"{bkey}:{key}"
                        e = _cilj(by_drum_key, dkey)
                        e["notes"] += 1
                        e["vel_hist"][vel] += 1
                        e["keys"].add(key)
                    for target in (by_binding,):
                        e = _cilj(target, bkey)
                        e["notes"] += 1
                        e["vel_hist"][vel] += 1
                        e["keys"].add(key)
                    e = _cilj(by_family, fam_name)
                    e["notes"] += 1
                    e["vel_hist"][vel] += 1
                    e["keys"].add(key)

    bindings_out = {}
    for bkey, e in sorted(by_binding.items()):
        binding_t = tuple(int(x) for x in bkey.split("."))
        name = BINDING_NAMES.get(binding_t)
        bindings_out[bkey] = _finalize(e) | {
            "name": name,
            "family": family_of(name, binding_t[0], binding_t[2]),
            "binding": list(binding_t),
        }
    return {
        "format": FORMAT_ID,
        "authority": AUTHORITY,
        "source_dir": str(corpus_dir),
        "files": used_files,
        "by_binding": bindings_out,
        "by_drum_key": {
            k: _finalize(by_drum_key[k]) | {"name": BINDING_NAMES.get(
                tuple(int(x) for x in k.split(":")[0].split(".")))}
            for k in sorted(by_drum_key)
        },
        "by_family": {k: _finalize(by_family[k]) for k in sorted(by_family)},
        "summary": {
            "corpus_files": len(files),
            "midi_files_parsed": len(used_files),
            "unique_bindings": len(bindings_out),
            "unique_drum_keys": len(by_drum_key),
            "total_notes": sum(e["notes"] for e in by_binding.values()),
            "families": sorted(by_family),
        },
    }


# Factory identiteti (PA800_FACTORY_SOUND_LIST_v1) — učitava se lazy
_BINDING_NAMES: dict[tuple[int, int, int], str] | None = None


def _load_binding_names() -> dict[tuple[int, int, int], str]:
    global _BINDING_NAMES
    if _BINDING_NAMES is None:
        from baja_pa_manager.midi.optimizer import _evidence_file
        path = _evidence_file("PA800_FACTORY_SOUND_LIST_v1.json")
        if path.is_file():
            raw = json.loads(path.read_text(encoding="utf-8"))
            _BINDING_NAMES = {
                (int(r["cc00"]), int(r["cc32"]), int(r["pc"])): str(r["name"])
                for r in raw.get("bindings", [])
            }
        else:
            _BINDING_NAMES = {}
    return _BINDING_NAMES


class _LazyNames(dict):
    def get(self, binding, default=None):  # noqa: D401 — lazy proxy
        return _load_binding_names().get(binding, default)


BINDING_NAMES: dict = _LazyNames()


def load_profiles(path: Path) -> dict[str, Any]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("format") != FORMAT_ID:
        raise ValueError(f"Nepoznat format profila: {path}")
    return data


def write_profiles(corpus_dir: Path, out_path: Path, manifest_path: Path | None = None) -> dict[str, Any]:
    out_path = Path(out_path)
    if out_path.exists():
        raise FileExistsError(f"Izlaz postoji (no-overwrite): {out_path}")
    data = extract_corpus(Path(corpus_dir), manifest_path)
    out_path.write_text(
        json.dumps(data, indent=1, ensure_ascii=False, sort_keys=True),
        encoding="utf-8")
    return {"out": str(out_path), "summary": data["summary"]}
