#!/usr/bin/env python3
"""Conservative MIDI audit core for the Korg Pa800 optimizer project."""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
import struct
import tempfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from .rx_coverage import audit_rx_tracks


DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def _evidence_file(name: str) -> Path:
    """Resolve an evidence JSON shipped in baja_pa_manager/data (env override allowed)."""
    import os
    env = os.environ.get("BAJA_PA800_DATA")
    candidates = []
    if env:
        candidates.append(Path(env) / name)
    candidates.append(DATA_DIR / name)
    candidates.append(Path(__file__).resolve().parent / name)
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return DATA_DIR / name


@dataclass
class Event:
    tick: int
    kind: str
    status: int
    data: bytes


def vlq(data: bytes, pos: int) -> tuple[int, int]:
    value = 0
    for _ in range(4):
        if pos >= len(data):
            raise ValueError("truncated VLQ")
        byte = data[pos]
        pos += 1
        value = (value << 7) | (byte & 0x7F)
        if not byte & 0x80:
            return value, pos
    raise ValueError("VLQ longer than four bytes")


def encode_vlq(value: int) -> bytes:
    if not 0 <= value <= 0x0FFFFFFF:
        raise ValueError("VLQ value out of range")
    result = bytearray([value & 0x7F])
    value >>= 7
    while value:
        result.insert(0, 0x80 | (value & 0x7F))
        value >>= 7
    return bytes(result)


def parse_track(data: bytes) -> list[Event]:
    events: list[Event] = []
    pos = tick = 0
    running: int | None = None
    while pos < len(data):
        delta, pos = vlq(data, pos)
        tick += delta
        if pos >= len(data):
            raise ValueError("missing event after delta")
        lead = data[pos]
        if lead & 0x80:
            status = lead
            pos += 1
            if status < 0xF0:
                running = status
        elif running is not None:
            status = running
        else:
            raise ValueError(f"running status without prior status at {pos}")
        if status == 0xFF:
            running = None
            if pos >= len(data):
                raise ValueError("truncated meta event")
            meta_type = data[pos]
            pos += 1
            length, pos = vlq(data, pos)
            payload = data[pos:pos + length]
            if len(payload) != length:
                raise ValueError("truncated meta payload")
            pos += length
            events.append(Event(tick, f"meta-{meta_type:02x}", status, payload))
            if meta_type == 0x2F:
                if length or pos != len(data):
                    raise ValueError("invalid End of Track or data after End of Track")
                break
        elif status in (0xF0, 0xF7):
            running = None
            length, pos = vlq(data, pos)
            payload = data[pos:pos + length]
            if len(payload) != length:
                raise ValueError("truncated SysEx payload")
            pos += length
            events.append(Event(tick, "sysex", status, payload))
        else:
            if not 0x80 <= status <= 0xEF:
                raise ValueError(f"unsupported SMF status {status:02X}")
            family = status & 0xF0
            length = 1 if family in (0xC0, 0xD0) else 2
            payload = data[pos:pos + length]
            if len(payload) != length:
                raise ValueError("truncated channel event")
            if any(byte >= 128 for byte in payload):
                raise ValueError("channel data byte exceeds 127")
            pos += length
            events.append(Event(tick, "channel", status, payload))
    if not events or events[-1].kind != "meta-2f":
        raise ValueError("missing End of Track")
    return events


def parse_smf(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    if len(data) < 14 or data[:4] != b"MThd":
        raise ValueError("not a standard MIDI file")
    header_len = struct.unpack_from(">I", data, 4)[0]
    if header_len < 6 or 8 + header_len > len(data):
        raise ValueError("invalid MIDI header length")
    fmt, declared_tracks, division = struct.unpack_from(">HHH", data, 8)
    if fmt not in (0, 1) or not declared_tracks or (fmt == 0 and declared_tracks != 1):
        raise ValueError("supported input: standard SMF 0 or 1 with valid track count")
    if header_len != 6 or division == 0:
        raise ValueError("unsupported extended header or invalid timing division")
    if division & 0x8000 and ((division >> 8) not in (232, 231, 227, 226) or not division & 255):
        raise ValueError("invalid SMPTE division")
    pos = 8 + header_len
    tracks = []
    while pos + 8 <= len(data) and data[pos:pos + 4] == b"MTrk":
        length = struct.unpack_from(">I", data, pos + 4)[0]
        start = pos + 8
        end = start + length
        if end > len(data):
            raise ValueError("track chunk exceeds file")
        tracks.append(parse_track(data[start:end]))
        pos = end
    if len(tracks) != declared_tracks or pos != len(data):
        raise ValueError("track count mismatch or unrecognized trailing chunks")
    return {
        "path": str(path.resolve()), "format": fmt, "declared_tracks": declared_tracks,
        "parsed_tracks": len(tracks), "division": division, "trailing_bytes": len(data) - pos,
        "tracks": tracks,
    }


SAFE_REDUNDANT_CC = {7, 10, 11, 91, 93}
VERSION = "0.15.0"


CROSS_DELAY_REFERENCE = {
    "manual": "Korg Pa800 Advanced Edit Manual, effects 065/066",
    "effect": "065 Stereo BPM Delay",
    "alternate_effect": "066 Stereo BPM Multi Tap Delay",
    "mode": "Cross Feedback",
    "tempo_source": "MIDI BPM sync",
    "left_tap": "3/16 note",
    "right_tap": "1/4 note",
    "feedback": 28,
    "high_damp": 35,
    "low_damp": 10,
    "spread": 100,
    "fx_amount": 32,
    "parameter_status": (
        "Effect names, modes and available parameters are documented by Korg; numeric values are "
        "a conservative optimizer preset, not Korg factory-mandated values."
    ),
}


INSTRUMENT_FAMILIES = (
    (0, 7, "piano", "Piano/Keys", (21, 108), {7: 100, 10: 64, 91: 22, 93: 5}),
    (8, 15, "chromatic", "Chromatic Percussion", (36, 96), {7: 94, 10: 60, 91: 24, 93: 8}),
    (16, 23, "organ", "Organ", (36, 96), {7: 96, 10: 64, 91: 18, 93: 16}),
    (24, 31, "guitar", "Guitar", (40, 88), {7: 96, 10: 48, 91: 18, 93: 10}),
    (32, 39, "bass", "Bass", (23, 72), {7: 104, 10: 64, 91: 4, 93: 0}),
    (40, 47, "strings", "Strings", (36, 96), {7: 92, 10: 76, 91: 30, 93: 14}),
    (48, 55, "ensemble", "Ensemble/Choir", (36, 96), {7: 90, 10: 72, 91: 32, 93: 18}),
    (56, 63, "brass", "Brass", (40, 88), {7: 98, 10: 68, 91: 17, 93: 5}),
    (64, 71, "reed", "Reed", (46, 96), {7: 96, 10: 56, 91: 19, 93: 4}),
    (72, 79, "pipe", "Pipe/Flute", (48, 96), {7: 95, 10: 60, 91: 26, 93: 7}),
    (80, 87, "synth_lead", "Synth Lead", (36, 96), {7: 98, 10: 64, 91: 22, 93: 12}),
    (88, 95, "synth_pad", "Synth Pad", (36, 96), {7: 84, 10: 80, 91: 34, 93: 22}),
    (96, 103, "synth_fx", "Synth FX", (36, 108), {7: 80, 10: 48, 91: 36, 93: 24}),
    (104, 111, "ethnic", "Ethnic", (36, 96), {7: 94, 10: 58, 91: 24, 93: 8}),
    (112, 119, "percussive", "Percussive", (36, 96), {7: 92, 10: 70, 91: 16, 93: 6}),
    (120, 127, "sound_fx", "Sound FX", (0, 127), {7: 82, 10: 64, 91: 38, 93: 20}),
)


def find_special_registry(explicit: Path | None = None) -> Path | None:
    """Locate the evidence-backed Pa800 RX/DNC registry without guessing addresses."""
    candidates = []
    if explicit is not None:
        candidates.append(explicit)
    candidates.extend((
        _evidence_file("PA800_FACTORY_SPECIAL_REGISTRY_v2.json"),
    ))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return None


def load_special_registry(explicit: Path | None = None) -> dict[str, Any]:
    path = find_special_registry(explicit)
    if path is None:
        return {"available": False, "path": None, "rx_sounds": [], "dnc_sounds": [], "rx_drum_kits": []}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("format") != "pa800-factory-special-sound-registry":
        raise ValueError(f"Nepoznat RX/DNC registry format: {path}")
    return {
        "available": True, "path": str(path.resolve()),
        "rx_sounds": raw.get("rx_sounds", []),
        "dnc_sounds": raw.get("dnc_sounds", []),
        "rx_drum_kits": raw.get("rx_drum_kits", []),
    }


def load_oscillator_registry() -> dict[str, Any]:
    path = _evidence_file("RX_OSCILLATOR_REGISTRY_v3.json")
    if not path.is_file():
        return {"available": False, "path": None, "sounds": [], "drum_key_layer_evidence": {},
                "hardware_profiles": {}}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("format") != "pa800-rx-oscillator-registry":
        raise ValueError(f"Nepoznat RX oscillator registry format: {path}")
    detail_path = _evidence_file("PA800_HARDWARE_VERIFIED_OSC_PROFILES.json")
    hardware_profiles = json.loads(detail_path.read_text(encoding="utf-8")) if detail_path.is_file() else {}
    return {
        "available": True, "path": str(path.resolve()), "sounds": raw.get("sounds", []),
        "drum_key_layer_evidence": raw.get("drum_key_layer_evidence", {}),
        "hardware_profile_path": str(detail_path.resolve()) if detail_path.is_file() else None,
        "hardware_profiles": hardware_profiles,
    }


def load_native_oscillator_catalog() -> dict[str, Any]:
    """Load the native KMP multisample catalog parsed from ROM.KMP.

    This provides 606 multisample definitions with 128-byte key-to-sample maps
    extracted from the proven 100% OC20-decoded Pa800 package. The key maps
    tell us which MIDI key triggers which sample index for each multisample.

    This is read-only evidence. It does not modify any source files.
    """
    path = _evidence_file("NATIVE_OSCILLATOR_CATALOG_v1.json")
    if not path.is_file():
        return {"available": False, "path": None, "multisamples": [], "programs": [],
                "multisamples_by_name": {}, "multisample_count": 0}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("format") != "pa800-native-oscillator-catalog-v1":
        return {"available": False, "path": str(path.resolve()), "multisamples": [],
                "programs": [], "multisamples_by_name": {}, "multisample_count": 0}
    kmp_records = []
    for rec in raw.get("kmp_records", []):
        if rec.get("name") and rec.get("key_map"):
            kmp_records.append(rec)
    return {
        "available": True,
        "path": str(path.resolve()),
        "pcg_sha256": raw.get("pcg_sha256"),
        "kmp_sha256": raw.get("kmp_sha256"),
        "pcg_total_records": raw.get("pcg_total_records", 0),
        "pcg_non_empty": raw.get("pcg_non_empty", 0),
        "multisample_count": len(kmp_records),
        "multisamples": kmp_records,
        "multisamples_by_name": {r["name"]: r for r in kmp_records},
        "programs": raw.get("programs", []),
        "resolution_rate": raw.get("resolution_rate", 0),
        "policy": "READ_ONLY_NATIVE_EVIDENCE; NO_AUTOMATIC_VELOCITY_OR_TRIGGER_THRESHOLDS",
    }


def load_native_style_catalog() -> dict[str, Any]:
    """Load the native STY catalog parsed from BANK*.STY files.

    This provides 18 style banks with 34,381 unique style names, 395,140
    program change events, and 270,628 note events extracted from the proven
    100% OC20-decoded Pa800 package. The style banks contain MIDI patterns
    that reference specific programs from the PCG.

    This is read-only evidence. It does not modify any source files.
    """
    path = _evidence_file("NATIVE_STYLE_CATALOG_v1.json")
    if not path.is_file():
        return {"available": False, "path": None, "banks": [], "bank_count": 0,
                "total_style_names": 0, "total_program_changes": 0, "total_note_events": 0}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if raw.get("format") != "pa800-native-style-catalog":
        return {"available": False, "path": str(path.resolve()), "banks": [], "bank_count": 0,
                "total_style_names": 0, "total_program_changes": 0, "total_note_events": 0}
    banks = []
    for bank_name, bank_data in raw.get("banks", {}).items():
        banks.append({
            "file": bank_name,
            "size": bank_data.get("size", 0),
            "style_names": bank_data.get("style_names", []),
            "style_name_count": bank_data.get("style_name_count", 0),
            "total_program_changes": bank_data.get("total_program_changes", 0),
            "total_note_events": bank_data.get("total_note_events", 0),
        })
    summary = raw.get("summary", {})
    return {
        "available": True,
        "path": str(path.resolve()),
        "bank_count": len(banks),
        "banks": banks,
        "total_style_names": summary.get("total_style_names", 0),
        "total_program_changes": summary.get("total_program_changes", 0),
        "total_note_events": summary.get("total_note_events", 0),
        "unique_programs": summary.get("unique_programs", 0),
        "policy": "READ_ONLY_NATIVE_EVIDENCE; NO_AUTOMATIC_VELOCITY_OR_TRIGGER_THRESHOLDS",
    }


def pa800_factory_evidence() -> dict[str, Any]:
    """Summarize the proven native Pa800 package extraction available locally.

    This is evidence for audit/reporting only. Native styles and PCG data are
    readable corpus material, not automatic transformation rules.
    """
    here = Path(__file__).resolve().parent
    root = DATA_DIR / "extracted_files_oc20_lzss"
    manifest_path = root / "extraction_manifest.json"
    if not manifest_path.is_file():
        root = here / "extracted_files_oc20_lzss"
        manifest_path = root / "extraction_manifest.json"
    if not manifest_path.is_file():
        return {
            "available": False,
            "native_decode_complete": False,
            "path": str(root),
            "policy": "NO_NATIVE_FACTORY_CORPUS_AVAILABLE",
        }
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    stats = manifest.get("stats", {})
    files = manifest.get("files", [])
    complete = [row for row in files if row.get("status") in {"complete", "raw_extracted"}]
    suffix_counts = Counter(Path(str(row.get("path", ""))).suffix.upper() or "<none>" for row in complete)
    midi_files = sorted(row["path"] for row in complete if str(row.get("path", "")).upper().endswith(".MID"))
    style_files = sorted(row["path"] for row in complete if str(row.get("path", "")).upper().endswith(".STY"))
    reference_files = [
        row["path"] for row in complete
        if str(row.get("path", "")).upper().endswith((".MID", ".STY", ".PCG", ".SBD", ".PRF", ".PAD", ".GBL"))
    ]
    native_decode_complete = (
        int(stats.get("failed", -1)) == 0
        and int(stats.get("partial", -1)) == 0
        and int(stats.get("complete", 0)) + int(stats.get("raw", 0)) == int(stats.get("total", -2))
    )
    native_catalog = load_native_oscillator_catalog()
    native_style_catalog = load_native_style_catalog()
    return {
        "available": True,
        "native_decode_complete": native_decode_complete,
        "path": str(root.resolve()),
        "manifest": str(manifest_path.resolve()),
        "decoder": manifest.get("decoder"),
        "stats": stats,
        "complete_files": len(complete),
        "suffix_counts": dict(sorted(suffix_counts.items())),
        "factory_midi_files": len(midi_files),
        "factory_style_banks": len(style_files),
        "factory_reference_files": len(reference_files),
        "example_midi_files": midi_files[:8],
        "example_style_files": style_files[:8],
        "native_oscillator_catalog": {
            "available": native_catalog.get("available", False),
            "multisample_count": native_catalog.get("multisample_count", 0),
            "pcg_total_records": native_catalog.get("pcg_total_records", 0),
            "pcg_non_empty": native_catalog.get("pcg_non_empty", 0),
            "resolution_rate": native_catalog.get("resolution_rate", 0),
        },
        "native_style_catalog": {
            "available": native_style_catalog.get("available", False),
            "bank_count": native_style_catalog.get("bank_count", 0),
            "total_style_names": native_style_catalog.get("total_style_names", 0),
            "total_program_changes": native_style_catalog.get("total_program_changes", 0),
            "total_note_events": native_style_catalog.get("total_note_events", 0),
            "unique_programs": native_style_catalog.get("unique_programs", 0),
        },
        "policy": "READ_ONLY_FACTORY_CORPUS; NO_AUTOMATIC_VELOCITY_OR_TRIGGER_THRESHOLDS_FROM_DISTRIBUTIONS",
    }


def decoded_hardware_layer(
    registry: dict[str, Any], binding: tuple[int | None, int | None, int | None],
    note: int, velocity: int,
) -> dict[str, Any] | None:
    if any(value is None for value in binding):
        return None
    profile = registry.get("hardware_profiles", {}).get(".".join(str(int(value)) for value in binding))
    if not profile:
        return None
    oscillator = None
    for row in profile.get("oscillators", []):
        zone = row.get("velocity_zone") or []
        key_zone = row.get("key_zone") or []
        key_match = note >= 96 if row.get("semantic_role") in {"RX_NOISE", "RX_NOISE_SPECIAL_KEYS"} else note < 96
        if len(zone) == 2 and int(zone[0]) <= velocity <= int(zone[1]) and key_match:
            oscillator = row
            break
    if oscillator is None:
        return None
    switch = oscillator.get("vel_switch_l_to_h")
    side = "high" if switch is not None and velocity >= int(switch) else "low"
    sample = oscillator.get(side)
    role = str(oscillator.get("semantic_role") or "UNRESOLVED")
    label = role.casefold().replace("_to_", "/").replace("_", " ")
    if role == "DEAD_TO_MUTE" and side == "high":
        label = "mute (palm-style mute family)"
    return {
        "sound": profile.get("identity", {}).get("name"), "profile_status": profile.get("status"),
        "oscillator": oscillator.get("osc"), "semantic_role": role,
        "articulation_label": label, "velocity_zone": oscillator.get("velocity_zone"),
        "key_zone": oscillator.get("key_zone"), "switch_l_to_h": switch, "active_side": side,
        "multisample": sample,
        "confidence": oscillator.get("confidence") or profile.get("status"),
        "palm_wording_status": (
            "INFERRED_FAMILY_LABEL; hardware evidence proves Clean Guitar Mute, not a literal Palm sample name"
            if label.startswith("mute (palm-style") else None
        ),
    }


def available_rx_kits(registry_path: Path | None = None) -> list[str]:
    registry = load_special_registry(registry_path)
    return sorted(
        row["name"] for row in registry["rx_drum_kits"]
        if row.get("factory_address_status") == "EXACT_FACTORY_CORPUS"
        and all(row.get(key) is not None for key in (
            "factory_corpus_cc00", "factory_corpus_cc32", "factory_corpus_pc"
        ))
    )


def special_sound_usage(tracks: list[list[Event]], registry_path: Path | None = None) -> dict[str, Any]:
    registry = load_special_registry(registry_path)
    identities: dict[tuple[int, int, int, bool], dict[str, Any]] = {}
    for row in registry["rx_sounds"] + registry["dnc_sounds"]:
        if all(row.get(key) is not None for key in ("cc00", "cc32", "pc")):
            identities[(int(row["cc00"]), int(row["cc32"]), int(row["pc"]), False)] = row
    for row in registry["rx_drum_kits"]:
        if row.get("factory_address_status") == "EXACT_FACTORY_CORPUS":
            identities[(
                int(row["factory_corpus_cc00"]), int(row["factory_corpus_cc32"]),
                int(row["factory_corpus_pc"]), True,
            )] = row
    found = []
    for track_index, events in enumerate(tracks):
        bank: dict[int, list[int | None]] = defaultdict(lambda: [None, None])
        for event in events:
            if event.kind != "channel":
                continue
            channel, family = event.status & 15, event.status & 0xF0
            if family == 0xB0 and event.data[0] in (0, 32):
                bank[channel][0 if event.data[0] == 0 else 1] = event.data[1]
            elif family == 0xC0:
                row = identities.get((bank[channel][0], bank[channel][1], event.data[0], channel == 9))
                if row:
                    found.append({
                        "track": track_index, "tick": event.tick, "channel": channel + 1,
                        "name": row["name"], "kind": row["kind"],
                        "cc00": bank[channel][0], "cc32": bank[channel][1], "pc": event.data[0],
                    })
    return {
        "registry_available": registry["available"], "registry_path": registry["path"],
        "assignment_events": len(found), "assignments": found,
        "unique_names": sorted({row["name"] for row in found}),
    }


def apply_special_sound_preferences(
    tracks: list[list[Event]], prefer_rx_dnc: bool = False,
    rx_kit_name: str | None = None, registry_path: Path | None = None,
) -> tuple[list[list[Event]], list[dict[str, Any]], set[int], dict[str, Any]]:
    """Select only catalog-verified RX/DNC identities and exact RX-kit addresses.

    Melodic replacement is limited to the same GM program number. DNC wins where
    available; otherwise the strongest Factory-corpus RX candidate is selected.
    All special channels are returned as velocity-protected because their trigger
    semantics cannot be inferred from the RX/DNC suffix.
    """
    registry = load_special_registry(registry_path)
    if (prefer_rx_dnc or rx_kit_name) and not registry["available"]:
        raise ValueError("RX/DNC registry nije pronađen; zvukovi nisu promijenjeni.")
    melodic_rows = registry["rx_sounds"] + registry["dnc_sounds"]
    by_binding = {
        (row.get("cc00"), row.get("cc32"), row.get("pc")): row
        for row in melodic_rows
        if all(row.get(key) is not None for key in ("cc00", "cc32", "pc"))
    }
    kit_by_binding = {
        (row.get("factory_corpus_cc00"), row.get("factory_corpus_cc32"), row.get("factory_corpus_pc")): row
        for row in registry["rx_drum_kits"]
        if row.get("factory_address_status") == "EXACT_FACTORY_CORPUS"
    }
    grades = {"STRONG": 4, "GOOD": 3, "LIMITED": 2, "FALLBACK": 1}
    by_program: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in melodic_rows:
        if all(row.get(key) is not None for key in ("cc00", "cc32", "pc")):
            # User-reported failure: neither distortion RX sound has a proven
            # velocity/trigger profile. Preserve existing selections, but do not
            # introduce these sounds automatically from GM distortion guitar.
            if str(row.get("name", "")).casefold().startswith("dist. guitar rx"):
                continue
            by_program[int(row["pc"])].append(row)
    for rows in by_program.values():
        rows.sort(key=lambda row: (
            row.get("detail_status") == "HARDWARE_OBSERVED_PARTIAL",
            row.get("kind") == "DNC",
            grades.get(row.get("factory_corpus_support_grade"), 0),
            row.get("name", ""),
        ), reverse=True)

    kit = None
    if rx_kit_name:
        kit = next((row for row in registry["rx_drum_kits"] if row.get("name") == rx_kit_name), None)
        if kit is None or kit.get("factory_address_status") != "EXACT_FACTORY_CORPUS":
            raise ValueError(f"RX kit nema dokazanu jedinstvenu adresu: {rx_kit_name}")
        kit = {
            "name": kit["name"], "kind": "RX_DRUM_KIT",
            "cc00": int(kit["factory_corpus_cc00"]),
            "cc32": int(kit["factory_corpus_cc32"]),
            "pc": int(kit["factory_corpus_pc"]),
        }

    blocked = blocked_channels_for(tracks)
    output: list[list[Event]] = []
    changes: list[dict[str, Any]] = []
    protected: set[int] = set()
    for track_index, events in enumerate(tracks):
        bank: dict[int, list[int | None]] = defaultdict(lambda: [None, None])
        program_seen: set[int] = set()
        trusted = defaultdict(lambda: True)
        confirmed = defaultdict(set)
        cooked: list[Event] = []
        for event in events:
            if event.kind != "channel":
                if event.kind == "sysex" or event.kind in {"meta-20", "meta-21"}:
                    for channel in range(16):
                        trusted[channel] = False
                        confirmed[channel].clear()
                cooked.append(event)
                continue
            channel = event.status & 15
            family = event.status & 0xF0
            if family == 0xB0 and event.data[0] in (0, 32):
                bank[channel][0 if event.data[0] == 0 else 1] = event.data[1]
                confirmed[channel].add(event.data[0])
                cooked.append(event)
                continue
            target = None
            reason = None
            if family == 0xC0:
                if confirmed[channel] == {0, 32}:
                    trusted[channel] = True
                program_seen.add(channel)
                binding_key = (bank[channel][0], bank[channel][1], event.data[0])
                existing = (kit_by_binding.get(binding_key) if channel == 9 else by_binding.get(binding_key))
                if existing:
                    protected.add(channel)
                if channel == 9 and kit is not None and channel not in blocked:
                    target, reason = kit, "USER_SELECTED_RX_KIT"
                elif channel != 9 and prefer_rx_dnc and channel not in blocked and existing is None and trusted[channel] and all(v in (None, 0) for v in bank[channel]):
                    candidates = by_program.get(event.data[0], [])
                    if candidates:
                        target, reason = candidates[0], "SAME_GM_PROGRAM_VERIFIED_SPECIAL"
            elif family == 0x90 and event.data[1] > 0 and channel not in program_seen:
                # MIDI defaults to program 0. Make that implicit choice explicit only
                # when an exact target was requested and the channel has one owner.
                if channel == 9 and kit is not None and channel not in blocked:
                    target, reason = kit, "USER_SELECTED_RX_KIT_DEFAULT_PROGRAM"
                elif channel != 9 and prefer_rx_dnc and channel not in blocked and trusted[channel] and all(v in (None, 0) for v in bank[channel]):
                    candidates = by_program.get(0, [])
                    if candidates:
                        target, reason = candidates[0], "DEFAULT_GM_PROGRAM_VERIFIED_SPECIAL"
                if target:
                    program_seen.add(channel)
            if target:
                binding = (int(target["cc00"]), int(target["cc32"]), int(target["pc"]))
                cooked.extend((
                    Event(event.tick, "channel", 0xB0 | channel, bytes((0, binding[0]))),
                    Event(event.tick, "channel", 0xB0 | channel, bytes((32, binding[1]))),
                ))
                if family != 0xC0:
                    cooked.append(Event(event.tick, "channel", 0xC0 | channel, bytes((binding[2],))))
                else:
                    event = Event(event.tick, event.kind, event.status, bytes((binding[2],)))
                bank[channel] = [binding[0], binding[1]]
                protected.add(channel)
                changes.append({
                    "code": "SELECT_SPECIAL_SOUND", "track": track_index, "tick": event.tick,
                    "channel": channel + 1, "name": target["name"], "kind": target["kind"],
                    "cc00": binding[0], "cc32": binding[1], "pc": binding[2], "reason": reason,
                })
            cooked.append(event)
        output.append(cooked)
    summary = {
        "registry_available": registry["available"], "registry_path": registry["path"],
        "prefer_rx_dnc": prefer_rx_dnc, "rx_kit": rx_kit_name,
        "selected_events": len(changes), "protected_velocity_channels": [x + 1 for x in sorted(protected)],
    }
    return output, changes, protected, summary


def _note_contexts(events: list[Event]) -> dict[int, dict[str, Any]]:
    active: dict[tuple[int, int], list[int]] = defaultdict(list)
    notes: dict[int, dict[str, Any]] = {}
    for index, event in enumerate(events):
        if event.kind != "channel":
            continue
        channel, family = event.status & 15, event.status & 0xF0
        if family == 0x90 and event.data[1] > 0:
            active[(channel, event.data[0])].append(index)
            notes[index] = {
                "tick": event.tick, "channel": channel, "note": event.data[0],
                "velocity": event.data[1], "duration": None,
            }
        elif family == 0x80 or (family == 0x90 and event.data[1] == 0):
            queue = active[(channel, event.data[0])]
            if queue:
                start_index = queue.pop(0)
                notes[start_index]["duration"] = max(0, event.tick - notes[start_index]["tick"])
    by_channel: dict[int, list[tuple[int, dict[str, Any]]]] = defaultdict(list)
    for index, row in notes.items():
        by_channel[row["channel"]].append((index, row))
    for rows in by_channel.values():
        rows.sort(key=lambda item: (item[1]["tick"], item[0]))
        tick_counts = Counter(row["tick"] for _, row in rows)
        prior = None
        for _, row in rows:
            row["simultaneous_notes"] = tick_counts[row["tick"]]
            row["previous_note"] = prior["note"] if prior else None
            row["previous_tick"] = prior["tick"] if prior else None
            row["interval_from_previous"] = abs(row["note"] - prior["note"]) if prior else None
            row["gap_from_previous"] = (
                max(0, row["tick"] - prior["tick"] - (prior["duration"] or 0)) if prior else None
            )
            if prior is None or row["tick"] > prior["tick"]:
                prior = row
    return notes


def apply_articulation_engine(
    tracks: list[list[Event]], sound_changes: list[dict[str, Any]], enabled: bool = False,
    division: int = 480, intensity: int = 35,
) -> tuple[list[list[Event]], list[dict[str, Any]], dict[str, Any]]:
    """Apply hardware-proven RX working zones and audit existing articulations.

    Newly assigned RX sounds are normalized into their proven working oscillator
    window so an ordinary GM velocity cannot accidentally become Stop/Gliss/Mute.
    Existing RX articulation events and C7+ trigger notes are classified and kept.
    DNC data is kept unchanged until a per-sound trigger map is proven.
    """
    if not 0 <= intensity <= 100:
        raise ValueError("articulation intensity must be between 0 and 100")
    registry = load_oscillator_registry()
    profiles = {
        (int(row["cc00"]), int(row["cc32"]), int(row["pc"])): row
        for row in registry["sounds"]
        if all(row.get(key) is not None for key in ("cc00", "cc32", "pc"))
    }
    newly_selected = {
        (int(row["channel"]) - 1, int(row["cc00"]), int(row["cc32"]), int(row["pc"]))
        for row in sound_changes if row.get("kind") == "RX"
    }
    special = load_special_registry()
    dnc_bindings = {
        (int(row["cc00"]), int(row["cc32"]), int(row["pc"]))
        for row in special["dnc_sounds"]
        if all(row.get(key) is not None for key in ("cc00", "cc32", "pc"))
    }
    output: list[list[Event]] = []
    changes: list[dict[str, Any]] = []
    semantics = Counter()
    generated_semantics = Counter()
    decoded_layers = Counter()
    resolved_multisample_events = 0
    deep_notes = noise_notes = dnc_notes = kit_layer_notes = 0
    kit_evidence = registry["drum_key_layer_evidence"]
    for track_index, events in enumerate(tracks):
        contexts = _note_contexts(events)
        bank: dict[int, list[int | None]] = defaultdict(lambda: [None, None])
        active_binding: dict[int, tuple[int | None, int | None, int | None]] = {}
        cooked: list[Event] = []
        for event_index, event in enumerate(events):
            replacement = event
            if event.kind == "channel":
                channel, family = event.status & 15, event.status & 0xF0
                if family == 0xB0 and event.data[0] in (0, 32):
                    bank[channel][0 if event.data[0] == 0 else 1] = event.data[1]
                elif family == 0xC0:
                    active_binding[channel] = (bank[channel][0], bank[channel][1], event.data[0])
                elif family == 0x90 and event.data[1] > 0:
                    # Bank Select is pending state; it becomes audible only when a
                    # Program Change commits the new Bank/Program selection.
                    binding = active_binding.get(channel, (None, None, None))
                    if channel == 9 and binding == (120, 0, 4):
                        evidence = kit_evidence.get(str(event.data[0]))
                        if evidence:
                            kit_layer_notes += 1
                    elif binding in dnc_bindings:
                        dnc_notes += 1
                    profile = profiles.get(binding)
                    if profile:
                        deep_notes += 1
                        note, old = event.data
                        windows = [
                            window for window in profile.get("windows", [])
                            if int(window["velocity_min"]) <= old <= int(window["velocity_max"])
                            and (window.get("key_min") is None or note >= int(window["key_min"]))
                            and (window.get("key_max") is None or note <= int(window["key_max"]))
                        ]
                        if windows:
                            window = min(windows, key=lambda row: (
                                int(row.get("key_max", 127)) - int(row.get("key_min", 0)),
                                int(row["velocity_max"]) - int(row["velocity_min"]),
                            ))
                            semantic = str(window["semantic"])
                            semantics[semantic] += 1
                            existing_layer = decoded_hardware_layer(registry, binding, note, old)
                            if existing_layer:
                                layer_key = existing_layer["articulation_label"]
                                decoded_layers[layer_key] += 1
                                if existing_layer.get("multisample"):
                                    resolved_multisample_events += 1
                            if note >= 96:
                                noise_notes += 1
                            selected_key = (channel, binding[0], binding[1], binding[2])
                            if enabled and selected_key in newly_selected and note < 96:
                                working = next(
                                    (row for row in profile["windows"] if "working" in str(row["semantic"]).casefold()),
                                    None,
                                )
                                if working:
                                    target = working
                                    target_semantic = "working"
                                    reason = "NEW_RX_MAPPING_AVOID_ACCIDENTAL_SPECIAL_TRIGGER"
                                    context = contexts.get(event_index, {})
                                    duration = context.get("duration")
                                    interval = context.get("interval_from_previous")
                                    gap = context.get("gap_from_previous")
                                    mono = context.get("simultaneous_notes", 1) == 1
                                    short = duration is not None and duration <= max(1, division // 4)
                                    very_short = duration is not None and duration <= max(1, division // 8)
                                    profile_name = str(profile["name"]).casefold()
                                    if "guitar" in profile_name:
                                        mute = next((row for row in profile["windows"] if any(
                                            token in str(row["semantic"]).casefold() for token in ("dead", "mute")
                                        )), None)
                                        upper = next((row for row in profile["windows"] if any(
                                            token in str(row["semantic"]).casefold() for token in ("slap", "slide")
                                        )), None)
                                        if mute and short and old <= 40 + intensity // 3:
                                            target, target_semantic = mute, "dead" if very_short else "mute"
                                            reason = "SHORT_LOW_VELOCITY_GUITAR_ARTICULATION"
                                        elif upper and mono and interval is not None and interval >= 5 and old >= 124 - intensity // 3:
                                            target, target_semantic = upper, "slide/slap"
                                            reason = "ACCENTED_GUITAR_INTERVAL_ARTICULATION"
                                    else:
                                        stop = next((row for row in profile["windows"] if "stop" in str(row["semantic"]).casefold()), None)
                                        gliss = next((row for row in profile["windows"] if "gliss" in str(row["semantic"]).casefold()), None)
                                        harmonic = next((row for row in profile["windows"] if "harmonic" in str(row["semantic"]).casefold()), None)
                                        if gliss and mono and interval is not None and interval >= 5 and (
                                            gap is None or gap <= division
                                        ) and old <= max(5, intensity // 5):
                                            target, target_semantic = gliss, "gliss"
                                            reason = "VERY_SOFT_BASS_INTERVAL_GLISS"
                                        elif stop and short and old <= 40 + intensity // 3:
                                            target, target_semantic = stop, "stop"
                                            reason = "SHORT_LOW_VELOCITY_BASS_STOP"
                                        elif harmonic and mono and interval is not None and interval >= 7 and (
                                            gap is None or gap <= division * 2
                                        ) and old >= 124 - intensity // 3:
                                            target = harmonic
                                            target_semantic = "slap" if "slap" in profile_name else "harmonic"
                                            reason = (
                                                "ACCENTED_BASS_LEAP_SLAP" if target_semantic == "slap"
                                                else "ACCENTED_BASS_LEAP_HARMONIC"
                                            )
                                    lo, hi = int(target["velocity_min"]), int(target["velocity_max"])
                                    switch = target.get("switch")
                                    if target_semantic == "dead" and switch and lo < int(switch) <= hi:
                                        hi = int(switch) - 1
                                    elif target_semantic == "mute" and switch and lo < int(switch) <= hi:
                                        lo = int(switch)
                                    elif target_semantic == "slide/slap" and switch and lo < int(switch) <= hi:
                                        lo = int(switch)
                                    new = lo + round((old - 1) * (hi - lo) / 126)
                                    new = max(lo, min(hi, new))
                                    if new != old:
                                        replacement = Event(event.tick, event.kind, event.status, bytes((note, new)))
                                        generated_semantics[target_semantic] += 1
                                        hardware_layer = decoded_hardware_layer(registry, binding, note, new)
                                        changes.append({
                                            "code": "ARTICULATION_WORKING_ZONE" if target_semantic == "working" else "ARTICULATION_ENHANCE",
                                            "track": track_index,
                                            "tick": event.tick, "channel": channel + 1, "note": note,
                                            "before": old, "after": new, "sound": profile["name"],
                                            "semantic": target_semantic, "window": [lo, hi],
                                            "duration_ticks": duration, "interval_from_previous": interval,
                                            "gap_from_previous": gap,
                                            "simultaneous_notes": context.get("simultaneous_notes"),
                                            "reason": reason,
                                            "decoded_hardware_layer": hardware_layer,
                                        })
            cooked.append(replacement)
        output.append(cooked)
    summary = {
        "enabled": enabled, "intensity": intensity, "registry_available": registry["available"],
        "registry_path": registry["path"], "hardware_profiles": len(profiles),
        "hardware_profile_path": registry.get("hardware_profile_path"),
        "deep_profile_notes": deep_notes,
        "normalized_working_notes": sum(row["code"] == "ARTICULATION_WORKING_ZONE" for row in changes),
        "enhanced_articulations": sum(row["code"] == "ARTICULATION_ENHANCE" for row in changes),
        "generated_semantics": dict(generated_semantics),
        "decoded_input_layers": dict(decoded_layers),
        "resolved_multisample_events": resolved_multisample_events,
        "existing_noise_trigger_notes_preserved": noise_notes,
        "unresolved_dnc_notes_preserved": dnc_notes,
        "pop_std_exact_key_layer_notes_preserved": kit_layer_notes,
        "observed_semantics": dict(semantics),
        "policy": "HARDWARE_WINDOWS_ONLY; NO_UNPROVEN_TRIGGER_NOTES_OR_DNC_CONTROLLERS",
    }
    return output, changes, summary


def blocked_channels_for(tracks: list[list[Event]]) -> set[int]:
    owners: dict[int, set[int]] = defaultdict(set)
    for index, events in enumerate(tracks):
        for event in events:
            if event.kind == "channel":
                owners[event.status & 15].add(index)
    blocked = {channel for channel, track_ids in owners.items() if len(track_ids) > 1}
    if len(tracks) > 1 and any(
        event.kind == "sysex" or event.kind in {"meta-21", "meta-20"}
        for events in tracks for event in events
    ):
        blocked = set(range(16))
    return blocked


def optimize_track(events: list[Event], blocked_channels: set[int] | None = None) -> tuple[list[Event], list[dict[str, Any]]]:
    output: list[Event] = []
    last_cc: dict[tuple[int, int], int] = {}
    changes: list[dict[str, Any]] = []
    for event in events:
        if event.kind == "sysex" or event.kind in {"meta-21", "meta-20"}:
            # A device-specific message may alter controller state.
            last_cc.clear()
        if event.kind == "channel":
            family = event.status & 0xF0
            channel = event.status & 0x0F
            if family == 0xC0:
                last_cc.clear()
            elif family == 0xB0:
                cc, value = event.data
                key = (channel, cc)
                if channel not in (blocked_channels or set()) and cc in SAFE_REDUNDANT_CC and last_cc.get(key) == value:
                    changes.append({
                        "code": "REMOVE_REDUNDANT_CC", "tick": event.tick,
                        "channel": channel + 1, "controller": cc, "value": value,
                    })
                    continue
                if cc >= 120 or cc in {0, 32, 98, 99, 100, 101}:
                    # Mode/reset, bank and parameter-selection messages are barriers.
                    last_cc.clear()
                last_cc[key] = value
        output.append(event)
    return output, changes


def optimize_velocities(
    tracks: list[list[Event]], strength: int = 35, include_drums: bool = False,
    protected_channels: set[int] | None = None,
) -> tuple[list[list[Event]], list[dict[str, Any]], dict[str, Any]]:
    """Instrument/binding-aware dynamics; no invented factory trigger values.

    Median groups are isolated by track, committed bank/program and drum key.
    RX/DNC channels and unclassified non-GM banks are preserved. Bank Select
    only affects the group after Program Change commits it.
    """
    if not 0 <= strength <= 100:
        raise ValueError("velocity strength must be between 0 and 100")
    values: dict[tuple, list[int]] = defaultdict(list)
    shared = blocked_channels_for(tracks)
    event_groups = {}
    group_profiles = {}
    for track_index, events in enumerate(tracks):
        pending = defaultdict(lambda: [0, 0])
        active = defaultdict(lambda: (0, 0, 0))
        epoch = defaultdict(int)
        trusted = defaultdict(lambda: True)
        bank_confirmed = defaultdict(set)
        for event_index, event in enumerate(events):
            if event.kind == "sysex" or event.kind in {"meta-20", "meta-21"}:
                for channel in range(16):
                    trusted[channel] = False
                    bank_confirmed[channel].clear()
                    epoch[channel] += 1
            if event.kind == "channel":
                channel, family = event.status & 15, event.status & 0xF0
                if family == 0xB0 and event.data[0] in (0, 32):
                    pending[channel][0 if event.data[0] == 0 else 1] = event.data[1]
                    bank_confirmed[channel].add(event.data[0])
                elif family == 0xC0:
                    active[channel] = (*pending[channel], event.data[0])
                    epoch[channel] += 1
                    if bank_confirmed[channel] == {0, 32}:
                        trusted[channel] = True
            if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0:
                channel = event.status & 0x0F
                binding = active[channel]
                group = (track_index, channel, *binding, epoch[channel], event.data[0] if channel == 9 else None)
                event_groups[track_index, event_index] = group
                classified = trusted[channel] and (binding[:2] == (0, 0))
                profile = instrument_family(binding[2], channel == 9)
                group_profiles[group] = {"track": track_index, "channel": channel + 1,
                    "bank_program": list(binding), "family": profile["key"],
                    "drum_key": event.data[0] if channel == 9 else None,
                    "program_segment": epoch[channel],
                    "evidence": "SOURCE_ADAPTIVE_NOT_FACTORY_TRIGGER_MAP",
                    "status": "PRESERVED_SHARED_OR_ROUTED_CHANNEL" if channel in shared else
                              "PRESERVED_SPECIAL" if channel in (protected_channels or set()) else
                              "PRESERVED_UNCERTAIN_DEVICE_STATE" if not trusted[channel] else
                              "PRESERVED_UNKNOWN_BANK" if not classified else
                              "PRESERVED_DRUMS" if channel == 9 and not include_drums else "ADAPTIVE"}
                if classified and (include_drums or channel != 9) and channel not in (protected_channels or set()) and channel not in shared:
                    values[group].append(event.data[1])
    medians = {group: float(statistics.median(items)) for group, items in values.items()}
    factor = 1.0 - 0.35 * (strength / 100.0)
    output: list[list[Event]] = []
    changes: list[dict[str, Any]] = []
    before_by_channel: dict[int, list[int]] = defaultdict(list)
    after_by_channel: dict[int, list[int]] = defaultdict(list)
    for track_index, events in enumerate(tracks):
        cooked: list[Event] = []
        for event_index, event in enumerate(events):
            replacement = event
            if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0:
                channel = event.status & 0x0F
                old = event.data[1]
                before_by_channel[channel].append(old)
                group = event_groups[track_index, event_index]
                if group in medians and strength:
                    new = max(1, min(127, round(medians[group] + (old - medians[group]) * factor)))
                    if new != old:
                        replacement = Event(event.tick, event.kind, event.status, bytes((event.data[0], new)))
                        changes.append({
                            "code": "VELOCITY_COMPRESS", "track": track_index, "tick": event.tick,
                            "channel": channel + 1, "note": event.data[0], "before": old, "after": new,
                            "family": group_profiles[group]["family"], "bank_program": list(group[2:5]),
                            "evidence": "SOURCE_ADAPTIVE_NOT_FACTORY_TRIGGER_MAP",
                        })
                    after_by_channel[channel].append(new)
                else:
                    after_by_channel[channel].append(old)
            cooked.append(replacement)
        output.append(cooked)
    channels = []
    for channel in sorted(before_by_channel):
        before = before_by_channel[channel]
        after = after_by_channel[channel]
        channels.append({
            "channel": channel + 1, "protected_drums": channel == 9 and not include_drums,
            "protected_special_sound": channel in (protected_channels or set()),
            "notes": len(before), "before_min": min(before), "before_max": max(before),
            "before_average": round(sum(before) / len(before), 2),
            "after_min": min(after), "after_max": max(after),
            "after_average": round(sum(after) / len(after), 2),
            "changed": sum(a != b for a, b in zip(before, after)),
        })
    return output, changes, {
        "enabled": strength > 0, "strength": strength, "range_factor": round(factor, 4),
        "include_drums_channel_10": include_drums,
        "protected_special_channels": [x + 1 for x in sorted(protected_channels or set())],
        "channels": channels,
        "engine": "INSTRUMENT_BINDING_AWARE", "profiles": list(group_profiles.values()),
        "factory_velocity_values_complete": False,
        "distortion_rx_policy": "NO_AUTOMATIC_REMAP_WITHOUT_VERIFIED_PROFILE",
        "shared_or_routed_channels_preserved": [c + 1 for c in sorted(shared)],
    }


def _text_meta(event: Event) -> str:
    if event.kind not in {"meta-01", "meta-03", "meta-04", "meta-06", "meta-07"}:
        return ""
    return event.data.decode("utf-8", errors="replace").casefold()


def _track_name(events: list[Event]) -> str:
    names = [event.data.decode("utf-8", errors="replace") for event in events if event.kind == "meta-03"]
    return " / ".join(names)


def _note_pairs(events: list[Event], channel: int) -> list[tuple[int, int, int, int]]:
    active: dict[int, list[tuple[int, int]]] = defaultdict(list)
    pairs: list[tuple[int, int, int, int]] = []
    for event in events:
        if event.kind != "channel" or event.status & 15 != channel:
            continue
        family = event.status & 0xF0
        if family == 0x90 and event.data[1] > 0:
            if event.data[0] <= 95:  # Never clone the C7+ RX/DNC noise/trigger area.
                active[event.data[0]].append((event.tick, event.data[1]))
        elif family == 0x80 or family == 0x90 and event.data[1] == 0:
            note = event.data[0]
            if active[note]:
                start, velocity = active[note].pop(0)
                pairs.append((start, max(start + 1, event.tick), note, velocity))
    return pairs


def _pair_polyphony(pairs: list[tuple[int, int, int, int]]) -> tuple[int, float]:
    timeline = []
    for start, end, _, _ in pairs:
        timeline.extend(((start, 1), (end, -1)))
    active = peak = polyphonic_starts = starts = 0
    for _, delta in sorted(timeline, key=lambda row: (row[0], row[1])):
        if delta > 0:
            starts += 1
            if active:
                polyphonic_starts += 1
            active += 1
            peak = max(peak, active)
        else:
            active = max(0, active - 1)
    return peak, round(polyphonic_starts / starts, 4) if starts else 0.0


def _dominant_program(events: list[Event], channel: int) -> int:
    current = 0
    counts = Counter()
    for event in events:
        if event.kind != "channel" or event.status & 15 != channel:
            continue
        family = event.status & 0xF0
        if family == 0xC0:
            current = event.data[0]
        elif family == 0x90 and event.data[1] > 0:
            counts[current] += 1
    return counts.most_common(1)[0][0] if counts else current


def _detect_unnamed_delay(tracks: list[list[Event]], division: int) -> dict[str, Any] | None:
    """Find a strong delayed-copy relationship across two MIDI channels."""
    if division & 0x8000:
        return None
    streams: dict[tuple[int, int], set[tuple[int, int]]] = {}
    for track_index, events in enumerate(tracks):
        for channel in range(16):
            if channel == 9:
                continue
            notes = {
                (event.data[0], event.tick) for event in events
                if event.kind == "channel" and event.status == 0x90 | channel and event.data[1] > 0
            }
            if len(notes) >= 12:
                streams[(track_index, channel)] = notes
    delays = sorted({max(1, division // 2), max(1, division * 3 // 4), division, division * 3 // 2})
    best = None
    keys = list(streams)
    for left_index, left_key in enumerate(keys):
        left = streams[left_key]
        for right_key in keys[left_index + 1:]:
            right = streams[right_key]
            for source_key, source_notes, echo_key, echo_notes in (
                (left_key, left, right_key, right), (right_key, right, left_key, left),
            ):
                for delay in delays:
                    matches = sum((note, tick + delay) in echo_notes for note, tick in source_notes)
                    coverage = matches / min(len(source_notes), len(echo_notes))
                    if matches >= 12 and coverage >= 0.65:
                        candidate = (coverage, matches, delay, source_key, echo_key)
                        if best is None or candidate[:2] > best[:2]:
                            best = candidate
    if best is None:
        return None
    coverage, matches, delay, source_key, echo_key = best
    return {
        "method": "DELAYED_NOTE_COPY_HEURISTIC", "confidence": "strong",
        "coverage": round(coverage, 4), "matched_notes": matches,
        "delay_ticks": delay, "source_track": source_key[0] + 1,
        "source_channel": source_key[1] + 1, "echo_track": echo_key[0] + 1,
        "echo_channel": echo_key[1] + 1,
    }


def _cross_delay_source(
    tracks: list[list[Event]], protected_channels: set[int]
) -> tuple[int, int, list[tuple[int, int, int, int]], int, dict[str, Any]] | None:
    """Choose one safe melodic track/channel without borrowing RX/DNC or drums."""
    candidates = []
    for track_index, events in enumerate(tracks):
        name = _track_name(events).casefold()
        channels = sorted({
            event.status & 15 for event in events
            if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0
        })
        for channel in channels:
            if channel == 9 or channel in protected_channels:
                continue
            pairs = _note_pairs(events, channel)
            if not pairs:
                continue
            source_binding = first_note_binding(events, channel)
            if source_binding is None or source_binding[:2] != (0, 0):
                continue
            program = source_binding[2]
            if any(event.kind == "sysex" for event in events) or any(
                event.kind == "channel" and event.status & 15 == channel and (
                    event.status & 0xF0 in {0xA0, 0xD0, 0xE0}
                    or event.status & 0xF0 == 0xC0 and event.data[0] != program
                    or event.status & 0xF0 == 0xB0 and (
                        event.data[0] in {0, 32} and event.data[1] != 0
                        or event.data[0] in {1, 2, 64, 66} and event.data[1] > 0
                    )
                ) for event in events
            ):
                # Note-copy echo cannot reproduce delayed bends, articulation
                # controls, held pedals or an intervening sound change correctly.
                continue
            average_pitch = sum(row[2] for row in pairs) / len(pairs)
            peak_polyphony, overlap_ratio = _pair_polyphony(pairs)
            score = min(len(pairs), 500)
            if 24 <= program <= 31:  # guitars
                score += 900
            elif 80 <= program <= 87:  # synth leads
                score += 850
            elif 64 <= program <= 79:  # reeds/pipes
                score += 750
            elif 40 <= program <= 55:  # strings/ensemble
                score += 500
            elif 32 <= program <= 39:  # bass must not become the normal echo source
                score -= 800
            if any(word in name for word in ("lead", "solo", "melody", "git", "guitar")):
                score += 700
            if any(word in name for word in ("bass", "drum", "perc")):
                score -= 900
            if average_pitch < 45:
                score -= 500
            if peak_polyphony == 1:
                score += 650
            elif peak_polyphony == 2 and overlap_ratio <= 0.2:
                score += 250
            elif peak_polyphony >= 4 or overlap_ratio > 0.45:
                score -= 700
            metrics = {
                "notes": len(pairs), "average_pitch": round(average_pitch, 2),
                "peak_polyphony": peak_polyphony, "overlap_ratio": overlap_ratio,
                "selection_score": round(score, 2),
            }
            candidates.append((score, track_index, channel, pairs, program, metrics))
    if not candidates:
        return None
    _, track_index, channel, pairs, program, metrics = max(candidates, key=lambda row: (row[0], len(row[3])))
    return track_index, channel, pairs, program, metrics


def add_cross_delay_echo_track(
    tracks: list[list[Event]], fmt: int, division: int, enabled: bool = False,
    amount: int = 35, protected_channels: set[int] | None = None,
) -> tuple[list[list[Event]], list[dict[str, Any]], dict[str, Any]]:
    """Add a portable two-tap MIDI echo only when an Echo/Delay track is absent.

    This audibly approximates a cross delay. It deliberately does not emit an
    unverified Pa800 effect-selection SysEx message.
    """
    if not 0 <= amount <= 100:
        raise ValueError("cross delay amount must be between 0 and 100")
    summary: dict[str, Any] = {
        "enabled": enabled, "amount": amount, "status": "DISABLED",
        "reference_settings": CROSS_DELAY_REFERENCE,
        "sys_ex_policy": "NO_UNVERIFIED_PA800_FX_SYSEX",
        "description": (
            "Ako nema imenovanog Echo/Delay tracka, pravi se tempo-sinhronizovani MIDI echo "
            "na slobodnim kanalima: prvi tap 3/16 lijevo, drugi 1/4 desno. Originalne note "
            "ostaju netaknute; RX/DNC, drums i C7+ trigger-note nisu izvor echa."
        ),
    }
    if not enabled:
        return [list(events) for events in tracks], [], summary
    if amount == 0:
        summary.update(status="SKIPPED_ZERO_AMOUNT", reason="Cross Delay amount is 0%")
        return [list(events) for events in tracks], [], summary
    if division & 0x8000:
        summary.update(status="SKIPPED_SMPTE_TIMING", reason="BPM note-sync needs PPQN timing")
        return [list(events) for events in tracks], [], summary
    echo_hits = []
    for index, events in enumerate(tracks):
        matching = sorted({
            text for event in events if (text := _text_meta(event))
            and any(word in text for word in ("echo", "delay", "odjek"))
        })
        if matching:
            echo_hits.append({"track": index + 1, "text": matching})
    if echo_hits:
        summary.update(status="EXISTING_ECHO_TRACK", detected=echo_hits, reason="Existing Echo/Delay text metadata")
        return [list(events) for events in tracks], [], summary
    unnamed_delay = _detect_unnamed_delay(tracks, division)
    if unnamed_delay:
        summary.update(
            status="EXISTING_UNNAMED_DELAY", detected=[unnamed_delay],
            reason="Strong tempo-related delayed-note copy already exists",
        )
        return [list(events) for events in tracks], [], summary
    protected = set(protected_channels or set()) | blocked_channels_for(tracks)
    source = _cross_delay_source(tracks, protected)
    if source is None:
        summary.update(status="SKIPPED_NO_SAFE_SOURCE", reason="No non-drum, non-RX/DNC paired melody notes")
        return [list(events) for events in tracks], [], summary
    source_track, source_channel, pairs, program, source_metrics = source
    used_channels = {
        event.status & 15 for events in tracks for event in events if event.kind == "channel"
    }
    free_channels = [channel for channel in range(15, -1, -1) if channel != 9 and channel not in used_channels]
    if not free_channels:
        summary.update(status="SKIPPED_NO_FREE_CHANNEL", reason="All non-drum MIDI channels are in use")
        return [list(events) for events in tracks], [], summary
    tap_channels = free_channels[:2]
    tap_specs = [
        (tap_channels[0], round(division * 3 / 4), 28, 0.42 + amount * 0.0025, "left"),
    ]
    if len(tap_channels) > 1:
        tap_specs.append((tap_channels[1], division, 100, 0.30 + amount * 0.002, "right"))

    staged: list[tuple[int, int, Event]] = []
    sequence = 0
    meta_kind = "meta-03" if fmt == 1 else "meta-06"
    staged.append((0, sequence, Event(0, meta_kind, 0xFF, b"PA800 Cross Delay Echo")))
    sequence += 1
    description = b"Auto MIDI echo: 3/16 L + 1/4 R; Pa800 FX 065 Cross Feedback recommendation"
    staged.append((0, sequence, Event(0, "meta-01", 0xFF, description)))
    sequence += 1
    source_events = tracks[source_track]
    for echo_channel, _, pan, _, _ in tap_specs:
        # Copy only routing identity. The echo receives its own quieter mixer setup.
        for event in source_events:
            if event.kind != "channel" or event.status & 15 != source_channel:
                continue
            family = event.status & 0xF0
            if family == 0xC0 or family == 0xB0 and event.data[0] in {0, 32}:
                staged.append((event.tick, sequence, Event(event.tick, "channel", family | echo_channel, event.data)))
                sequence += 1
        for cc, value in ((7, 72), (10, pan), (11, 100), (91, 18)):
            staged.append((0, sequence, Event(0, "channel", 0xB0 | echo_channel, bytes((cc, value)))))
            sequence += 1
    changes: list[dict[str, Any]] = []
    shortened_note_offs = 0
    ordered_pairs = sorted(pairs, key=lambda row: (row[0], row[2], row[1]))
    next_same_note: list[int | None] = [None] * len(ordered_pairs)
    following: dict[int, int] = {}
    for pair_index in range(len(ordered_pairs) - 1, -1, -1):
        start, _, note, _ = ordered_pairs[pair_index]
        next_same_note[pair_index] = following.get(note)
        following[note] = start
    for echo_channel, delay, pan, scale, side in tap_specs:
        for pair_index, (start, end, note, velocity) in enumerate(ordered_pairs):
            echo_velocity = max(1, min(127, round(velocity * scale)))
            on_tick, off_tick = start + delay, end + delay
            next_start = next_same_note[pair_index]
            if next_start is not None and off_tick >= next_start + delay:
                off_tick = max(on_tick + 1, next_start + delay - 1)
                shortened_note_offs += 1
            staged.append((on_tick, sequence, Event(on_tick, "channel", 0x90 | echo_channel, bytes((note, echo_velocity)))))
            sequence += 1
            staged.append((off_tick, sequence, Event(off_tick, "channel", 0x80 | echo_channel, bytes((note, 0)))))
            sequence += 1
            changes.append({
                "code": "ADD_CROSS_DELAY_TAP", "source_track": source_track,
                "source_channel": source_channel + 1, "echo_channel": echo_channel + 1,
                "tick": start, "echo_tick": on_tick, "delay_ticks": delay,
                "side": side, "pan": pan, "note": note, "source_velocity": velocity,
                "echo_velocity": echo_velocity,
            })
    last_tick = max((event.tick for _, _, event in staged), default=0)
    staged.append((last_tick, sequence, Event(last_tick, "meta-2f", 0xFF, b"")))
    echo_events = [event for _, _, event in sorted(staged, key=lambda row: (row[0], row[1]))]
    output = [list(events) for events in tracks]
    if fmt == 1:
        output.append(echo_events)
        physical_track = len(output)
    else:
        base = [event for event in output[0] if event.kind != "meta-2f"]
        additions = [event for event in echo_events if event.kind != "meta-2f"]
        combined = [(event.tick, 0, i, event) for i, event in enumerate(base)]
        combined.extend((event.tick, 1, i, event) for i, event in enumerate(additions))
        merged = [row[3] for row in sorted(combined, key=lambda row: (row[0], row[1], row[2]))]
        final_tick = max((event.tick for event in merged), default=0)
        merged.append(Event(final_tick, "meta-2f", 0xFF, b""))
        output[0] = merged
        physical_track = 1
    summary.update({
        "status": "ADDED", "source_track": source_track + 1,
        "source_track_name": _track_name(source_events) or None,
        "source_channel": source_channel + 1, "source_program": program,
        "source_selection": source_metrics,
        "echo_track": physical_track, "echo_channels": [x[0] + 1 for x in tap_specs],
        "taps": [{"side": x[4], "delay_ticks": x[1], "pan": x[2], "velocity_scale": round(x[3], 3)} for x in tap_specs],
        "source_notes": len(pairs), "added_note_ons": len(changes),
        "stereo": len(tap_specs) == 2, "shortened_overlapping_note_offs": shortened_note_offs,
        "physical_track_created": fmt == 1,
    })
    return output, changes, summary


def note_structure_counter(tracks: list[list[Event]]) -> Counter:
    output = Counter()
    for track_index, events in enumerate(tracks):
        for event in events:
            if event.kind != "channel" or event.status & 0xF0 not in (0x80, 0x90):
                continue
            family = event.status & 0xF0
            is_on = family == 0x90 and event.data[1] > 0
            output[(track_index, event.tick, event.status & 15, event.data[0], is_on)] += 1
    return output


def counter_is_subset(before: Counter, after: Counter) -> bool:
    return all(after[key] >= count for key, count in before.items())


def instrument_family(program: int, drum_channel: bool = False) -> dict[str, Any]:
    if drum_channel:
        return {
            "key": "drums", "name": "Drums/Percussion", "range": (0, 127),
            "mix": {7: 100, 10: 64, 91: 10, 93: 0},
        }
    for low, high, key, name, practical_range, mix in INSTRUMENT_FAMILIES:
        if low <= program <= high:
            return {"key": key, "name": name, "range": practical_range, "mix": dict(mix)}
    raise ValueError(f"invalid MIDI program: {program}")


def first_note_binding(events: list[Event], channel: int) -> tuple[int, int, int] | None:
    pending = [0, 0]
    active = (0, 0, 0)
    trusted = True
    confirmed = set()
    for event in events:
        if event.kind == "sysex" or event.kind in {"meta-20", "meta-21"}:
            trusted = False
            confirmed.clear()
        if event.kind != "channel" or event.status & 15 != channel:
            continue
        family = event.status & 0xF0
        if family == 0xB0 and event.data[0] in {0, 32}:
            pending[0 if event.data[0] == 0 else 1] = event.data[1]
            confirmed.add(event.data[0])
        elif family == 0xC0:
            active = (*pending, event.data[0])
            if confirmed == {0, 32}:
                trusted = True
        elif family == 0x90 and event.data[1] > 0:
            return active if trusted else None
    return None


def apply_instrument_intelligence(
    tracks: list[list[Event]], enabled: bool = False, intensity: int = 35,
    protected_channels: set[int] | None = None,
) -> tuple[list[list[Event]], list[dict[str, Any]], dict[str, Any]]:
    """Classify instruments and fill only missing mix CCs; never rewrite notes.

    Practical ranges are diagnostic rather than destructive. Existing CC7/10/91/93
    values and all RX/DNC protected channels remain untouched.
    """
    if not 0 <= intensity <= 100:
        raise ValueError("instrument intelligence intensity must be between 0 and 100")
    protected = set(protected_channels or set())
    blocked = blocked_channels_for(tracks)
    controllers: dict[int, set[int]] = defaultdict(set)
    for events in tracks:
        for event in events:
            if event.kind == "channel" and event.status & 0xF0 == 0xB0:
                controllers[event.status & 15].add(event.data[0])
    insertions: dict[tuple[int, int], list[Event]] = defaultdict(list)
    channel_reports = []
    changes = []
    neutral = {7: 100, 10: 64, 91: 0, 93: 0}
    for track_index, events in enumerate(tracks):
        channels = sorted({
            event.status & 15 for event in events
            if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0
        })
        for channel in channels:
            note_rows = [
                (index, event) for index, event in enumerate(events)
                if event.kind == "channel" and event.status == 0x90 | channel and event.data[1] > 0
            ]
            if not note_rows:
                continue
            pairs = _note_pairs(events, channel)
            first_binding = first_note_binding(events, channel)
            program = first_binding[2] if first_binding else 0
            family = instrument_family(program, channel == 9)
            pitches = [event.data[0] for _, event in note_rows]
            low, high = family["range"]
            below = sum(note < low for note in pitches)
            above = sum(note > high for note in pitches)
            peak, overlap_ratio = _pair_polyphony(pairs)
            program_changes = sum(
                event.kind == "channel" and event.status == 0xC0 | channel for event in events
            )
            warnings = []
            if below or above:
                warnings.append({
                    "code": "OUTSIDE_PRACTICAL_RANGE", "below": below, "above": above,
                    "policy": "REPORT_ONLY_NO_TRANSPOSE",
                })
            if family["key"] in {"bass", "guitar", "reed", "pipe", "synth_lead"} and peak > 4:
                warnings.append({"code": "UNUSUALLY_HIGH_POLYPHONY", "peak": peak})
            if program_changes > 3:
                warnings.append({"code": "MANY_PROGRAM_CHANGES", "count": program_changes})
            programs = {event.data[0] for event in events if event.kind == "channel" and event.status == 0xC0 | channel}
            mixed_programs = len(programs | {program}) > 1
            known_gm_binding = first_binding is not None and first_binding[:2] == (0, 0) and not any(
                event.kind == "channel" and event.status == 0xB0 | channel
                and event.data[0] in {0, 32} and event.data[1] != 0 for event in events
            )
            if mixed_programs:
                warnings.append({"code": "MIXED_PROGRAMS_NO_AUTOMATIC_MIX", "policy": "KEEP_EXISTING_MIX"})
            if not known_gm_binding:
                warnings.append({"code": "UNRESOLVED_BANK_OR_DEVICE_STATE_NO_AUTOMATIC_MIX"})
            can_modify = enabled and intensity > 0 and channel not in protected and channel not in blocked and known_gm_binding and not mixed_programs
            added = []
            if can_modify:
                target_mix = dict(family["mix"])
                if family["key"] in {"guitar", "strings", "ensemble", "synth_pad"} and channel % 2:
                    target_mix[10] = 128 - target_mix[10]
                first_index, first_note = note_rows[0]
                for cc in (7, 10, 91, 93):
                    if cc in controllers[channel]:
                        continue
                    target = target_mix[cc]
                    value = round(neutral[cc] + (target - neutral[cc]) * intensity / 100)
                    if cc in {91, 93} and value == 0:
                        continue
                    event = Event(first_note.tick, "channel", 0xB0 | channel, bytes((cc, value)))
                    insertions[(track_index, first_index)].append(event)
                    added.append({"controller": cc, "value": value, "target_at_100": target})
                    changes.append({
                        "code": "ADD_MISSING_INSTRUMENT_MIX_CC", "track": track_index,
                        "tick": first_note.tick, "channel": channel + 1, "program": program,
                        "family": family["key"], "controller": cc, "value": value,
                        "reason": "CONTROLLER_ABSENT; PRESERVE_EXISTING_MIX",
                    })
            channel_reports.append({
                "track": track_index + 1, "track_name": _track_name(events) or None,
                "channel": channel + 1, "dominant_program": program,
                "family": family["key"], "family_name": family["name"],
                "notes": len(pitches), "pitch_min": min(pitches), "pitch_max": max(pitches),
                "practical_range": [low, high], "outside_range": below + above,
                "peak_polyphony": peak, "overlap_ratio": overlap_ratio,
                "program_changes": program_changes,
                "existing_mix_controllers": sorted(controllers[channel] & {7, 10, 91, 93}),
                "first_note_bank_program": list(first_binding) if first_binding else None,
                "mixed_programs_preserved": mixed_programs,
                "added_mix_controllers": added,
                "protected_special_sound": channel in protected,
                "blocked_shared_channel": channel in blocked,
                "warnings": warnings,
            })
    output = []
    for track_index, events in enumerate(tracks):
        cooked = []
        for event_index, event in enumerate(events):
            cooked.extend(insertions.get((track_index, event_index), []))
            cooked.append(event)
        output.append(cooked)
    return output, changes, {
        "enabled": enabled, "intensity": intensity,
        "policy": "CLASSIFY_ALL; FILL_ONLY_MISSING_CC; REPORT_RANGE; NEVER_AUTO_TRANSPOSE",
        "channels": channel_reports, "classified_channels": len(channel_reports),
        "mix_cc_added": len(changes),
        "protected_special_channels": [channel + 1 for channel in sorted(protected)],
        "blocked_shared_channels": [channel + 1 for channel in sorted(blocked)],
        "range_warning_channels": sum(bool(row["outside_range"]) for row in channel_reports),
    }


def serialize_track(events: list[Event]) -> bytes:
    output = bytearray()
    previous_tick = 0
    has_eot = False
    running_status: int | None = None
    for event in events:
        if event.tick < previous_tick:
            raise ValueError("events are not ordered by tick")
        output.extend(encode_vlq(event.tick - previous_tick))
        previous_tick = event.tick
        if event.kind.startswith("meta-"):
            running_status = None
            meta_type = int(event.kind[5:], 16)
            output.extend((0xFF, meta_type))
            output.extend(encode_vlq(len(event.data)))
            output.extend(event.data)
            has_eot |= meta_type == 0x2F
        elif event.kind == "sysex":
            running_status = None
            output.append(event.status)
            output.extend(encode_vlq(len(event.data)))
            output.extend(event.data)
        elif event.kind == "channel":
            if event.status != running_status:
                output.append(event.status)
                running_status = event.status
            output.extend(event.data)
        else:
            raise ValueError(f"unsupported event kind: {event.kind}")
    if not has_eot:
        output.extend(b"\x00\xff\x2f\x00")
    return bytes(output)


def write_smf(path: Path, fmt: int, division: int, tracks: list[list[Event]]) -> None:
    content = bytearray(b"MThd" + struct.pack(">IHHH", 6, fmt, len(tracks), division))
    for events in tracks:
        body = serialize_track(events)
        content.extend(b"MTrk" + struct.pack(">I", len(body)) + body)
    path.write_bytes(content)


def fingerprint_events(tracks: list[list[Event]], category: str) -> str:
    digest = hashlib.sha256()
    for track_index, events in enumerate(tracks):
        for event in events:
            family = event.status & 0xF0 if event.kind == "channel" else None
            include = (
                category == "notes" and event.kind == "channel" and family in (0x80, 0x90)
                or category == "note-structure" and event.kind == "channel" and family in (0x80, 0x90)
                or category == "meta" and event.kind.startswith("meta-")
                or category == "sysex" and event.kind == "sysex"
                or category == "protected-channel" and event.kind == "channel" and not (
                    family in (0x80, 0x90) or family == 0xB0 and event.data[0] in SAFE_REDUNDANT_CC
                )
                or category == "nonrouting-channel" and event.kind == "channel" and not (
                    family in (0x80, 0x90, 0xC0)
                    or family == 0xB0 and event.data[0] in (SAFE_REDUNDANT_CC | {0, 32})
                )
            )
            if include:
                digest.update(struct.pack(">II", track_index, event.tick))
                digest.update(event.kind.encode("ascii") + b"\0")
                event_data = event.data
                if category == "note-structure" and family == 0x90 and event.data[1] > 0:
                    event_data = bytes((event.data[0], 1))
                digest.update(bytes([event.status]) + event_data)
    return digest.hexdigest()


def critical_performance_counter(tracks: list[list[Event]]) -> Counter:
    """Source performance controls and note-off encoding must survive exactly."""
    result = Counter()
    for track_index, events in enumerate(tracks):
        for event in events:
            if event.kind != "channel":
                continue
            family = event.status & 0xF0
            if family in {0x80, 0xA0, 0xD0, 0xE0} or (
                family == 0x90 and event.data[1] == 0
            ) or (family == 0xB0 and event.data[0] not in SAFE_REDUNDANT_CC | {0, 32}):
                result[(track_index, event.tick, event.status, event.data)] += 1
    return result


def midi_quality_report(tracks: list[list[Event]], velocity: dict) -> dict:
    """Report unresolved musical risks without inventing corrections or thresholds."""
    warnings = []
    distortion = []
    for track_index, events in enumerate(tracks):
        bank = defaultdict(lambda: [0, 0])
        binding = defaultdict(lambda: (0, 0, 0))
        sustain = {}
        histograms = defaultdict(Counter)
        for event in events:
            if event.kind == "sysex":
                binding.clear()
                continue
            if event.kind != "channel":
                continue
            channel, family = event.status & 15, event.status & 0xF0
            if family == 0xB0:
                if event.data[0] in {0, 32}:
                    bank[channel][0 if event.data[0] == 0 else 1] = event.data[1]
                elif event.data[0] == 64:
                    sustain[channel] = event.data[1]
                elif event.data[0] == 121:
                    sustain[channel] = 0
            elif family == 0xC0:
                binding[channel] = (*bank[channel], event.data[0])
            elif family == 0x90 and event.data[1] > 0 and binding[channel] in {(121, 9, 30), (121, 10, 30)}:
                histograms[channel, binding[channel]][event.data[1]] += 1
        for (channel, address), histogram in histograms.items():
            distortion.append({"track": track_index, "channel": channel + 1, "bank_program": list(address),
                               "velocity_histogram": dict(sorted(histogram.items())),
                               "highest_velocity_notes": histogram[127],
                               "known_trigger_threshold": None})
            if histogram[127]:
                warnings.append({"code": "DISTORTION_RX_MAXIMUM_DYNAMIC_REVIEW", "track": track_index,
                                 "channel": channel + 1, "notes_at_127": histogram[127],
                                 "policy": "REPORT_ONLY_USER_REPORTED_RISK_NOT_A_PROVEN_TRIGGER_THRESHOLD"})
        for channel, value in sustain.items():
            if value >= 64:
                warnings.append({"code": "SUSTAIN_LEFT_ON", "track": track_index,
                                 "channel": channel + 1, "value": value, "policy": "REPORT_ONLY_NO_END_EVENT_INSERTION"})
        audit_result = audit_track(events, track_index)
        for issue in audit_result["issues"]:
            if issue["code"] in {"OVERLAPPING_NOTES", "ORPHAN_NOTE_OFF", "HANGING_NOTES"}:
                warnings.append({"track": track_index, **issue, "policy": "REPORT_ONLY_NO_PITCH_TIMING_REPAIR"})
    skipped = Counter(p["status"] for p in velocity.get("profiles", []) if p["status"] != "ADAPTIVE")
    return {"warnings": warnings, "warning_count": len(warnings), "distortion_rx": distortion,
            "preserved_velocity_profile_reasons": dict(skipped),
            "policy": "PRESERVE_PERFORMANCE_AND_REPORT_UNRESOLVED_RISKS"}


def optimize(
    source: Path, destination: Path, velocity_strength: int = 0,
    include_drums_velocity: bool = False, prefer_rx_dnc: bool = False,
    rx_kit_name: str | None = None, registry_path: Path | None = None,
    articulation_engine: bool = False, articulation_intensity: int = 35,
    cross_delay_engine: bool = False, cross_delay_amount: int = 35,
    instrument_engine: bool = False, instrument_intensity: int = 35,
) -> dict[str, Any]:
    if source.resolve() == destination.resolve() or destination.exists():
        raise ValueError("Odaberi novi izlazni naziv. Postojeći fajlovi se ne prepisuju.")
    parsed = parse_smf(source)
    original_tracks = parsed["tracks"]
    sound_tracks, sound_changes, special_channels, sound_summary = apply_special_sound_preferences(
        original_tracks, prefer_rx_dnc, rx_kit_name, registry_path
    )
    articulation_tracks, articulation_changes, articulation_summary = apply_articulation_engine(
        sound_tracks, sound_changes, articulation_engine, parsed["division"], articulation_intensity
    )
    velocity_tracks, velocity_changes, velocity_summary = optimize_velocities(
        articulation_tracks, velocity_strength, include_drums_velocity, special_channels
    )
    instrument_tracks, instrument_changes, instrument_summary = apply_instrument_intelligence(
        velocity_tracks, instrument_engine, instrument_intensity, special_channels
    )
    optimized_tracks = []
    changes = []
    blocked = blocked_channels_for(original_tracks)
    for index, events in enumerate(instrument_tracks):
        optimized, track_changes = optimize_track(events, blocked)
        optimized_tracks.append(optimized)
        changes.extend(dict(change, track=index) for change in track_changes)
    optimized_tracks, cross_delay_changes, cross_delay_summary = add_cross_delay_echo_track(
        optimized_tracks, parsed["format"], parsed["division"], cross_delay_engine,
        cross_delay_amount, special_channels,
    )
    changes.extend(sound_changes)
    changes.extend(articulation_changes)
    changes.extend(velocity_changes)
    changes.extend(instrument_changes)
    changes.extend(cross_delay_changes)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="pa800-verify-", dir=destination.parent) as temporary:
        candidate = Path(temporary) / "candidate.mid"
        write_smf(candidate, parsed["format"], parsed["division"], optimized_tracks)
        verified = parse_smf(candidate)
        if verified["tracks"] != optimized_tracks:
            raise ValueError("event-by-event round trip verification failed")
        output_bytes = candidate.read_bytes()
    before_notes = sum(
        1 for track in original_tracks for event in track
        if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0
    )
    after_notes = sum(
        1 for track in verified["tracks"] for event in track
        if event.kind == "channel" and event.status & 0xF0 == 0x90 and event.data[1] > 0
    )
    before_sysex = sum(event.kind == "sysex" for track in original_tracks for event in track)
    after_sysex = sum(event.kind == "sysex" for track in verified["tracks"] for event in track)
    source_note_structure_preserved = counter_is_subset(
        note_structure_counter(original_tracks), note_structure_counter(verified["tracks"])
    )
    echo_added = cross_delay_summary["status"] == "ADDED"
    verification = {
        "reparse_ok": True,
        "notes_before": before_notes, "notes_after": after_notes,
        "sysex_before": before_sysex, "sysex_after": after_sysex,
        "notes_preserved": source_note_structure_preserved,
        "source_note_structure_preserved": source_note_structure_preserved,
        "note_count_unchanged": before_notes == after_notes,
        "expected_echo_note_ons": len(cross_delay_changes),
        "echo_note_count_verified": after_notes == before_notes + len(cross_delay_changes),
        "sysex_preserved": before_sysex == after_sysex,
        "critical_performance_controls_preserved": counter_is_subset(
            critical_performance_counter(original_tracks), critical_performance_counter(verified["tracks"])
        ),
    }
    for category in ("notes", "note-structure", "meta", "sysex", "protected-channel", "nonrouting-channel"):
        before_hash = fingerprint_events(original_tracks, category)
        after_hash = fingerprint_events(verified["tracks"], category)
        verification[f"{category}_fingerprint_before"] = before_hash
        verification[f"{category}_fingerprint_after"] = after_hash
        verification[f"{category}_fingerprint_preserved"] = before_hash == after_hash
    required = ["notes_preserved", "sysex_preserved", "sysex_fingerprint_preserved", "critical_performance_controls_preserved"]
    if echo_added:
        required.append("echo_note_count_verified")
    else:
        required.extend((
            "note-structure_fingerprint_preserved", "meta_fingerprint_preserved",
            "nonrouting-channel_fingerprint_preserved",
        ))
        if not sound_changes:
            required.append("protected-channel_fingerprint_preserved")
        if velocity_strength == 0 and not articulation_changes:
            required.append("notes_fingerprint_preserved")
    if not all(verification[key] for key in required):
        raise ValueError("optimization verification failed; no output saved")
    with destination.open("xb") as handle:
        handle.write(output_bytes)
    return {
        "optimizer_version": VERSION,
        "source": str(source.resolve()), "destination": str(destination.resolve()),
        "mode": "CONSERVATIVE", "removed_events": sum(
            x["code"] == "REMOVE_REDUNDANT_CC" for x in changes
        ),
        "total_changes": len(changes),
        "changes": changes, "verification": verification,
        "velocity": velocity_summary,
        "midi_quality": midi_quality_report(original_tracks, velocity_summary),
        "factory_evidence": pa800_factory_evidence(),
        "rx_coverage": audit_rx_tracks(articulation_tracks),
        "special_sounds": sound_summary,
        "special_sound_changes": len(sound_changes),
        "articulation_engine": articulation_summary,
        "articulation_velocity_changes": len(articulation_changes),
        "cross_delay_engine": cross_delay_summary,
        "cross_delay_note_events": len(cross_delay_changes),
        "instrument_engine": instrument_summary,
        "instrument_mix_changes": len(instrument_changes),
        "removed_cc_events": sum(x["code"] == "REMOVE_REDUNDANT_CC" for x in changes),
        "changed_velocity_events": len(velocity_changes),
        "cc_cleanup_blocked_channels": [x + 1 for x in sorted(blocked)],
        "input_bytes": source.stat().st_size, "output_bytes": len(output_bytes),
        "audit": audit(destination),
    }


def audit_track(events: list[Event], index: int) -> dict[str, Any]:
    active: dict[tuple[int, int], list[int]] = defaultdict(list)
    channels = Counter()
    families = Counter()
    controllers = Counter()
    duplicate_cc = overlaps = orphan_off = 0
    last_cc: dict[tuple[int, int], int] = {}
    note_velocities = []
    max_tick = 0
    for event in events:
        max_tick = max(max_tick, event.tick)
        if event.kind != "channel":
            families[event.kind] += 1
            continue
        channel = event.status & 0x0F
        family = event.status & 0xF0
        channels[str(channel + 1)] += 1
        families[f"{family:02x}"] += 1
        if family == 0x90 and event.data[1] > 0:
            key = (channel, event.data[0])
            if active[key]:
                overlaps += 1
            active[key].append(event.tick)
            note_velocities.append(event.data[1])
        elif family == 0x80 or (family == 0x90 and event.data[1] == 0):
            key = (channel, event.data[0])
            if active[key]:
                active[key].pop(0)
            else:
                orphan_off += 1
        elif family == 0xB0:
            cc, value = event.data
            controllers[str(cc)] += 1
            key = (channel, cc)
            if last_cc.get(key) == value:
                duplicate_cc += 1
            last_cc[key] = value
    hanging = sum(len(values) for values in active.values())
    issues = []
    if overlaps:
        issues.append({"code": "OVERLAPPING_NOTES", "count": overlaps, "severity": "warning"})
    if orphan_off:
        issues.append({"code": "ORPHAN_NOTE_OFF", "count": orphan_off, "severity": "warning"})
    if hanging:
        issues.append({"code": "HANGING_NOTES", "count": hanging, "severity": "error"})
    if duplicate_cc:
        issues.append({"code": "DUPLICATE_CC", "count": duplicate_cc, "severity": "info"})
    return {
        "track": index, "events": len(events), "end_tick": max_tick,
        "channels": dict(channels), "event_families": dict(families),
        "controllers": dict(controllers), "notes": len(note_velocities),
        "velocity_min": min(note_velocities) if note_velocities else None,
        "velocity_max": max(note_velocities) if note_velocities else None,
        "velocity_average": round(sum(note_velocities) / len(note_velocities), 2) if note_velocities else None,
        "issues": issues,
    }


def song_profile(tracks: list[list[Event]], division: int) -> dict[str, Any]:
    channel_rows: dict[int, dict[str, Any]] = {
        channel: {
            "channel": channel + 1, "role_hint": "Drums/Percussion" if channel == 9 else "Melodic",
            "notes": 0, "note_min": None, "note_max": None, "programs": set(),
            "bank_msb": set(), "bank_lsb": set(), "pitch_bend_events": 0,
        }
        for channel in range(16)
    }
    tempo: list[tuple[int, int, int, int]] = []
    signatures: list[dict[str, int]] = []
    text_meta = Counter()
    sysex_manufacturers = Counter()
    timeline: list[tuple[int, int, int, int]] = []
    end_tick = 0
    for track_index, events in enumerate(tracks):
        for order, event in enumerate(events):
            end_tick = max(end_tick, event.tick)
            if event.kind == "meta-51" and len(event.data) == 3:
                tempo.append((event.tick, track_index, order, int.from_bytes(event.data, "big")))
            elif event.kind == "meta-58" and len(event.data) >= 2:
                signatures.append({
                    "tick": event.tick, "numerator": event.data[0],
                    "denominator": 1 << event.data[1],
                })
            elif event.kind.startswith("meta-") and event.kind[5:] in {"01", "02", "03", "04", "05", "06", "07"}:
                text_meta[event.kind] += 1
            elif event.kind == "sysex" and event.data:
                manufacturer = event.data[0]
                sysex_manufacturers[f"0x{manufacturer:02X}"] += 1
            if event.kind != "channel":
                continue
            family = event.status & 0xF0
            channel = event.status & 0x0F
            row = channel_rows[channel]
            if family == 0x90 and event.data[1] > 0:
                note = event.data[0]
                row["notes"] += 1
                row["note_min"] = note if row["note_min"] is None else min(row["note_min"], note)
                row["note_max"] = note if row["note_max"] is None else max(row["note_max"], note)
                timeline.append((event.tick, 1, track_index, order))
            elif family == 0x80 or (family == 0x90 and event.data[1] == 0):
                timeline.append((event.tick, -1, track_index, order))
            elif family == 0xC0:
                row["programs"].add(event.data[0])
            elif family == 0xE0:
                row["pitch_bend_events"] += 1
            elif family == 0xB0:
                if event.data[0] == 0:
                    row["bank_msb"].add(event.data[1])
                elif event.data[0] == 32:
                    row["bank_lsb"].add(event.data[1])

    active = peak = 0
    # At equal ticks, Note Off is processed before Note On to avoid false peaks.
    for _, direction, _, _ in sorted(timeline, key=lambda item: (item[0], item[1], item[2], item[3])):
        active = max(0, active + direction)
        peak = max(peak, active)

    duration_seconds = None
    if not division & 0x8000:
        tempo_map = sorted(tempo)
        if not tempo_map or tempo_map[0][0] != 0:
            tempo_map.insert(0, (0, -1, -1, 500_000))
        seconds = 0.0
        current_tick = 0
        current_tempo = tempo_map[0][3]
        for tick, _, _, value in tempo_map[1:]:
            if tick > end_tick:
                break
            seconds += (tick - current_tick) * current_tempo / division / 1_000_000
            current_tick, current_tempo = tick, value
        seconds += (end_tick - current_tick) * current_tempo / division / 1_000_000
        duration_seconds = round(seconds, 3)

    channels = []
    for row in channel_rows.values():
        if not (row["notes"] or row["programs"] or row["bank_msb"] or row["bank_lsb"] or row["pitch_bend_events"]):
            continue
        cooked = dict(row)
        for key in ("programs", "bank_msb", "bank_lsb"):
            cooked[key] = sorted(cooked[key])
        channels.append(cooked)
    return {
        "end_tick": end_tick,
        "duration_seconds": duration_seconds,
        "tempo_events": [{"tick": tick, "track": track_index,
                          "microseconds_per_quarter": value,
                          "bpm": round(60_000_000 / value, 3)}
                         for tick, track_index, _, value in sorted(tempo)],
        "time_signatures": signatures,
        "peak_polyphony": peak,
        "text_meta_counts": dict(text_meta),
        "sysex_manufacturers": dict(sysex_manufacturers),
        "korg_sysex_events": sysex_manufacturers.get("0x42", 0),
        "channels": channels,
    }


def audit(path: Path) -> dict[str, Any]:
    parsed = parse_smf(path)
    source_tracks = parsed.pop("tracks")
    blocked = blocked_channels_for(source_tracks)
    removable = sum(len(optimize_track(events, blocked)[1]) for events in source_tracks)
    profile = song_profile(source_tracks, parsed["division"])
    _, _, existing_special_channels, _ = apply_special_sound_preferences(source_tracks)
    _, _, cross_delay_analysis = add_cross_delay_echo_track(
        source_tracks, parsed["format"], parsed["division"], True, 35,
        existing_special_channels,
    )
    _, _, instrument_analysis = apply_instrument_intelligence(
        source_tracks, False, 35, existing_special_channels
    )
    tracks = [audit_track(events, i) for i, events in enumerate(source_tracks)]
    issues = [dict(item, track=row["track"]) for row in tracks for item in row["issues"]]
    return {
        **parsed, "optimizer_version": VERSION, "tracks": tracks, "issues": issues,
        "eligible_redundant_cc": removable,
        "cc_cleanup_blocked_channels": [x + 1 for x in sorted(blocked)],
        "song_profile": profile,
        "factory_evidence": pa800_factory_evidence(),
        "special_sound_usage": special_sound_usage(source_tracks),
        "cross_delay_analysis": cross_delay_analysis,
        "instrument_analysis": instrument_analysis,
        "pa800_safe_to_transform": not any(x["severity"] == "error" for x in issues),
        "mode": "READ_ONLY_AUDIT",
        "native_style_warning": "OC20 native package decoding is proven read-only; native STY/PCG writing remains intentionally disabled.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("midi", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--optimize", action="store_true", help="write a conservatively optimized MIDI")
    parser.add_argument("--velocity-strength", type=int, default=0, metavar="0-100")
    parser.add_argument("--include-drums-velocity", action="store_true")
    parser.add_argument("--prefer-rx-dnc", action="store_true",
                        help="prefer verified RX/DNC sounds with the same GM program")
    parser.add_argument("--rx-kit", help="select an exact Factory-corpus RX drum kit by name")
    parser.add_argument("--special-registry", type=Path)
    parser.add_argument("--articulation-engine", action="store_true",
                        help="normalize newly mapped hardware-profile RX notes into proven working zones")
    parser.add_argument("--articulation-intensity", type=int, default=35, metavar="0-100")
    parser.add_argument("--cross-delay-engine", action="store_true",
                        help="add a tempo-synced stereo MIDI echo track when none is named")
    parser.add_argument("--cross-delay-amount", type=int, default=35, metavar="0-100")
    parser.add_argument("--instrument-engine", action="store_true",
                        help="classify channels and fill only missing mix controllers")
    parser.add_argument("--instrument-intensity", type=int, default=35, metavar="0-100")
    args = parser.parse_args()
    if args.optimize:
        midi_output = args.output or args.midi.with_name(args.midi.stem + "_PA800_OPTIMIZED.MID")
        report_output = midi_output.with_suffix(".optimization.json")
        if report_output.exists():
            raise SystemExit(f"Report already exists: {report_output}")
        result = optimize(
            args.midi, midi_output, args.velocity_strength, args.include_drums_velocity,
            args.prefer_rx_dnc, args.rx_kit, args.special_registry, args.articulation_engine,
            args.articulation_intensity, args.cross_delay_engine, args.cross_delay_amount,
            args.instrument_engine, args.instrument_intensity,
        )
        report_output.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(json.dumps({"destination": result["destination"], "removed_events": result["removed_events"],
                          "changed_velocity_events": result["changed_velocity_events"],
                          "special_sound_changes": result["special_sound_changes"],
                          "articulation_velocity_changes": result["articulation_velocity_changes"],
                          "cross_delay_note_events": result["cross_delay_note_events"],
                          "instrument_mix_changes": result["instrument_mix_changes"],
                          "verification": result["verification"]}, indent=2))
        print(f"Report: {report_output.resolve()}")
        return 0
    result = audit(args.midi)
    output = args.output or args.midi.with_suffix(".pa800-audit.json")
    if output.exists():
        raise SystemExit(f"Report already exists: {output}")
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in (
        "path", "format", "parsed_tracks", "division", "issues", "pa800_safe_to_transform"
    )}, indent=2))
    print(f"Report: {output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
