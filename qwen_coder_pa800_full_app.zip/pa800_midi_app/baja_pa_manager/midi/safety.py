"""MIDI sigurnosni sloj — hard rule iz EvidenceRegistry:

"Existing note timing/pitch — no quantize, snap, humanize or pitch mutation."

Direktno veže dva nezavisna mehanizma na isti pravilnik:
  * ``style.midi_bridge`` (mido)          → NoteFingerprint poređenja
  * ``midi.optimizer`` fingerprinti       → SMF event-level dokazi
"""
from __future__ import annotations

from pathlib import Path

from ..core.evidence import EvidenceRegistry
from ..core.models import WritePolicy


class MidiSafetyError(ValueError):
    pass


def policy() -> WritePolicy:
    rules = EvidenceRegistry.default().by_module("MidiSafety")
    return rules[0].policy if rules else WritePolicy.IMPLEMENT


def assert_smf_note_structure_preserved(before_tracks, after_tracks) -> None:
    """Optimizer-level: struktura (tick/kanal/nota/on-off) mora biti očuvana.

    Cross-delay engine jedini smije DODATI note-on događaje (echo track),
    zato provjeravamo 'subset' umjesto jednakosti — isti kriterij koji
    koristi sam optimizer verification pipeline.
    """
    from .optimizer import note_structure_counter, counter_is_subset
    if not counter_is_subset(note_structure_counter(before_tracks), note_structure_counter(after_tracks)):
        raise MidiSafetyError("Existing MIDI note timing/order/pitch changed")


def assert_mido_note_structure_unchanged(before_midi, after_midi) -> None:
    from ..style.midi_bridge import assert_note_structure_unchanged
    assert_note_structure_unchanged(before_midi, after_midi)


def guard_optimize(source: Path, destination: Path, **options):
    """Pozovi konzervativni optimizer i dodatno potvrdi hard rule prije upisa."""
    from .optimizer import optimize, parse_smf
    report = optimize(Path(source), Path(destination), **options)
    before = parse_smf(Path(source))["tracks"]
    after = parse_smf(Path(destination))["tracks"]
    assert_smf_note_structure_preserved(before, after)
    return report
