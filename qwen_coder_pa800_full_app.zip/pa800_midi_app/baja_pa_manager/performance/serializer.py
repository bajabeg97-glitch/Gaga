from __future__ import annotations

from .models import PerformanceBank, PerformanceSlot


class PerformanceSerializer:
    RELEASE2_SLOT_SIZE = 261
    RELEASE3_SLOT_SIZE = 357

    def parse(self, data: bytes, name: str = "") -> PerformanceBank:
        # Native geometry known; exact leaf semantics remain partly open.
        return PerformanceBank(name=name, raw=bytes(data))

    def build(self, bank: PerformanceBank) -> bytes:
        if bank.raw and not bank.slots:
            return bank.raw
        raise ValueError("Safe PRF writer requires fixture-backed slot serializer")
