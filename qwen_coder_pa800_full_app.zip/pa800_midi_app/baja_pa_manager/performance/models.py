from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class PerformanceSlot:
    slot_id: int
    payload: bytes
    release: int = 2
    extension: bytes = b""


@dataclass(slots=True)
class PerformanceBank:
    name: str
    slots: list[PerformanceSlot] = field(default_factory=list)
    raw: bytes = b""
