from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(slots=True)
class DependencyNode:
    key: str
    kind: str
    metadata: dict = field(default_factory=dict)


class DependencyGraph:
    def __init__(self):
        self.nodes: dict[str, DependencyNode] = {}
        self.edges: dict[str, set[str]] = {}

    def add_node(self, node: DependencyNode) -> None:
        self.nodes[node.key] = node
        self.edges.setdefault(node.key, set())

    def link(self, parent: str, child: str) -> None:
        if parent not in self.nodes or child not in self.nodes:
            raise KeyError("Both nodes must exist before linking")
        self.edges[parent].add(child)

    def walk(self, start: str) -> list[str]:
        seen: set[str] = set()
        stack = [start]
        out: list[str] = []
        while stack:
            key = stack.pop()
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
            stack.extend(sorted(self.edges.get(key, ()), reverse=True))
        return out

    def orphans(self) -> list[str]:
        referenced = {c for children in self.edges.values() for c in children}
        return [k for k in self.nodes if k not in referenced]
