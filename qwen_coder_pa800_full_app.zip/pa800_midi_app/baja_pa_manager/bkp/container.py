from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class BKPArchive:
    root: Path
    raw: bytes


class BKPReader:
    def load(self, path: Path) -> BKPArchive:
        return BKPArchive(path, path.read_bytes())


class BKPWriter:
    def save(self, archive: BKPArchive, path: Path) -> None:
        # Safe default: exact preservation only.
        path.write_bytes(archive.raw)
