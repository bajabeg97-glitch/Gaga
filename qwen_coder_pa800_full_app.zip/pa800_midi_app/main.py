#!/usr/bin/env python3
"""Baja Music — Korg Pa800 MIDI Studio (CLI).

Sve je direktno vezano na paket ``baja_pa_manager``:

    python main.py self-test
    python main.py gui
    python main.py audit pjesma.mid
    python main.py optimize pjesma.mid --prefer-rx-dnc --articulation-engine ...
    python main.py pipeline pjesma.mid --out out.mid   (KONAČNA LOGIKA — 19 koraka)
    python main.py pipeline --build-profiles corpus_dir/ [--profiles-out x.json]
    python main.py sty BANK01_DECOMP.STY
    python main.py pcg ROM.PCG [--filter piano]
    python main.py registry [--rx] [--kits]
    python main.py ports
    python main.py pc 121 10 0 --channel 1 [--port "Pa800"]
    python main.py play pjesma.mid [--port "Pa800"]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from baja_pa_manager.core.models import TargetModel
from baja_pa_manager.core.evidence import EvidenceRegistry
from baja_pa_manager.core.validator import Validator


def cmd_self_test(_args) -> int:
    report = Validator(EvidenceRegistry.default()).smoke_report()
    print(report.format())
    return 0 if report.ok else 1


def cmd_gui(_args) -> int:
    from baja_pa_manager.gui import run
    run()
    return 0


def cmd_audit(args) -> int:
    from baja_pa_manager.midi import audit
    result = audit(Path(args.midi))
    brief_keys = ("path", "format", "parsed_tracks", "division", "issues",
                  "pa800_safe_to_transform")
    print(json.dumps({k: result[k] for k in brief_keys}, indent=2, ensure_ascii=False))
    profile = result["song_profile"]
    print(json.dumps({
        "duration_seconds": profile["duration_seconds"],
        "peak_polyphony": profile["peak_polyphony"],
        "tempo_bpm": [f"{t['bpm']}" for t in profile["tempo_events"][:4]],
        "korg_sysex_events": profile["korg_sysex_events"],
        "special_sounds": result["special_sound_usage"]["unique_names"],
    }, indent=2, ensure_ascii=False))
    if args.output:
        Path(args.output).write_text(json.dumps(result, indent=2, ensure_ascii=False),
                                     encoding="utf-8")
        print(f"Report: {args.output}")
    return 0 if result["pa800_safe_to_transform"] else 1


def cmd_optimize(args) -> int:
    from baja_pa_manager.midi.safety import guard_optimize
    source = Path(args.midi)
    destination = Path(args.output or source.with_name(source.stem + "_PA800_OPTIMIZED.MID"))
    report = guard_optimize(
        source, destination,
        velocity_strength=args.velocity_strength,
        include_drums_velocity=args.include_drums_velocity,
        prefer_rx_dnc=args.prefer_rx_dnc,
        rx_kit_name=args.rx_kit,
        articulation_engine=args.articulation_engine,
        articulation_intensity=args.articulation_intensity,
        cross_delay_engine=args.cross_delay_engine,
        cross_delay_amount=args.cross_delay_amount,
        instrument_engine=args.instrument_engine,
        instrument_intensity=args.instrument_intensity,
    )
    report_path = destination.with_suffix(".optimization.json")
    if not report_path.exists():
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    brief = {
        "destination": report["destination"],
        "report": str(report_path),
        "total_changes": report["total_changes"],
        "removed_CC": report["removed_cc_events"],
        "velocity_changes": report["changed_velocity_events"],
        "special_sound_changes": report["special_sound_changes"],
        "articulation_changes": report["articulation_velocity_changes"],
        "cross_delay_notes": report["cross_delay_note_events"],
        "instrument_mix_changes": report["instrument_mix_changes"],
        "verification_ok": all(
            report["verification"][k] for k in
            ("notes_preserved", "sysex_preserved", "critical_performance_controls_preserved")
        ),
    }
    print(json.dumps(brief, indent=2, ensure_ascii=False))
    return 0


def cmd_sty(args) -> int:
    from baja_pa_manager.style.serializer import StyleInspector
    probe = StyleInspector().probe(Path(args.sty))
    print(json.dumps({
        "file": probe.path,
        "size": probe.size,
        "resources": {k: v for k, v in probe.resources.items() if k != "records"},
        "style_names": probe.style_names[:24],
        "style_name_count": len(probe.style_names),
        "sections": [
            {"idx": s["idx"], "name": s["name"], "size": s["size"],
             "program_changes": s["program_changes"], "note_events": s["note_events"]}
            for s in probe.sections
        ],
        "total_program_changes": probe.total_program_changes,
        "total_note_events": probe.total_note_events,
    }, indent=2, ensure_ascii=False))
    if args.resources:
        for record in probe.resources.get("records", []):
            print(f"@{record['offset']:#08x} [{record['index']:02d}] "
                  f"{record['type_name']:18s} flags={record['flags']:#04x} "
                  f"size={record['payload_size']:,}"
                  + ("  OC20" if record["compressed"] else ""))
    return 0


def cmd_pcg(args) -> int:
    from baja_pa_manager.sound.pcg import NativePCGReader
    pcg = NativePCGReader().read(Path(args.pcg))
    print(f"{pcg.path}: {len(pcg.programs)} programa, {len(pcg.named)} imenovanih, "
          f"KORF zapisa: {len(pcg.catalog_names)}")
    needle = (args.filter or "").casefold()
    count = 0
    for i, program in enumerate(pcg.programs):
        name = program.name or "(bez imena)"
        if needle and needle not in name.casefold():
            continue
        print(f"[{i:4d}] {name:24s} kat={program.category!s:>3} size={program.size or 0:5d}")
        count += 1
        if count >= args.limit:
            break
    return 0


def cmd_pipeline(args) -> int:
    from baja_pa_manager.midi.factory_pipeline import FactoryPipeline, DEFAULT_TARGETS
    from baja_pa_manager.midi.factory_profiles import write_profiles, extract_corpus

    if args.build_profiles:
        print(json.dumps(write_profiles(
            Path(args.build_profiles),
            Path(args.profiles_out or "baja_pa_manager/data/PA800_FACTORY_PERFORMANCE_PROFILES_v1.json")),
            indent=1, ensure_ascii=False))
        return 0

    targets = dict(DEFAULT_TARGETS)
    if args.target_bass:
        b = [int(x) for x in args.target_bass.split(".")]
        targets["BASS"] = (b[0], b[1], b[2])
    if args.target_guitar:
        g = [int(x) for x in args.target_guitar.split(".")]
        targets["GUITAR"] = (g[0], g[1], g[2])

    pipe = FactoryPipeline(
        profiles_path=Path(args.profiles) if args.profiles else None,
        targets=targets)
    src = Path(args.midi)
    dst = Path(args.out) if args.out else \
        src.with_name(src.stem + "_FACTORY_KONACNA.mid")
    report = pipe.run(src, dst)
    summary = {
        "issues": report["issues"],
        "ok": report["steps"][17]["ok"],
        "folds": report["steps"][11]["folds"],
        "velocity_applied": report["steps"][12]["velocity_applied"],
        "scope_excluded": report["steps"][12]["velocity_preserved_scope_excluded"],
        "engine_map": report["steps"][15]["engine_map"],
        "reset": report["steps"][9]["counts"],
    }
    print(json.dumps(summary, indent=1, ensure_ascii=False))
    print(f"Izlaz: {dst}")
    print(f"Report: {dst}.factory_report.json")
    return 0 if report["steps"][17]["ok"] else 1


def cmd_registry(args) -> int:

    from baja_pa_manager.midi import load_special_registry, available_rx_kits
    registry = load_special_registry()
    if not registry["available"]:
        print("RX/DNC registry nije pronađen.")
        return 1
    if args.kits or not (args.rx or args.dnc):
        print(f"RX kitovi ({len(available_rx_kits())} dokazanih):")
        for name in available_rx_kits():
            print(f"  {name}")
    for group, flag in (("rx_sounds", args.rx), ("dnc_sounds", args.dnc)):
        if not flag:
            continue
        print(f"{group} ({len(registry[group])}):")
        for row in registry[group]:
            if all(row.get(k) is not None for k in ("cc00", "cc32", "pc")):
                print(f"  CC0={row['cc00']:3d} CC32={row['cc32']:3d} PC={row['pc']:3d}  {row['name']}")
    return 0


def cmd_ports(_args) -> int:
    from baja_pa_manager.midi.live import list_ports
    print(json.dumps(list_ports(), indent=2, ensure_ascii=False))
    return 0


def cmd_pc(args) -> int:
    from baja_pa_manager.midi.live import Pa800Link, describe_event
    link = Pa800Link(args.port)
    link.open() if args.port else None
    try:
        events = link.select_program(args.cc00, args.cc32, args.pc, args.channel - 1)
        for event in events:
            print("→ " + describe_event(event))
    finally:
        link.close()
    if not args.port:
        print("(dry-run: nije zadan --port, ništa nije poslano na hardware)")
    return 0


def cmd_play(args) -> int:
    from baja_pa_manager.midi.live import Pa800Link
    link = Pa800Link(args.port)
    if args.port:
        link.open()
    else:
        print("(dry-run bez porta — samo simulacija redoslijeda)")
        link._sender = lambda event: print("→ " + event.as_bytes().hex(), flush=True)
    try:
        report = link.play_smf(Path(args.midi))
        print(json.dumps(report, indent=2))
    finally:
        link.close()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pa800-studio", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("self-test", help="validator smoke report")
    p.set_defaults(func=cmd_self_test)

    p = sub.add_parser("gui", help="pokreni Tkinter aplikaciju")
    p.set_defaults(func=cmd_gui)

    p = sub.add_parser("audit", help="read-only MIDI audit")
    p.add_argument("midi")
    p.add_argument("--output", "-o")
    p.set_defaults(func=cmd_audit)

    p = sub.add_parser("optimize", help="konzervativna MIDI optimizacija")
    p.add_argument("midi")
    p.add_argument("--output", "-o")
    p.add_argument("--velocity-strength", type=int, default=0, metavar="0-100")
    p.add_argument("--include-drums-velocity", action="store_true")
    p.add_argument("--prefer-rx-dnc", action="store_true")
    p.add_argument("--rx-kit")
    p.add_argument("--articulation-engine", action="store_true")
    p.add_argument("--articulation-intensity", type=int, default=35, metavar="0-100")
    p.add_argument("--cross-delay-engine", action="store_true")
    p.add_argument("--cross-delay-amount", type=int, default=35, metavar="0-100")
    p.add_argument("--instrument-engine", action="store_true")
    p.add_argument("--instrument-intensity", type=int, default=35, metavar="0-100")
    p.set_defaults(func=cmd_optimize)

    p = sub.add_parser("sty", help="probe STY banke (native parseri)")
    p.add_argument("sty")
    p.add_argument("--resources", action="store_true", help="ispiši kompletnu resursnu mapu")
    p.set_defaults(func=cmd_sty)

    p = sub.add_parser("pcg", help="PCG program katalog")
    p.add_argument("pcg")
    p.add_argument("--filter", "-f")
    p.add_argument("--limit", type=int, default=100)
    p.set_defaults(func=cmd_pcg)

    p = sub.add_parser("pipeline", help="KONAČNA LOGIKA — factory corpus pipeline (19 koraka)")
    p.add_argument("midi", nargs="?", help="ulaz .mid")
    p.add_argument("--out", default=None, help="izlaz .mid (ne smije postojati)")
    p.add_argument("--profiles", default=None, help="custom profiles JSON")
    p.add_argument("--target-bass", default=None, help="npr. 121.10.34")
    p.add_argument("--target-guitar", default=None, help="npr. 121.14.28")
    p.add_argument("--build-profiles", default=None, metavar="CORPUS_DIR",
                   help="sgradi performance profiles JSON iz corpus dir-a")
    p.add_argument("--profiles-out", default=None, help="cilj build-profiles JSON-a")
    p.set_defaults(func=cmd_pipeline)

    p = sub.add_parser("registry", help="RX/DNC dokazani zvukovi")
    p.add_argument("--rx", action="store_true")
    p.add_argument("--dnc", action="store_true")
    p.add_argument("--kits", action="store_true")
    p.set_defaults(func=cmd_registry)

    p = sub.add_parser("ports", help="MIDI portovi")
    p.set_defaults(func=cmd_ports)

    p = sub.add_parser("pc", help="address-first program select na Pa800")
    p.add_argument("cc00", type=int)
    p.add_argument("cc32", type=int)
    p.add_argument("pc", type=int)
    p.add_argument("--channel", type=int, default=1)
    p.add_argument("--port")
    p.set_defaults(func=cmd_pc)

    p = sub.add_parser("play", help="SMF playback na MIDI out")
    p.add_argument("midi")
    p.add_argument("--port")
    p.set_defaults(func=cmd_play)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except (ValueError, FileNotFoundError, KeyError, RuntimeError) as exc:
        print(f"GREŠKA: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
