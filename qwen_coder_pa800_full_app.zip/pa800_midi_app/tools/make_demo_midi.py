#!/usr/bin/env python3
"""Generiši demo MIDI (GM format) za brzu provjeru Pa800 Studija.

Koristi isključivo sam optimizer SMF writer — isti event model koji engine
parsira, pa je round-trip provjeren po definiciji.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from baja_pa_manager.midi.optimizer import Event, write_smf

TPQ = 480


def bar(tick: int) -> int:
    return tick


def make_tracks() -> tuple[int, list[list[Event]]]:
    # Track 0: tempo + meta
    conductor = [
        Event(0, "meta-03", 0xFF, b"Conductor"),
        Event(0, "meta-51", 0xFF, (500_000).to_bytes(3, "big")),  # 120 BPM
        Event(0, "meta-58", 0xFF, bytes((4, 2, 24, 8))),
        Event(TPQ * 16, "meta-2f", 0xFF, b""),
    ]

    # Track 1: GM Clean Guitar (PC 27 → RX kandidat), kanal 0
    guitar = [Event(0, "meta-03", 0xFF, b"Clean Guitar")]
    guitar += [
        Event(0, "channel", 0xB0, bytes((7, 100))),
        Event(0, "channel", 0xB0, bytes((7, 100))),  # redundantan CC (cleanup demo)
        Event(0, "channel", 0xB0, bytes((91, 30))),
    ]
    arpeggio = [40, 52, 56, 59, 64, 59, 56, 52]
    tick = 0
    for step in range(8):
        note = arpeggio[step]
        vel = 60 + (step % 4) * 18
        guitar.append(Event(tick, "channel", 0x90, bytes((note, vel))))
        guitar.append(Event(tick + TPQ // 2 - 40, "channel", 0x80, bytes((note, 0))))
        tick += TPQ // 2
    guitar.append(Event(0, "channel", 0xC0, bytes((27,))))  # PC POSLIJE nota (non-idealno)
    guitar.append(Event(TPQ * 8, "meta-2f", 0xFF, b""))
    # program change ispravno prije nota: ubaci na početak
    pc = Event(0, "channel", 0xC0, bytes((27,)))
    rest = [e for e in guitar if not (e.kind == "channel" and e.status == 0xC0)]
    guitar = rest[:1 + 3] + [pc] + rest[1 + 3:]

    # Track 2: GM Finger Bass (PC 33) + Kick kanal 9
    bass = [Event(0, "meta-03", 0xFF, b"Finger Bass")]
    bass.append(Event(0, "channel", 0xB0, bytes((0, 121))))
    bass.append(Event(0, "channel", 0xB0, bytes((32, 14))))
    bass.append(Event(0, "channel", 0xC2, bytes((33,))))  # kanal 2 = bass
    bass.append(Event(0, "channel", 0xB1, bytes((0, 0))))
    bass.append(Event(0, "channel", 0xB1, bytes((32, 0))))
    bass.append(Event(0, "channel", 0xC1, bytes((33,))))  # kanal 1: finger bass GM
    tick = 0
    for i in range(16):
        note = 28 + (i % 2) * 12
        bass.append(Event(tick, "channel", 0x91, bytes((note, 46 + (i % 3) * 30))))
        bass.append(Event(tick + TPQ // 2 - 60, "channel", 0x81, bytes((note, 0))))
        tick += TPQ // 2
    bass.append(Event(0, "channel", 0xB9, bytes((0, 120))))
    bass.append(Event(0, "channel", 0xB9, bytes((32, 0))))
    bass.append(Event(0, "channel", 0xC9, bytes((1,))))  # Standard kit 2
    tick = 0
    for i in range(16):
        bass.append(Event(tick, "channel", 0x99, bytes((36, 90))))
        bass.append(Event(tick + 120, "channel", 0x89, bytes((36, 0))))
        tick += TPQ // 2
    bass.append(Event(TPQ * 8, "meta-2f", 0xFF, b""))
    tracks = [conductor, guitar, bass]
    for events in tracks:
        events.sort(key=lambda e: e.tick)  # stabilno: unutar ticka zadržava redoslijed
    return TPQ, tracks


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "demo_pa800.mid")
    tpq, tracks = make_tracks()
    write_smf(out, 1, tpq, tracks)
    print(f"Demo MIDI: {out.resolve()} ({out.stat().st_size} B)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
