#!/usr/bin/env python3
"""Generiši minimalni format-konforman demo PCG (KORF + KBEG/KEND + OC32).

Namjena: demonstracija i test fixture za NativePCGReader pa se može vidi-
jeti kompletna Sound Catalog cjelina bez stvarnog ROM.PCG fajla. Ovo NIJE
fabrikovana evidence — sadrži samo ogledna imena programa.
"""
from __future__ import annotations

import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

PROGRAMS = [
    ("Grand Piano RX", 7),
    ("Bright Piano RX", 7),
    ("E.Piano 1 RX", 7),
    ("E.Organ BX3", 8),
    ("Clean Guitar RX1", 9),
    ("Dist. Guitar RX1", 9),
    ("Finger Bass RX", 10),
    ("Picked Bass RX", 10),
    ("Strings Ensemble", 11),
    ("Synth Pad Hope", 12),
    ("Synth Lead Elec", 13),
    ("Accordion 16'", 13),
]


def program_record(name: str, category: int, seed: int) -> bytes:
    encoded = name.encode("ascii") + b"\x00"
    params = bytes(seed & 0xFF for _ in range(48))
    size = 8 + len(encoded) + len(params)  # nakon "OC32": size(2)+flags(2)+cat+05+name+params
    return b"OC32" + struct.pack("<H", size - 4) + struct.pack("<H", 0) + bytes((category, 0x05)) + encoded + params


def build_pcg() -> bytes:
    out = bytearray(b"\x18\x00\x00\x64\x68" + b"BAJA-DEMO-PCG-PADDING")
    while len(out) < 0x17:
        out.append(0)
    korf = b"".join(
        name.encode("ascii").ljust(16, b"\x00") + struct.pack("<IHH", i, 0, cat)
        for i, (name, cat) in enumerate(PROGRAMS)
    )
    out += b"KORF" + struct.pack(">I", len(korf)) + korf
    block_start = len(out)
    for i, (name, cat) in enumerate(PROGRAMS):
        out += program_record(name, cat, i)
    kend_pad = b"\x00" * 32
    # KBEG: zadnji (ovdje jedini) entry pokazuje na glavni OC32 program blok
    out += b"KBEG" + struct.pack(">I", 4) + struct.pack(">I", block_start)
    out += b"KEND" + struct.pack(">I", len(kend_pad)) + kend_pad
    return bytes(out)


def main() -> int:
    out = Path(sys.argv[1] if len(sys.argv) > 1 else "demo.PCG")
    out.write_bytes(build_pcg())
    print(f"Demo PCG: {out.resolve()} ({out.stat().st_size} B, {len(PROGRAMS)} programa)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
