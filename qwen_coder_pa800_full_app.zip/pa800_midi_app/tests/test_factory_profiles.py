"""Testovi za Facory Corpus extractor — prvi izvor istine za range/vel."""
import json
from pathlib import Path

import pytest

from baja_pa_manager.midi.factory_profiles import (
    FORMAT_ID, extract_corpus, family_of, load_profiles, _percentile,
)

CORPUS = Path("/home/user/uploads/factory_corpus/demo_midis")
PROFILES = Path(__file__).resolve().parent.parent / \
    "baja_pa_manager/data/PA800_FACTORY_PERFORMANCE_PROFILES_v1.json"


def _corpus_ok():
    return CORPUS.is_dir() and any(CORPUS.glob("*.MID"))


# ------------------------------------------------------------- family model
class TestFamilyOf:
    def test_drums_cc120(self):
        assert family_of("Pop Std. Kit RX", 120, 4) == "DRUMS"
        assert family_of(None, 120, 0) == "DRUMS"

    def test_bass(self):
        assert family_of("Finger Bass RX", 121, 33) == "BASS"
        assert family_of("Picked Bass RX", 121, 34) == "BASS"
        assert family_of("FunkSlap Bass RX", 121, 36) == "BASS"

    def test_guitar(self):
        assert family_of("Clean Guitar RX1", 121, 28) == "GUITAR"
        assert family_of("Nylon Gtr RX1", 121, 24) == "GUITAR"
        assert family_of("Steel Gtr DNC", 121, 25) == "GUITAR"

    def test_strings_brass_wind_synth(self):
        assert family_of("Chamber Strings", 121, 48) == "STRINGS"
        assert family_of("Fat Brass", 121, 61) == "BRASS"
        assert family_of("Alto Sax", 121, 65) == "WIND"
        assert family_of("Seq. Analog", 121, 81) == "SYNTH"

    def test_piano_organ(self):
        assert family_of("Grand Piano RX", 121, 0) == "PIANO"
        assert family_of("Jimmy Organ DNC", 121, 18) == "ORGAN"

    def test_fallback_gm_bands(self):
        assert family_of(None, 121, 5) in ("PIANO", "KEYS")
        assert family_of(None, 121, 33) == "BASS"
        assert family_of(None, 121, 28) == "GUITAR"


class TestPercentile:
    def test_basic(self):
        assert _percentile([1, 2, 3, 4, 5], 50) == 3
        assert _percentile([1, 2, 3, 4, 5], 0) == 1
        assert _percentile([1, 2, 3, 4, 5], 100) == 5

    def test_interp(self):
        assert _percentile([10, 20], 50) == 15
        assert _percentile([10, 20], 25) == 12 or _percentile([10, 20], 25) == 13

    def test_single(self):
        assert _percentile([44], 50) == 44


# ------------------------------------------------------------- corpus extract
@pytest.mark.skipif(not _corpus_ok(), reason="corpus dir odsutan")
class TestCorpusExtraction:
    def test_extract_counts(self):
        r = extract_corpus(CORPUS)
        s = r["summary"]
        assert s["corpus_files"] == 54
        assert r["format"] == FORMAT_ID
        assert s["total_notes"] > 100000
        assert s["unique_bindings"] > 300
        assert s["unique_drum_keys"] > 500

    def test_manifest_verify_all_match(self):
        r = extract_corpus(CORPUS)
        ver = {f["manifest_verify"] for f in r["files"].values() if f["manifest_verify"]}
        assert ver == {"MATCH"}

    def test_deterministic_hashes(self):
        a = extract_corpus(CORPUS)
        b = extract_corpus(CORPUS)
        for name in a["files"]:
            assert a["files"][name]["sha256"] == b["files"][name]["sha256"]
        assert [p["vel_hist"] for p in a["by_binding"].values()] == \
               [p["vel_hist"] for p in b["by_binding"].values()]

    def test_known_bindings_have_profiles(self):
        r = extract_corpus(CORPUS)
        for key in ("121.13.33", "121.14.28", "121.15.25"):
            p = r["by_binding"].get(key)
            assert p is not None, key
            assert p["notes"] > 100, (key, p["notes"])
            assert p["key_lo"] <= p["key_hi"]
            assert 1 <= p["vel_min"] <= p["vel_max"] <= 127

    def test_finger_bass_rx_range_i_kriva(self):
        r = extract_corpus(CORPUS)
        p = r["by_binding"]["121.13.33"]
        assert p["family"] == "BASS"
        # stvarni svirani opseg iz corpus-a — ne izmišlja se
        assert p["key_lo"] >= 20 and p["key_hi"] <= 80
        assert p["percentiles"]["50"] > 40  # ne radi se plošno sve isto

    def test_drum_keys_per_kit(self):
        r = extract_corpus(CORPUS)
        kicks = [k for k in r["by_drum_key"] if k.rsplit(":", 1)[1] in ("35", "36")]
        assert len(kicks) > 3, kicks[:5]
        for k in kicks[:5]:
            p = r["by_drum_key"][k]
            assert p["notes"] > 0
            assert 1 <= p["vel_min"]
        # format: "cc00.cc32.pc:midi_key" — kit dio mora biti cijeli
        sample = kicks[0]
        kit_part = sample.split(":")[0]
        assert len(kit_part.split(".")) == 3

    def test_family_aggregate(self):
        r = extract_corpus(CORPUS)
        bass = r["by_family"].get("BASS")
        assert bass is not None and bass["notes"] > 1000
        gtr = r["by_family"].get("GUITAR")
        assert gtr is not None and gtr["notes"] > 5000


# ------------------------------------------------------------- load gate
class TestLoadProfiles:
    def test_format_gate(self):
        d = load_profiles(PROFILES)
        assert d["format"] == FORMAT_ID

    def test_format_gate_rejects(self, tmp_path):
        bad = tmp_path / "bad.json"
        bad.write_text(json.dumps({"format": "nije-ova"}))
        with pytest.raises(ValueError, match="format"):
            load_profiles(bad)

    def test_profiles_vel_hist_complete(self):
        d = load_profiles(PROFILES)
        for key, p in d["by_binding"].items():
            total = sum(p["vel_hist"].values())
            assert total == p["notes"], key
