from baja_pa_manager.core.evidence import EvidenceRegistry
from baja_pa_manager.core.validator import Validator


def test_registry():
    r = EvidenceRegistry.default()
    assert "SetManager" in r.modules()
    assert "SoundResolver" in r.modules()


def test_smoke():
    report = Validator(EvidenceRegistry.default()).smoke_report()
    assert report.ok
