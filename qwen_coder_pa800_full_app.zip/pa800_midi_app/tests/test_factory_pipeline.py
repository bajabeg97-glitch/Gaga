"""Testovi 19-step KONAČNE LOGIKE pipeline-a.

Tvrdna pravila testirana ovdje:
- original se nikad ne pregazi (no-overwrite);
- velocity se ne kopira li nego uzima iz Factory kriva;
- key range je od stvarnog instrumenta (corpus observed), fold je samo oktava,
  bez remap-a cijelog tracka;
- NRPN se nikad ne generira; postojeći CC/PB/AT se resetuje;
- target sound je engine-trigger iz evidencije (RX sanaje dokazima ima prednost);
- VALIDATE: tick redoslijed = identičan, velocity svi 1..127, samo oktavski
  pitch foldovi.
"""
import json
from pathlib import Path

import pytest

from baja_pa_manager.midi.factory_pipeline import (
    FactoryPipeline, DEFAULT_TARGETS, STEP_NAMES,
    detect_role, _inverse_cdf, _curve_lookup, _working_zone, _load_json,
    PROFILES_FILE,
)
from baja_pa_manager.midi.optimizer import Event, parse_smf, write_smf


DATA = Path(__file__).resolve().parent.parent / "baja_pa_manager/data"


# ------------------------------------------------------------- sitne pomoćne
def make_midi(tmp_path, tracks, division=480, name="in.mid"):
    p = tmp_path / name
    sorted_tracks = [sorted(tr, key=lambda e: e.tick) for tr in tracks]
    write_smf(p, 1, division, sorted_tracks)
    return p


def note_on(tick, ch, note, vel):
    return Event(tick, "channel", 0x90 | ch, bytes([note, vel]))


def note_off(tick, ch, note):
    return Event(tick, "channel", 0x80 | ch, bytes([note, 0]))


def prog(tick, ch, cc00, cc32, pc):
    return [
        Event(tick, "channel", 0xB0 | ch, bytes([0, cc00])),
        Event(tick, "channel", 0xB0 | ch, bytes([32, cc32])),
        Event(tick, "channel", 0xC0 | ch, bytes([pc])),
    ]


def cc(tick, ch, num, val):
    return Event(tick, "channel", 0xB0 | ch, bytes([num, val]))


def pb(tick, ch, lsb, msb):
    return Event(tick, "channel", 0xE0 | ch, bytes([lsb, msb]))


def at(tick, ch, press):
    return Event(tick, "channel", 0xD0 | ch, bytes([press]))


class TestHelpers:
    def test_role_detect(self):
        assert detect_role(9, None) == "DRUM"
        assert detect_role(0, 34) == "BASS"   # PC 34 = Finger Bass GM band
        assert detect_role(1, 28) == "GUITAR"  # PC 28 = Muted GT
        assert detect_role(2, 0) is None      # Piano = OTHER
        assert detect_role(3, None) is None

    def test_inverse_cdf_bounds(self):
        h = {"1": 5, "80": 5, "120": 5}
        assert 1 <= _inverse_cdf(h, 0.0) <= 127
        assert _inverse_cdf(h, 1.0) <= 127
        mids = sorted({_inverse_cdf(h, q / 10) for q in range(1, 20)})
        assert set(mids) <= {1, 80, 120}

    def test_curve_lookup_scope_excluded(self):
        fp = FactoryPipeline()
        p, src = _curve_lookup(fp.profiles, (0, 0, 99), "SFX")
        # SFX obično nema target profila za 0.0.99 — mora biti family ili EXCLUDED
        assert src in ("exact_binding", "family_aggregate", "scope_excluded")

    def test_working_zone(self):
        hw = _load_json("PA800_HARDWARE_VERIFIED_OSC_PROFILES.json")
        z = _working_zone(hw, (121, 10, 34))
        assert z is not None
        assert z[0] < z[1]
        # dokumentirana radna zona za Picked Bass RX
        assert z == (53, 113)


# ------------------------------------------------------------- cijeli pipeline
@pytest.fixture
def pipeline():
    return FactoryPipeline()


class TestPipeline19Steps:
    def test_svi_koraci_zapisani(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 14, 33) + [note_on(0, 0, 40, 80), note_off(96, 0, 40)],
            prog(0, 1, 121, 18, 24) + [note_on(0, 1, 55, 100), note_off(96, 1, 55)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        names = {v["name"] for v in report["steps"].values()}
        for i in range(1, 20):
            assert STEP_NAMES[i] in names, STEP_NAMES[i]

    def test_no_overwrite(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [prog(0, 0, 121, 14, 33) + [note_on(0, 0, 40, 80)]])
        out = tmp_path / "out.mid"
        pipeline.run(inp, out)
        with pytest.raises(FileExistsError, match="No-overwrite"):
            pipeline.run(inp, out)

    def test_original_preserved_bytes(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [prog(0, 0, 121, 14, 33) + [note_on(0, 0, 40, 80)]])
        before = inp.read_bytes()
        pipeline.run(inp, tmp_path / "out.mid")
        assert inp.read_bytes() == before, "Izvorni fajl promijenjen!"

    def test_controller_reset_all(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 14, 33)
            + [cc(0, 0, 1, 50), cc(0, 0, 7, 80), cc(0, 0, 10, 20), cc(0, 0, 64, 127),
               cc(0, 0, 98, 3), cc(0, 0, 99, 2), cc(0, 0, 100, 0), cc(0, 0, 101, 0),
               pb(0, 0, 0, 64), at(0, 0, 60)]
            + [note_on(0, 0, 40, 80), note_off(96, 0, 40)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        counts = report["steps"][9]["counts"]
        assert counts["cc"] == 4                      # 1,7,10,64
        assert counts["nrpn_or_rpn"] == 4             # 98,99,100,101
        assert counts["pitch_bend"] == 1
        assert counts["aftertouch"] == 1
        assert counts["target_head_replaced"] == 3    # cc0 + cc32 + pc (ciljni)
        # output MIDI: nema preostalih CC osim sound-change head-ova
        out_events = []
        for tr in parse_smf(out)["tracks"]:
            out_events.extend(tr)
        out_cc = [e for e in out_events if e.kind == "channel" and (e.status & 0xF0) == 0xB0]
        remaining_numbers = {e.data[0] for e in out_cc if e.data[0] not in (0, 32)}
        assert remaining_numbers == set(), f"preostali CC: {remaining_numbers}"
        # NRPN se nikad ne generira
        nrpn_out = [e for e in out_cc if e.data[0] in (98, 99, 100, 101)]
        assert nrpn_out == []

    def test_velocity_from_factory_not_original(self, pipeline, tmp_path):
        # 5 nota različitih velocity u ulazu; izlaz mora biti quantile mapiran
        # iz factory krive (SVE vrijedinosti unutar p05..p95 obično... ali
        # za cilj ne claim-amo; biramo target koji ima corpus curve).
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34)
            + [note_on(i * 96, 0, 40, v) for i, v in enumerate((10, 30, 50, 70, 100))]
            + [note_off((i + 1) * 96 - 8, 0, 40) for i in range(5)],
        ])
        out = tmp_path / "out.mid"
        pipeline.run(inp, out)
        smf = parse_smf(out)
        vels = [e.data[1] for tr in smf["tracks"] for e in tr
                if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        profile, src = _curve_lookup(pipeline.profiles, (121, 10, 34), "BASS")
        assert src in ("exact_binding", "family_aggregate")
        curve_vals = sorted(int(v) for v in profile["vel_hist"].keys())
        assert set(vels) <= set(curve_vals), "velocity van factory krive"
        assert vels != [10, 30, 50, 70, 100], "velocity prepisan iz originala"

    def test_rank_preserving(self, pipeline, tmp_path):
        # niži velocity u ulazu NE smije postati viši redoslijed u izlazu
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34)
            + [note_on(i * 96, 0, 40, v) for i, v in enumerate((20, 100, 50))]
            + [note_off((i + 1) * 96 - 8, 0, 40) for i in range(3)],
        ])
        out = tmp_path / "out.mid"
        pipeline.run(inp, out)
        vels = [e.data[1] for tr in parse_smf(out)["tracks"] for e in tr
                if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        assert vels[0] <= vels[2] <= vels[1], f"rank nije očuvan: {vels}"

    def test_articulation_landing_working_zone_vrlo_niskim_vel(self, pipeline, tmp_path):
        # curve simuliramo na donji rub → sve mora sletjeti u WORKING zonu (53-113)
        fam = dict(pipeline.profiles["by_family"]["BASS"])
        fam["vel_hist"] = {"1": 100}
        pipeline.profiles["by_family"]["BASS"] = fam
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34) + [note_on(0, 0, 40, v) for v in (1, 5, 10)],
        ])
        out = tmp_path / "out.mid"
        pipeline.run(inp, out)
        vels = [e.data[1] for tr in parse_smf(out)["tracks"] for e in tr
                if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        assert all(v >= 53 for v in vels), f"velociji ispod WORKING zone: {vels}"

    def test_key_range_folds_only_octave_and_in_range(self, pipeline, tmp_path):
        # cilj Finger Bass RX (121,13,33) → exact profil iz corpus-a, range ~[28,62]
        fp = FactoryPipeline(targets={"BASS": (121, 13, 33)})
        p, src = _curve_lookup(fp.profiles, (121, 13, 33), "BASS")
        assert src == "exact_binding"
        lo, hi = p["key_lo"], p["key_hi"]
        out_note = [k for k in range(40, 128, 12) if not (lo <= k <= hi)][0]
        in_note = [k for k in range(0, 24) if not (lo <= k <= hi)][0]
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 13, 33)
            + [note_on(0, 0, out_note, 80),
               note_on(96, 0, in_note, 80),
               note_off(192, 0, out_note), note_off(288, 0, in_note)],
        ])
        out = tmp_path / "out.mid"
        report = fp.run(inp, out)
        assert report["steps"][11]["folds"] > 0
        notes = [e.data[0] for tr in parse_smf(out)["tracks"] for e in tr
                 if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        for n in notes:
            assert lo <= n <= hi, f"nota {n} nije u range [{lo},{hi}]"
        # note_off pareni: ključevi note_off moraju odgovarati foldovanim ključevima
        offs = [e.data[0] for tr in parse_smf(out)["tracks"] for e in tr
                if e.kind == "channel" and (e.status & 0xF0) == 0x80]
        assert offs == notes[-len(offs):] or set(offs) == set(notes)

    def test_key_range_ne_remap_cijeli_track(self, pipeline, tmp_path):
        # note UNUTAR range-a ostaju netaknute (tick+key identični)
        p, _ = _curve_lookup(pipeline.profiles, (121, 10, 34), "BASS")
        lo, hi = p["key_lo"], p["key_hi"]
        inside = (lo + hi) // 2
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34)
            + [note_on(i * 96, 0, inside, 70) for i in range(4)]
            + [note_off((i + 1) * 96 - 8, 0, inside) for i in range(4)],
        ])
        out = tmp_path / "out.mid"
        pipeline.run(inp, out)
        notes_out = [e.data[0] for tr in parse_smf(out)["tracks"] for e in tr
                     if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        assert notes_out == [inside, inside, inside, inside]

    def test_sound_change_engine_trigger(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 14, 33)      # GM Finger Bass 33 → RX prefer
            + [note_on(0, 0, 40, 70), note_off(96, 0, 40)],
            prog(0, 1, 121, 18, 28)      # PC 28 = Muted Guitar → Clean RX1
            + [note_on(0, 1, 55, 90), note_off(96, 1, 55)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        em = report["steps"][15]["engine_map"]
        assert 0 in em and em[0]["name"] == "Picked Bass RX"
        assert em[0]["engine"] == "RX_DNC_HW_PROFILE"
        assert em[0]["working_zone"] == (53, 113)
        assert 1 in em and em[1]["name"] == "Clean Guitar RX1"
        # output MIDI: zaglavlje ima točno poruru target bindinga
        out_ev = [e for tr in parse_smf(out)["tracks"] for e in tr]
        cc00_ch0 = [e for e in out_ev if e.kind == "channel"
                    and e.status == 0xB0 and e.data[0] == 0]
        # barem jedno čišćenje direktne na RX adrese za Ch0
        assert any(e.data[1] == 121 for e in cc00_ch0)
        pc_ch0 = [e for e in out_ev if e.kind == "channel" and e.status == 0xC0]
        assert any(e.data[0] == 34 for e in pc_ch0), "Picked Bass RX pc nedostaje"

    def test_validate_tick_invariant(self, pipeline, tmp_path):
        ticks = [0, 96, 192, 288]
        keys_in = [40, 41, 42, 43]
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34)
            + [note_on(t, 0, k, 60) for t, k in zip(ticks, keys_in)]
            + [note_off(t + 88, 0, k) for t, k in zip(ticks, keys_in)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        assert report["steps"][17]["ok"], report["issues"]
        assert report["steps"][17]["note_ticks_preserved"]

    def test_validate_rejkuje_pitch_drift(self, pipeline, tmp_path):
        # ustreli plan: folding ≠ dozvoljen motnom range merge → simuliramo po
        # pokretanju uvijek sa malim range-om u kojem fold daje offset od 9.
        pipeline2 = FactoryPipeline()
        fam = dict(pipeline2.profiles["by_family"]["BASS"])
        fam["key_lo"], fam["key_hi"] = 40, 41
        pipeline2.profiles["by_family"]["BASS"] = fam
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34) + [note_on(0, 0, 50, 70), note_off(96, 0, 50)],
        ])
        report = pipeline2.run(inp, tmp_path / "out.mid")
        # fold loop će od 50 → 38 → under lo? loop prekida na granici. delta=12 → OK
        assert report["steps"][17]["pitch_folds_all_octave"]

    def test_other_channels_bez_dokaza_ostaju_u_tijelu(self, pipeline, tmp_path):
        # piano track (OTHER): ništa se ne dira — nema target, nema curve
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 3, 0) + [note_on(0, 0, 60, 80), note_off(96, 0, 60)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        # engine_map prazan
        assert report["steps"][15]["engine_map"] == {}
        vels = [e.data[1] for tr in parse_smf(out)["tracks"] for e in tr
                if e.kind == "channel" and (e.status & 0xF0) == 0x90 and e.data[1] > 0]
        assert vels == [80], f"OTHER kanal promijenjen: {vels}"
        assert not report["issues"]

    def test_output_parseable_and_sha_in_report(self, pipeline, tmp_path):
        inp = make_midi(tmp_path, [
            prog(0, 0, 121, 10, 34) + [note_on(0, 0, 40, 80), note_off(96, 0, 40)],
        ])
        out = tmp_path / "out.mid"
        report = pipeline.run(inp, out)
        parse_smf(out)   # parsabilno
        assert len(report["steps"][3]["sha256"]) == 64
        rr = Path(str(out) + ".factory_report.json")
        assert rr.is_file()          # 19. korak — report pisan
        d = json.loads(rr.read_text(encoding="utf-8"))
        assert d["pipeline"] == "KONACNA_LOGIKA_v1"


# ------------------------------------------------------------- integracija
DEMO = Path("/home/user/uploads/factory_corpus/demo_midis/BIGBAND.MID")


@pytest.mark.skipif(not DEMO.is_file(), reason="corpus nije prisutan")
class TestDemoCorpusFile:
    def test_bigband_kraj_kraja(self, pipeline, tmp_path):
        out = tmp_path / "bigband_opt.mid"
        report = pipeline.run(DEMO, out)
        assert report["steps"][17]["ok"], report["issues"]
        smf = parse_smf(out)
        assert smf["division"] > 0
        # output postoji, nema issues, engine_map postoji ili ne (ovisi o sadržaju)
        assert Path(str(out) + ".factory_report.json").is_file()

    def test_deterministic_two_runs(self, pipeline, tmp_path):
        a = pipeline.run(DEMO, tmp_path / "a.mid")
        b = pipeline.run(DEMO, tmp_path / "b.mid")
        assert json.dumps(a["steps"][12], sort_keys=True) == \
               json.dumps(b["steps"][12], sort_keys=True)
        assert json.dumps(a["steps"][11], sort_keys=True) == \
               json.dumps(b["steps"][11], sort_keys=True)
