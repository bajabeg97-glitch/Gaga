import json
from pathlib import Path
import tempfile
import unittest
from baja_pa_manager.midi.optimizer import Event
from baja_pa_manager.midi.rx_coverage import audit_rx_tracks, load_capabilities


def track(bank, program, velocity=127, key=60):
    return [Event(0, "channel", 0xB0, bytes([0, 121])),
            Event(0, "channel", 0xB0, bytes([32, bank])),
            Event(0, "channel", 0xC0, bytes([program])),
            Event(0, "channel", 0x90, bytes([key, velocity]))]


class RXCoverageTests(unittest.TestCase):
    def test_44_identities_without_false_window_promotion(self):
        data = load_capabilities()
        self.assertEqual(len(data["sounds"]), 44)
        self.assertEqual(sum(bool(s["windows"]) for s in data["sounds"]), 10)
        self.assertTrue(all(s["oscillators"] for s in data["sounds"]))

    def test_distortion_candidate_not_classified_as_exact_zone(self):
        tracks = [track(9, 30)]
        before = repr(tracks)
        report = audit_rx_tracks(tracks)
        row = report["detected"][0]
        self.assertEqual(row["known_window_events"], 0)
        self.assertEqual(row["unresolved_window_events"], 1)
        self.assertIn(114, row["candidate_switches_audit_only"])
        self.assertEqual(before, repr(tracks))

    def test_known_bass_working_zone(self):
        report = audit_rx_tracks([track(13, 33, 80, 40)])
        self.assertEqual(report["detected"][0]["known_window_events"], 1)
        self.assertEqual(report["detected"][0]["semantics"]["working"], 1)

    def test_pending_bank_does_not_rebind_sound(self):
        events = track(9, 30)
        events.insert(3, Event(0, "channel", 0xB0, bytes([32, 13])))
        report = audit_rx_tracks([events])
        self.assertEqual(report["detected"][0]["name"], "Dist. Guitar RX1")

    def test_shared_channel_not_guessed(self):
        report = audit_rx_tracks([track(9, 30), [Event(0, "channel", 0x90, bytes([60, 100]))]])
        self.assertEqual(report["detected"], [])
        self.assertEqual(report["shared_channels_not_guessed"], [1])

    def test_bad_zone_data_rejected(self):
        data = load_capabilities()
        data["sounds"][0]["windows"] = [{"velocity_min": 114, "velocity_max": 52}]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"bad.json"
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                load_capabilities(path)

    def test_candidate_windows_cannot_be_promoted_silently(self):
        data = load_capabilities()
        sound = next(s for s in data["sounds"] if s["name"] == "Dist. Guitar RX1")
        sound["windows"] = [{"velocity_min": 1, "velocity_max": 113}]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"bad.json"
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                load_capabilities(path)
