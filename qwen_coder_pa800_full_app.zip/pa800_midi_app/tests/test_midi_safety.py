import pytest

mido = pytest.importorskip("mido")

from baja_pa_manager.style.midi_bridge import snapshot_note_structure, MidiSafetyError, assert_note_structure_unchanged


def test_note_safety_velocity_allowed():
    before = mido.MidiFile(type=1, ticks_per_beat=480)
    tr = mido.MidiTrack()
    before.tracks.append(tr)
    tr.append(mido.Message("note_on", note=60, velocity=90, time=0))
    tr.append(mido.Message("note_off", note=60, velocity=0, time=480))

    after = mido.MidiFile(type=1, ticks_per_beat=480)
    tr2 = mido.MidiTrack()
    after.tracks.append(tr2)
    tr2.append(mido.Message("note_on", note=60, velocity=110, time=0))
    tr2.append(mido.Message("note_off", note=60, velocity=0, time=480))

    assert snapshot_note_structure(before) == snapshot_note_structure(after)
    assert_note_structure_unchanged(before, after)


def test_note_pitch_change_rejected():
    before = mido.MidiFile()
    tr = mido.MidiTrack()
    before.tracks.append(tr)
    tr.append(mido.Message("note_on", note=60, velocity=90, time=0))

    after = mido.MidiFile()
    tr2 = mido.MidiTrack()
    after.tracks.append(tr2)
    tr2.append(mido.Message("note_on", note=61, velocity=90, time=0))

    with pytest.raises(MidiSafetyError):
        assert_note_structure_unchanged(before, after)
