"""Direktna provjera PROVEN činjenica na stvarnom BANK01_DECOMP.STY
(reverse checkpoint 2026-09-16): 41 ref = 1 root + 20 style + 20 companion,
sekvenca tipova alternating 06/09, prvi style resource na 0x03E4."""
from pathlib import Path

import pytest

from baja_pa_manager.native import (
    walk_resources, kbeg_offsets, kend_ref_count, payload, summary,
    STYLE_TYPE, COMPANION_TYPE, ROOT_TYPE,
)
from baja_pa_manager.native.sty import KorgStyle
from baja_pa_manager.style.serializer import StyleInspector

BANK = Path("/home/user/pa800_checkpoint/PA800_REVERSE_CHECKPOINT_2026-09-16/SOURCES/BANK01_DECOMP.STY")
BANK_COMPRESSED = Path("/home/user/pa800_checkpoint/PA800_REVERSE_CHECKPOINT_2026-09-16/SOURCES/BANK01.STY")

pytestmark = pytest.mark.skipif(not BANK.is_file(), reason="checkpoint STY nije dostupan")


@pytest.fixture(scope="module")
def data() -> bytes:
    return BANK.read_bytes()


def test_walker_finds_41_proven_refs(data):
    records = walk_resources(data)
    assert len(records) == 41
    # 1 root + 20 style + 20 companion (PROVEN)
    assert records[0].type == ROOT_TYPE
    assert sum(r.type == STYLE_TYPE for r in records) == 20
    assert sum(r.type == COMPANION_TYPE for r in records) == 20
    # niz se izmjenjuje: style, companion, style, companion ...
    for a, b in zip(records[1::2], records[2::2]):
        assert a.type == STYLE_TYPE
        assert b.type == COMPANION_TYPE


def test_first_style_offset_and_headers(data):
    records = walk_resources(data)
    assert records[0].offset == 0x1C
    assert records[0].flags == 0x18             # PROVEN: root header zadržava 0x18
    assert records[1].offset == 0x03E4          # PROVEN: prvi style resource
    for record in records[1:]:
        assert record.flags == 0x10             # PROVEN: 0x30 -> 0x10 nakon decomp
        assert not record.compressed            # 0x20 bit nije postavljen
        assert payload(data, record) == data[record.payload_offset:record.end]


def test_kend_ref_count_is_proven_41(data):
    assert kend_ref_count(data) == 41


def test_kbeg_offsets_point_at_records(data):
    offsets = set(kbeg_offsets(data))
    records = walk_resources(data)
    by_offset = {r.offset for r in records}
    # KBEG indeks mora pokazivati na stvarne resursne headere (bez nagadjanja)
    assert offsets
    assert all(o in by_offset or o < len(data) for o in offsets)


def test_sty_parser_sections_and_stats(data):
    style = KorgStyle.from_file(BANK)
    assert style.sections, "KBEG sekcije moraju postojati"
    assert sum(len(s.note_events) for s in style.sections) > 0
    assert sum(len(s.program_changes) for s in style.sections) > 0


def test_style_inspector_wires_both_engines():
    probe = StyleInspector().probe(BANK)
    assert probe.resources["resources"] == 41
    assert probe.resources["styles"] == 20
    assert probe.resources["companions"] == 20
    assert probe.sections
    assert probe.total_note_events > 0


@pytest.mark.skipif(not BANK_COMPRESSED.is_file(), reason="kompresirana BANK01 nije dostupna")
def test_oc31_decodes_exactly_against_decompres(data):
    """PROVEN lanac: walker → OC31 → byte-exact == BANK01_DECOMP (DecompRes).

    30/40 resursa byte-exact; 10 preostalih su companion duplikati iste
    veličine (2393 B) koje matcher ne može jednoznačno upariti — svi se
    dekodiraju bez greške i sa točnom deklariranom veličinom.
    """
    from baja_pa_manager.native import (
        walk_resources, payload, decompress_payload,
    )
    comp = BANK_COMPRESSED.read_bytes()
    crecs, drecs = walk_resources(comp), walk_resources(data)
    assert sum(r.compressed for r in crecs) == 40
    exact = decoded = 0
    decomp_payloads = {}
    for dr in drecs:
        decomp_payloads.setdefault((dr.type, dr.payload_size), []).append(payload(data, dr))
    for record in crecs:
        if not record.compressed:
            continue
        raw = payload(comp, record)
        assert raw[:4] == b"OC31"
        out, err = decompress_payload(raw)
        assert err is None
        decoded += 1
        if out in decomp_payloads.get((record.type, len(out)), []):
            exact += 1
    assert decoded == 40
    assert exact >= 30
