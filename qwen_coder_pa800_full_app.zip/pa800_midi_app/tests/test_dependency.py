from baja_pa_manager.bkp.graph import DependencyGraph, DependencyNode


def test_graph_walk():
    g = DependencyGraph()
    for key, kind in [("style:a", "STYLE"), ("sound:a", "SOUND"), ("ms:a", "MULTISAMPLE"), ("sample:a", "SAMPLE")]:
        g.add_node(DependencyNode(key, kind))
    g.link("style:a", "sound:a")
    g.link("sound:a", "ms:a")
    g.link("ms:a", "sample:a")
    assert g.walk("style:a") == ["style:a", "sound:a", "ms:a", "sample:a"]
