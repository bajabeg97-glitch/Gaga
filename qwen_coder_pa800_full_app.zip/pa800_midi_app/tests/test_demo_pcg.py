from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.make_demo_pcg import build_pcg, PROGRAMS
from baja_pa_manager.sound.pcg import NativePCGReader


def test_demo_pcg_roundtrip(tmp_path):
    path = tmp_path / "demo.PCG"
    path.write_bytes(build_pcg())
    pcg = NativePCGReader().read(path)
    assert len(pcg.programs) == len(PROGRAMS)
    names = [p.name for p in pcg.named]
    assert "Clean Guitar RX1" in names
    assert "Finger Bass RX" in names
    guitar = next(p for p in pcg.programs if p.name == "Clean Guitar RX1")
    assert guitar.category == 9
