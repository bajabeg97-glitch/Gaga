"""End-to-end provjera direktnog vezivanja: GUI import, CLI, safety guard,
SetManager probe, live link (dry-run)."""
from pathlib import Path

import pytest


def test_gui_module_imports_without_display():
    from baja_pa_manager.gui import run  # noqa: F401
    from baja_pa_manager.gui.app import Pa800StudioApp  # noqa: F401


def test_main_parser_builds():
    import main
    parser = main.build_parser()
    args = parser.parse_args(["audit", "x.mid"])
    assert args.command == "audit"


def test_safety_guard_roundtrip(tmp_path):
    from baja_pa_manager.midi.optimizer import Event, write_smf
    from baja_pa_manager.midi.safety import guard_optimize
    src = tmp_path / "demo.mid"
    events = [
        Event(0, "meta-03", 0xFF, b"tr1"),
        Event(0, "channel", 0xC0, bytes([0])),
        Event(0, "channel", 0x90, bytes([60, 90])),
        Event(480, "channel", 0x80, bytes([60, 0])),
        Event(480, "meta-2f", 0xFF, b""),
    ]
    write_smf(src, 1, 480, [events])
    out = tmp_path / "demo_out.mid"
    report = guard_optimize(src, out)
    assert out.is_file()
    assert report["verification"]["notes_preserved"]


def test_live_link_dry_run_select_program():
    from baja_pa_manager.midi.live import Pa800Link, select_program_messages, describe_event
    events = select_program_messages(121, 10, 0, 0)
    sent = []
    link = Pa800Link(sender=sent.append)
    for event in events:
        link.send_raw(event)
    assert [describe_event(e) for e in sent] == [
        "ch01 CC0=121", "ch01 CC32=10", "ch01 PC=0",
    ]


def test_set_manager_probe_native(tmp_path):
    from baja_pa_manager.set_manager import SetManager
    bank = Path("/home/user/pa800_checkpoint/PA800_REVERSE_CHECKPOINT_2026-09-16/SOURCES/BANK01_DECOMP.STY")
    if not bank.is_file():
        pytest.skip("checkpoint STY nije dostupan")
    style_dir = tmp_path / "STYLE"
    style_dir.mkdir(parents=True)
    (style_dir / "BANK01.STY").write_bytes(bank.read_bytes())
    manager = SetManager()
    ws = manager.open_set(tmp_path)
    probes = manager.probe_workspace(ws)
    key = "STYLE/BANK01.STY"
    assert key in probes
    assert probes[key]["kind"] == "STY"
    assert probes[key]["resources"]["resources"] == 41
    assert probes[key]["note_events"] > 0
