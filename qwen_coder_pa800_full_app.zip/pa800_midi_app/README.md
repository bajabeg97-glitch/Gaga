# Baja Music — Korg Pa800 MIDI Studio

Python MIDI aplikacija za **Korg Pa800** — izgrađena direktno na
`MASTER_SOURCE_ALL_MODULES.md` skeletonu (`baja_pa_manager`) i
**PA800_REVERSE_CHECKPOINT_2026-09-16** materijalu. Svi dokazani moduli su
**direktno vezani** jedni na druge — bez posredničkih stubova gdje god je
dokaz postojao.

---

## Šta aplikacija radi

| Funkcija | Modul | Izvor dokaza |
|---|---|---|
| SMF čitanje/pisanje (parse/serialize/verify) | `midi/optimizer.py` | 1.986 linija proven engine |
| Konzervativna MIDI optimizacija (6 engine-a) | `midi/optimizer.py` | checkpoint test suite |
| RX/DNC zvukovi — address-first odabir | `midi/optimizer.py` + `midi/rx_coverage.py` | `PA800_FACTORY_SPECIAL_REGISTRY_v2.json` (44 RX + 23 DNC + 21 RX kit) |
| RX artikulacijske zone (working/stop/gliss/mute/slide/harmonic) | `midi/optimizer.py` | `RX_OSCILLATOR_REGISTRY_v3.json` + `RX_SOUND_CAPABILITIES_v1.json` (10 hardware-observed) |
| Velocity dinamika (median-aware, po instrument porodici) | `midi/optimizer.py` | `INSTRUMENT_FAMILIES` |
| Cross-delay echo track (BPM-sync, 3/16 L + 1/4 R) | `midi/optimizer.py` | Pa800 FX 065/066 dokumentacija |
| STY banka: KBEG/KEND walker + OC31 sekcije | `native/resources.py` + `native/sty.py` | PROVEN 41-ref layout (BANK01) |
| OC20/OC31 dekompresija resursa | `native/oc31.py` | oc31.c port — **30/40 byte-exact == DecompRes, 40/40 bez greške** |
| PCG katalog programa (KORF + OC32) | `native/pcg.py` + `sound/pcg.py` | REVERSE_ENGINEERING_REPORT |
| PAD imena | `native/pad.py` | checkpoint parser |
| Live MIDI (portovi, PC slanje, playback) | `midi/live.py` | mido (opcionalno) |
| Note-safety hard rule (bez quantize/pitch promjena) | `midi/safety.py` + `style/midi_bridge.py` | EvidenceRegistry `MidiSafety` |
| SET manager (otvaranje/probe kompletnog SET-a) | `set_manager.py` | master source + native probe |
| Evidence/Validator samotest | `core/` | master source |

## Pokretanje

```bash
cd pa800_midi_app
pip install mido            # opcionalno, samo za Live MIDI tab/cli
python -m pytest tests/     # 51 test — sve mora biti zeleno
python main.py self-test    # VALIDATION: PASS
```

### GUI

```bash
python main.py gui
```

Šest tabova: **SET Manager**, **MIDI Optimizer**, **STY Explorer**
(dugme "Učitaj BANK01_DECOMP demo" ako je checkpoint u
`/home/user/pa800_checkpoint`), **Sound Catalog** (PCG + RX/DNC registry),
**Live MIDI**, **Evidence**.

### CLI

```bash
# MIDI
python main.py audit pjesma.mid
python main.py optimize pjesma.mid --velocity-strength 40 \
    --prefer-rx-dnc --articulation-engine --articulation-intensity 45 \
    --cross-delay-engine --cross-delay-amount 30 \
    --instrument-engine --instrument-intensity 40

# Native formati
python main.py sty BANK01_DECOMP.STY --resources
python main.py pcg ROM.PCG --filter guitar

# RX/DNC registry (address-first: CC0/CC32/PC)
python main.py registry --kits
python main.py registry --rx

# Live (zahtijeva mido + python-rtmidi i Pa800 na USB MIDI)
python main.py ports
python main.py pc 121 10 0 --channel 1 --port "Pa800"
python main.py play pjesma.mid --port "Pa800"
```

Demo ulazi:

```bash
python tools/make_demo_midi.py demo_pa800.mid   # ogledni GM fajl
python tools/make_demo_pcg.py demo.PCG          # ogledni PCG katalog
python main.py optimize demo_pa800.mid -o demo_pa800_optimized.mid \
    --velocity-strength 40 --prefer-rx-dnc --articulation-engine
# → 2 RX zamjene + 16 artikulacijskih korekcija, verification_ok: true
```

## Arhitektura (sve direktno vezano)

```
main.py / gui/app.py
      │
      ├─ set_manager.SetManager ──► native.sty / native.pcg / native.pad
      │                                │
      ├─ style.serializer.StyleInspector ──► native.resources (KBEG/KEND walker)
      │                                      native.oc31 (OC20/OC31 decode)
      ├─ sound.pcg.NativePCGReader ──► native.pcg.KorgPCG
      ├─ core.container.ContainerReader ──► native.resources.walk_resources
      │
      ├─ midi.optimizer  (SMF engine, audit, 6 optimizacijskih engine-a)
      │      │  data/: 6 evidence JSON-a (RX/DNC registri + katalozi)
      │      └─ midi.rx_coverage  (coverage audit; rekonstruisan engine,
      │                              provjeren portiranim checkpoint testovima)
      ├─ midi.safety ──► optimizer fingerprinti + style.midi_bridge (mido)
      └─ midi.live ──► Pa800Link (program select po adresi/imenu, playback,
                                  Panic, dry-run mod bez porta)
```

## Hard pravila (EvidenceRegistry)

1. **Postojeće note su netaknute** — tick/pitch/redoslijed se nikad ne mijenja
   (dvostruka provjera: `note_structure_counter` subset + sha256 fingerprinti;
   mido fingerprinti u `midi_bridge`).
2. **Samо dokazano se piše** — RX/DNC adrese samo iz registra; RX zone samo iz
   10 hardware-observed profila; kandidati su *audit-only* i ne mogu se
   tiho promovirati (testom zaključano).
3. **Overwrite zabranjen** — optimizer odbija pisati preko postojećeg fajla,
   verifikuje reparse prije ikakvog upisa, piše izlaz u `xb` modu.
4. **Preserve-first** — svi nedokazani bajti ostaju raw (STS, Type-06,
   Performances, BKP graf, oscillator listovi).

## Napomena o `rx_coverage` modulu

Checkpoint je pozivao `rx_coverage_engine` modul koji nije bio uključen u
ZIP. Rekonstruisan je kao `baja_pa_manager/midi/rx_coverage.py` **strogo po
ugovoru** iz `tests/test_rx_coverage_engine.py` i JSON sheme
`RX_SOUND_CAPABILITIES_v1.json` (44 RX identiteta; zone samo uz
`HARDWARE_OBSERVED_PARTIAL`; `UNRESOLVED_PRESERVE` + zone → ValueError).
Svi portirani checkpoint testovi prolaze.

## Struktura projekta

```
pa800_midi_app/
├── main.py                     # CLI (self-test/gui/audit/optimize/sty/pcg/registry/ports/pc/play)
├── baja_pa_manager/
│   ├── core/                   # modeli, evidence, validator, container (+ native wiring)
│   ├── adapters/  bkp/         # model capabilities, dependency graf
│   ├── sound/                  # katalog, resolver, PCG (native reader), osc/dk/ms
│   ├── style/                  # modeli, workspace, track editor, serializer
│   │                           #   (+ StyleInspector), midi_bridge, sts
│   ├── performance/            # PRF modeli + guarded serializer
│   ├── native/                 # resources (KBEG/KEND), oc31, sty, pcg, pad
│   ├── midi/                   # optimizer, rx_coverage, safety, live, factory_reference
│   ├── data/                   # 6 evidence JSON-a + extraction_manifest (proven stats)
│   └── gui/app.py              # Tkinter studio (6 tabova)
├── tools/                      # make_demo_midi.py, make_demo_pcg.py
└── tests/                      # 51 test (master + checkpoint + native + wiring)
```

## Verifikacija

- `51 passed` — `python -m pytest tests/`
- `VALIDATION: PASS` — `python main.py self-test`
- BANK01_DECOMP: 41 PROVEN ref (1 ROOT + 20 STYLE + 20 STYLE_PERFORMANCE),
  KBEG/KEND count 41, prvi style na `0x03E4` (README_STATUS potvrde)
- BANK01 (kompresirana): 40/40 OC31 resursa dekodirano; 30 byte-exact ==
  DecompRes izlaz (ostalo su companion duplikati iste veličine)
