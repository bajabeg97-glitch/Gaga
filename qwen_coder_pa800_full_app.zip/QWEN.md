# Qwen Coder project guide

## Project

This is the Baja Music Korg Pa800 reverse-engineering and audio/MIDI tooling bundle.
The main Python packages are `pa800_engine/` and `pa800_midi_app/`.

## Start here

1. Read `README.md` for the package overview.
2. Read `docs/MASTER_SOURCE_ALL_MODULES.md` for architecture and source mapping.
3. Inspect `pa800_engine/` for synthesis and `pa800_midi_app/` for MIDI/style processing.
4. Use the tests in `pa800_engine/tests/` and `pa800_midi_app/tests/` as the behavior contract.

## Development commands

Linux/macOS:

```bash
python3 -m pip install -r pa800_midi_app/requirements.txt
python3 -m pytest pa800_engine/tests pa800_midi_app/tests -q
python3 -m pa800_engine --simple
```

Windows:

```bat
install.bat
run_tests.bat
```

## Important constraints

- Preserve evidence-backed values and source filenames unless a task explicitly changes them.
- Do not invent hardware behavior that is not supported by the evidence files.
- Keep deterministic rendering deterministic.
- Prefer small, tested changes and update tests when behavior changes.

## Archive note

This Qwen archive excludes generated WAV files and nested evidence ZIP archives to keep the upload compact. The original full archive remains available separately in the workspace.
