#!/usr/bin/env python3
"""Analyze strict PA800 STYLE sections with OC31 39 0B 00 00."""
import pathlib,re,json,sys
SIG=bytes.fromhex("4F 43 33 31 39 0B 00 00")
def scan(p):
 d=pathlib.Path(p).read_bytes(); out=[]
 for m in re.finditer(b"OC31",d):
  i=m.start()
  if d[i:i+8]==SIG:
   out.append({"offset":i,"first256":d[i+8:i+264].hex(" ")})
 return out
if __name__=="__main__":
 print(json.dumps({p:scan(p) for p in sys.argv[1:]},indent=2))
