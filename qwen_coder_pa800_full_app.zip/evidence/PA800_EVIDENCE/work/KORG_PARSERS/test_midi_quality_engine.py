import tempfile
import unittest
from pathlib import Path
from pa800_midi_optimizer import (Event, optimize_velocities, apply_instrument_intelligence,
    critical_performance_counter, midi_quality_report, optimize, write_smf,
    apply_special_sound_preferences, add_cross_delay_echo_track)


def event(status, data, tick=0):
    return Event(tick, "channel", status, bytes(data))


class MidiQualityTests(unittest.TestCase):
    def test_custom_sound_not_replaced_by_same_gm_program(self):
        tracks = [[event(0xB0, [0, 100]), event(0xB0, [32, 1]), event(0xC0, [33]), event(0x90, [40, 100])]]
        out, changes, _, _ = apply_special_sound_preferences(tracks, True)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_sysex_does_not_cause_guessing_a_default_rx_sound(self):
        tracks = [[Event(0, "sysex", 0xF0, b"\x42\xf7"), event(0xC0, [33]), event(0x90, [40, 100])]]
        out, changes, _, _ = apply_special_sound_preferences(tracks, True)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_note_echo_not_generated_for_pitch_bending_source(self):
        tracks = [[event(0xC0, [24]), event(0xE0, [0, 70]), event(0x90, [60, 100]),
                   event(0x80, [60, 0], 100)]]
        out, changes, summary = add_cross_delay_echo_track(tracks, 0, 480, True)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)
        self.assertEqual(summary["status"], "SKIPPED_NO_SAFE_SOURCE")

    def test_shared_channel_velocity_not_guessed(self):
        tracks = [[event(0xC0, [0])], [event(0x90, [60, 10]), event(0x90, [62, 100])]]
        out, changes, summary = optimize_velocities(tracks, 100)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)
        self.assertEqual(summary["shared_or_routed_channels_preserved"], [1])

    def test_sysex_state_unknown_until_explicit_binding(self):
        tracks = [[Event(0, "sysex", 0xF0, b"\x42\x01\xf7"), event(0xC0, [0]),
                   event(0x90, [60, 10]), event(0x90, [62, 100])]]
        out, changes, summary = optimize_velocities(tracks, 100)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)
        self.assertEqual(summary["profiles"][0]["status"], "PRESERVED_UNCERTAIN_DEVICE_STATE")

    def test_explicit_bank_program_restores_known_state(self):
        tracks = [[Event(0, "sysex", 0xF0, b"\x42\xf7"), event(0xB0, [0, 0]), event(0xB0, [32, 0]),
                   event(0xC0, [0]), event(0x90, [60, 10]), event(0x90, [62, 100])]]
        _, changes, _ = optimize_velocities(tracks, 100)
        self.assertEqual(len(changes), 2)

    def test_repeated_program_is_separate_dynamic_section(self):
        tracks = [[event(0xC0, [0]), event(0x90, [60, 10]), event(0x90, [62, 30]),
                   event(0xC0, [0]), event(0x90, [60, 100]), event(0x90, [62, 120])]]
        out, _, summary = optimize_velocities(tracks, 100)
        self.assertLess(out[0][1].data[1], 30)
        self.assertGreater(out[0][4].data[1], 100)
        self.assertEqual(len(summary["profiles"]), 2)

    def test_unknown_rx_kit_not_compressed(self):
        tracks = [[event(0xB9, [0, 120]), event(0xC9, [4]), event(0x99, [36, 10]), event(0x99, [36, 127])]]
        out, changes, _ = optimize_velocities(tracks, 100, True)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_mixed_instruments_do_not_get_wrong_mix(self):
        tracks = [[event(0xC0, [24]), event(0x90, [60, 100]), event(0x80, [60, 0], 20),
                   event(0xC0, [32], 30), event(0x90, [40, 100], 30)]]
        out, changes, _ = apply_instrument_intelligence(tracks, True, 100)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_unknown_bank_mix_is_preserved(self):
        tracks = [[event(0xB0, [0, 121]), event(0xC0, [24]), event(0x90, [60, 100])]]
        out, changes, _ = apply_instrument_intelligence(tracks, True, 100)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_distortion_maximum_and_sustain_are_report_only(self):
        tracks = [[event(0xB0, [0, 121]), event(0xB0, [32, 9]), event(0xC0, [30]),
                   event(0xB0, [64, 127]), event(0x90, [60, 127])]]
        quality = midi_quality_report(tracks, {})
        codes = {w["code"] for w in quality["warnings"]}
        self.assertIn("DISTORTION_RX_MAXIMUM_DYNAMIC_REVIEW", codes)
        self.assertIn("SUSTAIN_LEFT_ON", codes)
        self.assertIn("HANGING_NOTES", codes)
        self.assertIsNone(quality["distortion_rx"][0]["known_trigger_threshold"])

    def test_critical_performance_roundtrip(self):
        tracks = [[event(0xC0, [0]), event(0xB0, [64, 127]), event(0xE0, [0, 64]),
                   event(0xD0, [80]), event(0xA0, [60, 50]), event(0xB0, [1, 30]),
                   event(0xB0, [101, 0]), event(0xB0, [100, 0]), event(0xB0, [6, 2]),
                   event(0x90, [60, 10]), event(0x90, [62, 100]), event(0x80, [60, 45], 10),
                   event(0x90, [62, 0], 10), event(0xB0, [64, 0], 20)]]
        with tempfile.TemporaryDirectory() as directory:
            source, target = Path(directory)/"in.mid", Path(directory)/"out.mid"
            write_smf(source, 0, 480, tracks)
            result = optimize(source, target, velocity_strength=100)
            self.assertTrue(result["verification"]["critical_performance_controls_preserved"])
            self.assertTrue(result["verification"]["note-structure_fingerprint_preserved"])

    def test_performance_counter_detects_controller_changes(self):
        self.assertNotEqual(critical_performance_counter([[event(0xB0, [64, 127])]]),
                            critical_performance_counter([[event(0xB0, [64, 0])]]))
