import unittest
from pa800_pkg_records import catalogue


class PackageRecordTests(unittest.TestCase):
    def fixture(self):
        payload = b"OC20" + (3).to_bytes(4, "little") + b"\x01abc"
        body = (3).to_bytes(4, "big") + b"\0\0\0\x20F:\\Demo.xml\0\0\0\0\x03"
        raw = bytes.fromhex("f8 00 00 18") + len(body).to_bytes(4, "big") + body
        raw += bytes.fromhex("fb 00 00 38") + len(payload).to_bytes(4, "big") + payload
        raw += bytes.fromhex("fb 00 00 18 00 00 00 05") + b"12345"
        return raw, payload

    def test_payload_excludes_next_record(self):
        raw, payload = self.fixture()
        rows = catalogue(raw)
        self.assertEqual(len(rows), 1)
        row = rows[0]
        self.assertEqual(raw[row["payload_offset"]:row["payload_end"]], payload)
        self.assertEqual(row["oc20_declared_bytes"], 3)
        self.assertEqual(row["following_checksum_record_hex"], "31 32 33 34 35")

    def test_truncated_payload_rejected(self):
        raw, payload = self.fixture()
        self.assertEqual(catalogue(raw[:-14]), [])

    def test_consecutive_pages_are_not_lost(self):
        raw, payload = self.fixture()
        second = bytes.fromhex("fb 00 00 38") + len(payload).to_bytes(4, "big") + payload
        rows = catalogue(raw[:-13] + second + raw[-13:])
        self.assertEqual(len(rows[0]["oc20_pages"]), 2)
        self.assertEqual(rows[0]["page_declared_sum"], 6)
        self.assertFalse(rows[0]["page_sum_matches_metadata"])

    def test_unpaired_signature_rejected(self):
        self.assertEqual(catalogue(bytes.fromhex("f8 00 00 18") + b"\0" * 50), [])
