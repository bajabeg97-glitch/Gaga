import json
from pathlib import Path
import tempfile
import unittest
from pa800_optimizer_gui import manager_launch_spec


class MidiManagerLinkTests(unittest.TestCase):
    def test_relative_config_and_both_actions(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            app = root / "midi"
            manager = root / "manager"
            app.mkdir()
            (manager / "pa800_manager").mkdir(parents=True)
            (manager / "pa800_manager/app.py").touch()
            (manager / "run_pa800_manager.py").touch()
            (manager / "run_factory_evidence.py").touch()
            (app / "MANAGER_LINK.json").write_text(json.dumps({"manager_directory": "../manager"}))
            for target, name in (("manager", "run_pa800_manager.py"), ("evidence", "run_factory_evidence.py")):
                command, home = manager_launch_spec(app, target)
                self.assertEqual(home, manager.resolve())
                self.assertEqual(Path(command[1]).name, name)

    def test_unconnected_manager_fails_explicitly(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                manager_launch_spec(Path(directory), "manager")

    def test_unknown_action_is_rejected(self):
        with self.assertRaises(ValueError):
            manager_launch_spec(Path("."), "delete")
