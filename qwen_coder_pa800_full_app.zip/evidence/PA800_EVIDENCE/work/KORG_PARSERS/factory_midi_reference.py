"""Read-only Style Works export analysis; distributions are not RX trigger maps."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import struct
import zipfile

from pa800_midi_optimizer import parse_track
from rx_coverage_engine import load_capabilities


def decode(data):
    if len(data) < 14 or data[:4] != b"MThd":
        raise ValueError("Missing MIDI header")
    size, fmt, count, division = struct.unpack_from(">IHHH", data, 4)
    if size != 6 or fmt not in (0, 1, 2) or not division:
        raise ValueError("Unsupported MIDI header")
    tracks, cursor = [], 14
    for _ in range(count):
        if data[cursor:cursor+4] != b"MTrk":
            raise ValueError("Missing track header")
        length = int.from_bytes(data[cursor+4:cursor+8], "big")
        end = cursor + 8 + length
        if end > len(data):
            raise ValueError("Track exceeds member size")
        tracks.append(parse_track(data[cursor+8:end]))
        cursor = end
    if cursor != len(data):
        raise ValueError("Trailing bytes after MIDI tracks")
    return tracks, division


def percentile(histogram, fraction):
    total = sum(histogram.values())
    rank = max(1, int((total - 1) * fraction) + 1)
    seen = 0
    for value, count in sorted(histogram.items()):
        seen += count
        if seen >= rank:
            return value
    return None


def track_notes(events):
    """Only explicit track-local bank/program bindings count as exact references.

    CV tracks may inherit routing elsewhere; these remain unbound instead of
    being silently assigned a sound from a different CV/track.
    """
    pending = defaultdict(lambda: [None, None])
    active = {}
    for event in events:
        if event.kind == "sysex" or event.kind in {"meta-20", "meta-21"}:
            active.clear()
            pending.clear()
        if event.kind != "channel":
            continue
        channel, family = event.status & 15, event.status & 0xF0
        if family == 0xB0 and event.data[0] in {0, 32}:
            pending[channel][0 if event.data[0] == 0 else 1] = event.data[1]
        elif family == 0xC0:
            active[channel] = (*pending[channel], event.data[0])
        elif family == 0x90 and event.data[1] > 0:
            binding = active.get(channel)
            yield event, binding if binding and None not in binding else None


def compare_tracks(tracks, reference):
    """Exact binding/drum-key comparison only; never modifies MIDI events."""
    if reference.get("format") != "pa800-factory-velocity-reference" or reference.get("automatic_apply") is not False:
        raise ValueError("Expected observation-only Factory data")
    index = {}
    for row in reference["references"]:
        key = (tuple(row["bank_program"]), row["drum_key"])
        if key in index:
            raise ValueError("Duplicate Factory binding/drum key")
        index[key] = row
    groups = {}
    unbound = 0
    for number, events in enumerate(tracks):
        for event, binding in track_notes(events):
            if binding is None:
                unbound += 1
                continue
            drum_key = event.data[0] if binding[0] == 120 else None
            key = (number, event.status & 15, binding, drum_key)
            groups.setdefault(key, Counter())[event.data[1]] += 1
    results = []
    for (track, channel, binding, drum_key), histogram in groups.items():
        row = index.get((binding, drum_key))
        observed = {f"p{n:02d}": percentile(histogram, n / 100) for n in (5, 50, 95)}
        result = {"track": track, "channel": channel + 1, "bank_program": list(binding),
                  "drum_key": drum_key, "notes": sum(histogram.values()), "input_percentiles": observed,
                  "match": "EXACT_BINDING_AGGREGATE" if row else "NO_EXACT_REFERENCE",
                  "automatic_apply": False}
        if row:
            p = row["observed_percentiles"]
            result.update(rx_name=row.get("rx_name"), factory_percentiles=p,
                          factory_notes=row["notes"], factory_style_count=row["style_count"],
                          support="SUFFICIENT_FOR_COMPARISON" if row["notes"] >= 100 and row["style_count"] >= 3 else "SPARSE_OBSERVATION",
                          median_difference=observed["p50"] - p["p50"],
                          outside_observed_p05_p95=sum(count for v, count in histogram.items() if v < p["p05"] or v > p["p95"]))
        results.append(result)
    return {"format": "pa800-factory-midi-comparison", "automatic_apply": False,
            "scope": "BINDING_AGGREGATE_NOT_ROLE_CV_ELEMENT_MATCH", "unbound_notes_excluded": unbound,
            "matched_groups": sum(r["match"] == "EXACT_BINDING_AGGREGATE" for r in results),
            "warning": "Percentiles are export observations, not articulation thresholds or errors. No MIDI values changed.",
            "groups": results}


def analyze(source, output):
    if output.exists():
        raise FileExistsError("Choose a new output directory")
    rx = {tuple(s[k] for k in ("cc00", "cc32", "pc")): s for s in load_capabilities()["sounds"]}
    profiles = {}
    files, errors = [], []
    styles = set()
    all_notes = unbound = trigger_register_notes = 0
    with zipfile.ZipFile(source) as archive:
        names = sorted(n for n in archive.namelist() if n.lower().endswith(".mid"))
        if len(names) != len(set(names)):
            raise ValueError("Duplicate archive member names must be resolved")
        for number, name in enumerate(names, 1):
            info = archive.getinfo(name)
            if info.file_size > 16 * 1024 * 1024:
                errors.append({"member": name, "error": "Member outside analysis size limit"})
                continue
            data = archive.read(name)
            try:
                tracks, division = decode(data)
            except ValueError as exc:
                errors.append({"member": name, "error": str(exc)})
                continue
            stem = PurePosixPath(name).stem
            label, element = stem.rsplit("_", 1) if "_" in stem else (stem, "UNKNOWN")
            styles.add(label)
            file_notes = file_unbound = 0
            for track_index, events in enumerate(tracks):
                labels = [e.data.decode("latin1").strip() for e in events if e.kind == "meta-03"]
                role_cv = next((re.search(r"\b(DRUMS|PERC|PERCUSSION|BASS|ACC[1-5])\s+CV(\d+)\b", text, re.I)
                                for text in reversed(labels) if re.search(r"\b(DRUMS|PERC|PERCUSSION|BASS|ACC[1-5])\s+CV(\d+)\b", text, re.I)), None)
                role = role_cv.group(1).upper() if role_cv else "UNKNOWN"
                cv = int(role_cv.group(2)) if role_cv else None
                for event, binding in track_notes(events):
                    all_notes += 1
                    file_notes += 1
                    if binding is None:
                        unbound += 1
                        file_unbound += 1
                        continue
                    note, velocity = event.data
                    if note >= 96:
                        trigger_register_notes += 1
                    key = (binding, role, cv, element, note if binding[0] == 120 else None)
                    profile = profiles.setdefault(key, {"bank_program": list(binding), "role": role, "cv": cv,
                        "element": element, "drum_key": key[-1], "velocity_histogram": Counter(),
                        "pitch_histogram": Counter(), "styles": set(), "files": set(),
                        "rx_name": rx.get(binding, {}).get("name"),
                        "provenance": "USER_KEYBOARD_TO_STYLE_WORKS_EXPORT_NOT_RAW_NATIVE_STYLE",
                        "trigger_threshold_status": "NOT_INFERRED_FROM_DISTRIBUTION", "automatic_apply": False})
                    profile["velocity_histogram"][velocity] += 1
                    profile["pitch_histogram"][note] += 1
                    profile["styles"].add(label)
                    profile["files"].add(name)
            files.append({"member": name, "style_label": label, "element": element,
                          "sha256": hashlib.sha256(data).hexdigest(), "track_count": len(tracks),
                          "division": division, "note_ons": file_notes, "unbound_note_ons": file_unbound})
            if number % 500 == 0:
                print(f"Analyzed {number}/{len(names)} members", flush=True)
    serial = []
    for profile in profiles.values():
        histogram = profile["velocity_histogram"]
        profile["notes"] = sum(histogram.values())
        profile["observed_percentiles"] = {f"p{n:02d}": percentile(histogram, n / 100) for n in (5, 25, 50, 75, 95)}
        profile["style_count"] = len(profile["styles"])
        profile["member_count"] = len(profile["files"])
        profile["styles"] = sorted(profile["styles"])
        profile.pop("files")
        serial.append(profile)
    summary = {"source": str(source.resolve()), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
               "members": len(names), "valid_members": len(files), "errors": len(errors),
               "style_labels": len(styles), "profiles": len(serial), "note_ons": all_notes,
               "explicitly_bound_notes": all_notes - unbound, "unbound_notes_excluded": unbound,
               "bound_high_register_notes": trigger_register_notes,
               "rx_bindings_observed": sorted({p["rx_name"] for p in serial if p["rx_name"]}),
               "originals_modified": False, "automatic_velocity_application": False}
    output.mkdir(parents=True)
    (output / "FACTORY_MIDI_REFERENCE.json").write_text(json.dumps({"format": "pa800-styleworks-factory-reference",
        "version": 1, "summary": summary, "profiles": serial, "errors": errors}, indent=2), encoding="utf-8")
    (output / "SOURCE_MEMBERS.json").write_text(json.dumps(files, indent=2), encoding="utf-8")
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


def compact_reference(report):
    groups = {}
    for profile in report["profiles"]:
        key = (tuple(profile["bank_program"]), profile["drum_key"])
        group = groups.setdefault(key, {"bank_program": profile["bank_program"], "drum_key": profile["drum_key"],
            "rx_name": profile["rx_name"], "histogram": Counter(), "styles": set(),
            "elements": set(), "roles": set()})
        group["histogram"].update({int(k): v for k, v in profile["velocity_histogram"].items()})
        group["styles"].update(profile["styles"])
        group["elements"].add(profile["element"])
        group["roles"].add(profile["role"])
    references = []
    for group in groups.values():
        h = group.pop("histogram")
        group["velocity_histogram"] = dict(sorted(h.items()))
        group["notes"] = sum(h.values())
        group["style_count"] = len(group["styles"])
        group["styles"] = sorted(group["styles"])
        group["elements"] = sorted(group["elements"])
        group["roles"] = sorted(group["roles"])
        group["observed_percentiles"] = {f"p{n:02d}": percentile(h, n / 100) for n in (5, 25, 50, 75, 95)}
        group["automatic_apply"] = False
        group["trigger_threshold_status"] = "NOT_INFERRED_FROM_DISTRIBUTION"
        references.append(group)
    return {"format": "pa800-factory-velocity-reference", "version": 1,
            "summary": report["summary"], "references": references,
            "provenance": "USER_KEYBOARD_TO_STYLE_WORKS_EXPORT_NOT_RAW_NATIVE_STYLE",
            "automatic_apply": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--compact-existing", action="store_true")
    args = parser.parse_args()
    if args.compact_existing:
        if args.output.exists():
            raise FileExistsError("Refusing overwrite")
        result = compact_reference(json.loads(args.source.read_text(encoding="utf-8")))
        args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
        print(f"Compact reference buckets: {len(result['references'])}")
    else:
        analyze(args.source, args.output)
