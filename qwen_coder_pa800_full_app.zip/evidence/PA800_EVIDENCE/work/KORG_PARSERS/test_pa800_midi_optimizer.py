import tempfile
import unittest
from pathlib import Path

from pa800_midi_optimizer import (
    Event, add_cross_delay_echo_track, apply_articulation_engine, apply_instrument_intelligence,
    apply_special_sound_preferences, audit,
    available_rx_kits, encode_vlq,
    optimize, optimize_track, optimize_velocities,
    parse_track, song_profile, vlq,
)


class MidiOptimizerTests(unittest.TestCase):
    def test_vlq(self):
        self.assertEqual(vlq(bytes.fromhex("81 00"), 0), (128, 2))
        self.assertEqual(encode_vlq(128), bytes.fromhex("81 00"))

    def test_note_pair(self):
        events = parse_track(bytes.fromhex("00 90 3c 64 60 80 3c 00 00 ff 2f 00"))
        self.assertEqual(len(events), 3)

    def test_standard_file_audit(self):
        track = bytes.fromhex("00 90 3c 64 60 90 3c 00 00 ff 2f 00")
        midi = b"MThd\x00\x00\x00\x06\x00\x00\x00\x01\x01\xe0MTrk" + len(track).to_bytes(4, "big") + track
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "ok.mid"
            path.write_bytes(midi)
            report = audit(path)
        self.assertTrue(report["pa800_safe_to_transform"])
        self.assertEqual(report["tracks"][0]["notes"], 1)

    def test_conservative_optimization_round_trip(self):
        track = bytes.fromhex(
            "00 b0 07 64 00 b0 07 64 00 90 3c 64 60 90 3c 00 00 ff 2f 00"
        )
        midi = b"MThd\x00\x00\x00\x06\x00\x00\x00\x01\x01\xe0MTrk" + len(track).to_bytes(4, "big") + track
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "source.mid"
            destination = Path(directory) / "optimized.mid"
            source.write_bytes(midi)
            result = optimize(source, destination)
            report = audit(destination)
        self.assertEqual(result["removed_events"], 1)
        self.assertTrue(result["verification"]["notes_preserved"])
        self.assertTrue(result["verification"]["sysex_preserved"])
        self.assertEqual(report["tracks"][0]["notes"], 1)

    def test_shared_channel_can_be_blocked(self):
        events = [Event(0, "channel", 0xB0, bytes((7, 100))), Event(10, "channel", 0xB0, bytes((7, 100)))]
        optimized, changes = optimize_track(events, {0})
        self.assertEqual(optimized, events)
        self.assertEqual(changes, [])

    def test_song_profile_tempo_meter_and_polyphony(self):
        tracks = [[
            Event(0, "meta-51", 0xFF, bytes.fromhex("07 a1 20")),
            Event(0, "meta-58", 0xFF, bytes((4, 2, 24, 8))),
            Event(0, "channel", 0x90, bytes((60, 100))),
            Event(0, "channel", 0x91, bytes((64, 100))),
            Event(480, "channel", 0x80, bytes((60, 0))),
            Event(480, "channel", 0x81, bytes((64, 0))),
            Event(480, "meta-2f", 0xFF, b""),
        ]]
        profile = song_profile(tracks, 480)
        self.assertEqual(profile["duration_seconds"], 0.5)
        self.assertEqual(profile["peak_polyphony"], 2)
        self.assertEqual(profile["time_signatures"][0]["denominator"], 4)

    def test_velocity_compression_preserves_pitch_and_drums(self):
        tracks = [[
            Event(0, "channel", 0x90, bytes((60, 20))),
            Event(10, "channel", 0x90, bytes((62, 100))),
            Event(20, "channel", 0x99, bytes((36, 120))),
        ]]
        optimized, changes, summary = optimize_velocities(tracks, 100, False)
        self.assertEqual([event.data[0] for event in optimized[0]], [60, 62, 36])
        self.assertEqual([event.data[1] for event in optimized[0]], [34, 86, 120])
        self.assertEqual(len(changes), 2)
        self.assertTrue(summary["enabled"])

    def test_verified_deep_rx_selection_and_velocity_protection(self):
        tracks = [[
            Event(0, "channel", 0xC0, bytes((33,))),
            Event(0, "channel", 0x90, bytes((40, 20))),
            Event(10, "channel", 0x90, bytes((43, 110))),
        ]]
        selected, changes, protected, summary = apply_special_sound_preferences(tracks, True)
        self.assertEqual([(e.data[0], e.data[1]) for e in selected[0][:2]], [(0, 121), (32, 13)])
        self.assertEqual(selected[0][2].data, bytes((33,)))
        self.assertEqual(changes[0]["name"], "Finger Bass RX")
        self.assertEqual(protected, {0})
        optimized, velocity_changes, velocity = optimize_velocities(selected, 100, False, protected)
        self.assertEqual(optimized, selected)
        self.assertEqual(velocity_changes, [])
        self.assertEqual(velocity["protected_special_channels"], [1])
        self.assertTrue(summary["registry_available"])

    def test_articulation_engine_normalizes_new_rx_into_working_window(self):
        tracks = [[
            Event(0, "channel", 0xB0, bytes((0, 121))),
            Event(0, "channel", 0xB0, bytes((32, 13))),
            Event(0, "channel", 0xC0, bytes((33,))),
            Event(0, "channel", 0x90, bytes((40, 20))),
            Event(10, "channel", 0x90, bytes((43, 110))),
            Event(20, "channel", 0x90, bytes((100, 80))),
        ]]
        selected = [{"channel": 1, "cc00": 121, "cc32": 13, "pc": 33, "kind": "RX"}]
        optimized, changes, summary = apply_articulation_engine(tracks, selected, True)
        velocities = [event.data[1] for event in optimized[0] if event.status & 0xF0 == 0x90]
        self.assertEqual(velocities, [62, 105, 80])
        self.assertEqual(len(changes), 2)
        self.assertEqual(summary["existing_noise_trigger_notes_preserved"], 1)
        self.assertEqual(summary["observed_semantics"]["gliss"], 1)
        self.assertEqual(summary["observed_semantics"]["noise"], 1)

    def test_context_engine_uses_verified_clean_guitar_windows(self):
        tracks = [[
            Event(0, "channel", 0xB0, bytes((0, 121))),
            Event(0, "channel", 0xB0, bytes((32, 14))),
            Event(0, "channel", 0xC0, bytes((28,))),
            Event(0, "channel", 0x90, bytes((60, 40))),
            Event(30, "channel", 0x80, bytes((60, 0))),
            Event(240, "channel", 0x90, bytes((67, 120))),
            Event(480, "channel", 0x80, bytes((67, 0))),
        ]]
        selected = [{"channel": 1, "cc00": 121, "cc32": 14, "pc": 28, "kind": "RX"}]
        optimized, changes, summary = apply_articulation_engine(tracks, selected, True, 480, 100)
        velocities = [event.data[1] for event in optimized[0] if event.status & 0xF0 == 0x90]
        self.assertEqual(velocities, [28, 126])
        self.assertEqual([row["semantic"] for row in changes], ["dead", "slide/slap"])
        self.assertEqual(changes[0]["decoded_hardware_layer"]["multisample"]["name"], "Clean Guitar Dead")
        self.assertEqual(changes[1]["decoded_hardware_layer"]["multisample"]["name"], "Clean Guitar Slide")
        self.assertEqual(summary["enhanced_articulations"], 2)

    def test_picked_bass_gliss_resolves_exact_multisample(self):
        tracks = [[
            Event(0, "channel", 0xB0, bytes((0, 121))),
            Event(0, "channel", 0xB0, bytes((32, 10))),
            Event(0, "channel", 0xC0, bytes((34,))),
            Event(0, "channel", 0x90, bytes((40, 80))),
            Event(120, "channel", 0x80, bytes((40, 0))),
            Event(130, "channel", 0x90, bytes((45, 10))),
            Event(250, "channel", 0x80, bytes((45, 0))),
        ]]
        selected = [{"channel": 1, "cc00": 121, "cc32": 10, "pc": 34, "kind": "RX"}]
        _, changes, summary = apply_articulation_engine(tracks, selected, True, 480, 100)
        gliss = next(row for row in changes if row.get("semantic") == "gliss")
        layer = gliss["decoded_hardware_layer"]
        self.assertEqual(layer["oscillator"], 4)
        self.assertEqual(layer["multisample"]["id"], 379)
        self.assertEqual(layer["multisample"]["name"], "E.Bass Gliss")
        self.assertTrue(summary["hardware_profile_path"])

    def test_exact_rx_kit_selection(self):
        self.assertIn("Pop Std. Kit RX", available_rx_kits())
        tracks = [[
            Event(0, "channel", 0xC9, bytes((0,))),
            Event(0, "channel", 0x99, bytes((36, 100))),
        ]]
        selected, changes, protected, _ = apply_special_sound_preferences(
            tracks, False, "Pop Std. Kit RX"
        )
        self.assertEqual([event.data for event in selected[0][:3]], [bytes((0, 120)), bytes((32, 0)), bytes((4,))])
        self.assertEqual(changes[0]["kind"], "RX_DRUM_KIT")
        self.assertEqual(protected, {9})

    def test_cross_delay_adds_two_tempo_synced_taps(self):
        tracks = [[
            Event(0, "meta-03", 0xFF, b"Lead Guitar"),
            Event(0, "channel", 0xC0, bytes((27,))),
            Event(0, "channel", 0x90, bytes((60, 100))),
            Event(240, "channel", 0x80, bytes((60, 0))),
            Event(240, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = add_cross_delay_echo_track(tracks, 1, 480, True, 35)
        self.assertEqual(report["status"], "ADDED")
        self.assertEqual(report["echo_channels"], [16, 15])
        self.assertEqual([row["delay_ticks"] for row in report["taps"]], [360, 480])
        self.assertEqual(len(cooked), 2)
        self.assertEqual(len(changes), 2)
        echo_ons = [e for e in cooked[1] if e.kind == "channel" and e.status & 0xF0 == 0x90]
        self.assertEqual([e.tick for e in echo_ons], [360, 480])

    def test_cross_delay_does_not_duplicate_named_echo_track(self):
        tracks = [[
            Event(0, "meta-03", 0xFF, b"Cross Delay Echo"),
            Event(0, "channel", 0x90, bytes((60, 100))),
            Event(120, "channel", 0x80, bytes((60, 0))),
            Event(120, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = add_cross_delay_echo_track(tracks, 1, 480, True, 35)
        self.assertEqual(cooked, tracks)
        self.assertEqual(changes, [])
        self.assertEqual(report["status"], "EXISTING_ECHO_TRACK")

    def test_cross_delay_detects_unnamed_delayed_copy(self):
        events = []
        for index in range(12):
            tick = index * 240
            note = 60 + index % 5
            events.extend((
                Event(tick, "channel", 0x90, bytes((note, 90))),
                Event(tick + 120, "channel", 0x80, bytes((note, 0))),
                Event(tick + 240, "channel", 0x91, bytes((note, 45))),
                Event(tick + 360, "channel", 0x81, bytes((note, 0))),
            ))
        events.sort(key=lambda event: event.tick)
        events.append(Event(events[-1].tick, "meta-2f", 0xFF, b""))
        cooked, changes, report = add_cross_delay_echo_track([events], 0, 480, True, 35)
        self.assertEqual(cooked, [events])
        self.assertEqual(changes, [])
        self.assertEqual(report["status"], "EXISTING_UNNAMED_DELAY")
        self.assertGreaterEqual(report["detected"][0]["coverage"], 0.65)

    def test_cross_delay_prefers_monophonic_lead_over_dense_chords(self):
        events = [Event(0, "channel", 0xC0, bytes((48,))), Event(0, "channel", 0xC1, bytes((81,)))]
        for tick in (0, 480, 960, 1440):
            for note in (48, 52, 55, 60):
                events.extend((Event(tick, "channel", 0x90, bytes((note, 80))), Event(tick + 400, "channel", 0x80, bytes((note, 0)))))
            lead = 72 + tick // 480
            events.extend((Event(tick, "channel", 0x91, bytes((lead, 100))), Event(tick + 300, "channel", 0x81, bytes((lead, 0)))))
        events.sort(key=lambda event: event.tick)
        events.append(Event(events[-1].tick, "meta-2f", 0xFF, b""))
        _, _, report = add_cross_delay_echo_track([events], 0, 480, True, 35)
        self.assertEqual(report["source_channel"], 2)
        self.assertEqual(report["source_selection"]["peak_polyphony"], 1)

    def test_cross_delay_zero_amount_is_a_true_bypass(self):
        tracks = [[
            Event(0, "channel", 0x90, bytes((60, 100))),
            Event(120, "channel", 0x80, bytes((60, 0))),
            Event(120, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = add_cross_delay_echo_track(tracks, 1, 480, True, 0)
        self.assertEqual(cooked, tracks)
        self.assertEqual(changes, [])
        self.assertEqual(report["status"], "SKIPPED_ZERO_AMOUNT")

    def test_instrument_engine_fills_only_missing_guitar_mix(self):
        tracks = [[
            Event(0, "channel", 0xC0, bytes((27,))),
            Event(0, "channel", 0xB0, bytes((10, 91))),
            Event(10, "channel", 0x90, bytes((60, 100))),
            Event(250, "channel", 0x80, bytes((60, 0))),
            Event(250, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = apply_instrument_intelligence(tracks, True, 100)
        self.assertEqual(report["channels"][0]["family"], "guitar")
        self.assertEqual(report["channels"][0]["existing_mix_controllers"], [10])
        self.assertEqual({row["controller"] for row in changes}, {7, 91, 93})
        pan_events = [e for e in cooked[0] if e.kind == "channel" and e.status == 0xB0 and e.data[0] == 10]
        self.assertEqual([e.data[1] for e in pan_events], [91])

    def test_instrument_engine_reports_range_without_transposing(self):
        tracks = [[
            Event(0, "channel", 0xC0, bytes((33,))),
            Event(0, "channel", 0x90, bytes((90, 100))),
            Event(120, "channel", 0x80, bytes((90, 0))),
            Event(120, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = apply_instrument_intelligence(tracks, False, 35)
        self.assertEqual(cooked, tracks)
        self.assertEqual(changes, [])
        self.assertEqual(report["channels"][0]["family"], "bass")
        self.assertEqual(report["channels"][0]["outside_range"], 1)
        self.assertEqual(report["channels"][0]["warnings"][0]["policy"], "REPORT_ONLY_NO_TRANSPOSE")

    def test_instrument_engine_never_touches_protected_rx_channel(self):
        tracks = [[
            Event(0, "channel", 0xC0, bytes((28,))),
            Event(0, "channel", 0x90, bytes((60, 100))),
            Event(120, "channel", 0x80, bytes((60, 0))),
            Event(120, "meta-2f", 0xFF, b""),
        ]]
        cooked, changes, report = apply_instrument_intelligence(tracks, True, 100, {0})
        self.assertEqual(cooked, tracks)
        self.assertEqual(changes, [])
        self.assertTrue(report["channels"][0]["protected_special_sound"])

    def test_full_optimizer_verifies_added_instrument_mix(self):
        track = bytes.fromhex(
            "00 c0 1b 00 90 3c 64 81 70 80 3c 00 00 ff 2f 00"
        )
        midi = b"MThd\x00\x00\x00\x06\x00\x00\x00\x01\x01\xe0MTrk" + len(track).to_bytes(4, "big") + track
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "guitar.mid"
            destination = Path(directory) / "guitar_optimized.mid"
            source.write_bytes(midi)
            report = optimize(source, destination, instrument_engine=True, instrument_intensity=35)
        self.assertGreater(report["instrument_mix_changes"], 0)
        self.assertTrue(report["verification"]["notes_preserved"])
        self.assertTrue(report["verification"]["nonrouting-channel_fingerprint_preserved"])

    def test_native_oscillator_catalog_loads(self):
        from pa800_midi_optimizer import load_native_oscillator_catalog
        catalog = load_native_oscillator_catalog()
        self.assertTrue(catalog["available"])
        self.assertGreater(catalog["multisample_count"], 0)
        self.assertGreater(catalog["pcg_total_records"], 0)
        self.assertIn("multisamples_by_name", catalog)
        self.assertIn("GrandPiano_L", catalog["multisamples_by_name"])
        gp = catalog["multisamples_by_name"]["GrandPiano_L"]
        self.assertGreater(len(gp["key_map"]), 0)
        self.assertTrue(gp["key_map_summary"]["valid"])

    def test_factory_evidence_includes_native_catalog(self):
        from pa800_midi_optimizer import pa800_factory_evidence
        evidence = pa800_factory_evidence()
        self.assertTrue(evidence["available"])
        native = evidence["native_oscillator_catalog"]
        self.assertTrue(native["available"])
        self.assertGreater(native["multisample_count"], 0)
        self.assertGreater(native["pcg_total_records"], 0)

    def test_native_style_catalog_loads(self):
        from pa800_midi_optimizer import load_native_style_catalog
        catalog = load_native_style_catalog()
        self.assertTrue(catalog["available"])
        self.assertGreater(catalog["bank_count"], 0)
        self.assertGreater(catalog["total_style_names"], 0)
        self.assertGreater(catalog["total_program_changes"], 0)
        self.assertGreater(catalog["total_note_events"], 0)
        self.assertGreater(catalog["unique_programs"], 0)
        self.assertEqual(catalog["bank_count"], 18)

    def test_factory_evidence_includes_native_style_catalog(self):
        from pa800_midi_optimizer import pa800_factory_evidence
        evidence = pa800_factory_evidence()
        self.assertTrue(evidence["available"])
        native_style = evidence["native_style_catalog"]
        self.assertTrue(native_style["available"])
        self.assertEqual(native_style["bank_count"], 18)
        self.assertGreater(native_style["total_style_names"], 0)
        self.assertGreater(native_style["total_program_changes"], 0)
        self.assertGreater(native_style["total_note_events"], 0)
        self.assertGreater(native_style["unique_programs"], 0)

    def test_native_style_catalog_has_bank_details(self):
        from pa800_midi_optimizer import load_native_style_catalog
        catalog = load_native_style_catalog()
        self.assertTrue(catalog["available"])
        banks = catalog["banks"]
        self.assertEqual(len(banks), 18)
        bank01 = next(b for b in banks if b["file"] == "BANK01.STY")
        self.assertGreater(bank01["style_name_count"], 0)
        self.assertGreater(bank01["total_program_changes"], 0)
        self.assertGreater(bank01["total_note_events"], 0)
        self.assertGreater(len(bank01["style_names"]), 0)


if __name__ == "__main__":
    unittest.main()
