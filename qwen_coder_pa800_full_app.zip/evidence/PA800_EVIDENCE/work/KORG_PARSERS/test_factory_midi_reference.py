import unittest
from pa800_midi_optimizer import Event
from factory_midi_reference import compact_reference, compare_tracks, decode, percentile, track_notes


class FactoryReferenceTests(unittest.TestCase):
    def test_sysex_requires_new_explicit_banks(self):
        events = [Event(0, "channel", 0xB0, b"\x00\x79"), Event(0, "channel", 0xB0, b"\x20\x09"),
                  Event(0, "channel", 0xC0, b"\x1e"), Event(1, "sysex", 0xF0, b"\x01"),
                  Event(2, "channel", 0xC0, b"\x1e"), Event(3, "channel", 0x90, b"\x3c\x7f")]
        self.assertIsNone(list(track_notes(events))[0][1])

    def test_comparison_exact_binding_read_only(self):
        events = [Event(0, "channel", 0xB0, b"\x00\x79"), Event(0, "channel", 0xB0, b"\x20\x09"),
                  Event(0, "channel", 0xC0, b"\x1e"), Event(0, "channel", 0x90, b"\x3c\x7f")]
        before = [(e.tick, e.kind, e.status, e.data) for e in events]
        reference = {"format": "pa800-factory-velocity-reference", "automatic_apply": False,
                     "references": [{"bank_program": [121, 9, 30], "drum_key": None,
                                     "notes": 1000, "style_count": 5, "rx_name": "Dist. Guitar RX1",
                                     "observed_percentiles": {"p05": 32, "p50": 63, "p95": 100}}]}
        report = compare_tracks([events], reference)
        self.assertEqual(report["matched_groups"], 1)
        self.assertEqual(report["groups"][0]["median_difference"], 64)
        self.assertEqual(report["groups"][0]["outside_observed_p05_p95"], 1)
        self.assertFalse(report["automatic_apply"])
        self.assertEqual(before, [(e.tick, e.kind, e.status, e.data) for e in events])
        reference["references"][0]["bank_program"] = [121, 10, 30]
        self.assertEqual(compare_tracks([events], reference)["matched_groups"], 0)

    def test_bad_header_rejected(self):
        with self.assertRaises(ValueError):
            decode(b"bad")

    def test_percentiles_are_observations(self):
        self.assertEqual(percentile({10: 1, 20: 1, 100: 1}, .5), 20)

    def test_compact_reference_keeps_binding_and_drum_key_separate(self):
        common = {"bank_program": [120, 0, 4], "rx_name": None, "styles": ["Style"], "element": "Var1", "role": "DRUMS"}
        source = {"summary": {}, "profiles": [{**common, "drum_key": 36, "velocity_histogram": {"10": 1}},
                  {**common, "drum_key": 42, "velocity_histogram": {"100": 1}}]}
        result = compact_reference(source)
        self.assertEqual(len(result["references"]), 2)
        self.assertFalse(result["automatic_apply"])

    def test_missing_cv_routing_not_invented(self):
        events = [Event(0, "channel", 0x90, b"\x3c\x64")]
        self.assertIsNone(list(track_notes(events))[0][1])

    def test_pending_bank_does_not_replace_committed_binding(self):
        events = [Event(0, "channel", 0xB0, b"\x00\x79"), Event(0, "channel", 0xB0, b"\x20\x09"),
                  Event(0, "channel", 0xC0, b"\x1e"), Event(0, "channel", 0xB0, b"\x20\x0a"),
                  Event(0, "channel", 0x90, b"\x3c\x7f")]
        self.assertEqual(list(track_notes(events))[0][1], (121, 9, 30))
