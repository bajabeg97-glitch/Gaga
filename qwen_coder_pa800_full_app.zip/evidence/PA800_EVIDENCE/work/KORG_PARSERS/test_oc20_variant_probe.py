import unittest

from oc20_variant_probe import walk


class OC20VariantProbeTests(unittest.TestCase):
    def test_bad_header_is_rejected(self):
        with self.assertRaises(ValueError):
            walk(b"not OC20")

    def test_oversized_declaration_is_rejected(self):
        with self.assertRaises(ValueError):
            walk(b"OC20" + (0xFFFFFFFF).to_bytes(4, "little"))

    def test_bounded_literal(self):
        raw = b"OC20" + (3).to_bytes(4, "little") + b"\x01abc"
        result = walk(raw)
        self.assertEqual(result["output_bytes"], 3)
        self.assertEqual(result["prefix"], "abc")
        self.assertFalse(result["accepted"])

    def test_trailing_bytes_are_not_decoded_beyond_declared_length(self):
        raw = b"OC20" + (3).to_bytes(4, "little") + b"\x01abc\xff\xff"
        result = walk(raw)
        self.assertTrue(result["exact_declared_length"])
        self.assertIsNone(result["error"])
        self.assertEqual(result["unconsumed_bytes"], 2)
        self.assertFalse(result["accepted"])

    def test_lookbehind_is_not_zero_filled(self):
        result = walk(b"OC20" + (100).to_bytes(4, "little") + bytes.fromhex("40 1c"))
        self.assertIn("invalid distance", result["error"])
        self.assertEqual(result["output_bytes"], 0)
        self.assertFalse(result["accepted"])

    def test_output_cap(self):
        result = walk(b"OC20" + (1).to_bytes(4, "little") + b"\x01abc")
        self.assertEqual(result["error"], "literal bounds")
        self.assertEqual(result["output_bytes"], 0)

    def test_demo_first_match_and_short_literal(self):
        prefix = b'<?xml version="1.0" encoding="ISO-8859-1" standalone="yes"?>\r\n<DEMO'
        self.assertEqual(len(prefix), 67)
        raw = b"OC20" + (100).to_bytes(4, "little") + b"\x00\x31" + prefix
        raw += bytes.fromhex("40 1c 0a") + b"  <MAIN titl"
        result = walk(raw)
        self.assertEqual(result["prefix"], (prefix + b">\r\n  <MAIN titl").decode())
        self.assertFalse(result["accepted"])


if __name__ == "__main__":
    unittest.main()
