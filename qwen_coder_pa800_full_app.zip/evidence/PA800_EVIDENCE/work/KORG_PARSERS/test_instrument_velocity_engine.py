import unittest
from pa800_midi_optimizer import Event, instrument_family, optimize_velocities, apply_special_sound_preferences


def pc(program):
    return Event(0, "channel", 0xC0, bytes([program]))


def note(value, key=60, status=0x90):
    return Event(0, "channel", status, bytes([key, value]))


class InstrumentVelocityTests(unittest.TestCase):
    def test_all_gm_programs_are_classified(self):
        for program in range(128):
            self.assertTrue(instrument_family(program)["key"])

    def test_different_programs_do_not_share_median(self):
        tracks = [[pc(0), note(10), note(30), pc(32), note(100), note(120)]]
        out, _, summary = optimize_velocities(tracks, 100)
        self.assertLess(out[0][1].data[1], 30)
        self.assertGreater(out[0][4].data[1], 100)
        self.assertEqual(len(summary["profiles"]), 2)

    def test_unknown_bank_preserved(self):
        tracks = [[Event(0, "channel", 0xB0, bytes([0, 121])), pc(30), note(127), note(5)]]
        out, changes, summary = optimize_velocities(tracks, 100)
        self.assertEqual(out, tracks)
        self.assertEqual(changes, [])
        self.assertEqual(summary["profiles"][0]["status"], "PRESERVED_UNKNOWN_BANK")

    def test_pending_bank_does_not_change_active_program(self):
        tracks = [[pc(0), note(10), Event(0, "channel", 0xB0, bytes([0, 121])), note(30)]]
        out, changes, _ = optimize_velocities(tracks, 100)
        self.assertEqual(len(changes), 2)
        self.assertNotEqual(out, tracks)

    def test_rx_high_velocity_not_modified_by_generic_engine(self):
        tracks = [[pc(30), note(127), note(1), note(0)]]
        out, changes, _ = optimize_velocities(tracks, 100, False, {0})
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_drum_keys_have_independent_dynamics(self):
        tracks = [[note(10, 36, 0x99), note(30, 36, 0x99), note(100, 42, 0x99), note(120, 42, 0x99)]]
        out, _, summary = optimize_velocities(tracks, 100, True)
        self.assertLess(out[0][0].data[1], 30)
        self.assertGreater(out[0][2].data[1], 100)
        self.assertEqual(len(summary["profiles"]), 2)

    def test_distortion_rx_not_automatically_assigned(self):
        tracks = [[pc(30), note(127)]]
        out, changes, _, _ = apply_special_sound_preferences(tracks, True)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)

    def test_strength_zero_is_exact_bypass(self):
        tracks = [[pc(0), note(1), note(127), note(0)]]
        out, changes, _ = optimize_velocities(tracks, 0)
        self.assertEqual(out, tracks)
        self.assertFalse(changes)
