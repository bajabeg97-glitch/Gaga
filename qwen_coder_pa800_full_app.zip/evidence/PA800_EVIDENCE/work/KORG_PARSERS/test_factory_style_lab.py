import tempfile
import unittest
from pathlib import Path

from factory_style_lab import (
    attach_oc20_envelopes,
    inspect_factory_banks,
    inspect_midi,
    locate_track_marker,
)


class FactoryStyleLabTests(unittest.TestCase):
    def test_standard_midi_header(self):
        data = b"MThd\x00\x00\x00\x06\x00\x01\x00\x01\x01\xe0MTrk\x00\x00\x00\x04\x00\xff\x2f\x00"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.mid"
            path.write_bytes(data)
            result = inspect_midi(path, {})
        self.assertTrue(result["standard_smf_header"])
        self.assertEqual(result["complete_track_chunks"], 1)
        self.assertEqual(result["confidence"], "standard-midi")

    def test_korg_extension_byte(self):
        data = b"MThd\x00\x00\x00\x06\x40\x0c\x00\x14\x01\x01\x80MTrk\x00\x00\x00\x00"
        self.assertEqual(locate_track_marker(data), (15, "80"))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "test.bin"
            path.write_bytes(data)
            result = inspect_midi(path, {})
        self.assertTrue(result["korg_extended_header"])
        self.assertFalse(result["standard_smf_header"])

    def test_oc20_envelope(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            wrapper = root / "0001_wrapper.bin"
            wrapper.write_bytes(b"OC20" + (1000).to_bytes(4, "little") + b"\x06")
            manifest = [
                {"index": 1, "tag": "OC20", "size": 9, "file": wrapper.name},
                {"index": 2, "tag": "MThd", "size": 500, "file": "payload.bin"},
            ]
            rows = [{"index": 2, "actual_size": 500}]
            attach_oc20_envelopes(rows, manifest, root)
        self.assertTrue(rows[0]["oc20_envelope"])
        self.assertEqual(rows[0]["oc20_unpacked_size"], 1000)
        self.assertEqual(rows[0]["oc20_payload_prefix"], 6)
        self.assertEqual(rows[0]["packing_ratio"], 0.501)

    def test_factory_bank_inventory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "BANK01.STY").write_bytes(
                b"prefixOC20" + (123).to_bytes(4, "little") + b"\x06KORFtail"
            )
            rows = inspect_factory_banks(root)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["oc20_pages"], 1)
        self.assertEqual(rows[0]["korf_markers"], 1)
        self.assertEqual(rows[0]["declared_logical_bytes"], 123)


if __name__ == "__main__":
    unittest.main()
