#!/usr/bin/env python3
"""Forensic catalogue builder for Korg Pa800 factory Style/MIDI evidence.

This tool is deliberately conservative: a magic signature is evidence of a
candidate, not proof that the extracted file is a complete independent object.
It never modifies the source dump or extracted objects.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import struct
from collections import Counter
from pathlib import Path
from typing import Any


PRINTABLE = re.compile(rb"[\x20-\x7e]{4,}")


def be16(data: bytes, offset: int) -> int | None:
    if offset + 2 > len(data):
        return None
    return struct.unpack_from(">H", data, offset)[0]


def be32(data: bytes, offset: int) -> int | None:
    if offset + 4 > len(data):
        return None
    return struct.unpack_from(">I", data, offset)[0]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strings(data: bytes, limit: int = 24) -> list[str]:
    found: list[str] = []
    for match in PRINTABLE.finditer(data):
        value = match.group().decode("ascii", "replace").strip()
        if value and value not in found:
            found.append(value)
        if len(found) >= limit:
            break
    return found


def locate_track_marker(data: bytes) -> tuple[int | None, str]:
    """Find the first MTrk and describe bytes inserted after the MIDI header."""
    pos = data.find(b"MTrk", 14, min(len(data), 64))
    if pos < 0:
        return None, data[14:22].hex(" ").upper()
    return pos, data[14:pos].hex(" ").upper()


def walk_mtrk_chunks(data: bytes, first_track: int | None) -> dict[str, Any]:
    if first_track is None:
        return {"declared_track_chunks": 0, "complete_track_chunks": 0,
                "declared_midi_end": None, "chunk_walk_error": "MTrk not found"}
    pos = first_track
    declared = complete = 0
    error = None
    while pos + 8 <= len(data) and data[pos:pos + 4] == b"MTrk":
        length = be32(data, pos + 4)
        assert length is not None
        declared += 1
        end = pos + 8 + length
        if end > len(data):
            error = f"track {declared} declares end {end}, object has {len(data)} bytes"
            pos = end
            break
        complete += 1
        pos = end
    return {
        "declared_track_chunks": declared,
        "complete_track_chunks": complete,
        "declared_midi_end": pos,
        "chunk_walk_error": error,
    }


def inspect_midi(path: Path, item: dict[str, Any]) -> dict[str, Any]:
    data = path.read_bytes()
    first_track, extension = locate_track_marker(data)
    header_length = be32(data, 4)
    fmt = be16(data, 8)
    tracks = be16(data, 10)
    division = be16(data, 12)
    standard_header = bool(
        data.startswith(b"MThd") and header_length == 6 and fmt in (0, 1, 2)
        and division is not None and division != 0 and first_track == 14
    )
    korg_extended = bool(
        data.startswith(b"MThd") and header_length == 6
        and (fmt == 0x400C or first_track not in (None, 14))
    )
    result = {
        **item,
        "actual_size": len(data),
        "sha256": sha256(data),
        "header_length": header_length,
        "format_raw": fmt,
        "declared_tracks_raw": tracks,
        "division_raw": division,
        "first_mtrk_offset": first_track,
        "header_extension_hex": extension,
        "standard_smf_header": standard_header,
        "korg_extended_header": korg_extended,
        "sample_strings": strings(data),
    }
    result.update(walk_mtrk_chunks(data, first_track))
    result["confidence"] = (
        "standard-midi" if standard_header else
        "korg-extended-midi" if korg_extended else
        "signature-only"
    )
    return result


def inspect_style(path: Path, item: dict[str, Any]) -> dict[str, Any]:
    data = path.read_bytes()
    sig = data[:8]
    samples = strings(data, 40)
    style_words = [s for s in samples if any(c.isalpha() for c in s)]
    return {
        **item,
        "actual_size": len(data),
        "sha256": sha256(data),
        "signature_hex": sig.hex(" ").upper(),
        "signature_ascii": "".join(chr(b) if 32 <= b <= 126 else "." for b in sig),
        "sample_strings": samples,
        "has_human_readable_payload": bool(style_words),
        "confidence": "structured-candidate" if len(data) >= 64 and style_words else "signature-only",
    }


def attach_oc20_envelopes(
    midi: list[dict[str, Any]], manifest_objects: list[dict[str, Any]], objects: Path
) -> None:
    """Attach a directly preceding 9-byte OC20 resource envelope to MIDI rows."""
    by_index = {int(x["index"]): x for x in manifest_objects if "index" in x}
    group = 0
    previous_midi_index: int | None = None
    for row in midi:
        index = int(row["index"])
        if previous_midi_index is None or index - previous_midi_index > 3:
            group += 1
        previous_midi_index = index
        row["corpus_group"] = group
        prev = by_index.get(index - 1)
        if not prev or prev.get("tag") != "OC20" or int(prev.get("size", 0)) != 9:
            row["oc20_envelope"] = False
            continue
        path = find_object_file(objects, str(prev.get("file", "")))
        if path is None:
            row["oc20_envelope"] = False
            continue
        data = path.read_bytes()
        if len(data) != 9 or data[:4] != b"OC20":
            row["oc20_envelope"] = False
            continue
        unpacked = struct.unpack_from("<I", data, 4)[0]
        packed = int(row["actual_size"])
        row.update({
            "oc20_envelope": True,
            "oc20_object_index": int(prev["index"]),
            "oc20_unpacked_size": unpacked,
            "oc20_payload_prefix": data[8],
            "packed_payload_size": packed + 1,
            "packing_ratio": round((packed + 1) / unpacked, 6) if unpacked else None,
        })


def find_object_file(objects: Path, filename: str) -> Path | None:
    direct = objects / filename
    if direct.is_file():
        return direct
    # Older extractor versions emitted a shorter duplicate name.
    prefix = filename.split("_", 3)[:3]
    matches = sorted(objects.glob("_".join(prefix) + "*"))
    return matches[0] if matches else None


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            cooked = dict(row)
            cooked["sample_strings"] = " | ".join(row.get("sample_strings", []))
            writer.writerow(cooked)


def inspect_factory_banks(style_root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(style_root.glob("*.STY"), key=lambda p: p.name.upper()):
        data = path.read_bytes()
        offsets = [m.start() for m in re.finditer(re.escape(b"OC20"), data)]
        declared: list[int] = []
        for offset in offsets:
            if offset + 8 <= len(data):
                declared.append(struct.unpack_from("<I", data, offset + 4)[0])
        rows.append({
            "file": path.name,
            "path": str(path.resolve()),
            "size": len(data),
            "sha256": sha256(data),
            "oc20_pages": len(offsets),
            "oc31_markers": data.count(b"OC31"),
            "oc32_markers": data.count(b"OC32"),
            "korf_markers": data.count(b"KORF"),
            "kbeg_markers": data.count(b"KBEG"),
            "kend_markers": data.count(b"KEND"),
            "declared_logical_bytes": sum(declared),
            "first_oc20_offset": offsets[0] if offsets else None,
            "sample_strings": strings(data, 20),
        })
    return rows


def discover_factory_style_root(root: Path) -> Path | None:
    candidates = [
        root / "STARTUP" / "ALL" / "STYLE",
        root.parent / "PA800_OC20_OC31_CODEX_HANDOFF_2026-09-13" /
        "Pa800_os_res_v202_extracted" / "STARTUP" / "ALL" / "STYLE",
    ]
    return next((path for path in candidates if path.is_dir()), None)


def build_report(root: Path, output: Path, factory_style_root: Path | None = None) -> dict[str, Any]:
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    objects = root / "objects"
    midi: list[dict[str, Any]] = []
    styles: list[dict[str, Any]] = []
    missing: list[str] = []
    for source in manifest.get("objects", []):
        if source.get("tag") not in {"MThd", "STY"}:
            continue
        item = {k: source.get(k) for k in ("index", "offset", "end", "size", "tag", "file")}
        path = find_object_file(objects, str(source.get("file", "")))
        if path is None:
            missing.append(str(source.get("file")))
            continue
        item["path"] = str(path.resolve())
        (midi if source["tag"] == "MThd" else styles).append(
            inspect_midi(path, item) if source["tag"] == "MThd" else inspect_style(path, item)
        )

    attach_oc20_envelopes(midi, manifest.get("objects", []), objects)
    envelope_rows = [x for x in midi if x.get("oc20_envelope")]
    ratios = [float(x["packing_ratio"]) for x in envelope_rows if x.get("packing_ratio") is not None]
    factory_style_root = factory_style_root or discover_factory_style_root(root)
    factory_banks = inspect_factory_banks(factory_style_root) if factory_style_root else []

    summary = {
        "source": manifest.get("source"),
        "source_sha256": manifest.get("sha256"),
        "midi_candidates": len(midi),
        "style_candidates": len(styles),
        "midi_confidence": dict(Counter(x["confidence"] for x in midi)),
        "style_confidence": dict(Counter(x["confidence"] for x in styles)),
        "korg_format_values": dict(Counter(str(x["format_raw"]) for x in midi)),
        "korg_track_count_values": dict(Counter(str(x["declared_tracks_raw"]) for x in midi)),
        "oc20_wrapped_midi": len(envelope_rows),
        "oc20_payload_prefix_values": dict(Counter(str(x["oc20_payload_prefix"]) for x in envelope_rows)),
        "corpus_groups": max((int(x["corpus_group"]) for x in midi), default=0),
        "packing_ratio_min": min(ratios) if ratios else None,
        "packing_ratio_max": max(ratios) if ratios else None,
        "packing_ratio_average": round(sum(ratios) / len(ratios), 6) if ratios else None,
        "factory_style_root": str(factory_style_root.resolve()) if factory_style_root else None,
        "factory_style_files": len(factory_banks),
        "factory_style_oc20_pages": sum(int(x["oc20_pages"]) for x in factory_banks),
        "factory_style_korf_markers": sum(int(x["korf_markers"]) for x in factory_banks),
        "missing_object_files": missing,
        "important_limit": (
            "Objects were originally split at magic signatures. A candidate is not yet proof "
            "of a complete standalone factory Style or MIDI object."
        ),
    }
    output.mkdir(parents=True, exist_ok=True)
    payload = {"summary": summary, "midi": midi, "styles": styles, "factory_banks": factory_banks}
    (output / "factory_corpus.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    write_csv(output / "midi_candidates.csv", midi, [
        "index", "offset", "size", "actual_size", "format_raw", "declared_tracks_raw",
        "division_raw", "first_mtrk_offset", "header_extension_hex", "declared_track_chunks",
        "complete_track_chunks", "declared_midi_end", "confidence", "chunk_walk_error",
        "corpus_group", "oc20_envelope", "oc20_object_index", "oc20_unpacked_size",
        "oc20_payload_prefix", "packed_payload_size", "packing_ratio",
        "sha256", "path", "sample_strings",
    ])
    write_csv(output / "style_candidates.csv", styles, [
        "index", "offset", "size", "actual_size", "signature_hex", "signature_ascii",
        "has_human_readable_payload", "confidence", "sha256", "path", "sample_strings",
    ])
    write_csv(output / "factory_style_banks.csv", factory_banks, [
        "file", "size", "oc20_pages", "oc31_markers", "oc32_markers", "korf_markers",
        "kbeg_markers", "kend_markers", "declared_logical_bytes", "first_oc20_offset",
        "sha256", "path", "sample_strings",
    ])
    md = [
        "# Pa800 Factory Corpus — forensic catalogue", "",
        f"Source: `{summary['source']}`", "",
        f"- MIDI candidates: **{len(midi)}** ({summary['midi_confidence']})",
        f"- STY candidates: **{len(styles)}** ({summary['style_confidence']})",
        f"- Raw MIDI format values: `{summary['korg_format_values']}`",
        f"- Declared track-count values: `{summary['korg_track_count_values']}`",
        f"- MIDI blocks with a direct 9-byte OC20 envelope: **{summary['oc20_wrapped_midi']} / {len(midi)}**",
        f"- First OC20 payload-byte values: `{summary['oc20_payload_prefix_values']}`",
        f"- Contiguous MIDI corpus groups: **{summary['corpus_groups']}**",
        f"- Packed/unpacked ratio: **{summary['packing_ratio_min']}–{summary['packing_ratio_max']}**, average **{summary['packing_ratio_average']}**",
        f"- Native Factory Style banks: **{summary['factory_style_files']}**",
        f"- OC20 pages inside native Style banks: **{summary['factory_style_oc20_pages']}**",
        f"- KORF markers inside native Style banks: **{summary['factory_style_korf_markers']}**",
        f"- Missing extracted objects: **{len(missing)}**", "",
        "## Interpretation", "",
        summary["important_limit"],
        "`korg-extended-midi` means the block has a coherent MThd header but uses Pa-series "
        "extensions and must not be fed directly to a generic SMF parser.", "",
        "## Next reverse-engineering target", "",
        "Reverse the OC20 token stream using paired packed payload and declared unpacked size, then infer CV "
        "identity, element type, track role, NTT/NTR and sound assignments.", "",
    ]
    (output / "FACTORY_CORPUS_REPORT.md").write_text("\n".join(md), encoding="utf-8")
    return payload


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path, default=None)
    parser.add_argument("--factory-style-root", type=Path, default=None)
    args = parser.parse_args()
    root = args.root.resolve()
    output = (args.output or (root / "factory_style_lab_output")).resolve()
    factory_root = args.factory_style_root.resolve() if args.factory_style_root else None
    payload = build_report(root, output, factory_root)
    print(json.dumps(payload["summary"], indent=2))
    print(f"Reports written to: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
