import tempfile
import unittest
from pathlib import Path

from pa800_style_library import classify_style_bytes, process_style_library


def simple_midi() -> bytes:
    track = bytes.fromhex("00 90 3c 64 60 90 3c 00 00 ff 2f 00")
    return b"MThd\x00\x00\x00\x06\x00\x00\x00\x01\x01\xe0MTrk" + len(track).to_bytes(4, "big") + track


class StyleLibraryTests(unittest.TestCase):
    def test_detector_distinguishes_smf_and_native_sty(self):
        self.assertEqual(classify_style_bytes(simple_midi())["kind"], "STANDARD_MIDI")
        native = b"OC20" + b"\x00" * 12 + b"KORF" + b"OC31" + b"KBEG" + b"KEND"
        report = classify_style_bytes(native, "BANK01.STY")
        self.assertEqual(report["kind"], "NATIVE_KORG_STY")
        self.assertEqual(report["capability"], "AUDIT_AND_BYTE_PRESERVE_ONLY")

    def test_library_optimizes_midi_and_preserves_native_bank(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output = root / "source", root / "output"
            source.mkdir()
            (source / "style.mid").write_bytes(simple_midi())
            native = b"OC20" + b"\x00" * 12 + b"KORF" + b"OC31" + b"KBEG" + b"KEND"
            (source / "BANK01.STY").write_bytes(native)
            report = process_style_library(source, output, velocity_strength=0)
            self.assertEqual(report["status_counts"]["OPTIMIZED"], 1)
            self.assertEqual(report["status_counts"]["BLOCKED_NATIVE_COPIED_UNCHANGED"], 1)
            copied = output / "native_unchanged" / "BANK01.STY"
            self.assertEqual(copied.read_bytes(), native)
            self.assertTrue((output / "optimized_midi" / "style.MID").is_file())
            self.assertIn("cross_delay_note_events", report["optimization_totals"])
            self.assertEqual(sum(report["optimization_totals"]["cross_delay_status_counts"].values()), 1)


if __name__ == "__main__":
    unittest.main()
