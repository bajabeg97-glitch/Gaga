#!/usr/bin/env python3
"""KORG Pa800 STY format parser - read/write support."""
from pathlib import Path
import struct, json
from dataclasses import dataclass, field

@dataclass
class KorgStyleSection:
    """A single section within a KORG style."""
    idx: int
    start: int
    end: int
    size: int
    name: str
    raw_data: bytes = field(repr=False)
    program_changes: list[dict] = field(default_factory=list)
    note_events: list[dict] = field(default_factory=list)

@dataclass
class KorgStyle:
    """KORG Pa800 style file structure."""
    filename: str
    size: int
    style_names: list[str] = field(default_factory=list)
    sections: list[KorgStyleSection] = field(default_factory=list)
    
    @classmethod
    def from_file(cls, filepath: Path) -> "KorgStyle":
        data = filepath.read_bytes()
        style = cls(filename=filepath.name, size=len(data))
        
        # Parse KORF section (style catalog)
        korf_off = data.find(b"KORF")
        if korf_off >= 0:
            korf_len = struct.unpack_from(">I", data, korf_off + 4)[0]
            korf_data = data[korf_off + 8:korf_off + 8 + korf_len]
            
            # Extract style names
            i = 0
            while i < len(korf_data) - 16:
                chunk = korf_data[i:i + 16]
                null_pos = chunk.find(b"\x00")
                if 1 <= null_pos <= 15:
                    name_part = chunk[:null_pos]
                    if all(32 <= b <= 126 for b in name_part) and null_pos >= 2:
                        name = name_part.decode("ascii", errors="replace").strip()
                        if name not in style.style_names:
                            style.style_names.append(name)
                i += 1
        
        # Parse KBEG entries (section index)
        kbeg_off = data.find(b"KBEG")
        if kbeg_off < 0:
            return style
        
        kbeg_len = struct.unpack_from(">I", data, kbeg_off + 4)[0]
        kbeg_data = data[kbeg_off + 8:kbeg_off + 8 + kbeg_len]
        entries = [struct.unpack_from(">I", kbeg_data, i * 4)[0] for i in range(kbeg_len // 4)]
        
        # Find KEND
        kend_off = data.find(b"KEND")
        kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
        kend_end = kend_off + 8 + kend_len
        
        # Parse each section
        for i in range(len(entries)):
            start = entries[i]
            end = entries[i + 1] if i + 1 < len(entries) else kend_end
            section_data = data[start:end]
            
            # Extract section name from OC31 header
            name = ""
            oc31_pos = section_data.find(b"OC31")
            if oc31_pos >= 0:
                name_start = oc31_pos + 24
                if name_start < len(section_data):
                    name_end = section_data.find(b"\x00", name_start)
                    if name_end < 0:
                        name_end = name_start + 32
                    name_bytes = section_data[name_start:name_end]
                    if len(name_bytes) >= 3 and all(32 <= b <= 126 for b in name_bytes):
                        name = name_bytes.decode("ascii", errors="replace").strip()
            
            # Extract MIDI events
            pcs = []
            notes = []
            for j in range(len(section_data) - 1):
                if 0xC0 <= section_data[j] <= 0xCF:
                    ch = section_data[j] & 0x0F
                    pc = section_data[j + 1]
                    pcs.append({"ch": ch, "pc": pc, "pos": j})
                if j < len(section_data) - 2 and 0x90 <= section_data[j] <= 0x9F and section_data[j + 2] > 0:
                    ch = section_data[j] & 0x0F
                    note = section_data[j + 1]
                    vel = section_data[j + 2]
                    notes.append({"ch": ch, "note": note, "vel": vel, "pos": j})
            
            section = KorgStyleSection(
                idx=i,
                start=start,
                end=end,
                size=len(section_data),
                name=name,
                raw_data=section_data,
                program_changes=pcs,
                note_events=notes,
            )
            style.sections.append(section)
        
        return style
    
    def save(self, filepath: Path):
        output = {
            "format": "korg-pa800-style",
            "filename": self.filename,
            "size": self.size,
            "style_names": self.style_names[:50],
            "total_style_names": len(self.style_names),
            "sections": []
        }
        for sec in self.sections:
            output["sections"].append({
                "idx": sec.idx,
                "name": sec.name,
                "size": sec.size,
                "program_changes": len(sec.program_changes),
                "note_events": len(sec.note_events),
            })
        filepath.write_text(json.dumps(output, indent=2), encoding="utf-8")

if __name__ == "__main__":
    sty_dir = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\STYLE")
    
    for sty_file in sorted(sty_dir.glob("*.STY"))[:3]:
        style = KorgStyle.from_file(sty_file)
        print(f"\n{style.filename}:")
        print(f"  Size: {style.size:,} bytes")
        print(f"  Style names: {len(style.style_names)}")
        print(f"  Sections: {len(style.sections)}")
        for sec in style.sections:
            print(f"    [{sec.idx}] {sec.name or '(unnamed)':20s} {sec.size:6d} bytes  PC={len(sec.program_changes):4d}  Notes={len(sec.note_events):4d}")
