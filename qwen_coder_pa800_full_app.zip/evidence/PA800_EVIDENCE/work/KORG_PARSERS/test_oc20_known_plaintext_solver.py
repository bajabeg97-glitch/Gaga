import unittest

from oc20_known_plaintext_solver import (
    EXPECTED,
    EXPECTED_PREAMBLE,
    EXPECTED_STYLE_NAME,
    expand_fragment,
)


class KnownPlaintextSolverTests(unittest.TestCase):
    def test_exact_description(self):
        physical = (
            b"Make your select" + bytes.fromhex("41 8c 09") + b", or wait f" +
            bytes.fromhex("40 23") + b"the" + bytes.fromhex("40 ac 03") +
            b"mo to" + bytes.fromhex("61 80 0c") + b"rt!"
        )
        history = b'version="1.0" standalone="yes" descr=" your '
        expanded, proof = expand_fragment(physical, history)
        self.assertEqual(expanded, EXPECTED)
        self.assertEqual(len(proof), 4)
        self.assertTrue(all(row["exists_in_prior_output"] for row in proof))

    def test_exact_xml_preamble(self):
        physical = b"<DEMO" + bytes.fromhex("40 1c") + b"\n  <MAIN titl" + bytes.fromhex("40 78 00 07") + b'"'
        history = b'<?xml version="1.0" standalone="yes"?>\r\n'
        expanded, proof = expand_fragment(physical, history)
        self.assertEqual(expanded, EXPECTED_PREAMBLE)
        self.assertEqual(len(proof), 2)
        self.assertTrue(all(row["exists_in_prior_output"] for row in proof))

    def test_exact_factory_style_name(self):
        physical = b"Modern Rhythm " + bytes.fromhex("80 74 02") + b" Blu" + bytes.fromhex("56 90")
        history = b"Funk R&amp;B Choose Styles"
        expanded, proof = expand_fragment(physical, history)
        self.assertEqual(expanded, EXPECTED_STYLE_NAME)
        self.assertEqual(len(proof), 2)
        self.assertTrue(all(row["exists_in_prior_output"] for row in proof))


if __name__ == "__main__":
    unittest.main()
