"""Test different short_bias values on representative OC20 files."""
import sys
sys.path.insert(0, r"E:\Pa800_os_res_v202_EXTRACTED")
from oc20_variant_probe import walk
from pathlib import Path

oc20_dir = Path(r"E:\Pa800_os_res_v202_EXTRACTED\factory_style_lab_output\pkg_length_bounded\oc20_records")

test_files = [
    "0001_000D150E.oc20",
    "0029_005D1C31.oc20",
    "0013_00584D9B.oc20",
    "0098_00CDA805.oc20",
]

for bias in (0, 1, 2, 3, 4, 5):
    print(f"=== short_bias={bias} ===")
    for fname in test_files:
        f = oc20_dir / fname
        data = f.read_bytes()
        r = walk(data, short_bias=bias)
        ob = r["output_bytes"]
        db = r["declared_bytes"]
        ok = "accepted" if r["accepted"] else ("partial" if ob > 0 else "fail")
        err = r["error"] or ""
        print(f"  {fname}: {ob}/{db} {ok} {err}")
    print()
