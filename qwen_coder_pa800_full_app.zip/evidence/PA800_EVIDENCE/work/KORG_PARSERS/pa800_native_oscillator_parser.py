#!/usr/bin/env python3
"""Native KORG Pa800 oscillator/multisample catalog builder.

Parses ROM.PCG (program bank) + ROM.KMP (multisample assignments) from the
extracted PKG to build a provable sound-to-oscillator catalog.

Evidence only. No modification of source files.

Structure discovered:
  ROM.PCG KORF section:
    +0x00: 5-byte file header (18 00 00 64 68)
    +0x05: 24-byte records (16-byte name + 8-byte metadata)
    Trailing: KBEG index + KEND tail

  ROM.KMP: 158-byte (0x9E) multisample records:
    +0x00: 24-byte name
    +0x18: 8-byte metadata
    +0x20: 16-byte reserved
    +0x30: 128-byte key-to-sample map
    +0xB0: trailing flags
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
KORG_HDR = 16
KMP_RECORD_SIZE = 0x9E  # 158 bytes
PCG_RECORD_SIZE = 24    # 16-byte name + 8-byte metadata
PCG_NAME_OFFSET = 5     # names start at KORF+5


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read(path: Path) -> bytes:
    return path.read_bytes()


def safe_name(raw: bytes) -> str:
    return raw.decode("ascii", errors="replace").rstrip("\x00").rstrip(" ")


# ── ROM.PCG parser ──────────────────────────────────────────────────────────

def parse_pcg_programs(data: bytes) -> list[dict[str, Any]]:
    """Extract program records from the KORF section of ROM.PCG.

    Each 24-byte record:
      +0x00-0x0F: 16-byte name (null/space-padded)
      +0x10-0x17: 8-byte metadata (type, bank, program number, flags)
    """
    payload = data[KORG_HDR:]
    korf_off = payload.find(b"KORF")
    if korf_off < 0:
        return []
    korf_len = struct.unpack_from(">I", payload, korf_off + 4)[0]
    korf_data = payload[korf_off + 8: korf_off + 8 + korf_len]

    programs: list[dict[str, Any]] = []
    i = PCG_NAME_OFFSET  # skip 5-byte file header
    idx = 0

    while i + PCG_RECORD_SIZE <= len(korf_data) + PCG_NAME_OFFSET:
        name_bytes = korf_data[i:i + 16]
        meta = korf_data[i + 16:i + 24] if i + 24 <= len(korf_data) else b""

        name = safe_name(name_bytes)

        # Parse metadata: type, bank_msb, bank_lsb, program_num, category
        if len(meta) >= 8:
            type_byte = meta[2]   # 0x04 = program
            bank_lsb = meta[3]
            prog_lo = meta[4]
            prog_hi = meta[5]
            category = meta[6]
            flags = meta[7]
            program_number = (prog_hi << 8) | prog_lo
        else:
            type_byte = bank_lsb = prog_lo = prog_hi = 0
            category = flags = 0
            program_number = idx

        if name and not all(b == 0 or b == 0x20 for b in name_bytes[:len(name)]):
            programs.append({
                "index": idx,
                "offset": i,
                "name": name,
                "name_raw": name_bytes.hex(" "),
                "type_byte": type_byte,
                "bank_lsb": bank_lsb,
                "program_number": program_number,
                "category": category,
                "flags": flags,
                "metadata_hex": meta.hex(" ") if meta else "",
            })

        i += PCG_RECORD_SIZE
        idx += 1

    return programs


def parse_pcg_full(data: bytes) -> dict[str, Any]:
    """Full ROM.PCG parser: programs + KBEG index + KEND tail."""
    programs = parse_pcg_programs(data)
    payload = data[KORG_HDR:]

    korf_off = payload.find(b"KORF")
    korf_len = struct.unpack_from(">I", payload, korf_off + 4)[0]
    korf_end = korf_off + 8 + korf_len

    kbeg_off = payload.find(b"KBEG")
    kend_off = payload.find(b"KEND")

    kbeg_data = None
    if kbeg_off >= 0:
        kbeg_len = struct.unpack_from(">I", payload, kbeg_off + 4)[0]
        kbeg_data = payload[kbeg_off + 8: kbeg_off + 8 + kbeg_len]

    # Count non-empty programs
    non_empty = [p for p in programs if p["name"] and len(p["name"]) > 1]

    return {
        "source": "ROM.PCG",
        "total_size": len(data),
        "payload_size": len(payload),
        "korf_offset": korf_off,
        "korf_length": korf_len,
        "korf_end": korf_end,
        "kbeg_offset": kbeg_off,
        "kend_offset": kend_off,
        "kbeg_index_entries": len(kbeg_data) // 4 if kbeg_data else 0,
        "total_records": len(programs),
        "non_empty_records": len(non_empty),
        "programs": programs,
    }


# ── ROM.KMP parser ──────────────────────────────────────────────────────────

def parse_kmp_records(data: bytes) -> list[dict[str, Any]]:
    """Extract multisample records from ROM.KMP.

    Each 158-byte record:
      +0x00-0x17: 24-byte name
      +0x18-0x1F: 8-byte metadata
      +0x20-0x2F: 16-byte reserved
      +0x30-0xAF: 128-byte key-to-sample map
      +0xB0-0x9D: trailing flags
    """
    payload = data[KORG_HDR:]
    records: list[dict[str, Any]] = []

    # Find a known name to calibrate start position
    test_name = b"GrandPiano_L"
    first_hit = payload.find(test_name)
    if first_hit < 0:
        return []

    # Walk backwards to find first valid record
    start = first_hit
    while start >= KMP_RECORD_SIZE:
        prev = start - KMP_RECORD_SIZE
        prev_name = payload[prev:prev + 24]
        if all(b == 0 or b == 0x20 or (32 <= b <= 126) for b in prev_name[:16]):
            test = safe_name(prev_name)
            if test and len(test) > 1:
                start = prev
            else:
                break
        else:
            break

    # Walk forward
    offset = start
    while offset + KMP_RECORD_SIZE <= len(payload):
        rec = payload[offset:offset + KMP_RECORD_SIZE]
        name = safe_name(rec[0:24])

        # Metadata
        meta = rec[0x18:0x20]
        meta_word = struct.unpack_from(">H", rec, 0x18)[0] if len(rec) > 0x1A else 0

        # Find the 0xFF delimiter (7 bytes of 0xFF) to determine key map boundaries
        ff_marker = rec.find(b"\xff" * 7)
        if ff_marker < 0:
            ff_marker = KMP_RECORD_SIZE

        # Key map is between the metadata area and the FF delimiter
        # Metadata ends at +0x20 (32 bytes into record)
        km_start = 0x20
        km_end = ff_marker
        key_map = list(rec[km_start:km_end]) if km_end > km_start else []

        # Trailing flags after FF delimiter
        trail = rec[ff_marker:KMP_RECORD_SIZE] if ff_marker < KMP_RECORD_SIZE else b""

        records.append({
            "index": len(records),
            "offset": offset,
            "name": name,
            "name_hex": rec[0:24].hex(" "),
            "meta_hex": meta.hex(" ") if meta else "",
            "meta_word": meta_word,
            "key_map": key_map,
            "key_map_summary": _summarize_key_map(key_map),
            "trail_hex": trail.hex(" ") if trail else "",
        })

        offset += KMP_RECORD_SIZE

    return records


def _summarize_key_map(key_map: list[int]) -> dict[str, Any]:
    if not key_map:
        return {"valid": False}
    unique = sorted(set(s for s in key_map if s > 0))
    low = next((i for i, s in enumerate(key_map) if s > 0), None)
    high = next((i for i in range(len(key_map) - 1, -1, -1) if key_map[i] > 0), None)
    return {
        "valid": True,
        "unique_sample_count": len(unique),
        "sample_indices": unique[:20],
        "lowest_key": low,
        "highest_key": high,
        "total_mapped_keys": sum(1 for s in key_map if s > 0),
    }


def parse_kmp_full(data: bytes) -> dict[str, Any]:
    payload = data[KORG_HDR:]
    korf_off = payload.find(b"KORF")
    korf_len = struct.unpack_from(">I", payload, korf_off + 4)[0] if korf_off >= 0 else 0
    records = parse_kmp_records(data)

    return {
        "source": "ROM.KMP",
        "total_size": len(data),
        "payload_size": len(payload),
        "korf_offset": korf_off,
        "korf_length": korf_len,
        "record_size": KMP_RECORD_SIZE,
        "multisample_count": len(records),
        "records": records,
    }


# ── Cross-reference builder ─────────────────────────────────────────────────

def build_oscillator_catalog(
    pcg: dict[str, Any],
    kmp: dict[str, Any],
    rx_registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build cross-referenced oscillator catalog from PCG + KMP data."""
    kmp_by_name: dict[str, dict[str, Any]] = {}
    for rec in kmp.get("records", []):
        kmp_by_name[rec["name"]] = rec

    rx_by_name: dict[str, dict[str, Any]] = {}
    if rx_registry:
        for sound in rx_registry.get("sounds", []):
            rx_by_name[sound.get("rx_name", "")] = sound

    programs_with_oscillators: list[dict[str, Any]] = []
    resolved = unresolved = 0

    for prog in pcg.get("programs", []):
        name = prog["name"]
        kmp_match = kmp_by_name.get(name)
        rx_match = rx_by_name.get(name)

        entry = {
            "program_name": name,
            "program_index": prog.get("index"),
            "program_number": prog.get("program_number"),
            "category": prog.get("category"),
            "kmp_match": kmp_match["name"] if kmp_match else None,
            "kmp_offset": kmp_match["offset"] if kmp_match else None,
            "kmp_key_map_summary": kmp_match["key_map_summary"] if kmp_match else None,
            "rx_match": rx_match["rx_name"] if rx_match else None,
            "rx_oscillators": rx_match.get("oscillators") if rx_match else None,
            "confidence": "NATIVE_KMP_CROSS_REFERENCED" if kmp_match and rx_match else (
                "NATIVE_KMP_ONLY" if kmp_match else (
                    "RX_ONLY" if rx_match else "UNRESOLVED"
                )
            ),
        }

        if kmp_match or rx_match:
            resolved += 1
        else:
            unresolved += 1

        programs_with_oscillators.append(entry)

    return {
        "format": "pa800-native-oscillator-catalog-v1",
        "pcg_source": pcg.get("source"),
        "pcg_total_records": pcg.get("total_records"),
        "pcg_non_empty": pcg.get("non_empty_records"),
        "kmp_source": kmp.get("source"),
        "kmp_multisample_count": kmp.get("multisample_count"),
        "total_programs": len(programs_with_oscillators),
        "resolved_programs": resolved,
        "unresolved_programs": unresolved,
        "resolution_rate": round(resolved / max(1, len(programs_with_oscillators)) * 100, 1),
        "programs": programs_with_oscillators,
    }


# ── CLI ──────────────────────────────────────────────────────────────────────

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pkg-root", type=Path,
                        default=ROOT / "extracted_files_oc20_lzss" / "STARTUP" / "ALL")
    parser.add_argument("--rx-registry", type=Path,
                        default=ROOT / "RX_SOUND_CAPABILITIES_v1.json")
    parser.add_argument("--output", type=Path,
                        default=ROOT / "NATIVE_OSCILLATOR_CATALOG_v1.json")
    args = parser.parse_args()

    pcg_path = args.pkg_root / "SOUND" / "ROM.PCG"
    kmp_path = args.pkg_root / "MULTISMP" / "ROM.KMP"

    if not pcg_path.is_file():
        raise SystemExit(f"ROM.PCG not found: {pcg_path}")
    if not kmp_path.is_file():
        raise SystemExit(f"ROM.KMP not found: {kmp_path}")

    print(f"Parsing {pcg_path}...")
    pcg_data = read(pcg_path)
    pcg = parse_pcg_full(pcg_data)
    print(f"  Total records: {pcg['total_records']}")
    print(f"  Non-empty: {pcg['non_empty_records']}")

    print(f"Parsing {kmp_path}...")
    kmp_data = read(kmp_path)
    kmp = parse_kmp_full(kmp_data)
    print(f"  Multisamples: {kmp['multisample_count']}")

    rx_registry = None
    if args.rx_registry.is_file():
        rx_registry = json.loads(args.rx_registry.read_text(encoding="utf-8"))
        print(f"  RX registry: {len(rx_registry.get('sounds', []))} sounds")

    print("Building cross-referenced catalog...")
    catalog = build_oscillator_catalog(pcg, kmp, rx_registry)
    print(f"  Resolved: {catalog['resolved_programs']}/{catalog['total_programs']} ({catalog['resolution_rate']}%)")

    catalog["pcg_sha256"] = sha256(pcg_data)
    catalog["kmp_sha256"] = sha256(kmp_data)
    catalog["kmp_records"] = kmp.get("records", [])

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(catalog, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nCatalog written: {args.output}")

    print("\nSample entries:")
    for entry in catalog["programs"][:15]:
        print(f"  [{entry['confidence']:30s}] {entry['program_name']:25s}"
              f"  KMP={'YES' if entry['kmp_match'] else 'NO':3s}"
              f"  RX={'YES' if entry['rx_match'] else 'NO'}")
    if len(catalog["programs"]) > 15:
        print(f"  ... and {len(catalog['programs']) - 15} more")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
