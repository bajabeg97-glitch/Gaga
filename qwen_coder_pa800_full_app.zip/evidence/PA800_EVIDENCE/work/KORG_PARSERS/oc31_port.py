"""OC20 decompressor ported from KORG-Tools oc31.c reference implementation."""
from collections import Counter
from pathlib import Path
import json
import sys


def oc20_decompress(data: bytes, cap_output: bool = True) -> tuple[bytes, str | None]:
    """Decompress OC20/OC31 data following the exact algorithm from KORG-Tools oc31.c.
    
    Returns (decompressed_data, error_or_none).
    """
    if len(data) < 8 or data[:4] != b"OC20":
        return b"", "not OC20 header"
    
    uncompressed_size = int.from_bytes(data[4:8], "little")
    compressed = data[8:]
    
    out = bytearray()
    inp = 0

    def append_byte(value: int) -> bool:
        if len(out) >= uncompressed_size:
            return False
        out.append(value)
        return True

    def append_backref(offset: int, length: int) -> str | None:
        if offset + 1 > len(out):
            return f"invalid offset {offset} at output {len(out)}"
        backref_pos = len(out) - offset - 1
        for _ in range(length):
            if len(out) >= uncompressed_size and cap_output:
                return None
            if backref_pos < 0 or backref_pos >= len(out):
                return f"invalid backref read {backref_pos} at output {len(out)}"
            out.append(out[backref_pos])
            backref_pos += 1
        return None

    def append_literal(src: bytes) -> int:
        if not cap_output:
            out.extend(src)
            return len(src)
        room = max(0, uncompressed_size - len(out))
        take = min(room, len(src))
        out.extend(src[:take])
        return take
    
    while inp < len(compressed):
        flag_byte = compressed[inp]
        inp += 1
        
        if flag_byte >= 0x10:
            if flag_byte >= 0x40:
                # Type 1: 2-byte backref
                if inp >= len(compressed):
                    return bytes(out), "truncated type1"
                unknown2 = compressed[inp]
                inp += 1
                
                tmp = ((flag_byte << 8) | unknown2)
                length = (tmp >> 13) + 1
                offset = (tmp >> 2) & 0x7FF
                
                error = append_backref(offset, length)
                if error:
                    return bytes(out), error
                
                # Extra trailing bytes
                add_byte = unknown2 & 3
                while add_byte > 0:
                    if inp >= len(compressed):
                        return bytes(out), "truncated trailing"
                    append_byte(compressed[inp])
                    inp += 1
                    add_byte -= 1
                    
            elif flag_byte >= 0x20:
                # Type 2: medium backref
                tmp = flag_byte & 0x1F
                if tmp < 2:
                    if tmp == 0:
                        # 1-byte length + 2-byte offset
                        if inp + 2 >= len(compressed):
                            return bytes(out), "truncated type2a"
                        length = compressed[inp] + 0x22
                        inp += 1
                        unknown3 = compressed[inp]
                        unknown4 = compressed[inp + 1]
                        inp += 2
                        offset = ((unknown3 << 8) | unknown4) >> 2
                        
                        error = append_backref(offset, length)
                        if error:
                            return bytes(out), error.replace("invalid offset", "invalid offset2a")
                        
                        add_byte = unknown4 & 3
                        while add_byte > 0:
                            if inp >= len(compressed):
                                return bytes(out), "truncated trailing"
                            append_byte(compressed[inp])
                            inp += 1
                            add_byte -= 1
                    else:
                        # 2-byte length + 2-byte offset
                        if inp + 3 >= len(compressed):
                            return bytes(out), "truncated type2b"
                        unknown3 = compressed[inp]
                        unknown4 = compressed[inp + 1]
                        inp += 2
                        length = (unknown3 << 8) | unknown4
                        unknown5 = compressed[inp]
                        unknown6 = compressed[inp + 1]
                        inp += 2
                        offset = ((unknown5 << 8) | unknown6) >> 2
                        
                        if length:
                            error = append_backref(offset, length)
                            if error:
                                return bytes(out), error.replace("invalid offset", "invalid offset2b")
                        
                        add_byte = unknown6 & 3
                        while add_byte > 0:
                            if inp >= len(compressed):
                                return bytes(out), "truncated trailing"
                            append_byte(compressed[inp])
                            inp += 1
                            add_byte -= 1
                else:
                    # Fixed-length backref
                    length = tmp + 2
                    if inp + 1 >= len(compressed):
                        return bytes(out), "truncated type2c"
                    unknown2 = compressed[inp]
                    unknown3 = compressed[inp + 1]
                    inp += 2
                    offset = ((unknown2 << 8) | unknown3) >> 2
                    
                    error = append_backref(offset, length)
                    if error:
                        return bytes(out), error.replace("invalid offset", "invalid offset2c")
                    
                    add_byte = unknown3 & 3
                    while add_byte > 0:
                        if inp >= len(compressed):
                            return bytes(out), "truncated trailing"
                        append_byte(compressed[inp])
                        inp += 1
                        add_byte -= 1
            else:
                # Type 3: long-distance backref, offset is based at 0x4000.
                tmp = flag_byte & 7
                if tmp < 2:
                    if tmp == 0:
                        if inp + 2 >= len(compressed):
                            return bytes(out), "truncated type3a"
                        length = compressed[inp] + 0x0A
                        inp += 1
                        unknown3 = compressed[inp]
                        unknown4 = compressed[inp + 1]
                        inp += 2
                        offset = (((unknown3 << 8) | unknown4) >> 2) + 0x4000
                        if flag_byte & 8:
                            offset += 0x4000

                        error = append_backref(offset, length)
                        if error:
                            return bytes(out), error.replace("invalid offset", "invalid offset3a")

                        add_byte = unknown4 & 3
                        while add_byte > 0:
                            if inp >= len(compressed):
                                return bytes(out), "truncated trailing"
                            append_byte(compressed[inp])
                            inp += 1
                            add_byte -= 1
                    else:
                        if inp + 3 >= len(compressed):
                            return bytes(out), "truncated type3b"
                        unknown2 = compressed[inp]
                        unknown3 = compressed[inp + 1]
                        inp += 2
                        length = (unknown2 << 8) | unknown3
                        unknown4 = compressed[inp]
                        unknown5 = compressed[inp + 1]
                        inp += 2
                        offset = (((unknown4 << 8) | unknown5) >> 2) + 0x4000
                        if flag_byte & 8:
                            offset += 0x4000

                        if length:
                            error = append_backref(offset, length)
                            if error:
                                return bytes(out), error.replace("invalid offset", "invalid offset3b")

                        add_byte = unknown5 & 3
                        while add_byte > 0:
                            if inp >= len(compressed):
                                return bytes(out), "truncated trailing"
                            append_byte(compressed[inp])
                            inp += 1
                            add_byte -= 1
                else:
                    length = tmp + 2
                    if inp + 1 >= len(compressed):
                        return bytes(out), "truncated type3c"
                    unknown3 = compressed[inp]
                    unknown4 = compressed[inp + 1]
                    inp += 2
                    offset = (((unknown3 << 8) | unknown4) >> 2) + 0x4000
                    if flag_byte & 8:
                        offset += 0x4000

                    error = append_backref(offset, length)
                    if error:
                        return bytes(out), error.replace("invalid offset", "invalid offset3c")

                    add_byte = unknown4 & 3
                    while add_byte > 0:
                        if inp >= len(compressed):
                            return bytes(out), "truncated trailing"
                        append_byte(compressed[inp])
                        inp += 1
                        add_byte -= 1
        else:
            # flag_byte < 0x10: literal copy
            if flag_byte >= 2:
                length = flag_byte + 2
                if inp + length > len(compressed):
                    return bytes(out), f"truncated literal1 len={length}"
                append_literal(compressed[inp:inp + length])
                inp += length
            elif flag_byte == 0:
                if inp >= len(compressed):
                    return bytes(out), "truncated literal0"
                length = compressed[inp] + 0x12
                inp += 1
                if inp + length > len(compressed):
                    return bytes(out), f"truncated literal0b len={length}"
                append_literal(compressed[inp:inp + length])
                inp += length
            else:
                # flag_byte == 1: 2-byte length
                if inp + 1 >= len(compressed):
                    return bytes(out), "truncated literal1"
                length_pos = inp
                length = (compressed[inp] << 8) | compressed[inp + 1]
                inp += 2
                if length == 0:
                    if len(out) == uncompressed_size:
                        break
                    continue
                if inp + length > len(compressed):
                    # OC20 accepts the same small-literal form as flag bytes 2..15
                    # in streams where OC31 would otherwise claim an impossible
                    # long literal length.
                    inp = length_pos
                    length = flag_byte + 2
                    if inp + length > len(compressed):
                        return bytes(out), f"truncated literal1b len={length}"
                    append_literal(compressed[inp:inp + length])
                    inp += length
                else:
                    append_literal(compressed[inp:inp + length])
                    inp += length
        
        if len(out) >= uncompressed_size:
            break
    
    if len(out) != uncompressed_size:
        return bytes(out), f"size mismatch: got {len(out)}, expected {uncompressed_size}"
    
    return bytes(out), None


if __name__ == "__main__":
    # Test against all OC20 pages
    OC20_DIR = Path(r"E:\Pa800_os_res_v202_EXTRACTED\factory_style_lab_output\pkg_length_bounded\oc20_records")
    oc20_files = sorted(OC20_DIR.glob("*.oc20"))
    print(f"Testing {len(oc20_files)} pages with OC31 algorithm...")

    stats = {"complete": 0, "partial": 0, "failed": 0}
    errors = Counter()
    samples = []
    for idx, path in enumerate(oc20_files):
        data = path.read_bytes()
        out, err = oc20_decompress(data)
        expected = int.from_bytes(data[4:8], "little")
        if err is None and len(out) == expected:
            stats["complete"] += 1
        elif len(out) > 0:
            stats["partial"] += 1
            errors[err.split(":", 1)[0] if err else "partial"] += 1
            if len(samples) < 20:
                samples.append((idx, path.name, len(out), expected, err))
        else:
            stats["failed"] += 1
            errors[err.split(":", 1)[0] if err else "failed"] += 1
            if len(samples) < 20:
                samples.append((idx, path.name, len(out), expected, err))

    print(f"\nResults: {stats}")
    print("\nError patterns:")
    for error, count in errors.most_common(20):
        print(f"  {count:>4} {error}")
    print("\nPartial samples:")
    for row in samples:
        print(f"  page={row[0]:>3} {row[1]} decoded={row[2]}/{row[3]} error={row[4]}")
