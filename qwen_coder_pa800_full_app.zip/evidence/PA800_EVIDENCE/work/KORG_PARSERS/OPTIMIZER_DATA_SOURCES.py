#!/usr/bin/env python3
"""PA800 MIDI Optimizer — Svi izvori podataka (ulazi za optimizer)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "factory_style_lab_output"

SOURCES = {
    # === REGISTRI (ulaz za RX/DNC, velocity zone, oscillator profile) ===
    "rx_registry": {
        "path": ROOT / "PA800_FACTORY_SPECIAL_REGISTRY_v2.json",
        "desc": "44 RX + 23 DNC + 21 RX drum kit — glavni registry za zvukove",
        "size": "32KB",
    },
    "oscillator_registry": {
        "path": ROOT / "RX_OSCILLATOR_REGISTRY_v3.json",
        "desc": "10 hardware-observed RX soundova — velocity_zone [min,max] po oscilatoru",
        "size": "20KB",
    },
    "hardware_osc_profiles": {
        "path": ROOT / "PA800_HARDWARE_VERIFIED_OSC_PROFILES.json",
        "desc": "Detaljni oscillator profili — multisample, switch, key_zone, confidence",
        "size": "35KB",
    },
    "rx_capabilities": {
        "path": ROOT / "RX_SOUND_CAPABILITIES_v1.json",
        "desc": "44 RX sounds — oscillator switch_status, articulation_guess, trigger_mode",
        "size": "170KB",
    },

    # === FABRIČKI REFERENTNI PODACI ===
    "factory_midi_reference": {
        "path": OUT / "styleworks_factory_reference_v1" / "FACTORY_MIDI_REFERENCE.json",
        "desc": "34,848 profila — velocity_histogram + observed_percentiles za 1.43M note-onova",
        "size": "34MB",
    },
    "factory_sound_references": {
        "path": OUT / "styleworks_factory_reference_v1" / "FACTORY_SOUND_REFERENCES.json",
        "desc": "Factory sound reference katalog",
        "size": "2.9MB",
    },

    # === MIDI FAJLOVI (spremni za optimizaciju) ===
    "midi_original": {
        "path": ROOT,
        "desc": "Izvorni MIDI fajlovi koje optimizer čita",
        "files": [
            "A I Ti Me Izneveri_Original_Piano_roll.mid",
            "Kako da ti pomognem - Semsa.mid",
        ],
    },
    "midi_optimized": {
        "path": OUT,
        "desc": "Optimizovani MIDI izlazi (16 fajlova)",
        "files": [
            "A_I_TI_PA800_RX_ENHANCER.MID",
            "A_I_TI_PA800_RX_ENHANCER_V2.MID",
            "A_I_TI_PA800_RX_ENHANCER_DETAIL.MID",
            "A_I_TI_PA800_RX_OSC_DETAIL_V2.MID",
            "A_I_TI_PA800_INSTRUMENT_ENGINE_V1.MID",
            "A_I_TI_PA800_INSTRUMENT_ENGINE_V2.MID",
            "A_I_TI_PA800_CROSS_DELAY_V1.MID",
            "A_I_TI_PA800_CROSS_DELAY_V2.MID",
            "Kako da ti pomognem - Semsa_PA800_OPTIMIZED.MID",
            "Kako da ti pomognem - Semsa_PA800_OPTIMIZED_V2.MID",
            "Kako da ti pomognem - Semsa_PA800_OPTIMIZED_V3.MID",
            "Original_RX_APPLIED_VERIFIED_PA800_OPTIMIZED.MID",
            "Original_RX_APPLIED_VERIFIED_PA800_VELOCITY35.MID",
            "Original_RX_APPLIED_VERIFIED_PA800_RX_DNC.MID",
            "Original_RX_APPLIED_VERIFIED_PA800_ART_ENGINE.MID",
            "Original_RX_APPLIED_VERIFIED_PA800_ART_ENGINE_V2.MID",
        ],
    },
    "midi_demo_songs": {
        "path": OUT / "Desktop_STY_LIBRARY_V1" / "optimized_midi" / "Backup" / "Demosong",
        "desc": "16 PA800 demo songova (.MID) — bankovi sa Style podacima",
        "files": [
            "7898.MID", "BLDPIANO.MID", "DANCING.MID", "Disco.MID",
            "EASY.MID", "FILMSCOR.MID", "FOLKS.MID", "FUSION.MID",
            "JQUARTET.MID", "LATIN.MID", "LIVE.MID", "MUSETTE.MID",
            "NYLONGTR.MID", "ORGANSWG.MID", "PROGRESS.MID", "SNOWTOWN.MID",
        ],
    },

    # === OPTIMIZATION IZVJEŠTAJI (per-note velocity before/after) ===
    "velocity_compression_log": {
        "path": OUT / "Original_RX_APPLIED_VERIFIED_PA800_VELOCITY35.optimization.json",
        "desc": "1,790 VELOCITY_COMPRESS zapisa — before/after velocity za svaki note",
        "size": "322KB",
    },
    "rx_enhancer_log": {
        "path": OUT / "A_I_TI_PA800_RX_ENHANCER.optimization.json",
        "desc": "869 promjena — SELECT_SPECIAL_SOUND + ARTICULATION velocity zone transform",
        "size": "281KB",
    },
    "instrument_engine_v2_log": {
        "path": OUT / "A_I_TI_PA800_INSTRUMENT_ENGINE_V2.optimization.json",
        "desc": "1,123 promjena — decoded_hardware_layer sa velocity_zone + multisample",
        "size": "628KB",
    },
    "cross_delay_v1_log": {
        "path": OUT / "A_I_TI_PA800_CROSS_DELAY_V1.optimization.json",
        "desc": "Najveći log — cross delay echo + articulation + velocity",
        "size": "884KB",
    },

    # === STYLE FAJLOVI ===
    "native_factory_corpus": {
        "path": ROOT / "extracted_files_oc20_lzss",
        "desc": "100% dekodiran Pa800 OS resource corpus — 200 OC20 fajlova + 1 raw, read-only evidence",
        "size": "~135MB decoded",
    },
    "native_factory_manifest": {
        "path": ROOT / "extracted_files_oc20_lzss" / "extraction_manifest.json",
        "desc": "Manifest 100% OC20/LZSS ekstrakcije — complete=200, partial=0, failed=0, raw=1",
        "size": "manifest",
    },
    "native_sty_banks": {
        "path": ROOT / "extracted_files_oc20_lzss" / "STYLES",
        "desc": "Native factory .STY bankovi iz dokazano dekodiranog PKG-a — read-only corpus",
    },
    "favorite01_pilot": {
        "path": OUT / "FAVORITE01_PILOT",
        "desc": "FAVORITE01.STY pilot za name-patching i sound reference",
    },

    # === OC20 KOMPRESOVANI PODACI ===
    "oc20_records": {
        "path": OUT / "pkg_length_bounded" / "oc20_records",
        "desc": "746 OC20 stranica — sve 746/746 se dekodiraju preko OC20/OC31 LZSS hibrida",
    },
    "oc20_regression": {
        "path": OUT / "oc20_resource_regression.json",
        "desc": "Historijski regression prije kompletnog OC20 dekodera; zadržano radi poređenja",
        "size": "173KB",
    },

    # === RAW MIDI EVIDENCE ===
    "mthd_fragments": {
        "path": ROOT / "neighborhoods",
        "desc": "54 MThd.bin fajlova — MIDI header fragamenti iz firmware-a",
    },

    # === STYLE ZAVISNOSTI ===
    "style_sound_dependencies": {
        "path": OUT / "STAMEN_RX_FULL" / "ALL_STYLE_SOUND_DEPENDENCIES.json",
        "desc": "Per-style sound reference zavisnosti — offseti, SHA256, PCG skeniranje",
        "size": "25KB",
    },
}


def list_all():
    print("=" * 70)
    print("PA800 MIDI OPTIMIZER — SVI IZVORI PODATAKA")
    print("=" * 70)
    for key, src in SOURCES.items():
        path = src["path"]
        exists = "OK" if path.exists() else "MISSING"
        print(f"\n[{exists}] {key}")
        print(f"  Putanja: {path}")
        print(f"  Opis: {src['desc']}")
        if "size" in src:
            print(f"  Veličina: {src['size']}")
        if "files" in src:
            print(f"  Fajlovi ({len(src['files'])}):")
            for f in src["files"]:
                fp = path / f
                status = "OK" if fp.exists() else "MISSING"
                print(f"    [{status}] {f}")

    print("\n" + "=" * 70)
    print("KAKO KORISTITI U OPTIMIZERU:")
    print("=" * 70)
    print("""
1. load_special_registry() — čita PA800_FACTORY_SPECIAL_REGISTRY_v2.json
   -> rx_sounds, dnc_sounds, rx_drum_kits za SELECT_SPECIAL_SOUND

2. load_oscillator_registry() — čita RX_OSCILLATOR_REGISTRY_v3.json
   + PA800_HARDWARE_VERIFIED_OSC_PROFILES.json
   -> velocity_zone [min,max] za ARTICULATION_WORKING_ZONE / ARTICULATION_ENHANCE

3. optimize_velocities() — koristi velocity_strength parametar
   -> VELOCITY_COMPRESS sa before/after parovima

4. apply_articulation_engine() — koristi oscillator_registry
   -> ARTICULATION_WORKING_ZONE (spušta velocity u working zoni)
   -> ARTICULATION_ENHANCE (podiše velocity u harmonic zoni)

5. apply_instrument_intelligence() — koristi decoded_hardware_layer
   -> Detaljni oscillator info: multisample, switch, semantic_role

6. add_cross_delay_echo_track() — generiše novi track sa echo note-ovima
   -> CROSS_DELAY_ECHO sa tick offsetima

7. audit_rx_tracks() — koristi rx_coverage_engine
   -> Velocity histogrami, note count po kanalu

8. FACTORY_MIDI_REFERENCE.json (34MB) — referentni velocity podaci
   -> velocity_histogram i observed_percentiles za svaki profile
""")


if __name__ == "__main__":
    list_all()
