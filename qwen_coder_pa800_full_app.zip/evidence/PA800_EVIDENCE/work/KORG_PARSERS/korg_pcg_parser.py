#!/usr/bin/env python3
"""KORG Pa800 PCG format parser - corrected header parsing."""
from pathlib import Path
import struct, json
from dataclasses import dataclass, field

@dataclass
class KorgProgram:
    """A single KORG Pa800 program."""
    offset: int
    size: int
    category: int
    name: str
    raw_data: bytes = field(repr=False)
    
    def get_param(self, offset: int, size: int) -> int:
        if offset + size > len(self.raw_data):
            return 0
        if size == 1:
            return self.raw_data[offset]
        elif size == 2:
            return struct.unpack_from("<H", self.raw_data, offset)[0]
        elif size == 4:
            return struct.unpack_from("<I", self.raw_data, offset)[0]
        return 0

@dataclass
class KorgPCG:
    """KORG Pa800 PCG file structure."""
    programs: list[KorgProgram] = field(default_factory=list)
    program_names: list[str] = field(default_factory=list)
    
    @classmethod
    def from_file(cls, filepath: Path) -> "KorgPCG":
        data = filepath.read_bytes()
        pcg = cls()
        
        # Parse KORF section (program catalog with names)
        korf_off = data.find(b"KORF")
        if korf_off >= 0:
            korf_len = struct.unpack_from(">I", data, korf_off + 4)[0]
            korf_data = data[korf_off + 8:korf_off + 8 + korf_len]
            record_size = 24
            for i in range(korf_len // record_size):
                rec = korf_data[i * record_size:(i + 1) * record_size]
                name = rec[:16].split(b"\x00")[0].decode("ascii", errors="replace").strip()
                pcg.program_names.append(name)
        
        # Find KBEG entries
        kbeg_off = data.find(b"KBEG")
        if kbeg_off < 0:
            return pcg
        
        kbeg_len = struct.unpack_from(">I", data, kbeg_off + 4)[0]
        kbeg_data = data[kbeg_off + 8:kbeg_off + 8 + kbeg_len]
        entries = [struct.unpack_from(">I", kbeg_data, i * 4)[0] for i in range(kbeg_len // 4)]
        
        # Find KEND
        kend_off = data.find(b"KEND")
        kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
        block_end = kend_off + 8 + kend_len
        
        # Use the largest block
        if entries:
            block_start = entries[-1]
            block = data[block_start:block_end]
        else:
            return pcg
        
        # Find all OC32 markers
        oc32_positions = []
        pos = 0
        while True:
            pos = block.find(b"OC32", pos)
            if pos < 0:
                break
            oc32_positions.append(pos)
            pos += 1
        
        # Parse each program with corrected header parsing
        for i in range(len(oc32_positions)):
            prog_start = oc32_positions[i]
            prog_end = oc32_positions[i + 1] if i + 1 < len(oc32_positions) else len(block)
            prog_size = prog_end - prog_start
            prog_data = block[prog_start:prog_end]
            
            # Corrected header format:
            # [pre-header: 0-8 bytes] [OC32: 4 bytes] [size: 2 bytes] [flags: 2 bytes]
            # [category: 1 byte] [05: 1 byte] [name: N bytes] [params: M bytes]
            
            # Find OC32 within the program data
            oc32_pos = prog_data.find(b"OC32")
            if oc32_pos < 0:
                continue
            
            # Parse after OC32
            after_oc32 = prog_data[oc32_pos + 4:]
            if len(after_oc32) < 6:
                continue
            
            # Size at bytes 0-1 (little-endian)
            reported_size = struct.unpack_from("<H", after_oc32, 0)[0]
            
            # Bytes 2-3: flags
            flags = struct.unpack_from("<H", after_oc32, 2)[0]
            
            # Byte 4: category
            category = after_oc32[4]
            
            # Byte 5: type (always 0x05?)
            type_byte = after_oc32[5]
            
            # Name starts at byte 6
            name_start = 6
            name_end = after_oc32.find(b"\x00", name_start)
            if name_end < 0:
                name_end = name_start + 20
            name = after_oc32[name_start:name_end].decode("ascii", errors="replace").strip()
            
            # Parameters start after name
            param_start = name_end + 1
            param_data = after_oc32[param_start:]
            
            program = KorgProgram(
                offset=block_start + prog_start,
                size=prog_size,
                category=category,
                name=name,
                raw_data=param_data,
            )
            pcg.programs.append(program)
        
        return pcg
    
    def save(self, filepath: Path):
        output = {
            "format": "korg-pa800-pcg",
            "program_count": len(self.programs),
            "programs": []
        }
        for prog in self.programs:
            output["programs"].append({
                "name": prog.name,
                "category": prog.category,
                "size": prog.size,
                "offset": prog.offset,
                "param_hex": prog.raw_data[:64].hex() if prog.raw_data else "",
            })
        filepath.write_text(json.dumps(output, indent=2), encoding="utf-8")

if __name__ == "__main__":
    pcg_path = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\SOUND\ROM.PCG")
    pcg = KorgPCG.from_file(pcg_path)
    
    print(f"Loaded {len(pcg.programs)} programs")
    
    # Show programs with names
    named = [(i, p) for i, p in enumerate(pcg.programs) if p.name]
    print(f"Programs with names: {len(named)}")
    print(f"\nFirst 30 named programs:")
    for idx, prog in named[:30]:
        safe_name = prog.name.encode('ascii', errors='replace').decode()
        print(f"  [{idx:4d}] {safe_name:25s} cat={prog.category:3d} size={prog.size:5d}")
    
    # Category distribution
    cats = {}
    for p in pcg.programs:
        cats[p.category] = cats.get(p.category, 0) + 1
    print(f"\nCategory distribution:")
    for cat, count in sorted(cats.items()):
        print(f"  {cat:3d}: {count} programs")
    
    output_path = Path(r"E:\Pa800_SVE_DESIFROVANO\PCG_PARSED.json")
    pcg.save(output_path)
    print(f"\nSaved to: {output_path}")
