#!/usr/bin/env python3
"""KORG Pa800 PAD format parser - read/write support."""
from pathlib import Path
import struct, json
from dataclasses import dataclass, field

@dataclass
class KorgPad:
    """KORG Pa800 PAD file structure."""
    filename: str
    size: int
    raw_data: bytes = field(repr=False)
    names: list[str] = field(default_factory=list)
    
    @classmethod
    def from_file(cls, filepath: Path) -> "KorgPad":
        data = filepath.read_bytes()
        pad = cls(filename=filepath.name, size=len(data), raw_data=data)
        
        # Extract ASCII strings (pad names)
        i = 0
        while i < len(data) - 4:
            if all(32 <= data[i + k] <= 126 for k in range(4)):
                j = i
                while j < len(data) and 32 <= data[j] <= 126:
                    j += 1
                s = data[i:j].decode("ascii", errors="replace").strip()
                if len(s) >= 3 and s not in ["KORF", "KBEG", "KEND"]:
                    pad.names.append(s)
                i = j
            else:
                i += 1
        
        return pad
    
    def save(self, filepath: Path):
        output = {
            "format": "korg-pa800-pad",
            "filename": self.filename,
            "size": self.size,
            "names": self.names,
        }
        filepath.write_text(json.dumps(output, indent=2), encoding="utf-8")

if __name__ == "__main__":
    pad_dir = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\PAD")
    
    for pad_file in sorted(pad_dir.glob("*.PAD"))[:5]:
        pad = KorgPad.from_file(pad_file)
        print(f"\n{pad.filename}:")
        print(f"  Size: {pad.size:,} bytes")
        print(f"  Names: {len(pad.names)}")
        for name in pad.names[:10]:
            safe_name = name.encode('ascii', errors='replace').decode()
            print(f"    - {safe_name}")
