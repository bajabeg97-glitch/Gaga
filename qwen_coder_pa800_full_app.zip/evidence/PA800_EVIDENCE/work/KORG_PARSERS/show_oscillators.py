#!/usr/bin/env python3
"""Display native Pa800 multisample catalog in human-readable format."""
import json
from pathlib import Path

CATALOG = Path(r"E:\Pa800_os_res_v202_EXTRACTED\NATIVE_OSCILLATOR_CATALOG_v1.json")
data = json.loads(CATALOG.read_text(encoding="utf-8"))

records = data.get("kmp_records", [])
programs = data.get("programs", [])

print(f"=== Pa800 NATIVE OSCILLATOR CATALOG ===")
print(f"ROM.PCG: {data['pcg_total_records']} programa ({data['pcg_non_empty']} non-empty)")
print(f"ROM.KMP: {len(records)} multisample zapisa")
print(f"RX Registry: {data['resolved_programs']} resolved")
print()

# Group multisamples by category (inferred from name)
categories = {}
for rec in records:
    name = rec["name"]
    # Infer category from name patterns
    if any(k in name.lower() for k in ["piano", "epiano", "e.piano", "wurly", "rhodes", "clav"]):
        cat = "KEYBOARDS"
    elif any(k in name.lower() for k in ["guitar", "strat", "tele", "les paul", "acoustic", "nylon", "steel", "clean"]):
        cat = "GUITARS"
    elif any(k in name.lower() for k in ["bass", "e.bass", "pick", "slap", "finger"]):
        cat = "BASSES"
    elif any(k in name.lower() for k in ["strings", "violin", "viola", "cello", "ensemble"]):
        cat = "STRINGS"
    elif any(k in name.lower() for k in ["brass", "trumpet", "trombone", "horn", "tuba"]):
        cat = "BRASS"
    elif any(k in name.lower() for k in ["sax", "flute", "clarinet", "oboe", "woodwind", "recorder"]):
        cat = "WOODWINDS"
    elif any(k in name.lower() for k in ["organ", "drawbar", "pipe"]):
        cat = "ORGANS"
    elif any(k in name.lower() for k in ["synth", "lead", "pad", "saw", "square", "fm"]):
        cat = "SYNTHS"
    elif any(k in name.lower() for k in ["drum", "kit", "perc", "kick", "snare", "hihat"]):
        cat = "DRUMS"
    elif any(k in name.lower() for k in ["fx", "effect", "noise", "glide", "gliss", "mute", "dead", "slide", "scratch"]):
        cat = "FX/ARTICULATION"
    elif any(k in name.lower() for k in ["accordion", "harmonica", "melodica", "banjo", "mandolin", "ukulele"]):
        cat = "ETHNIC/FOLK"
    elif any(k in name.lower() for k in ["choir", "voice", "aah", "ooh", "hum"]):
        cat = "VOICES"
    else:
        cat = "OTHER"
    categories.setdefault(cat, []).append(rec)

# Print each category
for cat in sorted(categories.keys()):
    recs = categories[cat]
    print(f"--- {cat} ({len(recs)} multisample-a) ---")
    for rec in recs[:15]:
        name = rec["name"]
        summary = rec.get("key_map_summary", {})
        km_len = len(rec.get("key_map", []))
        low = summary.get("lowest_key")
        high = summary.get("highest_key")
        n_unique = summary.get("unique_sample_count", 0)
        n_mapped = summary.get("total_mapped_keys", 0)
        key_range = f"MIDI {low}-{high}" if low is not None and high is not None else "N/A"
        print(f"  {name:30s}  keys={km_len:3d}  mapped={n_mapped:3d}  samples={n_unique:3d}  range={key_range}")
    if len(recs) > 15:
        print(f"  ... i {len(recs)-15} vise")
    print()

# Show sample key map for a known instrument
print("=== PRIMER: GrandPiano_L key map ===")
gp = next((r for r in records if r["name"] == "GrandPiano_L"), None)
if gp:
    km = gp["key_map"]
    print(f"Key map ({len(km)} bajtova):")
    print("  Key:  ", " ".join(f"{i:2d}" for i in range(min(32, len(km)))))
    print("  Sample:", " ".join(f"{v:2d}" for v in km[:32]))
    if len(km) > 32:
        print("  Key:  ", " ".join(f"{i:2d}" for i in range(32, min(64, len(km)))))
        print("  Sample:", " ".join(f"{v:2d}" for v in km[32:64]))
    if len(km) > 64:
        print("  Key:  ", " ".join(f"{i:2d}" for i in range(64, min(96, len(km)))))
        print("  Sample:", " ".join(f"{v:2d}" for v in km[64:96]))
    print(f"  ... ostatak: {km[96:]}")
    print()
    print(f"  Interpretacija:")
    print(f"  - Kljucevi 0-15: nema sample-ova (silence)")
    print(f"  - Kljuc 16: sample #1, kljuc 17: sample #2, ..., kljuc 90: sample #75")
    print(f"  - Kljucevi 91-125: svi koriste sample #87 (poslednji sample)")
    print(f"  - Ukupno {summary['unique_sample_count']} razlicitih sample-ova za ovaj multisample")

# Show Clean Guitar key map
print()
print("=== PRIMER: Clean Guitar Str p key map ===")
cg = next((r for r in records if "Clean Guitar Str" in r["name"] and "f" not in r["name"]), None)
if cg:
    km = cg["key_map"]
    summary = cg["key_map_summary"]
    print(f"Key map ({len(km)} bajtova):")
    # Show non-zero portion
    nonzero_start = next((i for i, v in enumerate(km) if v > 0), 0)
    print(f"  Prvi non-zero na kljucu {nonzero_start}")
    print(f"  Key:  ", " ".join(f"{i:2d}" for i in range(nonzero_start, min(nonzero_start+32, len(km)))))
    print(f"  Sample:", " ".join(f"{v:2d}" for v in km[nonzero_start:nonzero_start+32]))
    print()
    print(f"  Interpretacija:")
    print(f"  - Kljucevi 0-{nonzero_start-1}: nema sample-ova")
    print(f"  - Svaki sample pokriva vise kljuceva (zone)")
    print(f"  - Ukupno {summary['unique_sample_count']} razlicitih sample-ova")
    print(f"  - {summary['total_mapped_keys']} kljuceva ima dodeljen sample")

# Print program list (first 30)
print()
print(f"=== PRVIH 30 PROGRAMA IZ ROM.PCG ===")
for prog in programs[:30]:
    print(f"  [{prog.get('index', prog.get('global_index', '?')):>5}] #{prog['program_number']:3d} cat={prog['category']:2d} {prog['name']}")
if len(programs) > 30:
    print(f"  ... i {len(programs)-30} vise")
