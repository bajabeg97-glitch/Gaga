import unittest

from oc20_oracle_lab import literal_405c_candidates, oc20_header


class Oc20OracleLabTests(unittest.TestCase):
    def test_header(self):
        result = oc20_header(b"OC20" + (5518).to_bytes(4, "little") + b"\x06payload")
        self.assertEqual(result["declared_logical_size"], 5518)
        self.assertEqual(result["first_payload_byte"], 6)

    def test_confirmed_405c_boundary(self):
        rows = literal_405c_candidates(bytes.fromhex("40 5c 04 03 00 4b 6f 6f 6c"))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["expected_physical_payload"], 6)
        self.assertTrue(rows[0]["complete"])


if __name__ == "__main__":
    unittest.main()
