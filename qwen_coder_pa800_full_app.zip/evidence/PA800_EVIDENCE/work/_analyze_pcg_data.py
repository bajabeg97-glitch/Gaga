#!/usr/bin/env python3
"""Analyze program data at KBEG offsets in ROM.PCG."""
from pathlib import Path
import struct

PCG = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\SOUND\ROM.PCG")
data = PCG.read_bytes()

# KBEG entries
kbeg_off = data.find(b"KBEG")
kbeg_len = struct.unpack_from(">I", data, kbeg_off + 4)[0]
kbeg_data = data[kbeg_off+8:kbeg_off+8+kbeg_len]
entries = [struct.unpack_from(">I", kbeg_data, i*4)[0] for i in range(kbeg_len // 4)]

print("KBEG ENTRIES AND DATA AT OFFSETS:")
print("=" * 60)

for i, entry in enumerate(entries):
    print(f"\n--- Entry [{i}] -> +{entry:08x} ---")
    
    # Show data at this offset
    chunk = data[entry:entry+128]
    print(f"  First 128 bytes:")
    for j in range(0, min(128, len(chunk)), 16):
        row = chunk[j:j+16]
        hex_part = " ".join(f"{b:02x}" for b in row)
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in row)
        print(f"    +{entry+j:08x}: {hex_part}  {ascii_part}")
    
    # Try to find strings
    strings = []
    k = 0
    while k < len(chunk) - 4:
        if all(32 <= chunk[k+l] <= 126 for l in range(4)):
            j = k
            while j < len(chunk) and 32 <= chunk[j] <= 126:
                j += 1
            s = chunk[k:j].decode("ascii", errors="replace")
            if len(s) >= 3:
                strings.append((entry + k, s))
            k = j
        else:
            k += 1
    if strings:
        print(f"  Strings: {strings[:5]}")

# Now let's look at the actual program data structure
# The gap between KORF and KBEG should contain program parameters
korf_off = data.find(b"KORF")
korf_len = struct.unpack_from(">I", data, korf_off + 4)[0]
korf_end = korf_off + 8 + korf_len
kbeg_start = entries[0]  # First KBEG entry

print(f"\n\nGAP ANALYSIS:")
print(f"KORF ends at: +{korf_end:08x}")
print(f"First KBEG entry: +{kbeg_start:08x}")
print(f"Gap size: {kbeg_start - korf_end:,} bytes")

# Analyze the gap data
gap = data[korf_end:kbeg_start]
print(f"\nGap data (first 256 bytes):")
for i in range(0, min(256, len(gap)), 16):
    chunk = gap[i:i+16]
    hex_part = " ".join(f"{b:02x}" for b in chunk)
    ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
    print(f"  +{korf_end+i:08x}: {hex_part}  {ascii_part}")

# Look for program-sized blocks
print(f"\nLOOKING FOR PROGRAM BLOCKS:")
# Try different record sizes
for rec_size in [32, 64, 96, 128, 160, 192, 224, 256]:
    num_records = len(gap) // rec_size
    if num_records > 100:
        # Check if records have consistent structure
        first_records = [gap[i*rec_size:(i+1)*rec_size] for i in range(min(5, num_records))]
        # Check if first bytes are similar
        first_bytes = [r[0] for r in first_records]
        if len(set(first_bytes)) <= 2:
            print(f"  {rec_size}-byte records: {num_records} records, first bytes: {first_bytes}")

# Look for the actual program parameter structure
# Each program should have oscillators, filters, effects, etc.
print(f"\nPROGRAM PARAMETER STRUCTURE:")
# Let's look at the data more carefully
# The first few programs should be at the beginning of the gap

# Find the first program by looking for "Piano" or similar
piano_pos = gap.find(b"Piano")
if piano_pos >= 0:
    print(f"  Found 'Piano' at gap offset +{piano_pos:08x}")
    # Show context around it
    start = max(0, piano_pos - 32)
    chunk = gap[start:piano_pos+128]
    print(f"  Context:")
    for i in range(0, min(256, len(chunk)), 16):
        row = chunk[i:i+16]
        hex_part = " ".join(f"{b:02x}" for b in row)
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in row)
        print(f"    +{start+i:08x}: {hex_part}  {ascii_part}")
