#!/usr/bin/env python3
"""Complete PCG reverse engineering - map the full structure."""
from pathlib import Path
import struct

PCG = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\SOUND\ROM.PCG")
data = PCG.read_bytes()

print("=" * 70)
print("COMPLETE PCG STRUCTURE MAP")
print("=" * 70)

# 1. File header analysis
print("\n1. FILE HEADER:")
header = data[:23]
print(f"   Magic: {header[:4].hex()}")
print(f"   Version: {header[4]:02x}.{header[5]:02x}")
print(f"   File size: {struct.unpack_from('>I', header, 6)[0]:,}")
print(f"   Header rest: {header[10:].hex()}")

# 2. KORF section - program catalog
korf_off = data.find(b"KORF")
korf_len = struct.unpack_from(">I", data, korf_off + 4)[0]
korf_data = data[korf_off+8:korf_off+8+korf_len]

print(f"\n2. KORF SECTION (Program Catalog):")
print(f"   Offset: +{korf_off:08x}")
print(f"   Length: {korf_len:,} bytes")
print(f"   Records: {korf_len // 24}")

# Parse ALL program names
programs = []
record_size = 24
for i in range(korf_len // record_size):
    rec = korf_data[i*record_size:(i+1)*record_size]
    name = rec[:16].split(b"\x00")[0].decode("ascii", errors="replace").strip()
    meta = rec[16:24]
    programs.append({"idx": i, "name": name, "meta": meta})

# Show first 20 programs
print(f"\n   First 20 programs:")
for p in programs[:20]:
    print(f"   [{p['idx']:5d}] {p['name']:20s} meta={p['meta'].hex()}")

# Count non-empty names
named = [p for p in programs if p["name"]]
print(f"\n   Total programs: {len(programs)}")
print(f"   Named programs: {len(named)}")

# 3. Analyze KBEG entries - these are the actual program data blocks
kbeg_off = data.find(b"KBEG")
kbeg_len = struct.unpack_from(">I", data, kbeg_off + 4)[0]
kbeg_data = data[kbeg_off+8:kbeg_off+8+kbeg_len]
entries = [struct.unpack_from(">I", kbeg_data, i*4)[0] for i in range(kbeg_len // 4)]

print(f"\n3. KBEG SECTION (Program Data Index):")
print(f"   Offset: +{kbeg_off:08x}")
print(f"   Length: {kbeg_len:,} bytes")
print(f"   Entries: {len(entries)}")

# 4. Analyze each program data block
print(f"\n4. PROGRAM DATA BLOCKS:")
for i, entry in enumerate(entries):
    # Find the next entry or KEND
    if i + 1 < len(entries):
        next_entry = entries[i + 1]
    else:
        kend_off = data.find(b"KEND")
        kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
        next_entry = kend_off + 8 + kend_len
    
    block_size = next_entry - entry
    block = data[entry:next_entry]
    
    # Find program name in block
    name_start = block.find(b"OC32") + 4
    if name_start < 4:
        name_start = 0
    name_end = block.find(b"\x00", name_start)
    if name_end < 0:
        name_end = name_start + 20
    name = block[name_start:name_end].decode("ascii", errors="replace").strip()
    
    print(f"\n   Block [{i}]: +{entry:08x} ({block_size:,} bytes)")
    print(f"     Name: {name.encode('ascii', errors='replace').decode()}")
    print(f"     Header: {block[:16].hex()}")
    
    # Analyze internal structure
    # Look for sub-sections
    for marker in [b"OC32", b"OC32R"]:
        pos = 0
        while True:
            pos = block.find(marker, pos)
            if pos < 0:
                break
            print(f"     {marker.decode()}: +{pos:04x}")
            pos += 1
    
    # Show first 64 bytes of parameters (after name)
    param_start = name_end + 1
    if param_start < len(block):
        params = block[param_start:param_start+64]
        print(f"     Parameters (first 64 bytes):")
        for j in range(0, min(64, len(params)), 16):
            chunk = params[j:j+16]
            hex_part = " ".join(f"{b:02x}" for b in chunk)
            print(f"       +{param_start+j:04x}: {hex_part}")

# 5. File structure summary
print(f"\n5. FILE STRUCTURE SUMMARY:")
print(f"   +00000000 - +{korf_off:08x}: File header ({korf_off} bytes)")
print(f"   +{korf_off:08x} - +{korf_off+8+korf_len:08x}: KORF (program catalog, {korf_len:,} bytes)")
print(f"   +{entries[0]:08x} - +{entries[-1]:08x}: Program data blocks")
print(f"   +{kbeg_off:08x} - +{kbeg_off+8+kbeg_len:08x}: KBEG (index, {kbeg_len} bytes)")
kend_off = data.find(b"KEND")
kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
print(f"   +{kend_off:08x} - +{kend_off+8+kend_len:08x}: KEND (end marker, {kend_len} bytes)")

# 6. Calculate total program data
total_program_data = sum(entries[i+1] - entries[i] if i+1 < len(entries) else kend_off - entries[i] for i in range(len(entries)))
print(f"\n   Total program data: {total_program_data:,} bytes")
print(f"   Average per program: {total_program_data // len(entries):,} bytes")
