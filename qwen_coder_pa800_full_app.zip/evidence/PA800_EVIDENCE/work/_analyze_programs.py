#!/usr/bin/env python3
"""Analyze individual program structure within Block [6]."""
from pathlib import Path
import struct

PCG = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\SOUND\ROM.PCG")
data = PCG.read_bytes()

# Block [6] starts at KBEG[6] = 0x6d00
block_start = 0x6d00
kend_off = data.find(b"KEND")
kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
block_end = kend_off + 8 + kend_len
block = data[block_start:block_end]

print(f"Block [6]: {len(block):,} bytes")
print("=" * 70)

# Find all OC32 markers
oc32_positions = []
pos = 0
while True:
    pos = block.find(b"OC32", pos)
    if pos < 0:
        break
    oc32_positions.append(pos)
    pos += 1

print(f"OC32 markers: {len(oc32_positions)}")

# Analyze first 10 programs
print(f"\nFirst 10 programs:")
for i in range(min(10, len(oc32_positions))):
    prog_start = oc32_positions[i]
    prog_end = oc32_positions[i + 1] if i + 1 < len(oc32_positions) else len(block)
    prog_size = prog_end - prog_start
    
    prog = block[prog_start:prog_end]
    
    # Find program name (after OC32 marker)
    name_start = prog.find(b"OC32") + 4
    # Skip type byte and some header bytes
    name_search_start = min(name_start + 10, len(prog))
    name_end = prog.find(b"\x00", name_search_start)
    if name_end < 0:
        name_end = name_search_start + 20
    name = prog[name_search_start:name_end].decode("ascii", errors="replace").strip()
    
    print(f"\n  Program [{i}]: +{prog_start:06x} ({prog_size:,} bytes)")
    print(f"    Name: {name.encode('ascii', errors='replace').decode()}")
    
    # Show header (first 32 bytes)
    header = prog[:32]
    print(f"    Header: {header.hex()}")
    
    # Analyze internal OC32 markers
    internal_markers = []
    j = 0
    while j < len(prog):
        if prog[j:j+4] == b"OC32":
            internal_markers.append(j)
        j += 1
    
    if len(internal_markers) > 1:
        print(f"    Internal OC32 markers: {len(internal_markers)}")
        for m in internal_markers[:5]:
            print(f"      +{m:04x}")

# Analyze the pattern of program sizes
print(f"\n\nPROGRAM SIZE ANALYSIS:")
sizes = []
for i in range(len(oc32_positions) - 1):
    size = oc32_positions[i + 1] - oc32_positions[i]
    sizes.append(size)

sizes.append(len(block) - oc32_positions[-1])  # Last program

print(f"Total programs: {len(sizes)}")
print(f"Min size: {min(sizes):,} bytes")
print(f"Max size: {max(sizes):,} bytes")
print(f"Average size: {sum(sizes) / len(sizes):,.0f} bytes")
print(f"Median size: {sorted(sizes)[len(sizes) // 2]:,} bytes")

# Show size distribution
size_ranges = {}
for s in sizes:
    if s < 100:
        bucket = "< 100"
    elif s < 200:
        bucket = "100-199"
    elif s < 300:
        bucket = "200-299"
    elif s < 400:
        bucket = "300-399"
    elif s < 500:
        bucket = "400-499"
    elif s < 1000:
        bucket = "500-999"
    else:
        bucket = ">= 1000"
    size_ranges[bucket] = size_ranges.get(bucket, 0) + 1

print(f"\nSize distribution:")
for bucket, count in sorted(size_ranges.items()):
    print(f"  {bucket}: {count} programs")
