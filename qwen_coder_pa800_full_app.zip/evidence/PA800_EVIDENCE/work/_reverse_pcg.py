#!/usr/bin/env python3
"""Deep reverse engineering of ROM.PCG binary structure."""
from pathlib import Path
import struct, json

PCG = Path(r"E:\Pa800_SVE_DESIFROVANO\01_EXTRACTED_FILES\STARTUP\ALL\SOUND\ROM.PCG")
data = PCG.read_bytes()

print("=" * 70)
print("ROM.PCG DEEP STRUCTURE ANALYSIS")
print("=" * 70)
print(f"Total size: {len(data):,} bytes")

# 1. Overall layout
print(f"\n1. FILE HEADER (first 32 bytes):")
for i in range(0, min(32, len(data)), 16):
    chunk = data[i:i+16]
    hex_part = " ".join(f"{b:02x}" for b in chunk)
    ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
    print(f"   +{i:04x}: {hex_part}  {ascii_part}")

# 2. Find all KORG sections
print(f"\n2. KORG SECTIONS:")
sections = []
for marker in [b"KORF", b"KBEG", b"KEND", b"KONF", b"KPRM", b"KDAT", b"KSCE", b"KTRK", b"KSTY"]:
    pos = 0
    while True:
        pos = data.find(marker, pos)
        if pos < 0:
            break
        length = struct.unpack_from(">I", data, pos + 4)[0] if pos + 8 <= len(data) else 0
        sections.append({"tag": marker.decode(), "offset": pos, "length": length})
        pos += 1

for s in sorted(sections, key=lambda x: x["offset"]):
    print(f"   {s['tag']}: +{s['offset']:08x}, length={s['length']:,}")

# 3. Analyze KORF section (program catalog)
korf_off = data.find(b"KORF")
if korf_off >= 0:
    korf_len = struct.unpack_from(">I", data, korf_off + 4)[0]
    korf_data = data[korf_off+8:korf_off+8+korf_len]
    
    print(f"\n3. KORF SECTION (program catalog):")
    print(f"   Offset: +{korf_off:08x}")
    print(f"   Length: {korf_len:,} bytes")
    
    # Parse program records (24 bytes each)
    record_size = 24
    num_records = len(korf_data) // record_size
    print(f"   Records: {num_records} (record size: {record_size} bytes)")
    
    # Show first 10 records
    print(f"\n   First 10 records:")
    for i in range(min(10, num_records)):
        rec = korf_data[i*record_size:(i+1)*record_size]
        name = rec[:16].split(b"\x00")[0].decode("ascii", errors="replace")
        # Parse metadata after name
        meta = rec[16:24]
        print(f"   [{i:4d}] name='{name:16s}' meta={meta.hex()}")
    
    # Analyze metadata bytes
    print(f"\n   Metadata analysis (first 50 records):")
    type_bytes = {}
    bank_bytes = {}
    pc_bytes = {}
    cat_bytes = {}
    for i in range(min(50, num_records)):
        rec = korf_data[i*record_size:(i+1)*record_size]
        meta = rec[16:24]
        type_byte = meta[0]
        bank_lsb = meta[1]
        program_num = meta[2]
        category = meta[3]
        
        type_bytes[type_byte] = type_bytes.get(type_byte, 0) + 1
        bank_bytes[bank_lsb] = bank_bytes.get(bank_lsb, 0) + 1
        pc_bytes[program_num] = pc_bytes.get(program_num, 0) + 1
        cat_bytes[category] = cat_bytes.get(category, 0) + 1
    
    print(f"   Type bytes: {sorted(type_bytes.items())}")
    print(f"   Bank LSB values: {sorted(bank_bytes.items())[:10]}...")
    print(f"   Program numbers: {sorted(pc_bytes.items())[:10]}...")
    print(f"   Category bytes: {sorted(cat_bytes.items())}")

# 4. Analyze KBEG section (index)
kbeg_off = data.find(b"KBEG")
if kbeg_off >= 0:
    kbeg_len = struct.unpack_from(">I", data, kbeg_off + 4)[0]
    kbeg_data = data[kbeg_off+8:kbeg_off+8+kbeg_len]
    num_entries = kbeg_len // 4
    
    print(f"\n4. KBEG SECTION (index):")
    print(f"   Offset: +{kbeg_off:08x}")
    print(f"   Length: {kbeg_len:,} bytes")
    print(f"   Entries: {num_entries}")
    
    # Show entries
    print(f"\n   Entries:")
    for i in range(num_entries):
        val = struct.unpack_from(">I", kbeg_data, i*4)[0]
        print(f"   [{i}] -> +{val:08x}")

# 5. Analyze KEND section
kend_off = data.find(b"KEND")
if kend_off >= 0:
    kend_len = struct.unpack_from(">I", data, kend_off + 4)[0]
    kend_data = data[kend_off+8:kend_off+8+kend_len]
    
    print(f"\n5. KEND SECTION:")
    print(f"   Offset: +{kend_off:08x}")
    print(f"   Length: {kend_len:,} bytes")
    print(f"   First 64 bytes:")
    for i in range(0, min(64, len(kend_data)), 16):
        chunk = kend_data[i:i+16]
        hex_part = " ".join(f"{b:02x}" for b in chunk)
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
        print(f"     +{i:04x}: {hex_part}  {ascii_part}")

# 6. Look for program data patterns
print(f"\n6. PROGRAM DATA PATTERNS:")
# Between KORF and KBEG, there should be program parameters
korf_end = korf_off + 8 + korf_len
kbeg_start = kbeg_off
gap = data[korf_end:kbeg_start]
print(f"   Gap between KORF and KBEG: {len(gap):,} bytes")
print(f"   Expected programs in gap: {len(gap) // 24} records (if 24-byte records)")

# Look for repeating patterns
print(f"\n   Looking for repeating byte patterns...")
for pattern_len in [2, 4, 8]:
    patterns = {}
    for i in range(0, min(1000, len(gap) - pattern_len), pattern_len):
        pat = gap[i:i+pattern_len]
        patterns[pat] = patterns.get(pat, 0) + 1
    most_common = sorted(patterns.items(), key=lambda x: -x[1])[:5]
    print(f"   {pattern_len}-byte patterns: {[(p.hex(), c) for p, c in most_common]}")

# 7. Check for program parameter blocks
print(f"\n7. PROGRAM PARAMETER ANALYSIS:")
# Each program should have a fixed-size parameter block
# Let's try to find the size by looking at KBEG entries
kbeg_entries = []
for i in range(num_entries):
    val = struct.unpack_from(">I", kbeg_data, i*4)[0]
    kbeg_entries.append(val)

# Calculate sizes between entries
sizes = []
for i in range(len(kbeg_entries) - 1):
    size = kbeg_entries[i+1] - kbeg_entries[i]
    sizes.append(size)

print(f"   KBEG entry sizes: {sizes[:10]}")
if sizes:
    avg_size = sum(sizes) / len(sizes)
    print(f"   Average size: {avg_size:.0f} bytes")
    print(f"   Min size: {min(sizes)} bytes")
    print(f"   Max size: {max(sizes)} bytes")
