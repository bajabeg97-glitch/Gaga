@echo off
REM ============================================================
REM  Baja Music - FULL PA800 bundle - instalacija okruzenja
REM  (Python 3.10+, auto PATH, venv + paketi, self-test)
REM ============================================================
setlocal EnableDelayedExpansion
cd /d "%~dp0"
title Baja Music - FULL bundle instalacija

echo.
echo [1/5] Provjera Python instalacije...
where python >nul 2>&1
if errorlevel 1 (
    echo GRESKA: Python nije na PATH-u.
    echo Preuzmi sa https://www.python.org/downloads/ ^(3.10 ili noviji^),
    echo pri instalaciji oznaci "Add Python to PATH".
    pause
    exit /b 1
)
python --version

echo.
echo [2/5] Virtuelno okruzenje (.venv)...
if not exist .venv (
    python -m venv .venv
    echo     Kreirano: .venv
) else (
    echo     Postoji: .venv
)
call .venv\Scripts\activate.bat

echo.
echo [3/5] Instalacija zahtjevnih paketa (numpy, pytest)...
python -m pip install --upgrade pip >nul
python -m pip install numpy pytest
if errorlevel 1 (
    echo GRESKA pri instalaciji paketa (provjeri internet konekciju).
    pause
    exit /b 1
)

echo.
echo [4/5] Self-test oba paketa...
python -c "import pa800_engine; print('  pa800_engine', pa800_engine.__version__, '- OK')"
python -c "import sys; sys.path.insert(0, r'%~dp0pa800_midi_app'); import baja_pa_manager; print('  baja_pa_manager (midi app) - OK')"
if errorlevel 1 (
    echo GRESKA pri importu — pogledaj gore.
    pause
    exit /b 1
)

echo.
echo [5/5] Gotovo. Dalje koristi:
echo     run.bat             - MENI SVIH APLIKACIJA
echo     run_engine.bat      - PA800 Engine - CLI sinteza MAX DEMO pjesme
echo     run_engine_gui.bat  - PA800 Engine - GUI studio
echo     run_tests.bat       - kompletan test suite (100+ testova)
echo     run_midi_app.bat    - MIDI Studio (CLI)
echo     run_midi_gui.bat    - MIDI Studio (GUI)
echo.
pause
